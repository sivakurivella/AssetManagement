# IIS Deployment

Target: Windows Server 2016+ with IIS 10, the **.NET 8 Hosting Bundle**, and SQL Server reachable from the web server.
Complete [INSTALL.md](INSTALL.md) steps 1–3 first.

## 1. Install IIS and the Hosting Bundle

```powershell
# Run as Administrator
Install-WindowsFeature Web-Server, Web-Default-Doc, Web-Static-Content, Web-Http-Errors, Web-Http-Logging, `
    Web-Stat-Compression, Web-Filtering, Web-Mgmt-Console, Web-AppInit
# Then install the ASP.NET Core 8 Hosting Bundle (dotnet-hosting-8.0.x-win.exe) and restart IIS:
iisreset
```

`Web-AppInit` (Application Initialization) lets the site warm up after a restart so background reminders keep running.

## 2. Folders

| Folder | Purpose | Permission for `IIS AppPool\GamAppPool` |
|---|---|---|
| `C:\inetpub\GlobalAssetManagement` | published application files | Read & execute |
| `C:\inetpub\GlobalAssetManagement\logs` | application log files (`gam-YYYYMMDD.log`) | Modify |
| `D:\GAMData\uploads` (`Uploads:RootPath`) | invoices, photos, documents | Modify |
| `D:\GAMBackups\Files` (`Backup:FilesBackupFolder`) | ZIP of uploads made by "Backup now" | Modify |
| `D:\GAMBackups\Database` (`Backup:DatabaseBackupFolder`) | `.bak` files – written by the **SQL Server service account**, on the SQL Server machine | (SQL service account: Modify) |

```powershell
$pool = "IIS AppPool\GamAppPool"
New-Item -ItemType Directory -Force C:\inetpub\GlobalAssetManagement\logs, D:\GAMData\uploads, D:\GAMBackups\Files, D:\GAMBackups\Database
icacls C:\inetpub\GlobalAssetManagement /grant "${pool}:(OI)(CI)RX"
icacls C:\inetpub\GlobalAssetManagement\logs /grant "${pool}:(OI)(CI)M"
icacls D:\GAMData\uploads /grant "${pool}:(OI)(CI)M"
icacls D:\GAMBackups\Files /grant "${pool}:(OI)(CI)M"
```

Do not give the pool identity write access to the application folder itself.

## 3. Application pool

```powershell
Import-Module WebAdministration
New-WebAppPool -Name GamAppPool
Set-ItemProperty IIS:\AppPools\GamAppPool -Name managedRuntimeVersion -Value ""          # "No Managed Code"
Set-ItemProperty IIS:\AppPools\GamAppPool -Name startMode -Value AlwaysRunning            # keep reminders/backups running
Set-ItemProperty IIS:\AppPools\GamAppPool -Name processModel.idleTimeout -Value "00:00:00"
Set-ItemProperty IIS:\AppPools\GamAppPool -Name recycling.periodicRestart.time -Value "00:00:00"
Set-ItemProperty IIS:\AppPools\GamAppPool -Name processModel.loadUserProfile -Value $true # required for ASP.NET Core Data Protection keys
```

Optionally schedule a recycle at a quiet time (e.g. 03:00) instead of the default 29-hour interval.

## 4. Site

1. Copy the contents of `artifacts\publish` (or unzip `GlobalAssetManagement-publish.zip`) into `C:\inetpub\GlobalAssetManagement`.
2. Create `appsettings.Production.json` there (see INSTALL.md §4). `web.config` already sets `ASPNETCORE_ENVIRONMENT=Production`.
3. Create the site:

```powershell
New-Website -Name "GlobalAssetManagement" -PhysicalPath C:\inetpub\GlobalAssetManagement -ApplicationPool GamAppPool -Port 80 -HostHeader assets.yourcompany.in
Set-ItemProperty "IIS:\Sites\GlobalAssetManagement" -Name applicationDefaults.preloadEnabled -Value $true
```

## 5. HTTPS (required)

Sign-in cookies, passwords and camera scanning (browsers allow the camera only on HTTPS) need a certificate.

1. Obtain a certificate for `assets.yourcompany.in` (internal CA, or a public CA such as Let's Encrypt via win-acme).
2. IIS Manager → site → **Bindings** → add `https`, port 443, host name, select the certificate.
3. Keep the HTTP binding only for redirection; the application redirects HTTP → HTTPS (`Security:RequireHttps=true`) and sends HSTS.
4. Set `App:PublicBaseUrl` to the `https://` address so QR labels encode the correct link. **Print labels after this is final.**

## 6. Secrets as environment variables (recommended)

Edit `web.config` on the server (not in the repository):

```xml
<environmentVariables>
  <environmentVariable name="ASPNETCORE_ENVIRONMENT" value="Production" />
  <environmentVariable name="ConnectionStrings__DefaultConnection" value="Server=SQL01;Database=GlobalAssetManagement;Trusted_Connection=True;Encrypt=True;" />
  <environmentVariable name="Email__Password" value="..." />
</environmentVariables>
```

## 7. Data Protection keys

ASP.NET Core encrypts sign-in cookies and anti-forgery tokens with keys stored in the pool user profile
(`%LOCALAPPDATA%\ASP.NET\DataProtection-Keys`) when `loadUserProfile` is true. If you run several web servers behind a load
balancer, configure a shared key ring – a single server needs nothing more.

## 8. Check the deployment

- `https://assets.yourcompany.in` → Setup page (first time) or sign-in page.
- Response headers include `X-Content-Type-Options`, `X-Frame-Options`, `Content-Security-Policy`, `Strict-Transport-Security`.
- If you see **HTTP 500.30 / 500.19**: install/repair the Hosting Bundle, check the connection string, temporarily set
  `stdoutLogEnabled="true"` in `web.config`, recycle the pool and read `logs\stdout_*.log`. Turn it off again afterwards.
- Windows Event Viewer → Application log, source `GlobalAssetManagement`, also receives errors.

## 9. Updating

1. Backup database **and** uploads.
2. `Stop-WebAppPool GamAppPool`
3. Copy the new published files over the old ones, **keeping** `appsettings.Production.json` and your edited `web.config`.
4. `Start-WebAppPool GamAppPool` – pending migrations are applied automatically on start.
   (Alternatively place `app_offline.htm` in the folder during the copy.)
