# User Manual – Global Asset Management

This manual follows the left-hand menu. What you see depends on your role: menu items and buttons you are not allowed to use
are hidden, and the server also refuses those actions.

## Contents
1. Signing in · 2. Roles · 3. Dashboard · 4. Masters · 5. Assets · 6. Labels & scanning · 7. Procurement · 8. Approvals ·
9. Allocation, transfers & returns · 10. Additions · 11. Maintenance & repairs · 12. Warranty & AMC · 13. Physical verification ·
14. Depreciation · 15. Disposal · 16. Reports · 17. Notifications · 18. Users & roles · 19. Audit trail · 20. Settings & backup ·
21. Tips

---

## 1. Signing in

- Open the address given by your administrator and sign in with your **user name or e-mail** and password.
- After 5 wrong passwords the account is locked for 15 minutes.
- **Forgot password** sends a reset link by e-mail (only when the administrator has configured e-mail).
- Your name menu (top right) → **Change password**, **Two-factor authentication** (any authenticator app: scan the QR code,
  enter the 6-digit code, keep the recovery codes) and **Sign out**.
- You are signed out after 60 minutes without activity (configurable).

## 2. Roles

| Role | Typical use |
|---|---|
| Super Administrator | everything, including roles and permissions; cannot be restricted |
| Administrator | everything except changing Super Administrator rights |
| Asset Manager | registers, issues, transfers, maintains, verifies assets; requests disposals |
| Purchase Manager | vendors, purchase requests, quotations, purchase orders, goods receipts, invoices |
| Department Manager | approves requests of the department, issues/transfers within it, raises repair requests |
| Maintenance Technician | work orders: diagnosis, labour, parts, testing, completion; verification scanning |
| Finance or Accounts User | classifies additions, runs depreciation, approves disposals and large orders, financial reports |
| Employee | sees assets issued to them, acknowledges handovers, raises service requests |
| Auditor or Read-Only User | views and exports everything except users and settings; cannot change data |

Administrators can change every role's permissions in **User & Role Management → Roles & Permissions** (View, Create, Edit,
Approve, Delete, Export per module). A user can also be limited to **one branch and/or department** on the user form; such users
only see and act on assets of that branch/department.

## 3. Dashboard

Fourteen tiles – total assets, in service, under repair, under maintenance, disposed, under warranty, warranty expiring soon,
AMC renewal due, pending service requests, overdue repairs, upcoming maintenance (30 days), acquisition cost, accumulated
depreciation and book value – and ten charts (assets by category, department, branch and status, monthly acquisitions,
maintenance expenses, repair costs, warranty expiry forecast for the next 12 months, AMC expenses by provider, depreciation by
financial year). Use the filters (branch, department, category,
period) at the top. **Click a tile or a chart bar** to open the matching list. All figures are calculated from live data.

## 4. Masters (Categories & Locations, Vendors, Service Providers)

Set these up before registering assets:

- **Branches → Departments → Locations** (building, floor, room) – a location belongs to one branch.
- **Employees** – code, name, department, branch, mobile and e-mail (used for notifications).
- **Asset Categories** – 26 categories are pre-loaded in groups A (Computers & IT), B (Furniture & Office Equipment),
  C (Plant, Machinery & Electrical), D (Vehicles & Others). For each category set the **code** (used in the asset code),
  default useful life, depreciation method, rate and residual %. These defaults are copied to new assets and can be changed per asset.
  Ask your accountant for the correct values – the pre-loaded numbers are only placeholders.
- Subcategories, Asset Types, Manufacturers, Brands, Models.
- **Vendors** (GSTIN, PAN, bank details, contact) and **Service Providers** (response time, agreement, contract end date).

Every master list has search, add, edit, deactivate and export. Records already used in transactions cannot be deleted – deactivate them.

## 5. Assets

**Asset Masters → Register Asset.** Mandatory: name, category and branch. The **Asset ID** (`GAM-000123`) is always generated;
the **Asset Code** (`LAP-HO-2026-0001` = category-branch-year-number) is generated unless you type your own. Both are unique, and
the serial number must be unique per manufacturer.

Sections of the form: identification, classification, placement (branch, department, location, custodian), purchase
(vendor, invoice, date, cost, GST, whether GST input credit is claimed, freight, installation), warranty, depreciation
(method, rate, life, residual value, start date) and other details (criticality, insurance, notes).

> **Capitalized cost** = purchase cost + freight/other + installation, plus GST only when input credit is **not** claimed.

**Statuses:** Requested, Ordered, Received, Under Installation, In Service, Under Repair, Under Maintenance, Inactive,
Transferred, Disposed, Lost / Written Off. Most status changes happen automatically through transactions; use **Change status**
on the asset page (with a reason) for manual changes such as Inactive. Disposed/Lost are set only through the Disposal module.

The **asset page** shows a summary, photos, documents (invoice, warranty card, manuals – PDF, Office, images; 10 MB each),
the QR code and barcode, and the **Timeline** of every event (registration, issue, transfer, repair, depreciation, verification ...).
After depreciation has been posted, cost fields are locked; corrections are made through additions or by reversing the run.

**All Assets** – filter by text, category, branch, department, location, status, condition, warranty status; export the list to
Excel/CSV/PDF; select rows to print labels.

## 6. Labels and scanning

- **Print Labels** – choose assets (or come from the filtered list), label size (A4 sheet of 24, or 38×25, 50×25, 75×50, 100×50 mm
  roll), content (QR, barcode or both) and whether to show the serial number. **Print** uses the browser; **TSPL file** produces a
  command file for TSC/TSPL thermal printers.
- The QR code contains `https://<your site>/a/GAM-000123` (or just the Asset ID if no public address is configured). Scanning it with
  any phone camera opens the asset page after sign-in.
- The **search box** in the top bar accepts an Asset ID, asset code or serial number – a USB barcode scanner can type into it.
- The **scan** button (top bar) opens Physical Verification, where the device camera reads QR codes and barcodes in the browser (HTTPS required).

## 7. Procurement (Vendors & Procurement, Asset Acquisition)

1. **Purchase Request** – department, purpose, items with estimated cost → **Submit**. It goes through the approval rules.
2. **Quotations** – once approved, record vendor quotations; **Compare** ranks them by total, delivery and warranty. Choosing a
   quotation that is not the lowest (L1) requires a reason.
3. **Purchase Order** – *Create PO from quotation* copies items and prices; edit terms, delivery date, tax → Submit → (approval) → **Issue**.
4. **Goods Receipt (GRN)** – record quantities received/accepted/rejected against the PO; over-receipt is blocked.
5. **Purchase Invoice** – invoice number (unique per vendor), amounts, freight, installation, link to PO/GRN.
6. **Register assets from invoice** – creates one asset per unit, splits freight and installation by value, records serial numbers,
   and links each asset to its PR, PO, GRN and invoice.

## 8. Approvals

**My Approvals** lists what is waiting for you. Rules (Settings → Approval Rules) decide the chain per module and amount, e.g.
purchase requests: level 1 Department Manager; above ₹1,00,000 also level 2 Administrator. Levels are decided in order, you cannot
approve something you created, and a rejection needs a reason. Every document shows its approval history.

## 9. Allocation, transfers and returns

- **Issue Asset** – to an employee, department or location; condition and accessories; **temporary loan** needs an expected return date.
- The employee (or an asset manager on their behalf) **acknowledges** the handover.
- **Transfers** – employee, department, branch or location; reason required; may need approval. Completing a transfer closes the old
  issue record and opens a new one.
- **Return** – date, condition, remarks. A damaged / not-working return moves the asset to Under Repair.
- **Returns Overdue** lists loans past their return date.

## 10. Additions

Record upgrades, spare parts or improvements against an asset. Finance then **classifies** each one:
- **Capital improvement** – added to the asset's gross cost from the capitalization date (optionally with a revised useful life);
  may need approval.
- **Revenue expense** – recorded for history and cost reports, not capitalized.

## 11. Maintenance & repairs

**Service Requests** follow 13 steps, shown as a progress bar on the request:

1. Request raised (anyone with Create permission; tick *asset not usable* to start downtime)
2. Under review → 3. Approved / rejected → 4. Technician or service provider assigned (creates a work order) → 5. Diagnosed →
6. Estimate submitted → 7. Estimate approved (automatic below the approval limit) → 8. Awaiting parts (optional) →
9. Work in progress → 10. Testing / quality check → 11. Completed → 12. User confirmation (or *not satisfied* → back to work) → 13. Closed.

On the **work order** record labour (hours × rate), parts (quantity × cost), then on completion travel, other expenses, GST,
repair warranty months and the service report. Totals and downtime hours are calculated automatically, the asset returns to
In Service and the repair appears in the asset's maintenance history.

**Maintenance Schedules** – preventive maintenance, inspections, calibration: frequency (weekly … yearly or every N days),
first due date, lead days, provider/AMC, checklist. Work orders are generated automatically *lead days* before each due date
(once per due date). Completing the work order moves the schedule to its next due date.

## 12. Warranty & AMC

- **Warranties** – several per asset (manufacturer, extended, repair); the primary one shows on the asset. Status: Active,
  Expiring Soon, Expired.
- **AMC Contracts** – provider, type (comprehensive, non-comprehensive, on-call), period, value, visits per year, response and
  resolution hours, covered assets. Visits are scheduled automatically; record each visit's call, response and resolution times.
- **Renew** creates the next contract (`AMC-01/R1`) for the following year with the same assets, after approval.

## 13. Physical verification

1. **New session** – title, branch / department / location. The expected asset list is taken at that moment.
2. **Scan** – on a phone or tablet open the session and scan labels with the camera (or type/scan codes). Each scan shows
   *Verified*, *Found at different location*, or *Not in register*. Choose the location you are standing in and the observed condition.
   If enabled for the session, the browser's location is recorded **with each scan** (the browser asks permission; this is not live tracking).
3. **Submit** – assets not scanned become **Missing**. After approval, wrong-location assets get their location corrected and the
   results are written to each asset's timeline. Use the *Missing Assets* report to follow up before any write-off.

## 14. Depreciation

**Run Depreciation** – choose the period (month, quarter or financial year) and optionally a branch → **Preview** shows per asset the
opening value, days, depreciation and closing value → **Post**. Methods: Straight Line (cost – residual over remaining life, or a
custom % of cost), Written Down Value (% of opening book value), None. Calculation is day-wise and never goes below residual value.
A period cannot be posted twice; the most recent run can be **reversed** with a reason. **Valuation Summary** groups gross cost,
accumulated depreciation and book value by category, branch or department.

## 15. Disposal

Request disposal (sale, transfer to another organization, donation, scrap, lost, damaged beyond repair, write-off) with a reason
and expected value → approval → **Complete** with the actual date and proceeds. Depreciation is caught up to the day before
disposal, profit or loss = proceeds – book value, the asset becomes Disposed or Lost / Written Off, open issue records and schedules
are closed, and the disposal record is locked.

## 16. Reports

28 reports in groups: asset registers (complete, category, department, branch, employee, location, utilization), procurement
(purchase, additions, vendor-wise), movements (transfers, issue & return), maintenance (schedule, repair history, repair cost
analysis, maintenance expense, maintenance due, downtime, service-provider performance), warranty & AMC (AMC register, warranty
expiry), verification (physical verification, missing assets), accounting (depreciation register, valuation, disposal register),
control (pending approvals, audit trail). Set filters → **View** → **Excel**, **CSV**, **PDF** or **Print**. Financial columns
appear only for users with financial report permission. Click a row to open the record.

## 17. Notifications & reminders

The bell shows unread alerts; **My Notifications** lists them – acknowledge when handled. Reminders are produced every hour for
warranty and AMC expiry, contract renewals, maintenance / inspection / calibration due, repairs pending or overdue, critical asset
downtime, loan returns, verification sessions left open and approvals waiting. Each reminder is sent once per threshold
(default 90, 60, 30, 15 and 7 days before; plus on expiry). Unacknowledged alerts can escalate to another role after N days.
**Reminder Settings** (administrators) – enable/disable each type, days, recipient roles, escalation, channels (in-app, e-mail,
SMS, WhatsApp). **Delivery Log** shows what was sent and any failure.

## 18. Users & roles

**Users** – create users (name, e-mail, user name, roles, optional linked employee, branch/department restriction), reset passwords,
force a password change, deactivate (instead of deleting) and unlock. **Login History** shows successful and failed sign-ins with IP address.

## 19. Audit trail

Every create, change and delete is recorded with user, time, IP address and the old/new values of each field. Filter by module, user,
date or record. The audit trail cannot be edited.

## 20. Settings & backup

**Organization** (name, address, GSTIN, logo, financial-year start month), **Application Settings**, **Approval Rules** and
**Backup & Restore** (backup now, backup log). See [BACKUP_RESTORE.md](BACKUP_RESTORE.md) – uploaded files must be backed up as well as the database.

## 21. Tips

- Dates are shown as dd-mm-yyyy and amounts in Indian format (12,34,567.00).
- Lists keep your filters in the address bar – bookmark useful views.
- On phones the menu opens with the ☰ button; scanning works best in good light, holding the label 10–20 cm from the camera.
