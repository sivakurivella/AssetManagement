# Installation Guide

This guide installs Global Asset Management on a Windows server with SQL Server. For the IIS-specific steps see
[IIS_DEPLOYMENT.md](IIS_DEPLOYMENT.md).

## 1. Prerequisites

| Component | Version | Notes |
|---|---|---|
| Windows Server | 2016 / 2019 / 2022 (or Windows 10/11 for a small office) | |
| SQL Server | 2016 or later – Express is fine for small installations (10 GB database limit) | Same server or a separate database server |
| .NET 8 **Hosting Bundle** | latest 8.0.x | On the web server. Installs the ASP.NET Core runtime and the IIS module. https://dotnet.microsoft.com/download/dotnet/8.0 |
| .NET 8 **SDK** | 8.0.100 or later | Only on the build machine (can be a developer PC) |
| IIS | with "ASP.NET Core Module V2" (installed by the Hosting Bundle) | Install IIS **before** the Hosting Bundle |
| Internet on the build machine | access to nuget.org | to restore NuGet packages and the `dotnet-ef` tool |

## 2. Build the release package

On the build machine, in the solution folder:

```powershell
powershell -ExecutionPolicy Bypass -File build\build.ps1
```

The script restores packages, builds in Release, creates the EF Core migration `InitialCreate` the first time,
runs the automated tests, writes `database\03_Schema.sql`, publishes to `artifacts\publish` and creates
`artifacts\GlobalAssetManagement-publish.zip`. It stops at the first failing step.

> Keep the generated `src\GlobalAssetManagement.Infrastructure\Persistence\Migrations` folder in source control.
> Future versions add new migrations on top of it so the database can be upgraded without data loss.

## 3. Create the database

In SQL Server Management Studio, connected as an administrator, run in order:

1. `database\01_CreateDatabase.sql` – creates `GlobalAssetManagement` (full recovery model, read-committed snapshot).
2. `database\02_CreateLoginAndUser.sql` – grants access to the IIS application pool identity (edit the pool name first),
   or to a SQL login (option B – choose the password at deployment time, never store it in the repository).
3. Tables: either let the application create them on first start (the account needs `db_ddladmin`, granted by script 2),
   **or** have your DBA run the generated `database\03_Schema.sql` and then remove `db_ddladmin`.

## 4. Configure the application

`appsettings.json` is a template only. On the server create **`appsettings.Production.json`** next to it
(copy `appsettings.Production.sample.json`) and set at least:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=SQLSERVER01;Database=GlobalAssetManagement;Trusted_Connection=True;Encrypt=True;TrustServerCertificate=False;"
  },
  "App":     { "PublicBaseUrl": "https://assets.yourcompany.in" },
  "Uploads": { "RootPath": "D:\\GAMData\\uploads" },
  "Backup":  { "DatabaseBackupFolder": "D:\\GAMBackups\\Database", "FilesBackupFolder": "D:\\GAMBackups\\Files" }
}
```

| Setting | Meaning |
|---|---|
| `ConnectionStrings:DefaultConnection` | SQL Server connection. The app will not start while it still contains `YOUR_SQL_SERVER`. If SQL Server uses a self-signed certificate, install a proper certificate rather than setting `TrustServerCertificate=True` in production. |
| `App:PublicBaseUrl` | Address users type in the browser. Used inside QR codes (`<url>/a/GAM-000001`) and e-mail links. Leave empty to encode only the Asset ID. |
| `App:AssetTagPrefix` | Prefix of Asset IDs (default `GAM`). Decide before registering assets. |
| `App:TimeZone` | Windows time-zone id for reminders and dates (default `India Standard Time`). |
| `Uploads:RootPath` | Folder for invoices, photos, documents. Put it **outside** the site folder so updates never touch it. |
| `Uploads:MaxFileSizeMb` | Per-file upload limit (default 10 MB). |
| `Notifications:IntervalMinutes` | How often reminders are generated and sent (default 60). |
| `Backup:*` | Folders, retention and optional nightly time (`AutoBackupHour`, 0–23) for the built-in backup. |
| `Email`, `Sms`, `WhatsApp` | Optional channels. Disabled by default; in-app notifications always work. |
| `Security:RequireHttps` | Redirect HTTP to HTTPS (keep `true` in production). |
| `Security:SessionTimeoutMinutes` | Sliding sign-in timeout (default 60). |
| `Seed:Organization` | Organization details written on first start (editable later under Settings → Organization). |
| `Seed:SampleData` | `false` in production. `true` adds demonstration assets – only for training databases. |

**Secrets** (SMTP password, SMS API key, WhatsApp access token, SQL password) are best supplied as environment variables of the
application pool or in `web.config` `<environmentVariables>`, e.g. `Email__Password`, `WhatsApp__AccessToken`,
`ConnectionStrings__DefaultConnection`. Do not commit `appsettings.Production.json`.

## 5. First start

1. Browse to the site. The database schema is created/migrated and master data is seeded: 9 roles, default permission matrix,
   the organization and a Head Office branch, 26 asset categories in groups A–D, asset types, settings, reminder settings
   (90/60/30/15/7 days) and default approval rules.
2. You are redirected to **/Setup**. Confirm the organization name and create the first **Super Administrator** (full name, e-mail, user name, password with
   at least 8 characters, upper case, lower case, digit and symbol). Setup closes permanently once a user exists.
3. Sign in and go to **Backup & System Settings → Organization** to check the name, address, GSTIN, logo and financial-year start month.
4. Review **Approval Rules** – the seeded limits are examples (e.g. purchase requests above ₹1,00,000 need a second level). Set your own.
5. Review **Categories** – default useful lives, depreciation methods and rates are placeholders for your accountant to confirm.
   The application does not assume any statutory rate.
6. Create branches, departments, locations, employees, vendors and service providers, then users with the right roles.

## 6. Verify

- Dashboard opens and shows zero counts (or the sample data on a training database).
- Register a test asset, open it, print its label, scan the QR code with a phone – it opens the asset page after sign-in.
- **Settings → Backup & Restore → Backup now** creates a `.bak` and a files ZIP in the configured folders.
- Check `logs\gam-YYYYMMDD.log` in the site folder for errors.

## Upgrading

1. Take a database **and files** backup ([BACKUP_RESTORE.md](BACKUP_RESTORE.md)).
2. Build the new version with `build\build.ps1` (it adds no migration if one exists; developers add new migrations with
   `dotnet ef migrations add <Name>`).
3. Stop the application pool, copy the new files over the site folder (keep `appsettings.Production.json`), start the pool.
   Pending migrations are applied on start-up – or run the regenerated idempotent `database\03_Schema.sql` first.
