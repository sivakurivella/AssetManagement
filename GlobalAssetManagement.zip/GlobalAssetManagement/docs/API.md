# API and Integration Reference

Global Asset Management is a server-rendered MVC application. The endpoints below are the stable machine-readable entry
points (JSON, files and scan URLs). All of them use the **same sign-in cookie and the same role permissions** as the web pages;
there are no API keys and no anonymous access. Calls from scripts must first sign in through `/Account/Login`
(or run in a browser session).

Base URL: the value of `App:PublicBaseUrl`, e.g. `https://assets.yourcompany.in`.

## Authentication behaviour

| Situation | Web pages | `/api/...` |
|---|---|---|
| not signed in | `302` redirect to `/Account/Login?ReturnUrl=...` | `401 Unauthorized` |
| signed in, no permission | `302` redirect to `/Account/AccessDenied` | `403 Forbidden` |
| unsafe method (POST) without anti-forgery token | `400 Bad Request` | `400 Bad Request` |

POST requests must send the anti-forgery token either as the form field `__RequestVerificationToken` or the header
`RequestVerificationToken` (value from any rendered form on the site).

## JSON endpoints

### `GET /api/assets/{code}` – look up one asset
Permission: **Assets – View**. `{code}` may be the Asset ID (`GAM-000123`), the asset code (`LAP-HO-2026-0001`) or the full QR URL
(URL-encoded). Users restricted to a branch/department get `404` for assets outside it.

```json
{
  "id": 123, "assetTag": "GAM-000123", "assetCode": "LAP-HO-2026-0001", "name": "Dell Latitude 5440",
  "category": "Laptops", "serialNumber": "5CG1234XYZ", "modelNumber": "Latitude 5440",
  "status": "InService", "condition": "Good", "branch": "Head Office", "department": "Accounts",
  "location": "Main / F1 / Room 12", "assignedTo": "Ravi Kumar",
  "warrantyExpiryDate": "2027-03-31T00:00:00", "nextServiceDate": "2026-12-01T00:00:00",
  "detailsUrl": "/Assets/Details/123"
}
```
`404 {"message":"Asset not found."}` when nothing matches.

### `GET /api/assets?q={term}` – search (max 50)
Permission: **Assets – View**. Matches Asset ID, code, name or serial number; returns `[{"id":123,"text":"GAM-000123 - Dell Latitude 5440 (S/N 5CG1234XYZ)"}]`.

### `GET /Assets/Lookup?q={term}` – picker data (max 30)
Same shape as above; used by the asset drop-downs.

### `POST /Verification/ScanCode` – record a verification scan
Permission: **Verification – Edit**. Form fields: `SessionId`, `Code`, optional `FoundLocationId`, `Condition`, `Remarks`,
`Latitude`, `Longitude` (stored only when the session has GPS capture enabled) plus the anti-forgery token. Response:

```json
{ "ok": true, "result": "WrongLocation", "resultText": "Found at Wrong Location",
  "message": "GAM-000123 found at a different location than recorded.",
  "tag": "GAM-000123", "name": "Dell Latitude 5440", "found": 41, "expected": 57 }
```
`result` is one of `Found`, `WrongLocation`, `Unregistered`. A closed session returns `400` with a message.

## Files

| Endpoint | Permission | Returns |
|---|---|---|
| `GET /Assets/Qr/{id}` | Assets – View | SVG QR code (encodes `{PublicBaseUrl}/a/{AssetTag}`, or the Asset ID when no base URL is set) |
| `GET /Assets/Barcode/{id}` | Assets – View | SVG Code 128 barcode of the Asset ID |
| `POST /Assets/PrintLabels` | Assets – View | printable HTML label sheet; fields `ids`, `size` (`A4-24`, `38x25`, `50x25`, `75x50`, `100x50`), `content` (`QR`, `Barcode`, `Both`), `showSerial` |
| `POST /Assets/LabelsTspl` | Assets – View | `asset-labels-{size}.prn` file with TSPL commands for TSC-compatible thermal printers (same `ids`, `size`, `showSerial`) |
| `GET /Assets/Export?format=xlsx\|csv\|pdf&...filters` | Assets – Export | asset list with the current filters |
| `GET /Reports/View/{key}?...filters` | report's module – View | HTML report |
| `GET /Reports/Export/{key}?format=xlsx\|csv\|pdf\|print&...filters` | report's module – View **and** Export | file download (or print view); every export is written to the audit trail |
| `GET /Files/Attachment/{id}` | View permission of the module the record belongs to | stored attachment with its original name |
| `GET /Files/AssetDocument/{id}`, `GET /Files/AssetImage/{id}` | Assets – View (and branch/department visibility) | asset documents and photos |

### Report keys
`asset-register`, `category-register`, `department-register`, `branch-register`, `employee-register`, `location-register`,
`purchase-register`, `addition-register`, `transfer-register`, `issue-return-register`, `maintenance-schedule`, `repair-history`,
`repair-cost-analysis`, `maintenance-expense`, `amc-register`, `warranty-expiry`, `maintenance-due`, `downtime`, `verification`,
`missing-assets`, `depreciation-register`, `valuation`, `disposal-register`, `vendor-purchases`, `provider-performance`,
`pending-approvals`, `utilization`, `audit-trail`.

### Report filter parameters
`From`, `To` (yyyy-MM-dd), `BranchId`, `DepartmentId`, `CategoryId`, `EmployeeId`, `LocationId`, `VendorId`, `Status`, `Search`,
`GroupBy` (valuation: `category`, `branch`, `department`). Each report uses the subset relevant to it. Money columns are included only
when the user has **Financial Reports – View**.

Excel files are generated as standard Office Open XML (.xlsx) workbooks with typed number/date cells; CSV files are UTF-8 with BOM
and cells starting with `= + - @` are prefixed with `'` to prevent formula injection; PDFs are A4 landscape with page numbers.
The built-in PDF writer uses the standard PDF fonts, so characters outside Latin-1 (for example Telugu) print as `?` in PDFs (₹ prints as `Rs.`) –
use Excel/CSV for such data.

## Scan URL

`GET /a/{AssetTag}` – the address printed in QR labels. After sign-in it redirects to `/Assets/Details/{id}`; unknown codes
return to the asset list with a message. Labels therefore keep working when an asset is renamed or moved, but **not** if
`App:PublicBaseUrl` changes – reprint labels after changing the site address.

## Outgoing integrations

| Channel | Configuration | Notes |
|---|---|---|
| E-mail | `Email:*` (SMTP host, port, SSL, user, password, from) | HTML e-mails for reminders and password reset |
| SMS | `Sms:UrlTemplate` with `{mobile}` and `{message}` placeholders, optional API-key header | works with most Indian HTTP SMS gateways; DLT template registration is your gateway's requirement |
| WhatsApp | `WhatsApp:PhoneNumberId`, `AccessToken`, approved `TemplateName` | Meta WhatsApp Cloud API; business-initiated messages need an approved template |

Each delivery attempt is recorded in **Notifications → Delivery Log** (sent, failed with reason, or skipped because the channel is not configured).

## Database access for BI tools

Reporting tools (Power BI, Excel) can read the SQL Server database directly with a **read-only** login (`db_datareader`).
Table names follow the entity names (`Assets`, `AssetAllocations`, `WorkOrders`, `DepreciationTransactions`, ...). Do not write
to the database directly – the application keeps audit trail, numbering and book values consistent only for changes made through it.
