# Architecture

## Layers

```
┌─────────────────────────────────────────────────────────────────────────────┐
│ GlobalAssetManagement.Web            ASP.NET Core 8 MVC                     │
│  Controllers · Razor views · PermissionPolicyProvider/Handler ·             │
│  HttpCurrentUser · SetupRedirectFilter · BusinessExceptionFilter ·          │
│  security headers · rate limiting · file logger · wwwroot (local libs)      │
├─────────────────────────────────────────────────────────────────────────────┤
│ GlobalAssetManagement.Infrastructure EF Core 8 + SQL Server, Identity        │
│  AppDbContext (audit, soft rules, row versions) · DbSeeder · migrations ·    │
│  LocalFileStorage · SMTP / HTTP-SMS / WhatsApp senders · UserDirectory ·     │
│  ScheduledJobsService (reminders, AMC status, schedules, nightly backup) ·   │
│  BackupService                                                               │
├─────────────────────────────────────────────────────────────────────────────┤
│ GlobalAssetManagement.Application    use cases                               │
│  AssetService · ProcurementService · AllocationService · AdditionService ·   │
│  MaintenanceService · WarrantyAmcService · VerificationService ·             │
│  DepreciationService · DisposalService · ApprovalService/Workflow ·          │
│  ReminderService · DashboardService · ReportService (28) · NumberingService  │
│  QR (ISO 18004) and Code 128 encoders · Excel/CSV/PDF exporters ·            │
│  upload validator · abstractions (IAppDbContext, ICurrentUser, IClock ...)   │
├─────────────────────────────────────────────────────────────────────────────┤
│ GlobalAssetManagement.Domain         no dependencies                         │
│  entities · enums · DepreciationCalculator · MaintenanceScheduler ·          │
│  ReminderPlanner · CoverageEvaluator · VerificationReconciler ·              │
│  ServiceRequestWorkflow · RepairCostCalculator · DisposalCalculator ·        │
│  FinancialYear · DocumentNumbers · Roles                                     │
└─────────────────────────────────────────────────────────────────────────────┘
```

Dependencies point downwards only. Business rules that need no database (depreciation, scheduling, reminder buckets,
reconciliation, workflow transitions) are pure functions in Domain and are unit-tested directly. Application services use
`IAppDbContext`, `ICurrentUser`, `IClock`, `IFileStorage` and the sender interfaces so they can run against EF Core InMemory in tests.

## Data model (main tables)

| Area | Tables |
|---|---|
| Organization | Companies, Branches, Departments, Locations, Employees |
| Catalogue | AssetCategories, AssetSubcategories, AssetTypes, Manufacturers, Brands, AssetModels |
| Assets | Assets, AssetDocuments, AssetImages, AssetEvents (timeline), Attachments |
| Procurement | Vendors, PurchaseRequests, PurchaseRequestItems, Quotations, PurchaseOrders, PurchaseOrderItems, GoodsReceipts, GoodsReceiptItems, PurchaseInvoices |
| Movements | AssetAllocations, AssetReturns, AssetTransfers, AssetAdditions |
| Maintenance | ServiceProviders, ServiceRequests, RepairEstimates, WorkOrders, WorkOrderLabour, WorkOrderParts, MaintenanceSchedules, MaintenanceHistory |
| Warranty / AMC | WarrantyRecords, AMContracts, AMContractAssets, ServiceVisits |
| Verification | PhysicalVerificationSessions, PhysicalVerificationItems |
| Accounting | DepreciationSchedules (runs), DepreciationTransactions, AssetDisposals |
| Control | ApprovalRules, Approvals, Notifications, NotificationLogs, NotificationSettings, AuditLogs, LoginHistory, ApplicationSettings, RolePermissions, NumberSequences, BackupLogs |
| Identity | AspNetUsers (+ FullName, EmployeeId, BranchId, DepartmentId, IsActive, MustChangePassword), AspNetRoles, AspNetUserRoles, ... |

Conventions: `decimal(18,2)` for money; `date` columns for business dates and UTC `datetime2` for timestamps;
`rowversion` on Assets, PurchaseRequests, PurchaseOrders, ServiceRequests, WorkOrders, AMContracts and AssetDisposals (optimistic concurrency – the user is asked
to reload on conflict); all foreign keys are `RESTRICT` except owned child lines (cascade), so history can never be deleted
by accident; unique indexes on Asset ID, asset code, master codes, document numbers, vendor + invoice number, reminder de-duplication key
and number sequences; serial numbers are indexed and checked for duplicates (per manufacturer) by `AssetService`.

## Key mechanisms

- **Numbering** – `NumberSequences(Prefix, Scope, LastNumber)` with a concurrency token and retry; document numbers are
  `PR/2026-27/0001` (per financial year), Asset IDs `GAM-000001` (global), asset codes `CAT-BRANCH-YEAR-0001`.
- **Audit trail** – `AppDbContext.SaveChangesAsync` stamps Created/Modified By/At and writes one `AuditLog` row per changed
  entity with a JSON list of field changes (old → new), user, IP and time. Exports and sign-ins are logged too.
- **Asset timeline** – `AssetHistory` records an `AssetEvent` for every business event and status change.
- **Approvals** – `ApprovalService.SubmitAsync` creates the chain from active `ApprovalRules` whose amount band matches;
  `ApprovalWorkflow.DecideAsync` enforces order, approver role, segregation of duties and a rejection reason, then calls the
  module's `IApprovalHandler.OnDecidedAsync`. If no rule applies, the document is approved immediately.
- **Repair lifecycle** – `ServiceRequestWorkflow` is an explicit transition table; every state change goes through it.
- **Depreciation** – `DepreciationCalculator` (pure): day-count pro-rata on 365 days; SLM over remaining life (or custom % of
  cost), WDV % of opening book value; residual floor; capital additions from their capitalization date with optional revised
  life. Posting is transactional and stores one `DepreciationTransaction` per asset and period; `DepreciatedUpTo` prevents double posting.
- **Reminders** – `ReminderPlanner.Bucket` maps "days to due date" to the largest configured threshold passed;
  `DedupKey = type:entity:id:dueDate:bucket` with a unique index guarantees each reminder is raised once even if jobs overlap.
  Escalation and multi-channel dispatch run in the same hourly job; each delivery is logged.
- **Background jobs** – `ScheduledJobsService` (hosted service, interval `Notifications:IntervalMinutes`) runs: AMC status refresh,
  preventive work-order generation, reminders, escalation, dispatch and the optional nightly backup. Each job is idempotent.
- **Files** – stored outside `wwwroot` with random names; served only through `FilesController` after permission checks;
  extension allow-list, size limit, magic-number check, no executables.

## Security design

| Control | Implementation |
|---|---|
| Authentication | ASP.NET Core Identity; password ≥ 8 with upper/lower/digit/symbol; lockout 5 attempts / 15 min; optional TOTP two-factor; security stamp re-validated every 5 minutes (deactivated users are signed out) |
| First user | no seeded accounts or passwords; `/Setup` creates the Super Administrator once and is then closed |
| Authorization | global "authenticated user" filter; `[Permission(module, action)]` policies resolved against the `RolePermissions` matrix; Super Administrator always allowed; views hide what the user cannot do |
| Data scope | users limited to a branch/department see and change only those assets (`DataScope.VisibleTo / EnsureCanSee`) |
| CSRF | `AutoValidateAntiforgeryToken` on every POST; tokens in all forms and the fetch() scan call |
| Brute force | fixed-window rate limit on sign-in (10/min/IP) plus Identity lockout |
| Headers | CSP (`default-src 'self'`, no external scripts), X-Content-Type-Options, X-Frame-Options SAMEORIGIN, Referrer-Policy, Permissions-Policy (camera/geolocation self only), HSTS, HTTPS redirect, server header removed |
| Cookies | `GAM.Auth` HttpOnly, SameSite=Lax, Secure on HTTPS, sliding expiry |
| Injection | EF Core parameterized queries only; backup command uses SQL parameters; CSV formula neutralisation; Razor HTML encoding |
| Secrets | none in the repository; connection string placeholder blocks start-up; secrets via environment variables / server-only file |
| Logging | structured logs to file (daily, retained 30 days), console, Windows Event Log; no passwords or tokens logged |

## Deliberate limits

- GPS is captured only as a one-time browser reading per verification scan when the user allows it; there is no tracking hardware integration.
- Tax and depreciation rates are configuration data, not code; the application does not decide statutory compliance.
- The built-in PDF writer uses standard Latin fonts (no Indic scripts).
- Single web server assumed (Data Protection keys and uploads on local disk); a web farm needs a shared key ring and file share.
