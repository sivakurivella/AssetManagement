# Backup and Restore

Global Asset Management keeps data in **two places**. Both must be backed up – a SQL Server backup alone does **not**
contain uploaded files.

| What | Where | Contains |
|---|---|---|
| SQL Server database `GlobalAssetManagement` | SQL Server | all records: assets, transactions, users, permissions, audit trail, settings, file *references* |
| Uploads folder (`Uploads:RootPath`) | web server disk, e.g. `D:\GAMData\uploads` | the actual invoice PDFs, warranty cards, photos, attachments |
| Configuration | `appsettings.Production.json`, edited `web.config` | connection string, mail/SMS settings – keep a copy in a safe place (it may contain secrets) |
| Data Protection keys (optional) | `%LOCALAPPDATA%\ASP.NET\DataProtection-Keys` of the pool user | only needed to keep users signed in across a server rebuild; losing them just forces everyone to sign in again |

A restore is consistent only when the database backup and the files backup were taken at about the same time.

## 1. Built-in backup (Backup & System Settings → Backup & Restore)

- **Backup now** runs `BACKUP DATABASE ... WITH CHECKSUM` into `Backup:DatabaseBackupFolder` and zips the uploads folder into
  `Backup:FilesBackupFolder`. Every run is recorded in the backup log on that page (status, size, file name, user).
- **Nightly backup**: set `Backup:AutoBackupHour` (0–23, server local time) and the background job takes one database + files
  backup per day at or after that hour. Leave it `null` to disable.
- **Retention**: after the nightly backup, files older than `Backup:RetentionDays` (default 30) are deleted from both folders –
  for the database folder only when the web server can reach that path (same machine or share).
- `Backup:DatabaseBackupFolder` is a path **on the SQL Server machine**, written by the SQL Server service account.
  If SQL Server is on another computer, use a local path there (or a UNC share the SQL service account can write to).
- The application account needs the `db_backupoperator` role (granted by `database\02_CreateLoginAndUser.sql`).

The built-in backup is a convenience. For production also use one of the scheduled methods below and copy backups **off the server**.

## 2. Scheduled database backup

- SQL Server Standard/Enterprise: run `database\06_SqlAgentBackupJob.sql` (nightly 01:30 full backup, verify, 30-day cleanup).
- SQL Server Express (no SQL Agent): Windows Task Scheduler, daily, as an account with backup rights:
  `sqlcmd -S .\SQLEXPRESS -E -i "C:\GAM\database\04_Backup.sql"` (remove `COMPRESSION` in the script for Express).
- For point-in-time recovery add transaction-log backups every 15–60 minutes (see the commented block in `04_Backup.sql`).

## 3. Scheduled files backup

Daily Task Scheduler job (run after the database backup):

```bat
robocopy "D:\GAMData\uploads" "\\BACKUPSERVER\GAM\uploads" /MIR /R:2 /W:5 /NP /LOG+:"D:\GAMBackups\robocopy.log"
```

`/MIR` mirrors deletions too; if you want to keep deleted files, use `/E` instead or back the share up with versioning.
Copy the `.bak` files to the same off-site location (e.g. `robocopy D:\GAMBackups\Database \\BACKUPSERVER\GAM\db *.bak /XO`).

**Recommended policy:** daily full database + files, log backups during working hours, 30 days on the server,
a weekly copy kept off-site for 1 year, and a test restore every quarter.

## 4. Restore

1. Inform users and **stop the application**: `Stop-WebAppPool GamAppPool` (or put `app_offline.htm` in the site folder).
2. Restore the database with `database\05_Restore.sql` (set the `.bak` path; check logical names with `RESTORE FILELISTONLY`;
   for point-in-time restore use `NORECOVERY` and apply the log backups).
3. Restore the uploads folder from the files backup taken closest to the database backup:
   - built-in ZIP: extract `GAM_Uploads_yyyyMMdd_HHmmss.zip` into the (empty) `Uploads:RootPath` folder;
   - robocopy copy: `robocopy "\\BACKUPSERVER\GAM\uploads" "D:\GAMData\uploads" /MIR`.
   Re-apply the `Modify` permission for `IIS AppPool\GamAppPool` if the folder was recreated.
4. Restoring onto a **new SQL Server**: re-create the login (script 02) and re-map the database user
   (`ALTER USER gam_app_user WITH LOGIN = ...`).
5. Start the application pool, sign in, open a few assets with attachments, and check the audit trail shows the expected last entries.
6. If the backup came from an older version of the application, the start-up migration upgrades it automatically.

## 5. Test restore (quarterly)

Restore to a separate database name (e.g. `GlobalAssetManagement_RestoreTest` with `MOVE` clauses) and a separate uploads folder,
point a test copy of the site at it, and verify record counts and a sample of documents. Delete the test copy afterwards.
