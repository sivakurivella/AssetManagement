# Test Cases

## 1. Automated tests

Project: `tests/GlobalAssetManagement.Tests` (xUnit). Run all of them with

```powershell
dotnet test tests\GlobalAssetManagement.Tests
dotnet test tests\GlobalAssetManagement.Tests --filter "Category!=Integration"   # unit tests only
dotnet test tests\GlobalAssetManagement.Tests --filter "Category=Integration"    # service + web tests
```

| Kind | Where | What runs |
|---|---|---|
| Unit | `Unit/` | pure business rules and document generation – no database |
| Integration (services) | `Integration/*Tests.cs` with `TestHost` | real application services on an isolated EF Core InMemory database per test, fixed clock (25-10-2026 10:00 IST), fake user, fake senders |
| Integration (web) | `Integration/SecurityTests.cs` with `WebFactory` | the full ASP.NET Core pipeline (routing, auth, permissions, anti-forgery, Razor views) on InMemory data with a test authentication scheme (`X-Test-Roles` header) |

Integration tests use EF Core InMemory, which does not enforce SQL Server unique indexes, `rowversion` or transactions; those
are covered by the manual cases below on a real SQL Server.

### Automated test list

**Integration/AccountingTests.cs**

- `DepreciationPostingTests`
  - Posting updates book value and cannot be repeated for the same period
  - Reversal restores book value and only latest run can be reversed
- `DisposalTests`
  - Sale catches up depreciation computes profit and locks the record
  - Lost asset has no proceeds and is written off
- `VerificationTests`
  - Session reconciles found wrong location missing and unregistered
- `ReportAndDashboardTests`
  - Every report runs and exports
  - Financial columns are hidden without financial access
  - Dashboard kpis come from live data

**Integration/AssetAndProcurementTests.cs**

- `AssetTests`
  - Creating assets generates unique ids codes and valuation
  - Duplicate asset code and serial number are rejected
  - Status changes are recorded and disposal status is reserved
  - Financial fields are locked after depreciation is posted
  - Asset with transactions cannot be deleted
  - Branch restricted users cannot see other branches
- `ProcurementTests`
  - Request to registration keeps full traceability and apportions charges
  - Multi level approval enforces roles order and segregation of duties
  - Small request needs only first level and rejection marks request rejected

**Integration/OperationsTests.cs**

- `AllocationTests`
  - Issue acknowledge transfer and return keep custody history
  - Temporary loans need a return date and overdue loans are listed
  - Location transfer rejects locations of another branch
- `AdditionTests`
  - Capital improvement increases gross cost and revenue expense does not
- `MaintenanceTests`
  - Repair request goes through the full lifecycle with costs and downtime
  - Repair cannot skip workflow steps
  - Preventive schedule generates one work order per due date
- `WarrantyAndReminderTests`
  - Reminders are raised once per threshold and not duplicated
  - Disabled alert type raises nothing
  - Amc renewal creates a linked contract covering the same assets

**Integration/SecurityTests.cs**

- `SecurityTests`
  - Anonymous users are sent to the login page
  - Api returns 401 instead of redirect for anonymous calls
  - Login page is public and sends security headers
  - Employee role cannot open administration pages
  - Super administrator can open pages
  - Auditor can view assets but not create them
  - Post without antiforgery token is rejected

**Unit/DepreciationTests.cs**

- `DepreciationTests`
  - StraightLine full year equals cost less residual over life
  - StraightLine partial first period is pro rata by days
  - StraightLine second year continues at same annual charge
  - Monthly runs add up to the annual charge
  - Book value never goes below residual value
  - Fully depreciated asset gets no further depreciation
  - Asset past its useful life is written down to residual
  - Not depreciated and not yet started assets return zero
  - WrittenDownValue applies rate to opening book value
  - WrittenDownValue partial year is pro rata
  - StraightLine with custom rate uses rate on cost
  - Capitalized addition mid period increases depreciation from its date
  - Revised useful life on addition changes the remaining charge
  - Period end before start is rejected
  - Wdv rate derived from life reduces cost to residual
  - Capitalized cost excludes gst when input credit is claimed
  - Disposal profit or loss compares proceeds with book value

**Unit/DocumentGenerationTests.cs**

- `QrAndBarcodeTests`
  - Short asset id fits in a version 1 qr code
  - Qr code has three finder patterns
  - Longer content selects a larger version and overflow is rejected
  - Qr svg is well formed
  - Code128 pattern table and checksum are correct
  - Code128 rejects characters outside code set b
- `ExportTests`
  - Totals row sums total columns
  - Row with wrong column count is rejected
  - Csv has bom headers and neutralises formula injection
  - Excel file is a valid open xml package
  - Pdf is paginated with valid structure
  - Pdf transliterates the rupee sign
  - Indian number formatting is used for money
- `UploadValidatorTests`
  - Valid pdf and image are accepted
  - Disallowed extensions are rejected
  - Renamed executable is rejected by signature
  - Size limits and empty files are enforced
  - Binary content disguised as text is rejected

**Unit/RulesTests.cs**

- `MaintenanceSchedulerTests`
  - Monthly schedule from month end does not drift
  - Every frequency produces the expected next date
  - Custom interval and far future lookups work
  - Schedule end date stops further occurrences
  - Occurrences in a window are listed
  - A future start date is the first due date
- `ReminderTests`
  - Bucket is the smallest threshold covering the remaining days
  - Daily scans raise exactly one reminder per interval
  - Renewed expiry date starts a new reminder series
  - Configured intervals are parsed safely
  - Warranty coverage status
  - Amc status moves to renewal due then expired but keeps final states
- `VerificationReconcilerTests`
  - Reconciliation classifies found wrong location missing and unregistered
  - Unscanned assets stay pending until the session is finalized
  - Asset without recorded location counts as found
- `WorkflowAndRulesTests`
  - Repair lifecycle happy path is allowed step by step
  - Invalid repair transitions are blocked
  - Failed test and unsatisfied user send the repair back
  - Repair cost and downtime
  - Permissions follow the role matrix and super admin has full access
  - Approval rule amount ranges
  - Financial year and document numbers
  - Purchase order totals include line gst and other charges

## 2. Manual acceptance tests (run on SQL Server + IIS before go-live)

Prepare: a fresh database, the Super Administrator from Setup, users for each role, 2 branches, 3 departments, 4 locations,
5 employees, 2 vendors, 1 service provider. "✓" = expected result.

### Installation & security
| # | Steps | Expected |
|---|---|---|
| S1 | Start the site with the placeholder connection string | ✓ start-up fails with a clear message in the log / stdout |
| S2 | First visit on an empty database | ✓ redirected to /Setup; after creating the admin, /Setup is no longer reachable |
| S3 | Sign in with a wrong password 5 times | ✓ account locked 15 minutes; Login History shows the failures with IP |
| S4 | 11 sign-in attempts within a minute from one PC | ✓ HTTP 429 on the 11th |
| S5 | Employee opens `/Users`, `/Settings`, `/Audit` by typing the URL | ✓ Access denied page |
| S6 | Auditor opens an asset | ✓ no Edit / Delete / Issue buttons; POSTing an edit form returns access denied |
| S7 | User restricted to branch VJA searches for a Head Office asset ID | ✓ not found; direct URL `/Assets/Details/{id}` refused |
| S8 | Browse via http:// | ✓ redirected to https://; response has HSTS, CSP, X-Frame-Options headers |
| S9 | Upload `invoice.pdf` that is really an .exe renamed; upload a 15 MB file | ✓ both rejected with a message |
| S10 | Deactivate a signed-in user | ✓ that user is signed out within 5 minutes |
| S11 | Enable two-factor for a user, sign in | ✓ 6-digit code requested; recovery code works once |

### Assets & labels
| # | Steps | Expected |
|---|---|---|
| A1 | Register a laptop: cost 50,000, GST 9,000, input credit claimed, freight 1,000, installation 500 | ✓ capitalized cost 51,500; ID GAM-000001; code LAP-HO-2026-0001 |
| A2 | Same with input credit **not** claimed | ✓ capitalized cost 60,500 |
| A3 | Register another asset with code LAP-HO-2026-0001 or an existing serial of the same manufacturer | ✓ rejected |
| A4 | Upload invoice PDF and 2 photos; open them | ✓ shown/downloaded; timeline shows the upload |
| A5 | Print labels A4-24 and 50×25 for 30 assets; scan a printed QR with a phone | ✓ phone opens the asset page after sign-in; barcode reads `GAM-000001` |
| A6 | Two users edit the same asset and save | ✓ second save gets "changed by another user" |
| A7 | Export the asset list to Excel, CSV and PDF | ✓ files open; totals correct; Indian number format |

### Procurement & approvals
| # | Steps | Expected |
|---|---|---|
| P1 | PR for 2 laptops × 60,000 by an employee of Accounts | ✓ status Pending Approval, level 1 Department Manager, level 2 Administrator (> ₹1,00,000) |
| P2 | Requester (also an admin) tries to approve level 2 | ✓ refused – own request |
| P3 | Manager approves L1, admin approves L2 | ✓ PR Approved; approval history shows both decisions |
| P4 | Enter 2 quotations; select the higher one without reason | ✓ refused; with reason accepted |
| P5 | PO from quotation → submit → approve → issue; GRN receiving 3 of 2 | ✓ over-receipt refused; GRN 2 OK; PO Received |
| P6 | Invoice with freight 1,000 + installation 2,000; register assets with 2 serial numbers | ✓ 2 assets, each +500 freight +1,000 installation, linked to PR/PO/GRN/invoice; repeat registration refused |
| P7 | Enter the same vendor invoice number twice | ✓ refused |

### Allocation, additions, maintenance
| # | Steps | Expected |
|---|---|---|
| M1 | Issue asset to Ravi; Ravi acknowledges from his login | ✓ asset In Service, custodian Ravi; acknowledgement recorded |
| M2 | Transfer to Lakshmi (employee transfer) | ✓ old issue closed, new issue opened, timeline updated |
| M3 | Temporary loan with return date tomorrow; advance the server date or wait | ✓ appears in Returns Overdue and reminder raised |
| M4 | Return as Damaged | ✓ asset Under Repair |
| M5 | Addition RAM 6,000 capital (revised life 4) and cleaning 500 revenue | ✓ gross cost +6,000; life 4; cleaning not capitalized |
| M6 | Service request "not powering on", asset down → review → approve → assign → diagnose → estimate 2,700 → work → labour 2 h × 500, part 1,500, travel 200 → testing pass → complete after 26 h → user confirms → close | ✓ every step in order, totals 2,700, downtime 26 h, asset back In Service; skipping a step is refused |
| M7 | Estimate above ₹10,000 | ✓ waits for Asset Manager approval before work can start |
| M8 | Quarterly schedule due in 5 days, lead 7 | ✓ one work order generated by the hourly job, not duplicated; completion moves next due by 3 months |

### Warranty, AMC, reminders
| # | Steps | Expected |
|---|---|---|
| W1 | Asset with warranty expiring in 20 days | ✓ one "30-day" reminder; no duplicate after next job runs; another at 15 and 7 days |
| W2 | Disable warranty reminders in Reminder Settings | ✓ no new warranty reminders |
| W3 | Configure SMTP; reminders e-mailed; wrong password | ✓ Delivery Log shows Sent / Failed with reason |
| W4 | AMC expiring in 19 days → Renewal Due; Renew at 26,000 → approve | ✓ AMC-01/R1 starts the day after expiry, same assets, visits scheduled; old contract Renewed |
| W5 | Set escalation days and role for an alert type; leave a reminder unacknowledged that long | ✓ escalation alert to the escalation role |

### Verification, depreciation, disposal
| # | Steps | Expected |
|---|---|---|
| V1 | Session for Head Office with 3 assets; scan one in place, one in another room, one unknown code; submit | ✓ Found / Wrong location / Unregistered / Missing; after approval wrong-location asset's location corrected |
| V2 | Session with GPS capture on a phone | ✓ browser asks permission; latitude/longitude saved per scan only |
| D1 | Laptop 60,000, residual 5 %, 3 years SLM, purchased 01-04-2025; post FY 2025-26 | ✓ depreciation 19,000; book value 41,000 |
| D2 | Post the same period again | ✓ refused |
| D3 | Post H1 and H2 separately; reverse H1 | ✓ refused (later run exists); reverse H2 works |
| D4 | WDV 40 % on 1,00,000 for two years | ✓ 40,000 then 24,000 |
| D5 | Sell the laptop on 01-10-2026 for 35,000 | ✓ catch-up depreciation to 30-09-2026; profit = 35,000 – book value; asset Disposed; record locked |
| D6 | Disposal of a lost asset with expected value | ✓ proceeds forced to 0; status Lost / Written Off |

### Reports, dashboard, backup
| # | Steps | Expected |
|---|---|---|
| R1 | Open each of the 28 reports with and without filters; export Excel/CSV/PDF/print | ✓ all run; exports match the screen; export logged in audit trail |
| R2 | Sign in as a user without Financial Reports | ✓ money columns absent in reports |
| R3 | Dashboard filters by branch / category / dates; click tiles and bars | ✓ counts match lists opened by drill-down |
| B1 | Backup now | ✓ .bak in the SQL backup folder and GAM_Uploads_*.zip in the files folder; log row Succeeded |
| B2 | Restore both to a test server (BACKUP_RESTORE.md §4) | ✓ assets and their attachments open |
| B3 | Audit trail after editing an asset | ✓ old and new values, user, IP, time |
