# Delivery Report – Global Asset Management 1.0.0

Prepared 25 October 2026 for S.S. Solutions, Guntur.

## 1. What is delivered

| Item | Location |
|---|---|
| Source code – 5 projects (Domain, Application, Infrastructure, Web, Tests) | `GlobalAssetManagement.sln`, `src/`, `tests/` |
| 69 C# files (~15,000 lines), 97 Razor views (~3,500 lines), 30 controllers, 58 database tables (plus Identity tables) | |
| Local front-end libraries with licences (Bootstrap 5.3.3, Bootstrap Icons 1.11.3, jQuery 3.7.1, jQuery Validation 1.21.0 + Unobtrusive 4.0.0, Chart.js 4.4.6, Tom Select 2.3.1, html5-qrcode 2.3.8) | `src/GlobalAssetManagement.Web/wwwroot/lib` |
| Configuration template without secrets (placeholder connection string) + production sample | `appsettings.json`, `appsettings.Production.sample.json` |
| SQL scripts: create database, login/user, backup, restore, SQL Agent job; schema-script instructions | `database/` |
| Build script: restore → build → migration → tests → schema script → publish → zip | `build/build.ps1`, `build/build.sh` |
| README, installation, IIS deployment, backup & restore, user manual, API reference, architecture, test cases, release notes | `README.md`, `docs/`, `RELEASE_NOTES.md` |
| 92 automated tests (132 test cases including theory rows) | `tests/GlobalAssetManagement.Tests` |

Requirement coverage (all modules of the specification): asset categories A–D, asset master with 11 statuses, IDs/codes,
QR/barcode labels and scanning, procurement with approval limits, allocation/transfer/return, additions (capital vs. revenue),
13-step repair lifecycle, maintenance scheduling, service providers, warranty/AMC with 90/60/30/15/7-day de-duplicated reminders
and escalation, physical verification, depreciation (SLM/WDV/custom rate), disposal, dashboard (14 KPIs, 10 charts, live data),
28 reports with Excel/CSV/PDF/print, 9 roles with permission matrix, audit trail, backup/restore, responsive UI with 18 menu sections.

## 2. What was verified, and how

This package was produced in an isolated build environment **without access to nuget.org**. NuGet packages (Entity Framework
Core, ASP.NET Core Identity EF stores, SQL Server provider, xUnit, Mvc.Testing) could therefore not be downloaded here. Verification
was done as follows – please read the limits in §3.

| Check | Method | Result |
|---|---|---|
| Whole solution compiles (all 5 projects incl. Razor views and tests) | .NET SDK 8.0.132, with the NuGet packages replaced by compile-only API stand-ins of the same namespaces/signatures | **0 errors, 0 warnings** |
| Unit tests (depreciation, scheduling, reminders, reconciliation, workflow, approvals rules, QR/barcode, Excel/CSV/PDF, upload validation) | compiled test assembly executed with a reflection test runner | **82 of 82 test cases passed** |
| QR codes | 12 samples (versions 1–10, error-correction L/M/Q/H) rendered to images and decoded with the independent ZXing-C++ decoder | **12/12 decoded to the exact text** |
| Code 128 barcodes | 3 samples decoded with ZXing-C++ | **3/3 decoded** |
| Excel export | generated .xlsx opened with openpyxl; well-formed Office Open XML | opens, typed numbers/dates |
| PDF export | generated 3-page report inspected (text, pagination, layout) | correct |
| CSV export | formula-injection cells neutralised, UTF-8 BOM | correct |
| Secrets | repository searched for passwords, keys, tokens | none – only placeholders |

## 3. Not verified here – to be done on your build machine

These steps need the real NuGet packages and a SQL Server. **`build\build.ps1` performs the first four automatically and stops on
any failure.**

1. **Real restore and build** against the actual NuGet packages (EF Core 8.0.11 etc.). The stand-ins match the APIs used, but
   only a real build proves it.
2. **EF Core migration not generated.** `Persistence/Migrations` does not exist yet; `build.ps1` creates `InitialCreate`
   (`dotnet ef migrations add`) and `database/03_Schema.sql`. Commit the generated migration. (Without it the app falls back to
   `EnsureCreated` – fine for a trial, but always generate the migration before production so later versions can upgrade.)
3. **50 integration test cases were not executed** (service tests on EF Core InMemory and web-pipeline tests with
   WebApplicationFactory: procurement end-to-end, approvals, repair lifecycle, reminders de-duplication, AMC renewal, depreciation
   posting/reversal, disposal, verification, all 28 reports, dashboard, authorization, anti-forgery). They compile; run them with
   `dotnet test`. Treat any failure as a defect to fix before go-live.
4. **No run against SQL Server and IIS yet** – the application has not been started end-to-end. Run the manual acceptance tests in
   `docs/TEST_CASES.md` §2 on a test server (they also cover what InMemory cannot: unique indexes, row-version conflicts, transactions,
   backup/restore).
5. **External channels** (SMTP, SMS gateway, WhatsApp Cloud API) need your accounts and were not exercised.

## 4. Known limitations and decisions

- **No default users or passwords.** The first Super Administrator is created on `/Setup`.
- **Depreciation rates, useful lives, residual % and approval limits** are seeded as editable examples. No statutory or tax rules are
  hard-coded – your accountant must confirm the values per category.
- **GPS**: only a single browser location reading per verification scan (with user permission). No continuous tracking or tracker hardware.
- **Backups**: SQL Server backups do not include uploaded documents; the built-in backup zips the uploads folder separately, and
  `docs/BACKUP_RESTORE.md` describes the file backup/restore. Both are required.
- **PDF**: standard Latin fonts – Telugu/other Indic text prints as `?` in PDF (Excel/CSV are fine).
- **Hosting**: single web server assumed (Data Protection keys and uploads on local disk).
- **Content-Security-Policy** allows inline scripts/styles (`'unsafe-inline'`) because several views use small inline scripts;
  all script files are served from the site itself.

## 5. Next steps

1. On a Windows PC with internet: install the .NET 8 SDK, unzip, run `powershell -ExecutionPolicy Bypass -File build\build.ps1`.
2. Fix anything the real build or the integration tests report (expected to be small, but it must be checked).
3. Deploy to a test IIS server (`docs/INSTALL.md`, `docs/IIS_DEPLOYMENT.md`), run `docs/TEST_CASES.md` §2, then go live.
