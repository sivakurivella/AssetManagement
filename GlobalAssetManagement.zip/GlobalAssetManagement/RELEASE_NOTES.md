# Release Notes

## Version 1.0.0 – 25 October 2026

First release of **Global Asset Management** for S.S. Solutions, Guntur.

### Included
- Asset master with categories A–D (26 seeded categories), sub-categories, types, makes, brands, models; 11 statuses; photos, documents, timeline.
- Automatic Asset ID / Asset Code, QR and Code 128 generation, label printing (A4 and roll sizes, TSPL), QR scan URLs.
- Procurement: purchase request, quotation comparison, purchase order, goods receipt, purchase invoice, asset registration with charge apportionment.
- Configurable multi-level approvals with amount limits and segregation of duties.
- Issue / acknowledgement / return, temporary loans, transfers between employees, departments, branches and locations.
- Additions: capital improvement vs. revenue expense.
- 13-step repair lifecycle, work orders with labour/parts/costs/downtime, preventive maintenance, inspection and calibration schedules.
- Warranties, AMC contracts with visits, SLA times and renewals; service providers.
- Reminders at 90/60/30/15/7 days (configurable) with de-duplication, escalation, in-app, e-mail, SMS and WhatsApp channels.
- Physical verification with camera/scanner input and optional per-scan browser GPS.
- Depreciation (SLM, WDV, custom rate) with preview, posting, reversal and valuation summary.
- Disposal with approval, profit/loss and locking.
- Dashboard (14 KPIs, 10 charts) and 28 reports with Excel, CSV, PDF and print.
- 9 roles, editable permission matrix, branch/department data restriction, two-factor sign-in, login history, full audit trail.
- Built-in database + uploaded-files backup, SQL scripts for database creation, backup, restore and SQL Agent job.
- Responsive Bootstrap 5 interface with 18 menu sections.

### Installation notes
- Requires .NET 8 runtime (Hosting Bundle for IIS) and SQL Server 2016+.
- Run `build\build.ps1` on a machine with internet access to generate the EF Core migration, run tests and publish (see DELIVERY_REPORT.md).
- No default users: the first Super Administrator is created on the Setup page.
- Review seeded approval limits and category depreciation defaults with your accountant before use.

### Known limitations
- PDF exports use standard Latin fonts; Telugu or other Indic text appears as `?` in PDFs (use Excel/CSV).
- GPS is a single browser reading per verification scan; no continuous location tracking.
- Designed for a single web server; a web farm needs a shared Data Protection key ring and shared uploads folder.
- SMS/WhatsApp delivery depends on your gateway account, sender registration (DLT) and approved WhatsApp templates.
