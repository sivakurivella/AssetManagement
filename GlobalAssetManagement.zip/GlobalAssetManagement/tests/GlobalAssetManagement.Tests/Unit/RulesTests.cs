using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using GlobalAssetManagement.Domain.Logic;

namespace GlobalAssetManagement.Tests.Unit;

public class MaintenanceSchedulerTests
{
    [Fact]
    public void Monthly_schedule_from_month_end_does_not_drift()
    {
        var start = new DateTime(2024, 1, 31);
        Assert.Equal(new DateTime(2024, 2, 29), MaintenanceScheduler.Occurrence(start, MaintenanceFrequency.Monthly, null, 1));
        Assert.Equal(new DateTime(2024, 3, 31), MaintenanceScheduler.Occurrence(start, MaintenanceFrequency.Monthly, null, 2));
        Assert.Equal(new DateTime(2024, 3, 31), MaintenanceScheduler.NextAfter(start, null, MaintenanceFrequency.Monthly, null, new DateTime(2024, 2, 29)));
    }

    [Theory]
    [InlineData(MaintenanceFrequency.Weekly, "2024-01-08")]
    [InlineData(MaintenanceFrequency.Fortnightly, "2024-01-15")]
    [InlineData(MaintenanceFrequency.Monthly, "2024-02-01")]
    [InlineData(MaintenanceFrequency.Quarterly, "2024-04-01")]
    [InlineData(MaintenanceFrequency.HalfYearly, "2024-07-01")]
    [InlineData(MaintenanceFrequency.Yearly, "2025-01-01")]
    public void Every_frequency_produces_the_expected_next_date(MaintenanceFrequency f, string expected)
    {
        var next = MaintenanceScheduler.NextAfter(new DateTime(2024, 1, 1), null, f, null, new DateTime(2024, 1, 1));
        Assert.Equal(DateTime.Parse(expected), next);
    }

    [Fact]
    public void Custom_interval_and_far_future_lookups_work()
    {
        Assert.Equal(new DateTime(2024, 1, 31), MaintenanceScheduler.NextAfter(new DateTime(2024, 1, 1), null, MaintenanceFrequency.CustomDays, 10, new DateTime(2024, 1, 25)));
        Assert.Equal(new DateTime(2029, 1, 15), MaintenanceScheduler.NextAfter(new DateTime(2024, 1, 15), null, MaintenanceFrequency.Quarterly, null, new DateTime(2028, 12, 1)));
    }

    [Fact]
    public void Schedule_end_date_stops_further_occurrences()
    {
        Assert.Null(MaintenanceScheduler.NextAfter(new DateTime(2024, 1, 1), new DateTime(2024, 3, 15), MaintenanceFrequency.Monthly, null, new DateTime(2024, 3, 1)));
        var list = MaintenanceScheduler.Occurrences(new DateTime(2024, 1, 1), new DateTime(2024, 4, 30), MaintenanceFrequency.Monthly, null, new DateTime(2024, 1, 1), new DateTime(2024, 12, 31));
        Assert.Equal(4, list.Count);
    }

    [Fact]
    public void Occurrences_in_a_window_are_listed()
    {
        var list = MaintenanceScheduler.Occurrences(new DateTime(2024, 1, 1), null, MaintenanceFrequency.Monthly, null, new DateTime(2024, 3, 1), new DateTime(2024, 6, 30));
        Assert.Equal(new[] { new DateTime(2024, 3, 1), new DateTime(2024, 4, 1), new DateTime(2024, 5, 1), new DateTime(2024, 6, 1) }, list);
    }

    [Fact]
    public void A_future_start_date_is_the_first_due_date()
    {
        Assert.Equal(new DateTime(2030, 5, 1), MaintenanceScheduler.NextAfter(new DateTime(2030, 5, 1), null, MaintenanceFrequency.Monthly, null, new DateTime(2024, 1, 1)));
    }
}

public class ReminderTests
{
    private static readonly DateTime Today = new(2026, 10, 25);
    private static readonly int[] Days = { 90, 60, 30, 15, 7 };

    [Theory]
    [InlineData(100, null)]
    [InlineData(90, 90)]
    [InlineData(61, 90)]
    [InlineData(45, 60)]
    [InlineData(31, 60)]
    [InlineData(30, 30)]
    [InlineData(8, 15)]
    [InlineData(0, 7)]
    [InlineData(-1, 0)]
    public void Bucket_is_the_smallest_threshold_covering_the_remaining_days(int daysLeft, int? expected)
    {
        Assert.Equal(expected, ReminderPlanner.Bucket(Today.AddDays(daysLeft), Today, Days));
    }

    [Fact]
    public void Daily_scans_raise_exactly_one_reminder_per_interval()
    {
        var expiry = Today.AddDays(120);
        var keys = new HashSet<string>();
        int raised = 0;
        for (var day = Today; day <= expiry.AddDays(10); day = day.AddDays(1))
        {
            if (ReminderPlanner.Bucket(expiry, day, Days) is { } b && keys.Add(ReminderPlanner.DedupKey(AlertType.WarrantyExpiry, "Asset", 7, expiry, b)))
                raised++;
        }
        Assert.Equal(6, raised); // 90, 60, 30, 15, 7 days before and once after expiry
    }

    [Fact]
    public void Renewed_expiry_date_starts_a_new_reminder_series()
    {
        var k1 = ReminderPlanner.DedupKey(AlertType.AmcExpiry, "AMContract", 1, new DateTime(2026, 11, 30), 30);
        var k2 = ReminderPlanner.DedupKey(AlertType.AmcExpiry, "AMContract", 1, new DateTime(2027, 11, 30), 30);
        Assert.NotEqual(k1, k2);
    }

    [Fact]
    public void Configured_intervals_are_parsed_safely()
    {
        Assert.Equal(new[] { 30, 7 }, ReminderPlanner.ParseDays(" 7, 30,x,7 "));
        Assert.Equal(ReminderPlanner.DefaultDays, ReminderPlanner.ParseDays(""));
        Assert.Equal(ReminderPlanner.DefaultDays, ReminderPlanner.ParseDays(null));
    }

    [Theory]
    [InlineData(null, CoverageStatus.None)]
    [InlineData(-1, CoverageStatus.Expired)]
    [InlineData(0, CoverageStatus.ExpiringSoon)]
    [InlineData(30, CoverageStatus.ExpiringSoon)]
    [InlineData(31, CoverageStatus.Active)]
    public void Warranty_coverage_status(int? daysLeft, CoverageStatus expected)
    {
        DateTime? expiry = daysLeft is { } d ? Today.AddDays(d) : null;
        Assert.Equal(expected, CoverageEvaluator.Evaluate(expiry, Today, 30));
    }

    [Fact]
    public void Amc_status_moves_to_renewal_due_then_expired_but_keeps_final_states()
    {
        Assert.Equal(AmcRenewalStatus.Active, CoverageEvaluator.EvaluateAmc(AmcRenewalStatus.Active, Today.AddDays(60), Today));
        Assert.Equal(AmcRenewalStatus.RenewalDue, CoverageEvaluator.EvaluateAmc(AmcRenewalStatus.Active, Today.AddDays(20), Today));
        Assert.Equal(AmcRenewalStatus.Expired, CoverageEvaluator.EvaluateAmc(AmcRenewalStatus.RenewalDue, Today.AddDays(-1), Today));
        Assert.Equal(AmcRenewalStatus.Renewed, CoverageEvaluator.EvaluateAmc(AmcRenewalStatus.Renewed, Today.AddDays(-100), Today));
    }
}

public class VerificationReconcilerTests
{
    [Fact]
    public void Reconciliation_classifies_found_wrong_location_missing_and_unregistered()
    {
        var expected = new[] { new ExpectedAsset(1, 10), new ExpectedAsset(2, 10), new ExpectedAsset(3, 20) };
        var scans = new[]
        {
            new ScanRecord(1, "GAM-000001", 10),
            new ScanRecord(1, "GAM-000001", 10),      // duplicate scan
            new ScanRecord(2, "GAM-000002", 20),      // found in another room
            new ScanRecord(9, "GAM-000009", 10),      // registered elsewhere
            new ScanRecord(null, "OLD-TAG-77", 10),   // not in the register
        };
        var lines = VerificationReconciler.Reconcile(expected, scans, finalize: true);

        Assert.Equal(VerificationResult.Found, lines.Single(l => l.AssetId == 1).Result);
        Assert.Equal(VerificationResult.WrongLocation, lines.Single(l => l.AssetId == 2).Result);
        Assert.Equal(VerificationResult.Missing, lines.Single(l => l.AssetId == 3).Result);
        var outside = lines.Single(l => l.AssetId == 9);
        Assert.Equal(VerificationResult.WrongLocation, outside.Result);
        Assert.False(outside.IsExpected);
        Assert.Equal(VerificationResult.Unregistered, lines.Single(l => l.AssetId is null).Result);
        Assert.Equal(5, lines.Count);
    }

    [Fact]
    public void Unscanned_assets_stay_pending_until_the_session_is_finalized()
    {
        var lines = VerificationReconciler.Reconcile(new[] { new ExpectedAsset(5, null) }, Array.Empty<ScanRecord>(), finalize: false);
        Assert.Equal(VerificationResult.Pending, lines.Single().Result);
    }

    [Fact]
    public void Asset_without_recorded_location_counts_as_found()
    {
        var lines = VerificationReconciler.Reconcile(new[] { new ExpectedAsset(5, null) }, new[] { new ScanRecord(5, "x", 99) }, true);
        Assert.Equal(VerificationResult.Found, lines.Single().Result);
    }
}

public class WorkflowAndRulesTests
{
    [Fact]
    public void Repair_lifecycle_happy_path_is_allowed_step_by_step()
    {
        var path = new[]
        {
            ServiceRequestStatus.Submitted, ServiceRequestStatus.UnderReview, ServiceRequestStatus.Approved, ServiceRequestStatus.TechnicianAssigned,
            ServiceRequestStatus.Diagnosed, ServiceRequestStatus.EstimateSubmitted, ServiceRequestStatus.EstimateApproved, ServiceRequestStatus.AwaitingParts,
            ServiceRequestStatus.InProgress, ServiceRequestStatus.Testing, ServiceRequestStatus.Completed, ServiceRequestStatus.UserConfirmed, ServiceRequestStatus.Closed
        };
        for (int i = 1; i < path.Length; i++)
            Assert.True(ServiceRequestWorkflow.CanTransition(path[i - 1], path[i]), $"{path[i - 1]} -> {path[i]}");
    }

    [Theory]
    [InlineData(ServiceRequestStatus.Submitted, ServiceRequestStatus.Completed)]
    [InlineData(ServiceRequestStatus.Approved, ServiceRequestStatus.InProgress)]
    [InlineData(ServiceRequestStatus.Closed, ServiceRequestStatus.InProgress)]
    [InlineData(ServiceRequestStatus.Rejected, ServiceRequestStatus.Approved)]
    [InlineData(ServiceRequestStatus.EstimateSubmitted, ServiceRequestStatus.InProgress)]
    public void Invalid_repair_transitions_are_blocked(ServiceRequestStatus from, ServiceRequestStatus to)
    {
        Assert.False(ServiceRequestWorkflow.CanTransition(from, to));
        Assert.Throws<InvalidOperationException>(() => ServiceRequestWorkflow.EnsureTransition(from, to));
    }

    [Fact]
    public void Failed_test_and_unsatisfied_user_send_the_repair_back()
    {
        Assert.True(ServiceRequestWorkflow.CanTransition(ServiceRequestStatus.Testing, ServiceRequestStatus.InProgress));
        Assert.True(ServiceRequestWorkflow.CanTransition(ServiceRequestStatus.Completed, ServiceRequestStatus.InProgress));
    }

    [Fact]
    public void Repair_cost_and_downtime()
    {
        Assert.Equal(5310.50m, RepairCostCalculator.Total(1500, 2800, 200, 0, 810.50m));
        Assert.Equal(1250.13m, RepairCostCalculator.Line(2.5m, 500.05m));
        Assert.Equal(26.5m, RepairCostCalculator.DowntimeHours(new DateTime(2026, 1, 1, 8, 0, 0), new DateTime(2026, 1, 2, 10, 30, 0)));
        Assert.Equal(0m, RepairCostCalculator.DowntimeHours(null, DateTime.Now));
        Assert.Throws<ArgumentException>(() => RepairCostCalculator.Total(-1, 0, 0, 0, 0));
    }

    [Fact]
    public void Permissions_follow_the_role_matrix_and_super_admin_has_full_access()
    {
        var perms = new[]
        {
            new RolePermission { RoleName = Roles.Employee, Module = AppModule.Maintenance, CanView = true, CanCreate = true },
            new RolePermission { RoleName = Roles.FinanceUser, Module = AppModule.Depreciation, CanView = true, CanApprove = true },
        };
        Assert.True(PermissionEvaluator.IsAllowed(new[] { "employee" }, perms, AppModule.Maintenance, PermissionAction.Create));
        Assert.False(PermissionEvaluator.IsAllowed(new[] { Roles.Employee }, perms, AppModule.Maintenance, PermissionAction.Approve));
        Assert.False(PermissionEvaluator.IsAllowed(new[] { Roles.Employee }, perms, AppModule.Users, PermissionAction.View));
        Assert.True(PermissionEvaluator.IsAllowed(new[] { Roles.SuperAdministrator }, perms, AppModule.Users, PermissionAction.Delete));
        Assert.False(PermissionEvaluator.IsAllowed(Array.Empty<string>(), perms, AppModule.Dashboard, PermissionAction.View));
    }

    [Fact]
    public void Approval_rule_amount_ranges()
    {
        var rule = new ApprovalRule { MinAmount = 50000, MaxAmount = 200000, IsActive = true };
        Assert.False(rule.AppliesTo(49999.99m));
        Assert.True(rule.AppliesTo(50000m));
        Assert.True(rule.AppliesTo(200000m));
        Assert.False(rule.AppliesTo(200000.01m));
        Assert.True(new ApprovalRule { MinAmount = 0, IsActive = true }.AppliesTo(99999999m));
        Assert.False(new ApprovalRule { MinAmount = 0, IsActive = false }.AppliesTo(1m));
    }

    [Fact]
    public void Financial_year_and_document_numbers()
    {
        var fy = FinancialYear.For(new DateTime(2026, 10, 25));
        Assert.Equal("2026-27", fy.Label);
        Assert.Equal(new DateTime(2026, 4, 1), fy.Start);
        Assert.Equal(new DateTime(2027, 3, 31), fy.End);
        Assert.Equal("2025-26", FinancialYear.For(new DateTime(2026, 3, 31)).Label);
        Assert.Equal("2026", FinancialYear.For(new DateTime(2026, 6, 1), 1).Label);
        Assert.Equal(new DateTime(2025, 4, 1), FinancialYear.FromLabel("2025-26").Start);

        Assert.Equal("GAM-000042", DocumentNumbers.AssetTag("GAM", 42));
        Assert.Equal("PO/2026-27/0007", DocumentNumbers.Document("PO", "2026-27", 7));
        Assert.Equal("IT-HO-2026-0003", DocumentNumbers.AssetCode("it", "h o", 2026, 3));
    }

    [Fact]
    public void Purchase_order_totals_include_line_gst_and_other_charges()
    {
        var po = new PurchaseOrder { OtherCharges = 500 };
        po.Items.Add(new PurchaseOrderItem { Quantity = 2, UnitPrice = 45000, TaxRate = 18 });
        po.Items.Add(new PurchaseOrderItem { Quantity = 3, UnitPrice = 999.99m, TaxRate = 12 });
        po.RecalculateTotals();
        Assert.Equal(92999.97m, po.SubTotal);
        Assert.Equal(16560.00m, po.TaxTotal);
        Assert.Equal(110059.97m, po.GrandTotal);
    }
}
