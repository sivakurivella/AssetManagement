using System.IO.Compression;
using System.Text;
using GlobalAssetManagement.Application.Common.Documents;
using GlobalAssetManagement.Application.Common.Files;
using GlobalAssetManagement.Application.Common.Reporting;

namespace GlobalAssetManagement.Tests.Unit;

public class QrAndBarcodeTests
{
    [Fact]
    public void Short_asset_id_fits_in_a_version_1_qr_code()
    {
        var qr = QrCode.EncodeText("GAM-000123", QrErrorCorrection.M);
        Assert.Equal(1, qr.Version);
        Assert.Equal(21, qr.Size);
    }

    [Fact]
    public void Qr_code_has_three_finder_patterns()
    {
        var qr = QrCode.EncodeText("https://assets.example.in/a/GAM-000123");
        int s = qr.Size;
        foreach (var (x, y) in new[] { (0, 0), (s - 7, 0), (0, s - 7) })
        {
            for (int i = 0; i < 7; i++)
            {
                Assert.True(qr[x + i, y]);      // top edge of finder
                Assert.True(qr[x + i, y + 6]);  // bottom edge
                Assert.True(qr[x, y + i]);      // left edge
                Assert.True(qr[x + 6, y + i]);  // right edge
            }
            Assert.False(qr[x + 1, y + 1]);     // light ring
            Assert.True(qr[x + 3, y + 3]);      // dark centre
        }
    }

    [Fact]
    public void Longer_content_selects_a_larger_version_and_overflow_is_rejected()
    {
        var uri = "otpauth://totp/Global%20Asset%20Management:admin%40example.in?secret=JBSWY3DPEHPK3PXPJBSWY3DPEHPK3PXP&issuer=Global%20Asset%20Management&digits=6";
        var qr = QrCode.EncodeText(uri, QrErrorCorrection.L);
        Assert.InRange(qr.Version, 6, 10);
        Assert.Throws<ArgumentException>(() => QrCode.EncodeText(new string('x', 400), QrErrorCorrection.H));
    }

    [Fact]
    public void Qr_svg_is_well_formed()
    {
        var svg = QrCode.EncodeText("GAM-000001").ToSvg(4);
        Assert.StartsWith("<svg", svg);
        Assert.EndsWith("</svg>", svg);
        Assert.Contains("viewBox=\"0 0 29 29\"", svg); // 21 modules + 2 x 4 quiet zone
    }

    [Fact]
    public void Code128_pattern_table_and_checksum_are_correct()
    {
        var table = Code128Encoder.PatternTable;
        Assert.Equal(107, table.Count);
        for (int i = 0; i < 106; i++) Assert.Equal(11, table[i].Sum(c => c - '0'));
        Assert.Equal(13, table[106].Sum(c => c - '0'));

        var values = Code128Encoder.Encode("PJJ123C");
        Assert.Equal(104, values[0]);                 // start B
        Assert.Equal(55, values[^2]);                 // (104 + 48 + 42*2 + 42*3 + 17*4 + 18*5 + 19*6 + 35*7) mod 103
        Assert.Equal(106, values[^1]);                // stop
        Assert.Equal(11 * 9 + 13, Code128Encoder.Widths("PJJ123C").Sum());
    }

    [Fact]
    public void Code128_rejects_characters_outside_code_set_b()
    {
        Assert.Throws<ArgumentException>(() => Code128Encoder.Encode("ID\t1"));
        Assert.Throws<ArgumentException>(() => Code128Encoder.Encode(""));
    }
}

public class ExportTests
{
    private static ReportTable Sample(int rows = 3)
    {
        var t = new ReportTable { Title = "Complete Asset Register: Test/2026", OrganizationName = "S.S. Solutions", GeneratedAt = new DateTime(2026, 10, 25, 10, 30, 0), GeneratedBy = "admin" };
        t.Filters.Add("Branch: Head Office");
        t.AddColumn("Asset ID").AddColumn("Name").AddColumn("Purchased", ColumnKind.Date).AddColumn("Qty", ColumnKind.Integer, true).AddColumn("Cost", ColumnKind.Money, true);
        for (int i = 0; i < rows; i++)
            t.AddRow($"/Assets/Details/{i}", $"GAM-{i:D6}", i == 0 ? "=HYPERLINK(\"http://evil\")" : $"Laptop <{i}> & \"case\"", new DateTime(2025, 4, 1).AddDays(i), 1, 1000.50m * (i + 1));
        return t;
    }

    [Fact]
    public void Totals_row_sums_total_columns()
    {
        var totals = Sample().TotalsRow();
        Assert.Equal("TOTAL", totals[0]);
        Assert.Equal(3L, totals[3]);
        Assert.Equal(6003.00m, totals[4]);
    }

    [Fact]
    public void Row_with_wrong_column_count_is_rejected()
    {
        var t = Sample(0);
        Assert.Throws<InvalidOperationException>(() => t.AddRow(null, "only one"));
    }

    [Fact]
    public void Csv_has_bom_headers_and_neutralises_formula_injection()
    {
        var bytes = CsvExporter.Export(Sample());
        Assert.Equal(new byte[] { 0xEF, 0xBB, 0xBF }, bytes.Take(3).ToArray());
        var text = Encoding.UTF8.GetString(bytes, 3, bytes.Length - 3);
        Assert.Contains("Asset ID,Name,Purchased,Qty,Cost", text);
        Assert.Contains("'=HYPERLINK", text);
        Assert.Contains("\"Laptop <1> & \"\"case\"\"\"", text);
        Assert.Contains("2025-04-01", text);
    }

    [Fact]
    public void Excel_file_is_a_valid_open_xml_package()
    {
        var bytes = ExcelExporter.Export(Sample());
        using var zip = new ZipArchive(new MemoryStream(bytes), ZipArchiveMode.Read);
        var names = zip.Entries.Select(e => e.FullName).ToList();
        foreach (var n in new[] { "[Content_Types].xml", "_rels/.rels", "xl/workbook.xml", "xl/_rels/workbook.xml.rels", "xl/styles.xml", "xl/worksheets/sheet1.xml" })
            Assert.Contains(n, names);
        string workbook = new StreamReader(zip.GetEntry("xl/workbook.xml")!.Open()).ReadToEnd();
        Assert.DoesNotContain("/", workbook.Split("name=\"")[1].Split('"')[0]); // invalid sheet-name characters removed
        string sheet = new StreamReader(zip.GetEntry("xl/worksheets/sheet1.xml")!.Open()).ReadToEnd();
        Assert.Contains("Laptop &lt;1&gt; &amp;", sheet);
        Assert.Contains("<v>1000.50</v>", sheet);
        var doc = System.Xml.Linq.XDocument.Parse(sheet); // must be well-formed XML
        Assert.NotNull(doc.Root);
    }

    [Fact]
    public void Pdf_is_paginated_with_valid_structure()
    {
        var bytes = PdfExporter.Export(Sample(120));
        var text = Encoding.Latin1.GetString(bytes);
        Assert.StartsWith("%PDF-1.4", text);
        Assert.EndsWith("%%EOF\n", text);
        Assert.Contains("/Count 4", text);
        Assert.Contains("(Page 1 of 4)", text);
        Assert.Contains("startxref", text);
    }

    [Fact]
    public void Pdf_transliterates_the_rupee_sign()
    {
        var t = Sample(1);
        t.Columns[1] = t.Columns[1] with { Header = "Cost (₹)" };
        var text = Encoding.Latin1.GetString(PdfExporter.Export(t));
        Assert.Contains("Cost \\(Rs.\\)", text);
    }

    [Fact]
    public void Indian_number_formatting_is_used_for_money()
    {
        Assert.Equal("12,34,567.50", ReportTable.Format(1234567.5m, ColumnKind.Money));
        Assert.Equal("25-10-2026", ReportTable.Format(new DateTime(2026, 10, 25), ColumnKind.Date));
        Assert.Equal("Yes", ReportTable.Format(true, ColumnKind.Text));
    }
}

public class UploadValidatorTests
{
    private const long Max = 10 * 1024 * 1024;
    private static readonly byte[] Pdf = Encoding.ASCII.GetBytes("%PDF-1.7\n");
    private static readonly byte[] Exe = { 0x4D, 0x5A, 0x90, 0x00 };
    private static readonly byte[] Png = { 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0, 0 };

    [Fact]
    public void Valid_pdf_and_image_are_accepted()
    {
        Assert.True(UploadValidator.Validate("invoice.PDF", 2048, Pdf, UploadValidator.DocumentExtensions, Max).Ok);
        Assert.True(UploadValidator.Validate("photo.png", 2048, Png, UploadValidator.ImageExtensions, Max).Ok);
    }

    [Theory]
    [InlineData("malware.exe")]
    [InlineData("invoice.pdf.exe")]
    [InlineData("script.js")]
    [InlineData("noextension")]
    public void Disallowed_extensions_are_rejected(string name)
    {
        Assert.False(UploadValidator.Validate(name, 100, Pdf, UploadValidator.DocumentExtensions, Max).Ok);
    }

    [Fact]
    public void Renamed_executable_is_rejected_by_signature()
    {
        var r = UploadValidator.Validate("invoice.pdf", 100, Exe, UploadValidator.DocumentExtensions, Max);
        Assert.False(r.Ok);
        Assert.Contains("does not match", r.Error);
        Assert.False(UploadValidator.Validate("photo.jpg", 100, Pdf, UploadValidator.ImageExtensions, Max).Ok);
    }

    [Fact]
    public void Size_limits_and_empty_files_are_enforced()
    {
        Assert.False(UploadValidator.Validate("big.pdf", Max + 1, Pdf, UploadValidator.DocumentExtensions, Max).Ok);
        Assert.False(UploadValidator.Validate("empty.pdf", 0, Pdf, UploadValidator.DocumentExtensions, Max).Ok);
    }

    [Fact]
    public void Binary_content_disguised_as_text_is_rejected()
    {
        Assert.False(UploadValidator.Validate("notes.txt", 10, new byte[] { 65, 0, 66 }, UploadValidator.DocumentExtensions, Max).Ok);
        Assert.True(UploadValidator.Validate("notes.csv", 10, Encoding.UTF8.GetBytes("a,b,c"), UploadValidator.DocumentExtensions, Max).Ok);
    }
}
