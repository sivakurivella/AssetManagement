using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using GlobalAssetManagement.Domain.Logic;

namespace GlobalAssetManagement.Tests.Unit;

public class DepreciationTests
{
    private static readonly DateTime FyStart = new(2024, 4, 1);
    private static readonly DateTime FyEnd = new(2025, 3, 31);

    private static DepreciationProfile Slm(decimal cost = 100000, decimal residual = 5000, decimal life = 5, decimal acc = 0, DateTime? start = null, decimal rate = 0)
        => new(DepreciationMethod.StraightLine, rate, life, residual, start ?? FyStart, cost, acc);

    [Fact]
    public void StraightLine_full_year_equals_cost_less_residual_over_life()
    {
        var r = DepreciationCalculator.Calculate(Slm(), FyStart, FyEnd);
        Assert.Equal(365, r.Days);
        Assert.Equal(19000.00m, r.Amount);
        Assert.Equal(81000.00m, r.ClosingBookValue);
    }

    [Fact]
    public void StraightLine_partial_first_period_is_pro_rata_by_days()
    {
        var r = DepreciationCalculator.Calculate(Slm(start: new DateTime(2024, 10, 1)), FyStart, FyEnd);
        Assert.Equal(182, r.Days);
        Assert.Equal(9473.97m, r.Amount); // 95,000 x 182/365 / 5
    }

    [Fact]
    public void StraightLine_second_year_continues_at_same_annual_charge()
    {
        var r = DepreciationCalculator.Calculate(Slm(acc: 19000), new DateTime(2025, 4, 1), new DateTime(2026, 3, 31));
        Assert.Equal(19000.00m, r.Amount);
    }

    [Fact]
    public void Monthly_runs_add_up_to_the_annual_charge()
    {
        decimal acc = 0;
        for (int m = 0; m < 12; m++)
        {
            var from = FyStart.AddMonths(m);
            var to = from.AddMonths(1).AddDays(-1);
            acc += DepreciationCalculator.Calculate(Slm(acc: acc), from, to).Amount;
        }
        Assert.InRange(acc, 18999.90m, 19000.10m);
    }

    [Fact]
    public void Book_value_never_goes_below_residual_value()
    {
        // Asset in its last year with only 1,000 left above residual.
        var r = DepreciationCalculator.Calculate(Slm(acc: 94000, start: new DateTime(2020, 4, 1)), FyStart, FyEnd);
        Assert.Equal(1000.00m, r.Amount);
        Assert.Equal(5000.00m, r.ClosingBookValue);
    }

    [Fact]
    public void Fully_depreciated_asset_gets_no_further_depreciation()
    {
        var r = DepreciationCalculator.Calculate(Slm(acc: 95000, start: new DateTime(2018, 4, 1)), FyStart, FyEnd);
        Assert.Equal(0m, r.Amount);
        Assert.Equal(5000m, r.ClosingBookValue);
    }

    [Fact]
    public void Asset_past_its_useful_life_is_written_down_to_residual()
    {
        var r = DepreciationCalculator.Calculate(Slm(acc: 80000, start: new DateTime(2015, 4, 1)), FyStart, FyEnd);
        Assert.Equal(15000.00m, r.Amount);
    }

    [Fact]
    public void Not_depreciated_and_not_yet_started_assets_return_zero()
    {
        var none = new DepreciationProfile(DepreciationMethod.None, 0, 5, 0, FyStart, 100000, 0);
        Assert.Equal(0m, DepreciationCalculator.Calculate(none, FyStart, FyEnd).Amount);
        var future = DepreciationCalculator.Calculate(Slm(start: new DateTime(2025, 6, 1)), FyStart, FyEnd);
        Assert.Equal(0m, future.Amount);
        Assert.Equal(0, future.Days);
    }

    [Fact]
    public void WrittenDownValue_applies_rate_to_opening_book_value()
    {
        var p1 = new DepreciationProfile(DepreciationMethod.WrittenDownValue, 40, 0, 0, FyStart, 100000, 0);
        var y1 = DepreciationCalculator.Calculate(p1, FyStart, FyEnd);
        Assert.Equal(40000.00m, y1.Amount);
        var p2 = p1 with { AccumulatedAtStart = y1.ClosingAccumulated };
        var y2 = DepreciationCalculator.Calculate(p2, new DateTime(2025, 4, 1), new DateTime(2026, 3, 31));
        Assert.Equal(24000.00m, y2.Amount);
    }

    [Fact]
    public void WrittenDownValue_partial_year_is_pro_rata()
    {
        var p = new DepreciationProfile(DepreciationMethod.WrittenDownValue, 15, 0, 0, new DateTime(2024, 10, 1), 200000, 0);
        var r = DepreciationCalculator.Calculate(p, FyStart, FyEnd);
        Assert.Equal(14958.90m, r.Amount); // 200,000 x 15% x 182/365
    }

    [Fact]
    public void StraightLine_with_custom_rate_uses_rate_on_cost()
    {
        var r = DepreciationCalculator.Calculate(Slm(cost: 100000, residual: 0, rate: 10), FyStart, FyEnd);
        Assert.Equal(10000.00m, r.Amount);
    }

    [Fact]
    public void Capitalized_addition_mid_period_increases_depreciation_from_its_date()
    {
        var withoutAddition = DepreciationCalculator.Calculate(Slm(residual: 0), FyStart, FyEnd);
        var withAddition = DepreciationCalculator.Calculate(Slm(residual: 0), FyStart, FyEnd,
            new[] { new CapitalAddition(new DateTime(2024, 10, 1), 10000m) });

        Assert.Equal(20000.00m, withoutAddition.Amount);
        Assert.Equal(10000m, withAddition.Additions);
        Assert.Equal(110000m, withAddition.ClosingGross);
        // The addition is spread over the remaining 4.5 years of life: about 10,000 x 0.5 / 4.5 extra this year.
        Assert.InRange(withAddition.Amount - withoutAddition.Amount, 1100m, 1125m);
    }

    [Fact]
    public void Revised_useful_life_on_addition_changes_the_remaining_charge()
    {
        var revised = DepreciationCalculator.Calculate(Slm(residual: 0), FyStart, FyEnd,
            new[] { new CapitalAddition(new DateTime(2024, 10, 1), 10000m, RevisedUsefulLifeYears: 8) });
        var normal = DepreciationCalculator.Calculate(Slm(residual: 0), FyStart, FyEnd,
            new[] { new CapitalAddition(new DateTime(2024, 10, 1), 10000m) });
        Assert.True(revised.Amount < normal.Amount);
    }

    [Fact]
    public void Period_end_before_start_is_rejected()
    {
        Assert.Throws<ArgumentException>(() => DepreciationCalculator.Calculate(Slm(), FyEnd, FyStart));
    }

    [Fact]
    public void Wdv_rate_derived_from_life_reduces_cost_to_residual()
    {
        decimal rate = DepreciationCalculator.WdvRateFromLife(100000, 5000, 5);
        Assert.InRange(rate, 45.06m, 45.08m);
        decimal bv = 100000;
        for (int y = 0; y < 5; y++) bv -= bv * rate / 100m;
        Assert.InRange(bv, 4995m, 5005m);
    }

    [Fact]
    public void Capitalized_cost_excludes_gst_when_input_credit_is_claimed()
    {
        Assert.Equal(51500m, Asset.ComputeCapitalizedCost(50000, 9000, true, 1000, 500));
        Assert.Equal(60500m, Asset.ComputeCapitalizedCost(50000, 9000, false, 1000, 500));
    }

    [Fact]
    public void Disposal_profit_or_loss_compares_proceeds_with_book_value()
    {
        Assert.Equal(-2500.50m, DisposalCalculator.ProfitOrLoss(10000m, 12500.50m));
        Assert.Equal(1500m, DisposalCalculator.ProfitOrLoss(4000m, 2500m));
        Assert.True(DisposalCalculator.HasProceeds(DisposalMethod.Sale));
        Assert.False(DisposalCalculator.HasProceeds(DisposalMethod.Lost));
        Assert.Equal(AssetStatus.LostOrWrittenOff, DisposalCalculator.FinalAssetStatus(DisposalMethod.WriteOff));
        Assert.Equal(AssetStatus.Disposed, DisposalCalculator.FinalAssetStatus(DisposalMethod.Scrap));
    }
}
