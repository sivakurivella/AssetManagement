using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Application.Models;
using GlobalAssetManagement.Application.Services;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using GlobalAssetManagement.Domain.Logic;
using Microsoft.EntityFrameworkCore;

namespace GlobalAssetManagement.Tests.Integration;

[Trait("Category", "Integration")]
public class AllocationTests
{
    [Fact]
    public async Task Issue_acknowledge_transfer_and_return_keep_custody_history()
    {
        using var h = await TestHost.CreateAsync();
        var a = await h.NewAssetAsync();
        var svc = h.Get<AllocationService>();

        var issue = await svc.IssueAsync(new IssueInput { AssetId = a.Id, EmployeeId = h.Ravi.Id, AccessoriesIssued = "Charger, bag" });
        var asset = await h.Db.Assets.FirstAsync(x => x.Id == a.Id);
        Assert.Equal(h.Ravi.Id, asset.AssignedEmployeeId);
        Assert.Equal(AssetStatus.InService, asset.Status);
        await Assert.ThrowsAsync<BusinessException>(() => svc.IssueAsync(new IssueInput { AssetId = a.Id, EmployeeId = h.Lakshmi.Id })); // already issued

        await svc.AcknowledgeAsync(issue.Id, "Received in good condition");
        Assert.True((await h.Db.AssetAllocations.FindAsync(issue.Id))!.IsAcknowledged);

        var transfer = await svc.RequestTransferAsync(new TransferInput { AssetId = a.Id, TransferType = TransferType.Employee, ToEmployeeId = h.Lakshmi.Id, Reason = "Role change", TransferDate = h.Clock.Today });
        Assert.Equal(TransferStatus.Completed, transfer.Status);   // no approval rules configured
        Assert.Equal(AllocationStatus.Returned, (await h.Db.AssetAllocations.FindAsync(issue.Id))!.Status);
        var current = await h.Db.AssetAllocations.SingleAsync(x => x.AssetId == a.Id && x.Status == AllocationStatus.Active);
        Assert.Equal(h.Lakshmi.Id, current.EmployeeId);

        await svc.ReturnAsync(new ReturnInput { AllocationId = current.Id, ReturnDate = h.Clock.Today, ReturnCondition = AssetCondition.Damaged, Remarks = "Screen cracked" });
        asset = await h.Db.Assets.AsNoTracking().FirstAsync(x => x.Id == a.Id);
        Assert.Null(asset.AssignedEmployeeId);
        Assert.Equal(AssetStatus.UnderRepair, asset.Status);       // damaged returns go to repair
        Assert.Equal(2, await h.Db.AssetReturns.CountAsync(r => r.AssetId == a.Id));
        Assert.Contains(await h.Db.AssetEvents.Where(e => e.AssetId == a.Id).Select(e => e.EventType).ToListAsync(), t => t == AssetEventType.Transferred);
    }

    [Fact]
    public async Task Temporary_loans_need_a_return_date_and_overdue_loans_are_listed()
    {
        using var h = await TestHost.CreateAsync();
        var a = await h.NewAssetAsync();
        var svc = h.Get<AllocationService>();
        await Assert.ThrowsAsync<BusinessException>(() => svc.IssueAsync(new IssueInput { AssetId = a.Id, EmployeeId = h.Ravi.Id, IsTemporaryLoan = true }));
        await svc.IssueAsync(new IssueInput { AssetId = a.Id, EmployeeId = h.Ravi.Id, IsTemporaryLoan = true, ExpectedReturnDate = h.Clock.Today.AddDays(3) });
        Assert.Empty(await svc.OverdueAsync());
        h.Clock.Advance(TimeSpan.FromDays(5));
        Assert.Single(await svc.OverdueAsync());
    }

    [Fact]
    public async Task Location_transfer_rejects_locations_of_another_branch()
    {
        using var h = await TestHost.CreateAsync();
        var a = await h.NewAssetAsync();
        var vja = await h.Db.Branches.FirstAsync(b => b.Code == "VJA");
        var vjaRoom = new Location { BranchId = vja.Id, Code = "V1", Building = "VJA", Room = "Store" };
        h.Db.Locations.Add(vjaRoom);
        await h.Db.SaveChangesAsync();
        var svc = h.Get<AllocationService>();
        await Assert.ThrowsAsync<BusinessException>(() => svc.RequestTransferAsync(new TransferInput { AssetId = a.Id, TransferType = TransferType.Location, ToLocationId = vjaRoom.Id, Reason = "x" }));
        var t = await svc.RequestTransferAsync(new TransferInput { AssetId = a.Id, TransferType = TransferType.Branch, ToBranchId = vja.Id, ToLocationId = vjaRoom.Id, Reason = "Branch opening" });
        Assert.Equal(TransferStatus.Completed, t.Status);
        Assert.Equal(vja.Id, (await h.Db.Assets.AsNoTracking().FirstAsync(x => x.Id == a.Id)).BranchId);
    }
}

[Trait("Category", "Integration")]
public class AdditionTests
{
    [Fact]
    public async Task Capital_improvement_increases_gross_cost_and_revenue_expense_does_not()
    {
        using var h = await TestHost.CreateAsync();
        var a = await h.NewAssetAsync(cost: 60000);
        var svc = h.Get<AdditionService>();

        var ram = await svc.CreateAsync(new AdditionInput { AssetId = a.Id, Description = "RAM upgrade 16 GB", Cost = 6000, TaxAmount = 1080, GstInputCreditClaimed = true, AdditionDate = h.Clock.Today });
        var clean = await svc.CreateAsync(new AdditionInput { AssetId = a.Id, Description = "Keyboard cleaning", Cost = 500, AdditionDate = h.Clock.Today });

        await svc.ClassifyAsync(new ClassifyAdditionInput { Id = ram.Id, ExpenditureType = ExpenditureType.CapitalImprovement, RevisedUsefulLifeYears = 4 });
        await svc.ClassifyAsync(new ClassifyAdditionInput { Id = clean.Id, ExpenditureType = ExpenditureType.RevenueExpense });

        var asset = await h.Db.Assets.AsNoTracking().FirstAsync(x => x.Id == a.Id);
        Assert.Equal(6000m, asset.CapitalizedAdditions);
        Assert.Equal(66000m, asset.GrossCost);
        Assert.Equal(66000m, asset.CurrentBookValue);
        Assert.Equal(4m, asset.UsefulLifeYears);
        Assert.Equal(AdditionStatus.Capitalized, (await h.Db.AssetAdditions.FindAsync(ram.Id))!.Status);
        Assert.Equal(AdditionStatus.Expensed, (await h.Db.AssetAdditions.FindAsync(clean.Id))!.Status);
        await Assert.ThrowsAsync<BusinessException>(() => svc.ClassifyAsync(new ClassifyAdditionInput { Id = ram.Id, ExpenditureType = ExpenditureType.RevenueExpense }));
    }
}

[Trait("Category", "Integration")]
public class MaintenanceTests
{
    [Fact]
    public async Task Repair_request_goes_through_the_full_lifecycle_with_costs_and_downtime()
    {
        using var h = await TestHost.CreateAsync();
        var a = await h.NewAssetAsync();
        var m = h.Get<MaintenanceService>();

        var sr = await m.CreateRequestAsync(new ServiceRequestInput { AssetId = a.Id, FaultDescription = "Laptop does not power on", Priority = Priority.High, AssetDown = true });
        Assert.Equal(ServiceRequestStatus.Submitted, sr.Status);
        await Assert.ThrowsAsync<BusinessException>(() => m.CreateRequestAsync(new ServiceRequestInput { AssetId = a.Id, FaultDescription = "Same fault again" }));

        await m.ReviewAsync(sr.Id, "Checked by IT desk");
        await m.DecideRequestAsync(sr.Id, true, null);
        Assert.Equal(AssetStatus.UnderRepair, (await h.Db.Assets.FindAsync(a.Id))!.Status);

        var wo = await m.AssignAsync(sr.Id, new WorkOrderInput { TechnicianName = "Suresh", ServiceProviderId = h.Provider.Id });
        Assert.Equal(WorkOrderStatus.Assigned, wo.Status);
        await m.DiagnoseAsync(wo.Id, "Faulty DC jack", "DC jack");
        await m.SubmitEstimateAsync(new EstimateInput { ServiceRequestId = sr.Id, LabourCharges = 1000, PartsCost = 1500, TravelCharges = 200 });
        Assert.Equal(ServiceRequestStatus.EstimateApproved, (await h.Db.ServiceRequests.FindAsync(sr.Id))!.Status);

        await m.StartWorkAsync(wo.Id);
        await m.AddLabourAsync(wo.Id, new WorkOrderLabour { TechnicianName = "Suresh", Hours = 2, RatePerHour = 500 });
        await m.AddPartAsync(wo.Id, new WorkOrderPart { PartName = "DC jack", Quantity = 1, UnitCost = 1500 });
        await m.SubmitForTestingAsync(wo.Id);
        await Assert.ThrowsAsync<BusinessException>(() => m.RecordQualityCheckAsync(wo.Id, false, ""));
        await m.RecordQualityCheckAsync(wo.Id, true, "Charges and boots normally");

        h.Clock.Advance(TimeSpan.FromHours(26));
        await m.CompleteWorkAsync(new WorkOrderCompletionInput { WorkOrderId = wo.Id, TravelCharges = 200, ServiceReport = "Replaced DC jack", RepairWarrantyMonths = 3 });

        var done = await m.LoadWorkOrderAsync(wo.Id);
        Assert.Equal(1000m, done.LabourCharges);
        Assert.Equal(1500m, done.PartsCost);
        Assert.Equal(2700m, done.TotalCost);
        Assert.Equal(26m, done.DowntimeHours);
        Assert.Equal(AssetStatus.InService, (await h.Db.Assets.AsNoTracking().FirstAsync(x => x.Id == a.Id)).Status);
        Assert.True(await h.Db.WarrantyRecords.AnyAsync(w => w.AssetId == a.Id && w.WarrantyType == WarrantyType.Repair));
        Assert.True(await h.Db.MaintenanceHistory.AnyAsync(x => x.WorkOrderId == wo.Id && x.Cost == 2700m));

        await m.ConfirmAsync(sr.Id, true, 5, "Working fine");
        await m.CloseRequestAsync(sr.Id);
        Assert.Equal(ServiceRequestStatus.Closed, (await h.Db.ServiceRequests.AsNoTracking().FirstAsync(x => x.Id == sr.Id)).Status);
        Assert.Equal(WorkOrderStatus.Closed, (await h.Db.WorkOrders.AsNoTracking().FirstAsync(x => x.Id == wo.Id)).Status);
    }

    [Fact]
    public async Task Repair_cannot_skip_workflow_steps()
    {
        using var h = await TestHost.CreateAsync();
        var a = await h.NewAssetAsync();
        var m = h.Get<MaintenanceService>();
        var sr = await m.CreateRequestAsync(new ServiceRequestInput { AssetId = a.Id, FaultDescription = "No display" });
        await Assert.ThrowsAsync<InvalidOperationException>(() => m.CloseRequestAsync(sr.Id));
        await Assert.ThrowsAsync<InvalidOperationException>(() => m.AssignAsync(sr.Id, new WorkOrderInput { TechnicianName = "X" }));
        await Assert.ThrowsAsync<BusinessException>(() => m.DecideRequestAsync(sr.Id, false, null)); // rejection needs a reason
    }

    [Fact]
    public async Task Preventive_schedule_generates_one_work_order_per_due_date()
    {
        using var h = await TestHost.CreateAsync();
        var a = await h.NewAssetAsync();
        var m = h.Get<MaintenanceService>();
        var s = await m.SaveScheduleAsync(new ScheduleInput { AssetId = a.Id, Title = "Quarterly cleaning", Frequency = MaintenanceFrequency.Quarterly, StartDate = h.Clock.Today.AddDays(5), LeadDays = 7, AssignedTechnician = "Suresh" });
        Assert.Equal(h.Clock.Today.AddDays(5), s.NextDueDate);
        Assert.Equal(s.NextDueDate, (await h.Db.Assets.AsNoTracking().FirstAsync(x => x.Id == a.Id)).NextServiceDate);

        Assert.Equal(1, await m.GenerateDueWorkOrdersAsync());
        Assert.Equal(0, await m.GenerateDueWorkOrdersAsync()); // idempotent
        var wo = await h.Db.WorkOrders.SingleAsync(w => w.MaintenanceScheduleId == s.Id);
        Assert.Equal(WorkOrderStatus.Assigned, wo.Status);

        await m.StartWorkAsync(wo.Id);
        Assert.Equal(AssetStatus.UnderMaintenance, (await h.Db.Assets.FindAsync(a.Id))!.Status);
        await m.CompleteWorkAsync(new WorkOrderCompletionInput { WorkOrderId = wo.Id, ServiceReport = "Cleaned fan and vents" });
        var sched = await h.Db.MaintenanceSchedules.AsNoTracking().FirstAsync(x => x.Id == s.Id);
        Assert.Equal(h.Clock.Today.AddDays(5).AddMonths(3), sched.NextDueDate);
        Assert.Equal(AssetStatus.InService, (await h.Db.Assets.AsNoTracking().FirstAsync(x => x.Id == a.Id)).Status);
    }
}

[Trait("Category", "Integration")]
public class WarrantyAndReminderTests
{
    [Fact]
    public async Task Reminders_are_raised_once_per_threshold_and_not_duplicated()
    {
        using var h = await TestHost.CreateAsync();
        await h.NewAssetAsync(warrantyExpiry: h.Clock.Today.AddDays(20));
        var r = h.Get<ReminderService>();

        int first = await r.GenerateAsync();
        Assert.Equal(1, first);                                  // 30-day bucket
        Assert.Equal(0, await r.GenerateAsync());                // same bucket -> no duplicate

        h.Clock.Advance(TimeSpan.FromDays(6));                   // now 14 days to expiry -> 15-day bucket
        Assert.Equal(1, await r.GenerateAsync());
        Assert.Equal(0, await r.GenerateAsync());

        var keys = await h.Db.Notifications.Where(n => n.AlertType == AlertType.WarrantyExpiry).Select(n => n.DedupKey).ToListAsync();
        Assert.Equal(2, keys.Count);
        Assert.Equal(keys.Count, keys.Distinct().Count());
    }

    [Fact]
    public async Task Disabled_alert_type_raises_nothing()
    {
        using var h = await TestHost.CreateAsync();
        h.Db.NotificationSettings.Add(new NotificationSetting { AlertType = AlertType.WarrantyExpiry, IsEnabled = false });
        await h.Db.SaveChangesAsync();
        await h.NewAssetAsync(warrantyExpiry: h.Clock.Today.AddDays(7));
        await h.Get<ReminderService>().GenerateAsync();
        Assert.False(await h.Db.Notifications.AnyAsync(n => n.AlertType == AlertType.WarrantyExpiry));
    }

    [Fact]
    public async Task Amc_renewal_creates_a_linked_contract_covering_the_same_assets()
    {
        using var h = await TestHost.CreateAsync();
        var a1 = await h.NewAssetAsync();
        var a2 = await h.NewAssetAsync();
        var w = h.Get<WarrantyAmcService>();
        var c = await w.SaveAmcAsync(new AmcInput
        {
            ContractNo = "AMC-01", ServiceProviderId = h.Provider.Id, StartDate = h.Clock.Today.AddYears(-1).AddDays(20),
            ExpiryDate = h.Clock.Today.AddDays(19), AnnualValue = 24000, VisitsPerYear = 4, AssetIds = { a1.Id, a2.Id }
        });
        await w.RefreshStatusesAsync();
        Assert.Equal(AmcRenewalStatus.RenewalDue, (await h.Db.AMContracts.AsNoTracking().FirstAsync(x => x.Id == c.Id)).RenewalStatus);

        await Assert.ThrowsAsync<BusinessException>(() => w.RequestRenewalAsync(c.Id, 0));
        await w.RequestRenewalAsync(c.Id, 26000);

        var renewed = await h.Db.AMContracts.Include(x => x.CoveredAssets).SingleAsync(x => x.RenewedFromContractId == c.Id);
        Assert.Equal("AMC-01/R1", renewed.ContractNo);
        Assert.Equal(26000m, renewed.AnnualValue);
        Assert.Equal(c.ExpiryDate.AddDays(1), renewed.StartDate);
        Assert.Equal(2, renewed.CoveredAssets.Count);
        Assert.Equal(4, await h.Db.ServiceVisits.CountAsync(v => v.AMContractId == renewed.Id));
        Assert.Equal(AmcRenewalStatus.Renewed, (await h.Db.AMContracts.AsNoTracking().FirstAsync(x => x.Id == c.Id)).RenewalStatus);
    }
}
