using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Application.Models;
using GlobalAssetManagement.Application.Services;
using GlobalAssetManagement.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace GlobalAssetManagement.Tests.Integration;

[Trait("Category", "Integration")]
public class DepreciationPostingTests
{
    private static readonly DateTime FyStart = new(2025, 4, 1), FyEnd = new(2026, 3, 31);

    [Fact]
    public async Task Posting_updates_book_value_and_cannot_be_repeated_for_the_same_period()
    {
        using var h = await TestHost.CreateAsync();
        var a = await h.NewAssetAsync(cost: 60000, purchase: FyStart);       // residual 3,000, 3 years SLM
        var svc = h.Get<DepreciationService>();

        var preview = await svc.PreviewAsync(FyStart, FyEnd, null);
        Assert.Equal(19000.00m, preview.Single().Result.Amount);

        var run = await svc.PostAsync(FyStart, FyEnd, null, "FY 2025-26");
        Assert.Equal(DepreciationRunStatus.Posted, run.Status);
        Assert.Equal(19000.00m, run.TotalDepreciation);
        Assert.Equal("2025-26", run.FinancialYear);

        var asset = await h.Db.Assets.AsNoTracking().FirstAsync(x => x.Id == a.Id);
        Assert.Equal(19000.00m, asset.AccumulatedDepreciation);
        Assert.Equal(41000.00m, asset.CurrentBookValue);
        Assert.Equal(FyEnd, asset.DepreciatedUpTo);

        await Assert.ThrowsAsync<BusinessException>(() => svc.PostAsync(FyStart, FyEnd, null, null)); // no double posting
        Assert.Equal(1, await h.Db.DepreciationTransactions.CountAsync(t => t.AssetId == a.Id));
    }

    [Fact]
    public async Task Reversal_restores_book_value_and_only_latest_run_can_be_reversed()
    {
        using var h = await TestHost.CreateAsync();
        var a = await h.NewAssetAsync(cost: 60000, purchase: FyStart);
        var svc = h.Get<DepreciationService>();
        var h1 = await svc.PostAsync(FyStart, new DateTime(2025, 9, 30), null, null);
        var h2 = await svc.PostAsync(new DateTime(2025, 10, 1), FyEnd, null, null);
        Assert.Equal(19000.00m, h1.TotalDepreciation + h2.TotalDepreciation);

        await Assert.ThrowsAsync<BusinessException>(() => svc.ReverseAsync(h1.Id, "wrong"));   // later run exists
        await Assert.ThrowsAsync<BusinessException>(() => svc.ReverseAsync(h2.Id, ""));        // reason required
        await svc.ReverseAsync(h2.Id, "Rate correction");

        var asset = await h.Db.Assets.AsNoTracking().FirstAsync(x => x.Id == a.Id);
        Assert.Equal(h1.TotalDepreciation, asset.AccumulatedDepreciation);
        Assert.Equal(new DateTime(2025, 9, 30), asset.DepreciatedUpTo);
        Assert.Equal(DepreciationRunStatus.Reversed, (await h.Db.DepreciationSchedules.AsNoTracking().FirstAsync(r => r.Id == h2.Id)).Status);
    }
}

[Trait("Category", "Integration")]
public class DisposalTests
{
    [Fact]
    public async Task Sale_catches_up_depreciation_computes_profit_and_locks_the_record()
    {
        using var h = await TestHost.CreateAsync();
        var a = await h.NewAssetAsync(cost: 60000, purchase: new DateTime(2025, 4, 1));
        await h.Get<AllocationService>().IssueAsync(new IssueInput { AssetId = a.Id, EmployeeId = h.Ravi.Id });
        await h.Get<DepreciationService>().PostAsync(new DateTime(2025, 4, 1), new DateTime(2026, 3, 31), null, null);
        var svc = h.Get<DisposalService>();

        var d = await svc.RequestAsync(new DisposalInput { AssetId = a.Id, Method = DisposalMethod.Sale, Reason = "Upgrade cycle", ExpectedValue = 30000, ProposedDisposalDate = h.Clock.Today });
        Assert.Equal(DisposalStatus.Approved, d.Status);  // no approval rules
        await Assert.ThrowsAsync<BusinessException>(() => svc.RequestAsync(new DisposalInput { AssetId = a.Id, Reason = "dup" }));
        await Assert.ThrowsAsync<BusinessException>(() => svc.CompleteAsync(new CompleteDisposalInput { Id = d.Id, DisposalDate = new DateTime(2026, 3, 1), DisposalValue = 1 })); // inside posted period
        await Assert.ThrowsAsync<BusinessException>(() => svc.CompleteAsync(new CompleteDisposalInput { Id = d.Id, DisposalDate = h.Clock.Today.AddDays(1), DisposalValue = 1 })); // future

        var date = new DateTime(2026, 10, 1);
        var preview = await svc.PreviewAsync(d.Id, date, 35000);
        var done = await svc.CompleteAsync(new CompleteDisposalInput { Id = d.Id, DisposalDate = date, DisposalValue = 35000, BuyerOrRecipient = "Staff buyback" });

        Assert.True(done.IsLocked);
        Assert.Equal(preview.BookValue, done.BookValueAtDisposal);
        Assert.Equal(done.GrossCostAtDisposal - done.AccumulatedDepreciationAtDisposal, done.BookValueAtDisposal);
        Assert.Equal(35000m - done.BookValueAtDisposal, done.ProfitOrLoss);
        Assert.True(done.AccumulatedDepreciationAtDisposal > 19000m);    // catch-up from 01-04-2026 to 30-09-2026

        var asset = await h.Db.Assets.AsNoTracking().FirstAsync(x => x.Id == a.Id);
        Assert.Equal(AssetStatus.Disposed, asset.Status);
        Assert.Equal(0m, asset.CurrentBookValue);
        Assert.Null(asset.AssignedEmployeeId);
        Assert.False(await h.Db.AssetAllocations.AnyAsync(x => x.AssetId == a.Id && x.Status == AllocationStatus.Active));
        await Assert.ThrowsAsync<BusinessException>(() => svc.CompleteAsync(new CompleteDisposalInput { Id = d.Id, DisposalDate = date }));
        await Assert.ThrowsAsync<BusinessException>(() => h.Get<AllocationService>().IssueAsync(new IssueInput { AssetId = a.Id, EmployeeId = h.Lakshmi.Id }));
    }

    [Fact]
    public async Task Lost_asset_has_no_proceeds_and_is_written_off()
    {
        using var h = await TestHost.CreateAsync();
        var a = await h.NewAssetAsync(cost: 10000, purchase: h.Clock.Today.AddDays(-10));
        var svc = h.Get<DisposalService>();
        var d = await svc.RequestAsync(new DisposalInput { AssetId = a.Id, Method = DisposalMethod.Lost, Reason = "Stolen from car", ExpectedValue = 5000 });
        var done = await svc.CompleteAsync(new CompleteDisposalInput { Id = d.Id, DisposalDate = h.Clock.Today, DisposalValue = 5000 });
        Assert.Equal(0m, done.DisposalValue);
        Assert.True(done.ProfitOrLoss < 0);
        Assert.Equal(AssetStatus.LostOrWrittenOff, (await h.Db.Assets.AsNoTracking().FirstAsync(x => x.Id == a.Id)).Status);
    }
}

[Trait("Category", "Integration")]
public class VerificationTests
{
    [Fact]
    public async Task Session_reconciles_found_wrong_location_missing_and_unregistered()
    {
        using var h = await TestHost.CreateAsync();
        var found = await h.NewAssetAsync("Found", locationId: h.Room1.Id);
        var moved = await h.NewAssetAsync("Moved", locationId: h.Room1.Id);
        var missing = await h.NewAssetAsync("Missing", locationId: h.Room1.Id);
        var svc = h.Get<VerificationService>();

        var s = await svc.CreateSessionAsync(new VerificationSessionInput { Title = "Q3 audit", BranchId = h.Branch.Id });
        Assert.Equal(3, s.Items.Count);

        var r1 = await svc.ScanAsync(new ScanInput { SessionId = s.Id, Code = found.AssetTag, FoundLocationId = h.Room1.Id });
        Assert.Equal(VerificationResult.Found, r1.Result);
        var r2 = await svc.ScanAsync(new ScanInput { SessionId = s.Id, Code = moved.AssetCode, FoundLocationId = h.Room2.Id });
        Assert.Equal(VerificationResult.WrongLocation, r2.Result);
        var r3 = await svc.ScanAsync(new ScanInput { SessionId = s.Id, Code = "UNKNOWN-42", FoundLocationId = h.Room1.Id });
        Assert.Equal(VerificationResult.Unregistered, r3.Result);

        await svc.SubmitAsync(s.Id);
        var items = await h.Db.PhysicalVerificationItems.AsNoTracking().Where(i => i.SessionId == s.Id).ToListAsync();
        Assert.Equal(VerificationResult.Missing, items.Single(i => i.AssetId == missing.Id).Result);
        Assert.Equal(VerificationResult.Found, items.Single(i => i.AssetId == found.Id).Result);
        Assert.Single(items, i => i.Result == VerificationResult.Unregistered);

        Assert.Equal(VerificationSessionStatus.Approved, (await h.Db.PhysicalVerificationSessions.AsNoTracking().FirstAsync(x => x.Id == s.Id)).Status);
        Assert.Equal(h.Room2.Id, (await h.Db.Assets.AsNoTracking().FirstAsync(x => x.Id == moved.Id)).LocationId); // location corrected
        await Assert.ThrowsAsync<BusinessException>(() => svc.ScanAsync(new ScanInput { SessionId = s.Id, Code = found.AssetTag }));
    }
}

[Trait("Category", "Integration")]
public class ReportAndDashboardTests
{
    private static async Task<TestHost> PopulatedAsync()
    {
        var h = await TestHost.CreateAsync();
        var a = await h.NewAssetAsync(cost: 60000, purchase: new DateTime(2025, 4, 1), warrantyExpiry: h.Clock.Today.AddDays(10));
        var b = await h.NewAssetAsync(cost: 40000, purchase: new DateTime(2026, 5, 10));
        await h.Get<AllocationService>().IssueAsync(new IssueInput { AssetId = a.Id, EmployeeId = h.Ravi.Id });
        await h.Get<MaintenanceService>().CreateRequestAsync(new ServiceRequestInput { AssetId = b.Id, FaultDescription = "Fan noise" });
        await h.Get<DepreciationService>().PostAsync(new DateTime(2025, 4, 1), new DateTime(2026, 3, 31), null, null);
        return h;
    }

    [Fact]
    public async Task Every_report_runs_and_exports()
    {
        using var h = await PopulatedAsync();
        var svc = h.Get<ReportService>();
        Assert.Equal(28, ReportService.Definitions.Count);
        Assert.Equal(28, ReportService.Definitions.Select(d => d.Key).Distinct(StringComparer.OrdinalIgnoreCase).Count());
        foreach (var def in ReportService.Definitions)
        {
            var table = await svc.RunAsync(def.Key, new ReportFilter { From = new DateTime(2025, 4, 1), To = h.Clock.Today }, includeFinancial: true);
            Assert.False(string.IsNullOrWhiteSpace(table.Title));
            Assert.NotEmpty(table.Columns);
            Assert.NotEmpty(Application.Common.Reporting.CsvExporter.Export(table));
            Assert.NotEmpty(Application.Common.Reporting.ExcelExporter.Export(table));
            Assert.NotEmpty(Application.Common.Reporting.PdfExporter.Export(table));
        }
        var register = await svc.RunAsync("asset-register", new ReportFilter(), true);
        Assert.Equal(2, register.Rows.Count);
    }

    [Fact]
    public async Task Financial_columns_are_hidden_without_financial_access()
    {
        using var h = await PopulatedAsync();
        var withMoney = await h.Get<ReportService>().RunAsync("asset-register", new ReportFilter(), true);
        var without = await h.Get<ReportService>().RunAsync("asset-register", new ReportFilter(), false);
        Assert.Contains(withMoney.Columns, c => c.Kind == Application.Common.Reporting.ColumnKind.Money);
        Assert.DoesNotContain(without.Columns, c => c.Kind == Application.Common.Reporting.ColumnKind.Money);
    }

    [Fact]
    public async Task Dashboard_kpis_come_from_live_data()
    {
        using var h = await PopulatedAsync();
        var data = await h.Get<DashboardService>().GetAsync(new DashboardFilter());
        decimal K(string key) => data.Kpis.Single(k => k.Key == key).Value;
        Assert.Equal(14, data.Kpis.Count);
        Assert.Equal(2, K("total"));
        Assert.Equal(1, K("warranty"));
        Assert.Equal(1, K("wsoon"));
        Assert.Equal(1, K("sr"));
        Assert.Equal(100000m, K("cost"));
        Assert.Equal(19000m, K("accdep"));
        Assert.Equal(81000m, K("bv"));
        Assert.True(data.Charts.Count >= 10);
    }
}
