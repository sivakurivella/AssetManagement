using GlobalAssetManagement.Application;
using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Application.Services;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using GlobalAssetManagement.Domain.Logic;
using GlobalAssetManagement.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace GlobalAssetManagement.Tests.Integration;

public sealed class FakeUser : ICurrentUser
{
    public string? UserId { get; set; } = "u-requester";
    public string UserName { get; set; } = "requester";
    public bool IsAuthenticated => true;
    public List<string> RoleList { get; set; } = new() { Domain.Logic.Roles.Administrator };
    public IReadOnlyCollection<string> Roles => RoleList;
    public bool IsInRole(string role) => RoleList.Contains(role, StringComparer.OrdinalIgnoreCase);
    public int? BranchId { get; set; }
    public int? DepartmentId { get; set; }
    public int? EmployeeId { get; set; }
    public string? IpAddress => "127.0.0.1";

    public void Become(string userName, params string[] roles)
    {
        UserName = userName;
        UserId = "u-" + userName;
        RoleList = roles.ToList();
    }
}

public sealed class FakeClock : IClock
{
    public DateTime UtcNow { get; set; } = new(2026, 10, 25, 4, 30, 0, DateTimeKind.Utc);
    public DateTime Now => UtcNow.AddHours(5.5);
    public DateTime Today => Now.Date;
    public DateTime ToLocal(DateTime utc) => utc.AddHours(5.5);
    public void Advance(TimeSpan by) => UtcNow = UtcNow.Add(by);
}

public sealed class TempStorage : IFileStorage
{
    public string RootPath { get; } = Path.Combine(Path.GetTempPath(), "gam-tests-" + Guid.NewGuid().ToString("N"));

    public async Task<string> SaveAsync(Stream content, string folder, string extension, CancellationToken ct = default)
    {
        Directory.CreateDirectory(Path.Combine(RootPath, folder));
        var name = Guid.NewGuid().ToString("N") + extension;
        await using var fs = File.Create(Path.Combine(RootPath, folder, name));
        await content.CopyToAsync(fs, ct);
        return name;
    }

    public Stream? OpenRead(string folder, string storedFileName)
    {
        var p = Path.Combine(RootPath, folder, storedFileName);
        return File.Exists(p) ? File.OpenRead(p) : null;
    }

    public void Delete(string folder, string storedFileName) => File.Delete(Path.Combine(RootPath, folder, storedFileName));
}

public sealed class FakeDirectory : IUserDirectory
{
    public List<(string Role, DirectoryUser User)> Users { get; } = new();

    public Task<IReadOnlyList<DirectoryUser>> GetUsersInRoleAsync(string role, CancellationToken ct = default) =>
        Task.FromResult<IReadOnlyList<DirectoryUser>>(Users.Where(u => u.Role == role).Select(u => u.User).ToList());

    public Task<DirectoryUser?> FindAsync(string userId, CancellationToken ct = default) =>
        Task.FromResult(Users.Select(u => u.User).FirstOrDefault(u => u.UserId == userId));
}

public sealed class FakeSender : IEmailSender, ISmsSender, IWhatsAppSender
{
    public bool IsConfigured { get; set; } = true;
    public List<(string To, string Text)> Sent { get; } = new();

    public Task<SendResult> SendAsync(string to, string subject, string htmlBody, CancellationToken ct = default)
    {
        if (!IsConfigured) return Task.FromResult(SendResult.NotConfigured);
        Sent.Add((to, subject));
        return Task.FromResult(SendResult.Ok);
    }

    public Task<SendResult> SendAsync(string mobile, string message, CancellationToken ct = default)
    {
        if (!IsConfigured) return Task.FromResult(SendResult.NotConfigured);
        Sent.Add((mobile, message));
        return Task.FromResult(SendResult.Ok);
    }
}

/// <summary>Application services wired to an isolated EF Core in-memory database with basic master data.</summary>
public sealed class TestHost : IDisposable
{
    public ServiceProvider Root { get; }
    public IServiceScope Scope { get; }
    public FakeUser User { get; } = new();
    public FakeClock Clock { get; } = new();
    public FakeDirectory Directory { get; } = new();
    public FakeSender Sender { get; } = new();
    public AppDbContext Db => Get<AppDbContext>();

    public Branch Branch = default!;
    public Department Department = default!;
    public AssetCategory Laptops = default!;
    public Location Room1 = default!, Room2 = default!;
    public Employee Ravi = default!, Lakshmi = default!;
    public Vendor Vendor1 = default!, Vendor2 = default!;
    public ServiceAgency Provider = default!;

    private TestHost()
    {
        var services = new ServiceCollection();
        services.AddLogging(b => b.SetMinimumLevel(LogLevel.Warning));
        services.AddApplication();
        services.Configure<AppOptions>(o => { o.AssetTagPrefix = "GAM"; o.ExpiringSoonDays = 30; });
        services.Configure<UploadOptions>(o => o.MaxFileSizeMb = 5);
        var dbName = "gam-" + Guid.NewGuid().ToString("N");
        services.AddDbContext<AppDbContext>(o => o.UseInMemoryDatabase(dbName).ConfigureWarnings(w => w.Ignore(InMemoryEventId.TransactionIgnoredWarning)));
        services.AddScoped<IAppDbContext>(sp => sp.GetRequiredService<AppDbContext>());
        services.AddSingleton<ICurrentUser>(User);
        services.AddSingleton<IClock>(Clock);
        services.AddSingleton<IFileStorage, TempStorage>();
        services.AddSingleton<IUserDirectory>(Directory);
        services.AddSingleton<IEmailSender>(Sender);
        services.AddSingleton<ISmsSender>(Sender);
        services.AddSingleton<IWhatsAppSender>(Sender);
        Root = services.BuildServiceProvider();
        Scope = Root.CreateScope();
    }

    public T Get<T>() where T : notnull => Scope.ServiceProvider.GetRequiredService<T>();

    public static async Task<TestHost> CreateAsync()
    {
        var h = new TestHost();
        var db = h.Db;
        var company = new Company { Name = "Test Org", City = "Guntur", FinancialYearStartMonth = 4 };
        db.Companies.Add(company);
        await db.SaveChangesAsync();
        h.Branch = new Branch { CompanyId = company.Id, Code = "HO", Name = "Head Office" };
        var vja = new Branch { CompanyId = company.Id, Code = "VJA", Name = "Vijayawada" };
        h.Department = new Department { Code = "IT", Name = "IT" };
        h.Laptops = new AssetCategory { Code = "LAP", Name = "Laptops", Group = CategoryGroup.ComputersIT, DefaultUsefulLifeYears = 3, DefaultDepreciationMethod = DepreciationMethod.StraightLine, DefaultResidualPercent = 5 };
        db.AddRange(h.Branch, vja, h.Department, h.Laptops);
        await db.SaveChangesAsync();
        h.Room1 = new Location { BranchId = h.Branch.Id, Code = "R1", Building = "Main", Room = "Room 1" };
        h.Room2 = new Location { BranchId = h.Branch.Id, Code = "R2", Building = "Main", Room = "Room 2" };
        h.Ravi = new Employee { EmployeeCode = "E1", FullName = "Ravi", BranchId = h.Branch.Id, DepartmentId = h.Department.Id };
        h.Lakshmi = new Employee { EmployeeCode = "E2", FullName = "Lakshmi", BranchId = h.Branch.Id, DepartmentId = h.Department.Id };
        h.Vendor1 = new Vendor { Code = "V1", Name = "Vendor One" };
        h.Vendor2 = new Vendor { Code = "V2", Name = "Vendor Two" };
        h.Provider = new ServiceAgency { Code = "SP1", CompanyName = "Fix-It Services", ResponseTimeHours = 8 };
        db.AddRange(h.Room1, h.Room2, h.Ravi, h.Lakshmi, h.Vendor1, h.Vendor2, h.Provider);
        db.RolePermissions.AddRange(PermissionService.Defaults());
        await db.SaveChangesAsync();
        return h;
    }

    public async Task<Asset> NewAssetAsync(string name = "Dell Latitude", decimal cost = 60000, int? locationId = null, string? serial = null, DateTime? purchase = null, DateTime? warrantyExpiry = null)
    {
        return await Get<AssetService>().CreateAsync(new Application.Models.AssetInput
        {
            Name = name, CategoryId = Laptops.Id, BranchId = Branch.Id, DepartmentId = Department.Id, LocationId = locationId ?? Room1.Id,
            PurchaseCost = cost, TaxRate = 18, TaxAmount = cost * 0.18m, GstInputCreditClaimed = true, SerialNumber = serial,
            PurchaseDate = purchase ?? Clock.Today, WarrantyStartDate = warrantyExpiry is null ? null : Clock.Today, WarrantyExpiryDate = warrantyExpiry
        });
    }

    public void Dispose()
    {
        Scope.Dispose();
        Root.Dispose();
    }
}
