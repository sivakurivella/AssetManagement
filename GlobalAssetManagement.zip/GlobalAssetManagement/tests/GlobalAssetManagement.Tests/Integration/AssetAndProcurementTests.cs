using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Application.Models;
using GlobalAssetManagement.Application.Services;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using GlobalAssetManagement.Domain.Logic;
using Microsoft.EntityFrameworkCore;

namespace GlobalAssetManagement.Tests.Integration;

[Trait("Category", "Integration")]
public class AssetTests
{
    [Fact]
    public async Task Creating_assets_generates_unique_ids_codes_and_valuation()
    {
        using var h = await TestHost.CreateAsync();
        var a1 = await h.NewAssetAsync(cost: 60000);
        var a2 = await h.NewAssetAsync(cost: 40000);

        Assert.Equal("GAM-000001", a1.AssetTag);
        Assert.Equal("GAM-000002", a2.AssetTag);
        Assert.Equal($"LAP-HO-{h.Clock.Today.Year}-0001", a1.AssetCode);
        Assert.Equal($"LAP-HO-{h.Clock.Today.Year}-0002", a2.AssetCode);
        Assert.Equal(60000m, a1.OriginalCost);          // GST input credit claimed, so not capitalized
        Assert.Equal(60000m, a1.CurrentBookValue);
        Assert.Equal(3000m, a1.ResidualValue);          // category default 5 %
        Assert.Equal(3m, a1.UsefulLifeYears);
        Assert.True(await h.Db.AssetEvents.AnyAsync(e => e.AssetId == a1.Id && e.EventType == AssetEventType.Registered));
    }

    [Fact]
    public async Task Duplicate_asset_code_and_serial_number_are_rejected()
    {
        using var h = await TestHost.CreateAsync();
        var svc = h.Get<AssetService>();
        await svc.CreateAsync(new AssetInput { Name = "A", CategoryId = h.Laptops.Id, BranchId = h.Branch.Id, AssetCode = "IT-001", SerialNumber = "SN1" });
        await Assert.ThrowsAsync<BusinessException>(() => svc.CreateAsync(new AssetInput { Name = "B", CategoryId = h.Laptops.Id, BranchId = h.Branch.Id, AssetCode = "it-001" }));
        await Assert.ThrowsAsync<BusinessException>(() => svc.CreateAsync(new AssetInput { Name = "C", CategoryId = h.Laptops.Id, BranchId = h.Branch.Id, SerialNumber = "SN1" }));
    }

    [Fact]
    public async Task Status_changes_are_recorded_and_disposal_status_is_reserved()
    {
        using var h = await TestHost.CreateAsync();
        var a = await h.NewAssetAsync();
        var svc = h.Get<AssetService>();
        await svc.ChangeStatusAsync(a.Id, AssetStatus.Inactive, AssetCondition.Fair, "Stored in godown");
        var reloaded = await h.Db.Assets.AsNoTracking().FirstAsync(x => x.Id == a.Id);
        Assert.Equal(AssetStatus.Inactive, reloaded.Status);
        Assert.Equal(AssetCondition.Fair, reloaded.Condition);
        Assert.True(await h.Db.AssetEvents.AnyAsync(e => e.AssetId == a.Id && e.EventType == AssetEventType.StatusChanged));
        await Assert.ThrowsAsync<BusinessException>(() => svc.ChangeStatusAsync(a.Id, AssetStatus.Disposed, null, "x"));
        await Assert.ThrowsAsync<BusinessException>(() => svc.ChangeStatusAsync(a.Id, AssetStatus.InService, null, ""));
    }

    [Fact]
    public async Task Financial_fields_are_locked_after_depreciation_is_posted()
    {
        using var h = await TestHost.CreateAsync();
        var a = await h.NewAssetAsync(purchase: new DateTime(2025, 4, 1));
        await h.Get<DepreciationService>().PostAsync(new DateTime(2025, 4, 1), new DateTime(2026, 3, 31), null, null);
        var svc = h.Get<AssetService>();
        var input = await svc.ToInputAsync(a.Id);
        Assert.True(input.FinancialsLocked);
        input.Name = "Renamed laptop";
        await svc.UpdateAsync(input); // non-financial edit still allowed
        input.PurchaseCost = 1;
        await Assert.ThrowsAsync<BusinessException>(() => svc.UpdateAsync(input));
    }

    [Fact]
    public async Task Asset_with_transactions_cannot_be_deleted()
    {
        using var h = await TestHost.CreateAsync();
        var free = await h.NewAssetAsync();
        var used = await h.NewAssetAsync();
        await h.Get<AllocationService>().IssueAsync(new IssueInput { AssetId = used.Id, EmployeeId = h.Ravi.Id });
        await h.Get<AssetService>().DeleteAsync(free.Id);
        Assert.False(await h.Db.Assets.AnyAsync(x => x.Id == free.Id));
        await Assert.ThrowsAsync<BusinessException>(() => h.Get<AssetService>().DeleteAsync(used.Id));
    }

    [Fact]
    public async Task Branch_restricted_users_cannot_see_other_branches()
    {
        using var h = await TestHost.CreateAsync();
        var a = await h.NewAssetAsync();
        var other = await h.Db.Branches.FirstAsync(b => b.Code == "VJA");
        h.User.BranchId = other.Id;
        var page = await h.Get<AssetService>().SearchAsync(new AssetFilter());
        Assert.Empty(page.Items);
        await Assert.ThrowsAsync<UnauthorizedAccessException>(() => h.Get<AssetService>().GetForDetailsAsync(a.Id));
    }
}

[Trait("Category", "Integration")]
public class ProcurementTests
{
    [Fact]
    public async Task Request_to_registration_keeps_full_traceability_and_apportions_charges()
    {
        using var h = await TestHost.CreateAsync();
        var p = h.Get<ProcurementService>();

        var pr = await p.SavePurchaseRequestAsync(new PurchaseRequestInput
        {
            BranchId = h.Branch.Id, DepartmentId = h.Department.Id, Purpose = "Laptops for accounts",
            Items = { new LineInput { Description = "Business laptop", CategoryId = h.Laptops.Id, Quantity = 2, UnitPrice = 60000 } }
        });
        Assert.StartsWith("PR/", pr.RequestNo);
        await p.SubmitPurchaseRequestAsync(pr.Id);                 // no approval rules -> approved directly
        Assert.Equal(PurchaseRequestStatus.Approved, (await h.Db.PurchaseRequests.FindAsync(pr.Id))!.Status);

        var q1 = await p.AddQuotationAsync(new QuotationInput { PurchaseRequestId = pr.Id, VendorId = h.Vendor1.Id, QuotationNo = "Q-1", SubTotal = 118000, TaxAmount = 21240, DeliveryDays = 7, WarrantyMonths = 36 });
        await p.AddQuotationAsync(new QuotationInput { PurchaseRequestId = pr.Id, VendorId = h.Vendor2.Id, QuotationNo = "Q-9", SubTotal = 125000, TaxAmount = 22500 });
        var ranked = await p.CompareAsync(pr.Id);
        Assert.Equal(q1.Id, ranked[0].Id);
        await Assert.ThrowsAsync<BusinessException>(() => p.SelectQuotationAsync(ranked[1].Id, null)); // not L1 without reason
        await p.SelectQuotationAsync(q1.Id, null);

        var poInput = await p.PurchaseOrderFromQuotationAsync(q1.Id);
        Assert.Equal(59000m, poInput.Items[0].UnitPrice);
        Assert.Equal(18m, poInput.Items[0].TaxRate);
        var po = await p.SavePurchaseOrderAsync(poInput);
        Assert.Equal(118000m, po.SubTotal);
        Assert.Equal(21240m, po.TaxTotal);
        await p.SubmitPurchaseOrderAsync(po.Id);
        await p.IssuePurchaseOrderAsync(po.Id);
        Assert.Equal(PurchaseRequestStatus.Ordered, (await h.Db.PurchaseRequests.FindAsync(pr.Id))!.Status);

        var grnInput = await p.NewGoodsReceiptAsync(po.Id);
        grnInput.Lines[0].QuantityReceived = 3; // more than ordered
        await Assert.ThrowsAsync<BusinessException>(() => p.ReceiveGoodsAsync(grnInput));
        grnInput.Lines[0].QuantityReceived = 2;
        var grn = await p.ReceiveGoodsAsync(grnInput);
        Assert.Equal(PurchaseOrderStatus.Received, (await h.Db.PurchaseOrders.FindAsync(po.Id))!.Status);

        var inv = await p.SaveInvoiceAsync(new PurchaseInvoiceInput
        {
            InvoiceNumber = "INV-77", VendorId = h.Vendor1.Id, PurchaseOrderId = po.Id, GoodsReceiptId = grn.Id,
            SubTotal = 118000, TaxAmount = 21240, FreightCharges = 1000, InstallationCharges = 2000
        });
        await Assert.ThrowsAsync<BusinessException>(() => p.SaveInvoiceAsync(new PurchaseInvoiceInput { InvoiceNumber = "INV-77", VendorId = h.Vendor1.Id, SubTotal = 1 }));

        var reg = await p.NewRegistrationAsync(inv.Id);
        Assert.Equal(2, reg.Lines[0].Quantity);
        reg.Lines[0].SerialNumbers = "SN-A\nSN-B";
        reg.BranchId = h.Branch.Id;
        var created = await p.RegisterAssetsAsync(reg);

        Assert.Equal(2, created.Count);
        Assert.All(created, a =>
        {
            Assert.Equal(inv.Id, a.PurchaseInvoiceId);
            Assert.Equal(po.Id, a.PurchaseOrderId);
            Assert.Equal(grn.Id, a.GoodsReceiptId);
            Assert.Equal(59000m, a.PurchaseCost);
            Assert.Equal(500m, a.AdditionalCharges);    // 1,000 freight split by value
            Assert.Equal(1000m, a.InstallationCharges);  // 2,000 installation split by value
            Assert.Equal(60500m, a.OriginalCost);
            Assert.NotNull(a.WarrantyExpiryDate);        // 36-month quotation warranty
        });
        Assert.Equal(new[] { "SN-A", "SN-B" }, created.Select(a => a.SerialNumber).OrderBy(s => s));
        Assert.Equal(2m, (await h.Db.PurchaseOrderItems.FirstAsync(i => i.PurchaseOrderId == po.Id)).RegisteredQuantity);
        await Assert.ThrowsAsync<BusinessException>(() => p.RegisterAssetsAsync(reg)); // nothing left to register
    }

    [Fact]
    public async Task Multi_level_approval_enforces_roles_order_and_segregation_of_duties()
    {
        using var h = await TestHost.CreateAsync();
        h.Db.ApprovalRules.AddRange(
            new ApprovalRule { Module = ApprovalModule.PurchaseRequest, Level = 1, MinAmount = 0, ApproverRole = Roles.DepartmentManager },
            new ApprovalRule { Module = ApprovalModule.PurchaseRequest, Level = 2, MinAmount = 100000.01m, ApproverRole = Roles.Administrator });
        await h.Db.SaveChangesAsync();
        var p = h.Get<ProcurementService>();
        var wf = h.Get<ApprovalWorkflow>();

        h.User.Become("requester", Roles.Employee, Roles.Administrator);
        var pr = await p.SavePurchaseRequestAsync(new PurchaseRequestInput { BranchId = h.Branch.Id, Purpose = "Server", Items = { new LineInput { Description = "Server", Quantity = 1, UnitPrice = 250000 } } });
        await p.SubmitPurchaseRequestAsync(pr.Id);
        var approvals = await h.Db.Approvals.Where(a => a.EntityId == pr.Id).OrderBy(a => a.Level).ToListAsync();
        Assert.Equal(2, approvals.Count);
        Assert.Equal(PurchaseRequestStatus.PendingApproval, (await h.Db.PurchaseRequests.FindAsync(pr.Id))!.Status);

        await Assert.ThrowsAsync<BusinessException>(() => wf.DecideAsync(approvals[1].Id, true, null));            // level 2 before level 1
        h.User.Become("clerk", Roles.Employee);
        await Assert.ThrowsAsync<UnauthorizedAccessException>(() => wf.DecideAsync(approvals[0].Id, true, null)); // wrong role

        h.User.Become("manager", Roles.DepartmentManager);
        var (_, done1, _) = await wf.DecideAsync(approvals[0].Id, true, "ok");
        Assert.False(done1);

        h.User.Become("requester", Roles.Administrator);
        await Assert.ThrowsAsync<BusinessException>(() => wf.DecideAsync(approvals[1].Id, true, null));            // cannot approve own request

        h.User.Become("director", Roles.Administrator);
        await Assert.ThrowsAsync<BusinessException>(() => wf.DecideAsync(approvals[1].Id, false, ""));             // rejection needs a reason
        var (_, done2, approved) = await wf.DecideAsync(approvals[1].Id, true, "approved");
        Assert.True(done2 && approved);
        Assert.Equal(PurchaseRequestStatus.Approved, (await h.Db.PurchaseRequests.AsNoTracking().FirstAsync(x => x.Id == pr.Id)).Status);
    }

    [Fact]
    public async Task Small_request_needs_only_first_level_and_rejection_marks_request_rejected()
    {
        using var h = await TestHost.CreateAsync();
        h.Db.ApprovalRules.Add(new ApprovalRule { Module = ApprovalModule.PurchaseRequest, Level = 1, MinAmount = 0, ApproverRole = Roles.DepartmentManager });
        h.Db.ApprovalRules.Add(new ApprovalRule { Module = ApprovalModule.PurchaseRequest, Level = 2, MinAmount = 100000.01m, ApproverRole = Roles.Administrator });
        await h.Db.SaveChangesAsync();
        var p = h.Get<ProcurementService>();
        var pr = await p.SavePurchaseRequestAsync(new PurchaseRequestInput { BranchId = h.Branch.Id, Purpose = "Mouse", Items = { new LineInput { Description = "Mouse", Quantity = 2, UnitPrice = 500 } } });
        await p.SubmitPurchaseRequestAsync(pr.Id);
        var approvals = await h.Db.Approvals.Where(a => a.EntityId == pr.Id).ToListAsync();
        Assert.Single(approvals);
        h.User.Become("manager", Roles.DepartmentManager);
        await h.Get<ApprovalWorkflow>().DecideAsync(approvals[0].Id, false, "Not budgeted");
        Assert.Equal(PurchaseRequestStatus.Rejected, (await h.Db.PurchaseRequests.AsNoTracking().FirstAsync(x => x.Id == pr.Id)).Status);
    }
}
