using System.Net;
using System.Security.Claims;
using System.Text.Encodings.Web;
using GlobalAssetManagement.Application.Services;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Logic;
using GlobalAssetManagement.Infrastructure.Identity;
using GlobalAssetManagement.Infrastructure.Persistence;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace GlobalAssetManagement.Tests.Integration;

/// <summary>Signs the request in with the roles listed in the X-Test-Roles header; no header means anonymous.</summary>
public sealed class TestAuthHandler(IOptionsMonitor<AuthenticationSchemeOptions> options, ILoggerFactory logger, UrlEncoder encoder)
    : AuthenticationHandler<AuthenticationSchemeOptions>(options, logger, encoder)
{
    public const string SchemeName = "Test";

    protected override Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        if (!Request.Headers.TryGetValue("X-Test-Roles", out var roles)) return Task.FromResult(AuthenticateResult.NoResult());
        var claims = new List<Claim> { new(ClaimTypes.NameIdentifier, "test-user"), new(ClaimTypes.Name, "tester") };
        claims.AddRange(roles.ToString().Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).Select(r => new Claim(ClaimTypes.Role, r)));
        var principal = new ClaimsPrincipal(new ClaimsIdentity(claims, SchemeName));
        return Task.FromResult(AuthenticateResult.Success(new AuthenticationTicket(principal, SchemeName)));
    }
}

public sealed class WebFactory : WebApplicationFactory<Program>
{
    private readonly string _db = "gam-web-" + Guid.NewGuid().ToString("N");

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");
        builder.UseSetting("ConnectionStrings:DefaultConnection", "Server=unused-in-tests;Database=GamTests;Trusted_Connection=True;");
        builder.UseSetting("Security:RequireHttps", "false");
        builder.ConfigureServices(services =>
        {
            services.RemoveAll<DbContextOptions<AppDbContext>>();
            services.RemoveAll<AppDbContext>();
            services.AddDbContext<AppDbContext>(o => o.UseInMemoryDatabase(_db).ConfigureWarnings(w => w.Ignore(InMemoryEventId.TransactionIgnoredWarning)));
            services.RemoveAll<IHostedService>();
            services.AddAuthentication(o => o.DefaultAuthenticateScheme = TestAuthHandler.SchemeName)
                    .AddScheme<AuthenticationSchemeOptions, TestAuthHandler>(TestAuthHandler.SchemeName, _ => { });
        });
    }

    public async Task SeedAsync()
    {
        using var scope = Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        if (await db.Companies.AnyAsync()) return;
        var company = new Company { Name = "Test Org", City = "Guntur", FinancialYearStartMonth = 4 };
        db.Companies.Add(company);
        await db.SaveChangesAsync();
        db.Branches.Add(new Branch { CompanyId = company.Id, Code = "HO", Name = "Head Office" });
        db.RolePermissions.AddRange(PermissionService.Defaults());
        await db.SaveChangesAsync();
        var users = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
        var result = await users.CreateAsync(new ApplicationUser { UserName = "admin", Email = "admin@example.invalid", FullName = "Test Admin", IsActive = true }, "Test#Pass1234");
        Assert.True(result.Succeeded, string.Join("; ", result.Errors.Select(e => e.Description)));
    }
}

[Trait("Category", "Integration")]
public class SecurityTests : IClassFixture<WebFactory>
{
    private readonly WebFactory _factory;

    public SecurityTests(WebFactory factory) => _factory = factory;

    private async Task<HttpClient> ClientAsync(string? roles)
    {
        await _factory.SeedAsync();
        var c = _factory.CreateClient(new WebApplicationFactoryClientOptions { AllowAutoRedirect = false });
        if (roles is not null) c.DefaultRequestHeaders.Add("X-Test-Roles", roles);
        return c;
    }

    [Theory]
    [InlineData("/")]
    [InlineData("/Assets")]
    [InlineData("/Reports")]
    [InlineData("/Users")]
    public async Task Anonymous_users_are_sent_to_the_login_page(string url)
    {
        var res = await (await ClientAsync(null)).GetAsync(url);
        Assert.Equal(HttpStatusCode.Redirect, res.StatusCode);
        Assert.Contains("/Account/Login", res.Headers.Location!.ToString());
    }

    [Fact]
    public async Task Api_returns_401_instead_of_redirect_for_anonymous_calls()
    {
        var res = await (await ClientAsync(null)).GetAsync("/api/assets/GAM-000001");
        Assert.Equal(HttpStatusCode.Unauthorized, res.StatusCode);
    }

    [Fact]
    public async Task Login_page_is_public_and_sends_security_headers()
    {
        var res = await (await ClientAsync(null)).GetAsync("/Account/Login");
        Assert.Equal(HttpStatusCode.OK, res.StatusCode);
        Assert.Equal("nosniff", res.Headers.GetValues("X-Content-Type-Options").Single());
        Assert.Equal("SAMEORIGIN", res.Headers.GetValues("X-Frame-Options").Single());
        Assert.Contains("frame-ancestors 'self'", res.Headers.GetValues("Content-Security-Policy").Single());
    }

    [Theory]
    [InlineData("/Users")]
    [InlineData("/Roles")]
    [InlineData("/Settings")]
    [InlineData("/Audit")]
    public async Task Employee_role_cannot_open_administration_pages(string url)
    {
        var res = await (await ClientAsync(Roles.Employee)).GetAsync(url);
        Assert.Equal(HttpStatusCode.Redirect, res.StatusCode);
        Assert.Contains("AccessDenied", res.Headers.Location!.ToString());
    }

    [Theory]
    [InlineData("/")]
    [InlineData("/Assets")]
    [InlineData("/Assets/Create")]
    [InlineData("/Reports")]
    [InlineData("/Reports/View/asset-register")]
    [InlineData("/PurchaseRequests")]
    [InlineData("/ServiceRequests")]
    [InlineData("/Depreciation")]
    [InlineData("/Users")]
    [InlineData("/Settings")]
    [InlineData("/Masters/Index/Vendor")]
    public async Task Super_administrator_can_open_pages(string url)
    {
        var res = await (await ClientAsync(Roles.SuperAdministrator)).GetAsync(url);
        Assert.Equal(HttpStatusCode.OK, res.StatusCode);
    }

    [Fact]
    public async Task Auditor_can_view_assets_but_not_create_them()
    {
        var c = await ClientAsync(Roles.Auditor);
        Assert.Equal(HttpStatusCode.OK, (await c.GetAsync("/Assets")).StatusCode);
        var create = await c.GetAsync("/Assets/Create");
        Assert.Equal(HttpStatusCode.Redirect, create.StatusCode);
        Assert.Contains("AccessDenied", create.Headers.Location!.ToString());
    }

    [Fact]
    public async Task Post_without_antiforgery_token_is_rejected()
    {
        var c = await ClientAsync(Roles.SuperAdministrator);
        var res = await c.PostAsync("/Notifications/Acknowledge", new FormUrlEncodedContent(new Dictionary<string, string> { ["ids"] = "1" }));
        Assert.Equal(HttpStatusCode.BadRequest, res.StatusCode);
    }
}
