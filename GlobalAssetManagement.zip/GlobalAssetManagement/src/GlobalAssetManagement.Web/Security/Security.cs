using System.Security.Claims;
using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Application.Services;
using GlobalAssetManagement.Domain.Enums;
using GlobalAssetManagement.Domain.Logic;
using GlobalAssetManagement.Infrastructure.Identity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;

namespace GlobalAssetManagement.Web.Security;

public static class AppClaims
{
    public const string FullName = "gam:fullname";
    public const string BranchId = "gam:branch";
    public const string DepartmentId = "gam:department";
    public const string EmployeeId = "gam:employee";
    public const string MustChangePassword = "gam:mustchange";
}

/// <summary>Adds full name, branch / department restriction and employee link to the authentication cookie.</summary>
public sealed class AppClaimsPrincipalFactory(UserManager<ApplicationUser> users, RoleManager<IdentityRole> roles, IOptions<IdentityOptions> options)
    : UserClaimsPrincipalFactory<ApplicationUser, IdentityRole>(users, roles, options)
{
    protected override async Task<ClaimsIdentity> GenerateClaimsAsync(ApplicationUser user)
    {
        var id = await base.GenerateClaimsAsync(user);
        id.AddClaim(new Claim(AppClaims.FullName, string.IsNullOrWhiteSpace(user.FullName) ? user.UserName ?? "" : user.FullName));
        if (user.BranchId is { } b) id.AddClaim(new Claim(AppClaims.BranchId, b.ToString()));
        if (user.DepartmentId is { } d) id.AddClaim(new Claim(AppClaims.DepartmentId, d.ToString()));
        if (user.EmployeeId is { } e) id.AddClaim(new Claim(AppClaims.EmployeeId, e.ToString()));
        if (user.MustChangePassword) id.AddClaim(new Claim(AppClaims.MustChangePassword, "1"));
        return id;
    }
}

public sealed class HttpCurrentUser(IHttpContextAccessor accessor) : ICurrentUser
{
    private ClaimsPrincipal? Principal => accessor.HttpContext?.User;

    public string? UserId => Principal?.FindFirstValue(ClaimTypes.NameIdentifier);
    public string UserName => IsAuthenticated ? Principal!.Identity!.Name ?? "unknown" : "system";
    public bool IsAuthenticated => Principal?.Identity?.IsAuthenticated == true;
    public IReadOnlyCollection<string> Roles => Principal?.FindAll(ClaimTypes.Role).Select(c => c.Value).ToList() ?? new List<string>();
    public bool IsInRole(string role) => Principal?.IsInRole(role) == true;
    public int? BranchId => Int(AppClaims.BranchId);
    public int? DepartmentId => Int(AppClaims.DepartmentId);
    public int? EmployeeId => Int(AppClaims.EmployeeId);
    public string? IpAddress => accessor.HttpContext?.Connection.RemoteIpAddress?.ToString();

    private int? Int(string type) => int.TryParse(Principal?.FindFirstValue(type), out int v) ? v : null;
}

/// <summary>Requires a module permission, e.g. [Permission(AppModule.Assets, PermissionAction.Create)].</summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
public sealed class PermissionAttribute : AuthorizeAttribute
{
    public const string Prefix = "PERM:";

    public PermissionAttribute(AppModule module, PermissionAction action = PermissionAction.View)
    {
        Policy = $"{Prefix}{module}:{action}";
    }
}

public sealed record PermissionRequirement(AppModule Module, PermissionAction Action) : IAuthorizationRequirement;

public sealed class PermissionPolicyProvider(IOptions<AuthorizationOptions> options) : DefaultAuthorizationPolicyProvider(options)
{
    public override async Task<AuthorizationPolicy?> GetPolicyAsync(string policyName)
    {
        if (policyName.StartsWith(PermissionAttribute.Prefix, StringComparison.Ordinal))
        {
            var parts = policyName[PermissionAttribute.Prefix.Length..].Split(':');
            if (parts.Length == 2 && Enum.TryParse<AppModule>(parts[0], out var m) && Enum.TryParse<PermissionAction>(parts[1], out var a))
                return new AuthorizationPolicyBuilder().RequireAuthenticatedUser().AddRequirements(new PermissionRequirement(m, a)).Build();
        }
        return await base.GetPolicyAsync(policyName);
    }
}

public sealed class PermissionHandler(PermissionService permissions) : AuthorizationHandler<PermissionRequirement>
{
    protected override async Task HandleRequirementAsync(AuthorizationHandlerContext context, PermissionRequirement requirement)
    {
        if (context.User.Identity?.IsAuthenticated != true) return;
        var roles = context.User.FindAll(ClaimTypes.Role).Select(c => c.Value);
        if (await permissions.IsAllowedAsync(roles, requirement.Module, requirement.Action))
            context.Succeed(requirement);
    }
}

/// <summary>Used by views to show or hide buttons and menu items.</summary>
public sealed class PermissionChecker(PermissionService permissions, IHttpContextAccessor accessor)
{
    private IReadOnlyList<Domain.Entities.RolePermission>? _all;

    public async Task<bool> CanAsync(AppModule module, PermissionAction action = PermissionAction.View)
    {
        var user = accessor.HttpContext?.User;
        if (user?.Identity?.IsAuthenticated != true) return false;
        _all ??= await permissions.GetAllAsync();
        return PermissionEvaluator.IsAllowed(user.FindAll(ClaimTypes.Role).Select(c => c.Value), _all, module, action);
    }
}

/// <summary>Turns business-rule violations into friendly messages instead of error pages.</summary>
public sealed class BusinessExceptionFilter(ILogger<BusinessExceptionFilter> logger, ITempDataDictionaryFactory tempDataFactory) : IExceptionFilter
{
    public void OnException(ExceptionContext context)
    {
        string? message = context.Exception switch
        {
            BusinessException b => b.Message,
            UnauthorizedAccessException u => u.Message,
            Microsoft.EntityFrameworkCore.DbUpdateConcurrencyException => "The record was changed by another user. Please reload and try again.",
            _ => null
        };
        if (message is null) return;
        if (context.Exception is UnauthorizedAccessException) logger.LogWarning("Access denied: {Message} ({Path})", message, context.HttpContext.Request.Path);

        var req = context.HttpContext.Request;
        bool ajax = req.Headers.XRequestedWith == "XMLHttpRequest" || req.Path.StartsWithSegments("/api")
                    || req.Headers.Accept.Any(a => a?.Contains("application/json") == true);
        if (ajax)
        {
            context.Result = new JsonResult(new { ok = false, message }) { StatusCode = context.Exception is UnauthorizedAccessException ? 403 : 400 };
        }
        else
        {
            var temp = tempDataFactory.GetTempData(context.HttpContext);
            temp["Error"] = message;
            string referer = req.Headers.Referer.ToString();
            string target = Uri.TryCreate(referer, UriKind.Absolute, out var uri) && uri.Host == req.Host.Host ? uri.PathAndQuery : "/";
            context.Result = new RedirectResult(target);
        }
        context.ExceptionHandled = true;
    }
}

/// <summary>Until the first administrator exists, every page redirects to the one-time setup page.</summary>
public sealed class SetupRedirectFilter(UserManager<ApplicationUser> users, IMemoryCache cache) : IAsyncActionFilter
{
    public const string CacheKey = "setup:has-users";

    public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
    {
        var controller = context.RouteData.Values["controller"]?.ToString();
        var action = context.RouteData.Values["action"]?.ToString();
        bool exempt = controller == "Setup" || (controller == "Home" && action is "Error" or "Status");
        if (!exempt)
        {
            if (!cache.TryGetValue(CacheKey, out bool hasUsers))
            {
                hasUsers = users.Users.Any();
                if (hasUsers) cache.Set(CacheKey, true);
            }
            if (!hasUsers)
            {
                context.Result = new RedirectToActionResult("Index", "Setup", null);
                return;
            }
        }
        await next();
    }
}
