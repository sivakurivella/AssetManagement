using System.Globalization;
using GlobalAssetManagement.Application.Services;
using GlobalAssetManagement.Domain.Enums;
using Microsoft.AspNetCore.Html;

namespace GlobalAssetManagement.Web.Infrastructure;

/// <summary>Formatting helpers used by Razor views.</summary>
public static class Ui
{
    private static readonly CultureInfo India = CreateCulture();

    private static CultureInfo CreateCulture()
    {
        try { return CultureInfo.GetCultureInfo("en-IN"); }
        catch (CultureNotFoundException) { return CultureInfo.InvariantCulture; }
    }

    public static string Money(decimal? v) => v is null ? "" : "₹ " + v.Value.ToString("N2", India);
    public static string Num(decimal? v) => v is null ? "" : v.Value.ToString("#,##0.##", India);
    public static string Date(DateTime? d) => d is null ? "" : d.Value.ToString("dd-MM-yyyy", CultureInfo.InvariantCulture);
    public static string DateTimeText(DateTime? d) => d is null ? "" : d.Value.ToString("dd-MM-yyyy HH:mm", CultureInfo.InvariantCulture);
    public static string Size(long bytes) => bytes < 1024 ? $"{bytes} B" : bytes < 1048576 ? $"{bytes / 1024.0:0.#} KB" : $"{bytes / 1048576.0:0.#} MB";
    public static string Name(Enum e) => e.DisplayName();

    public static HtmlString Badge(Enum value)
    {
        string tone = value switch
        {
            AssetStatus.InService or ServiceRequestStatus.Closed or ServiceRequestStatus.UserConfirmed or WorkOrderStatus.Verified
                or WorkOrderStatus.Closed or WorkOrderStatus.Completed or PurchaseOrderStatus.Received or PurchaseRequestStatus.Approved
                or PurchaseOrderStatus.Approved or ApprovalStatus.Approved or AllocationStatus.Returned or TransferStatus.Completed
                or AdditionStatus.Capitalized or DisposalStatus.Completed or AmcRenewalStatus.Active or AmcRenewalStatus.Renewed
                or CoverageStatus.Active or VerificationResult.Found or VerificationSessionStatus.Approved or DepreciationRunStatus.Posted
                or ServiceVisitStatus.Completed or ServiceRequestStatus.Completed or DisposalStatus.Approved => "success",
            AssetStatus.UnderRepair or AssetStatus.UnderMaintenance or ServiceRequestStatus.InProgress or ServiceRequestStatus.AwaitingParts
                or WorkOrderStatus.InProgress or WorkOrderStatus.OnHold or CoverageStatus.ExpiringSoon or AmcRenewalStatus.RenewalDue
                or AmcRenewalStatus.RenewalPendingApproval or VerificationResult.WrongLocation or Priority.High or AlertSeverity.Warning
                or PurchaseOrderStatus.PartiallyReceived or ServiceRequestStatus.Testing => "warning",
            AssetStatus.Disposed or AssetStatus.LostOrWrittenOff or AssetStatus.Inactive or ServiceRequestStatus.Cancelled
                or WorkOrderStatus.Cancelled or PurchaseRequestStatus.Cancelled or PurchaseOrderStatus.Cancelled or ApprovalStatus.Cancelled
                or DepreciationRunStatus.Reversed or TransferStatus.Cancelled or AdditionStatus.Expensed or PurchaseOrderStatus.Closed
                or PurchaseRequestStatus.Closed or CoverageStatus.None or VerificationResult.Pending or ServiceVisitStatus.Cancelled => "secondary",
            ServiceRequestStatus.Rejected or ApprovalStatus.Rejected or PurchaseRequestStatus.Rejected or PurchaseOrderStatus.Rejected
                or CoverageStatus.Expired or AmcRenewalStatus.Expired or VerificationResult.Missing or Priority.Critical or AlertSeverity.Critical
                or TransferStatus.Rejected or AdditionStatus.Rejected or DisposalStatus.Rejected or VerificationSessionStatus.Rejected
                or ServiceVisitStatus.Missed => "danger",
            VerificationResult.Unregistered => "purple",
            _ => "primary"
        };
        return new HtmlString($"<span class=\"badge rounded-pill text-bg-{tone} badge-{tone}\">{System.Net.WebUtility.HtmlEncode(value.DisplayName())}</span>");
    }

    /// <summary>Dropdown items for an enum with display names, marking the current value as selected.</summary>
    public static List<Microsoft.AspNetCore.Mvc.Rendering.SelectListItem> EnumItems<T>(T? selected = null, params T[] exclude) where T : struct, Enum =>
        Enum.GetValues<T>().Where(v => !exclude.Contains(v))
            .Select(v => new Microsoft.AspNetCore.Mvc.Rendering.SelectListItem(v.DisplayName(), v.ToString(), selected is { } s && s.Equals(v)))
            .ToList();

    public static List<Microsoft.AspNetCore.Mvc.Rendering.SelectListItem> EnumItems<T>(T selected, params T[] exclude) where T : struct, Enum =>
        EnumItems<T>((T?)selected, exclude);

    public static HtmlString Coverage(DateTime? expiry, DateTime today, int soonDays = 30)
    {
        var s = Domain.Logic.CoverageEvaluator.Evaluate(expiry, today, soonDays);
        return Badge(s);
    }
}
