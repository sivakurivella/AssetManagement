using System.Collections.Concurrent;
using System.Text.Json;
using Microsoft.Extensions.Options;

namespace GlobalAssetManagement.Web.Logging;

public sealed class FileLoggerOptions
{
    public bool Enabled { get; set; } = true;

    /// <summary>Folder for daily log files. Relative paths resolve from the application folder.</summary>
    public string Path { get; set; } = "logs";
    public LogLevel MinimumLevel { get; set; } = LogLevel.Information;
    public int RetainDays { get; set; } = 30;
}

/// <summary>
/// Structured file logger writing one JSON object per line to logs/gam-yyyyMMdd.log (daily files, old files pruned).
/// The IIS application pool identity needs Modify permission on the logs folder.
/// </summary>
public sealed class FileLoggerProvider : ILoggerProvider
{
    private readonly FileLoggerOptions _options;
    private readonly BlockingCollection<string> _queue = new(10000);
    private readonly Thread _writer;
    private readonly string _folder;

    public FileLoggerProvider(IOptions<FileLoggerOptions> options)
    {
        _options = options.Value;
        _folder = System.IO.Path.IsPathRooted(_options.Path) ? _options.Path : System.IO.Path.Combine(AppContext.BaseDirectory, _options.Path);
        _writer = new Thread(WriteLoop) { IsBackground = true, Name = "GAM file logger" };
        if (_options.Enabled)
        {
            try { Directory.CreateDirectory(_folder); _writer.Start(); }
            catch { _options.Enabled = false; }
        }
    }

    public ILogger CreateLogger(string categoryName) => new FileLogger(this, categoryName);

    internal bool IsEnabled(LogLevel level) => _options.Enabled && level >= _options.MinimumLevel && level != LogLevel.None;

    internal void Enqueue(string line)
    {
        if (!_queue.IsAddingCompleted) _queue.TryAdd(line);
    }

    private void WriteLoop()
    {
        DateTime lastPrune = DateTime.MinValue;
        foreach (var line in _queue.GetConsumingEnumerable())
        {
            try
            {
                var file = System.IO.Path.Combine(_folder, $"gam-{DateTime.Now:yyyyMMdd}.log");
                File.AppendAllText(file, line + Environment.NewLine);
                if ((DateTime.Now - lastPrune).TotalHours > 12)
                {
                    lastPrune = DateTime.Now;
                    foreach (var old in Directory.GetFiles(_folder, "gam-*.log").Select(f => new FileInfo(f)).Where(f => f.LastWriteTime < DateTime.Now.AddDays(-_options.RetainDays)))
                        old.Delete();
                }
            }
            catch
            {
                // Logging must never crash the application.
            }
        }
    }

    public void Dispose()
    {
        _queue.CompleteAdding();
        if (_writer.IsAlive) _writer.Join(TimeSpan.FromSeconds(2));
    }

    private sealed class FileLogger(FileLoggerProvider provider, string category) : ILogger
    {
        public IDisposable? BeginScope<TState>(TState state) where TState : notnull => null;
        public bool IsEnabled(LogLevel logLevel) => provider.IsEnabled(logLevel);

        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception? exception, Func<TState, Exception?, string> formatter)
        {
            if (!IsEnabled(logLevel)) return;
            var entry = new Dictionary<string, object?>
            {
                ["ts"] = DateTimeOffset.Now.ToString("yyyy-MM-ddTHH:mm:ss.fffzzz"),
                ["level"] = logLevel.ToString(),
                ["category"] = category,
                ["message"] = formatter(state, exception)
            };
            if (eventId.Id != 0) entry["eventId"] = eventId.Id;
            if (state is IEnumerable<KeyValuePair<string, object?>> props)
                foreach (var (k, v) in props)
                    if (k != "{OriginalFormat}") entry["p_" + k] = v?.ToString();
            if (exception is not null) entry["exception"] = exception.ToString();
            provider.Enqueue(JsonSerializer.Serialize(entry));
        }
    }
}
