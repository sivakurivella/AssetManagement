using System.Text;
using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Application.Common.Documents;
using GlobalAssetManagement.Application.Common.Reporting;
using GlobalAssetManagement.Application.Models;
using GlobalAssetManagement.Application.Services;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using GlobalAssetManagement.Infrastructure.Persistence;
using GlobalAssetManagement.Web.Security;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace GlobalAssetManagement.Web.Controllers;

public sealed class AssetDetailsViewModel
{
    public Asset Asset { get; init; } = default!;
    public List<AssetEvent> Timeline { get; init; } = new();
    public List<AssetAllocation> Allocations { get; init; } = new();
    public List<AssetTransfer> Transfers { get; init; } = new();
    public List<ServiceRequest> ServiceRequests { get; init; } = new();
    public List<WorkOrder> WorkOrders { get; init; } = new();
    public List<MaintenanceSchedule> Schedules { get; init; } = new();
    public List<WarrantyRecord> Warranties { get; init; } = new();
    public List<AMContract> Contracts { get; init; } = new();
    public List<AssetAddition> Additions { get; init; } = new();
    public List<DepreciationTransaction> Depreciation { get; init; } = new();
    public AssetDisposal? Disposal { get; init; }
    public string QrSvg { get; init; } = "";
    public string BarcodeSvg { get; init; } = "";
    public string ScanUrl { get; init; } = "";
}

public sealed class LabelSheetViewModel
{
    public List<Asset> Assets { get; init; } = new();
    public string Size { get; init; } = "50x25";
    public string Content { get; init; } = "QR";
    public bool ShowSerial { get; init; } = true;
    public string OrganizationName { get; init; } = "";
    public Func<Asset, string> Url { get; init; } = _ => "";
}

[Permission(AppModule.Assets)]
public sealed class AssetsController(
    AssetService assets,
    AttachmentService attachments,
    SettingsService settings,
    LookupService lookups,
    ReportService reports,
    AppDbContext db,
    IOptions<AppOptions> options) : AppController
{
    public async Task<IActionResult> Index([FromQuery] AssetFilter filter)
    {
        Crumbs("Assets", ("Asset Masters", null), ("All Assets", null));
        await FilterListsAsync(filter);
        ViewBag.Filter = filter;
        return View(await assets.SearchAsync(filter));
    }

    [Permission(AppModule.Assets, PermissionAction.Export)]
    public async Task<IActionResult> Export([FromQuery] AssetFilter filter, [FromServices] PermissionChecker perm, string format = "xlsx")
    {
        var rf = new ReportFilter
        {
            BranchId = filter.BranchId, DepartmentId = filter.DepartmentId, CategoryId = filter.CategoryId, LocationId = filter.LocationId,
            VendorId = filter.VendorId, Status = filter.Status?.ToString(), Search = filter.Search
        };
        var table = await reports.RunAsync("asset-register", rf, await perm.CanAsync(AppModule.FinancialReports));
        return format switch
        {
            "csv" => File(CsvExporter.Export(table), "text/csv", "AssetRegister.csv"),
            "pdf" => File(PdfExporter.Export(table), "application/pdf", "AssetRegister.pdf"),
            _ => File(ExcelExporter.Export(table), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "AssetRegister.xlsx")
        };
    }

    public async Task<IActionResult> Details(int id)
    {
        var a = await assets.GetForDetailsAsync(id);
        if (a is null) return NotFound();
        Crumbs(a.AssetTag, ("Asset Masters", null), ("All Assets", "/Assets"), (a.AssetTag, null));
        var url = ScanUrl(a);
        var vm = new AssetDetailsViewModel
        {
            Asset = a,
            Timeline = await assets.TimelineAsync(id),
            Allocations = await db.AssetAllocations.AsNoTracking().Include(x => x.Employee).Include(x => x.Department).Include(x => x.Location).Include(x => x.Return)
                .Where(x => x.AssetId == id).OrderByDescending(x => x.IssueDate).ToListAsync(),
            Transfers = await db.AssetTransfers.AsNoTracking().Include(x => x.FromBranch).Include(x => x.ToBranch).Include(x => x.ToEmployee).Include(x => x.ToDepartment).Include(x => x.ToLocation)
                .Where(x => x.AssetId == id).OrderByDescending(x => x.TransferDate).ToListAsync(),
            ServiceRequests = await db.ServiceRequests.AsNoTracking().Where(x => x.AssetId == id).OrderByDescending(x => x.RequestedAt).ToListAsync(),
            WorkOrders = await db.WorkOrders.AsNoTracking().Include(x => x.ServiceProvider).Where(x => x.AssetId == id).OrderByDescending(x => x.CreatedAt).ToListAsync(),
            Schedules = await db.MaintenanceSchedules.AsNoTracking().Where(x => x.AssetId == id).OrderBy(x => x.NextDueDate).ToListAsync(),
            Warranties = await db.WarrantyRecords.AsNoTracking().Where(x => x.AssetId == id).OrderByDescending(x => x.ExpiryDate).ToListAsync(),
            Contracts = await db.AMContracts.AsNoTracking().Include(c => c.ServiceProvider).Where(c => c.CoveredAssets.Any(x => x.AssetId == id)).OrderByDescending(c => c.ExpiryDate).ToListAsync(),
            Additions = await db.AssetAdditions.AsNoTracking().Where(x => x.AssetId == id).OrderByDescending(x => x.AdditionDate).ToListAsync(),
            Depreciation = await db.DepreciationTransactions.AsNoTracking().Include(x => x.DepreciationSchedule).Where(x => x.AssetId == id).OrderByDescending(x => x.PeriodTo).ToListAsync(),
            Disposal = await db.AssetDisposals.AsNoTracking().Where(x => x.AssetId == id).OrderByDescending(x => x.Id).FirstOrDefaultAsync(),
            QrSvg = QrCode.EncodeText(url).ToSvg(4),
            BarcodeSvg = Code128Encoder.ToSvg(a.AssetTag, 2, 50, false),
            ScanUrl = url
        };
        return View(vm);
    }

    /// <summary>Target of the QR code on each label. Requires sign-in and permission like any other page.</summary>
    [HttpGet]
    public async Task<IActionResult> Scan(string tag)
    {
        var a = await assets.FindByCodeAsync(tag);
        if (a is null) { Error($"No asset found for code '{tag}'."); return RedirectToAction(nameof(Index)); }
        CurrentUser.EnsureCanSee(a);
        return RedirectToAction(nameof(Details), new { id = a.Id });
    }

    [HttpGet]
    public async Task<IActionResult> Lookup(string? q)
        => Json((await lookups.AssetsAsync(CurrentUser, q, 30)).Select(i => new { id = i.Id, text = i.Text }));

    [HttpGet, Permission(AppModule.Assets, PermissionAction.Create)]
    public async Task<IActionResult> Create()
    {
        Crumbs("Register Asset", ("Asset Masters", null), ("All Assets", "/Assets"), ("Register", null));
        var input = await assets.NewInputAsync();
        await FormListsAsync(input);
        return View("Form", input);
    }

    [HttpPost, Permission(AppModule.Assets, PermissionAction.Create)]
    public async Task<IActionResult> Create(AssetInput input, string? saveAndNew)
    {
        Crumbs("Register Asset", ("Asset Masters", null), ("All Assets", "/Assets"), ("Register", null));
        Asset? created = null;
        if (ModelState.IsValid && await TryAsync(async () => created = await assets.CreateAsync(input)))
        {
            Success($"Asset {created!.AssetTag} registered.");
            return saveAndNew is not null ? RedirectToAction(nameof(Create)) : RedirectToAction(nameof(Details), new { id = created.Id });
        }
        await FormListsAsync(input);
        return View("Form", input);
    }

    [HttpGet, Permission(AppModule.Assets, PermissionAction.Edit)]
    public async Task<IActionResult> Edit(int id)
    {
        var input = await assets.ToInputAsync(id);
        Crumbs("Edit Asset", ("Asset Masters", null), ("All Assets", "/Assets"), (input.AssetCode ?? "", $"/Assets/Details/{id}"), ("Edit", null));
        await FormListsAsync(input);
        return View("Form", input);
    }

    [HttpPost, Permission(AppModule.Assets, PermissionAction.Edit)]
    public async Task<IActionResult> Edit(int id, AssetInput input)
    {
        input.Id = id;
        Crumbs("Edit Asset", ("Asset Masters", null), ("All Assets", "/Assets"), ("Edit", null));
        if (ModelState.IsValid && await TryAsync(() => assets.UpdateAsync(input)))
        {
            Success("Asset updated.");
            return RedirectToAction(nameof(Details), new { id });
        }
        var current = await assets.ToInputAsync(id);
        input.FinancialsLocked = current.FinancialsLocked;
        await FormListsAsync(input);
        return View("Form", input);
    }

    [HttpPost, Permission(AppModule.Assets, PermissionAction.Edit)]
    public async Task<IActionResult> ChangeStatus(int id, AssetStatus status, AssetCondition? condition, string reason)
    {
        await assets.ChangeStatusAsync(id, status, condition, reason);
        Success("Status updated.");
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost, Permission(AppModule.Assets, PermissionAction.Delete)]
    public async Task<IActionResult> Delete(int id)
    {
        await assets.DeleteAsync(id);
        Success("Asset deleted.");
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, Permission(AppModule.Assets, PermissionAction.Edit)]
    public async Task<IActionResult> UploadDocument(int id, IFormFile? file, AssetDocumentType documentType, string? description)
    {
        var a = await db.Assets.FirstOrDefaultAsync(x => x.Id == id);
        if (a is null) return NotFound();
        CurrentUser.EnsureCanSee(a);
        if (file is null) { Error("Choose a file to upload."); return RedirectToAction(nameof(Details), new { id }); }
        if (documentType == AssetDocumentType.Photograph) await attachments.AddAssetImageAsync(a, file, description);
        else await attachments.AddAssetDocumentAsync(a, file, documentType, description);
        Success($"{file.FileName} uploaded.");
        return Redirect($"/Assets/Details/{id}#documents");
    }

    [HttpPost, Permission(AppModule.Assets, PermissionAction.Delete)]
    public async Task<IActionResult> DeleteDocument(int id, int documentId, bool image, [FromServices] IFileStorage storage)
    {
        if (image)
        {
            var img = await db.AssetImages.FirstOrDefaultAsync(x => x.Id == documentId && x.AssetId == id);
            if (img is not null) { db.AssetImages.Remove(img); await db.SaveChangesAsync(); storage.Delete(AttachmentService.ImageFolder, img.StoredFileName); }
        }
        else
        {
            var doc = await db.AssetDocuments.FirstOrDefaultAsync(x => x.Id == documentId && x.AssetId == id);
            if (doc is not null) { db.AssetDocuments.Remove(doc); await db.SaveChangesAsync(); storage.Delete(AttachmentService.AssetFolder, doc.StoredFileName); }
        }
        Success("Document removed.");
        return Redirect($"/Assets/Details/{id}#documents");
    }

    [HttpGet]
    public async Task<IActionResult> Qr(int id)
    {
        var a = await db.Assets.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        if (a is null) return NotFound();
        return Content(QrCode.EncodeText(ScanUrl(a)).ToSvg(8), "image/svg+xml");
    }

    [HttpGet]
    public async Task<IActionResult> Barcode(int id)
    {
        var a = await db.Assets.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        if (a is null) return NotFound();
        return Content(Code128Encoder.ToSvg(a.AssetTag, 2, 60, true), "image/svg+xml");
    }

    // ------------------------------------------------------------------ labels

    [HttpGet]
    public async Task<IActionResult> Labels([FromQuery] AssetFilter filter)
    {
        Crumbs("Print Asset Labels", ("Asset Masters", null), ("Print Labels", null));
        filter.PageSize = 500;
        await FilterListsAsync(filter);
        ViewBag.Filter = filter;
        ViewBag.DefaultSize = await settings.GetAsync("Labels.DefaultSize", "50x25");
        ViewBag.DefaultContent = await settings.GetAsync("Labels.Content", "QR");
        return View(await assets.SearchAsync(filter));
    }

    [HttpPost]
    public async Task<IActionResult> PrintLabels(List<int> ids, string size = "50x25", string content = "QR", bool showSerial = true)
    {
        if (ids.Count == 0) { Error("Select at least one asset."); return RedirectToAction(nameof(Labels)); }
        var list = await assets.ForLabelsAsync(ids);
        var company = await settings.GetCompanyAsync();
        return View("LabelSheet", new LabelSheetViewModel
        {
            Assets = list, Size = size, Content = content, ShowSerial = showSerial, OrganizationName = company.Name, Url = ScanUrl
        });
    }

    /// <summary>TSPL command file for TSC thermal label printers (send to the printer with the TSC utility or copy /b to the port).</summary>
    [HttpPost]
    public async Task<IActionResult> LabelsTspl(List<int> ids, string size = "50x25", bool showSerial = true)
    {
        if (ids.Count == 0) { Error("Select at least one asset."); return RedirectToAction(nameof(Labels)); }
        var list = await assets.ForLabelsAsync(ids);
        var company = await settings.GetCompanyAsync();
        var (w, h) = size switch { "38x25" => (38, 25), "75x50" => (75, 50), "100x50" => (100, 50), _ => (50, 25) };
        int dots(double mm) => (int)Math.Round(mm * 8); // 203 dpi
        var sb = new StringBuilder();
        sb.Append($"SIZE {w} mm,{h} mm\r\nGAP 2 mm,0 mm\r\nDIRECTION 1\r\nREFERENCE 0,0\r\nCODEPAGE 1252\r\nSET TEAR ON\r\n");
        string Clean(string s) => new string(s.Where(c => c >= 32 && c < 127 && c != '"').ToArray());
        foreach (var a in list)
        {
            int qrCell = h >= 50 ? 5 : 3;
            sb.Append("CLS\r\n");
            sb.Append($"TEXT {dots(2)},{dots(1.5)},\"2\",0,1,1,\"{Clean(company.Name)[..Math.Min(Clean(company.Name).Length, w / 2)]}\"\r\n");
            sb.Append($"QRCODE {dots(2)},{dots(5)},M,{qrCell},A,0,\"{Clean(ScanUrl(a))}\"\r\n");
            int tx = dots(h >= 50 ? 32 : 20);
            sb.Append($"TEXT {tx},{dots(6)},\"3\",0,1,1,\"{Clean(a.AssetTag)}\"\r\n");
            sb.Append($"TEXT {tx},{dots(10)},\"1\",0,1,1,\"{Clean(a.Name)[..Math.Min(Clean(a.Name).Length, (w - 20) / 2 + 4)]}\"\r\n");
            if (showSerial && !string.IsNullOrEmpty(a.SerialNumber)) sb.Append($"TEXT {tx},{dots(13)},\"1\",0,1,1,\"S/N {Clean(a.SerialNumber)}\"\r\n");
            if (h >= 50) sb.Append($"BARCODE {dots(32)},{dots(20)},\"128\",{dots(12)},0,0,2,4,\"{Clean(a.AssetTag)}\"\r\n");
            sb.Append("PRINT 1,1\r\n");
        }
        return File(Encoding.ASCII.GetBytes(sb.ToString()), "application/octet-stream", $"asset-labels-{size}.prn");
    }

    // ------------------------------------------------------------------ helpers

    private string ScanUrl(Asset a)
    {
        var baseUrl = string.IsNullOrWhiteSpace(options.Value.PublicBaseUrl) ? $"{Request.Scheme}://{Request.Host}{Request.PathBase}" : options.Value.PublicBaseUrl!.TrimEnd('/');
        return $"{baseUrl}/a/{Uri.EscapeDataString(a.AssetTag)}";
    }

    private async Task FilterListsAsync(AssetFilter f)
    {
        ViewBag.Categories = await SelectAsync<AssetCategory>(f.CategoryId);
        ViewBag.Branches = await SelectAsync<Branch>(f.BranchId);
        ViewBag.Departments = await SelectAsync<Department>(f.DepartmentId);
        ViewBag.Locations = await SelectAsync<Location>(f.LocationId);
        ViewBag.Employees = await SelectAsync<Employee>(f.EmployeeId);
    }

    private async Task FormListsAsync(AssetInput i)
    {
        ViewBag.Categories = await SelectAsync<AssetCategory>(i.CategoryId);
        var subs = await db.AssetSubcategories.AsNoTracking().Include(s => s.Category).Where(s => s.IsActive).OrderBy(s => s.Category!.Name).ThenBy(s => s.Name).ToListAsync();
        ViewBag.Subcategories = subs.Select(s => new SelectListItem($"{s.Category!.Name} › {s.Name}", s.Id.ToString(), s.Id == i.SubcategoryId)).ToList();
        ViewBag.AssetTypes = await SelectAsync<AssetType>(i.AssetTypeId);
        ViewBag.Manufacturers = await SelectAsync<Manufacturer>(i.ManufacturerId);
        ViewBag.Brands = await SelectAsync<Brand>(i.BrandId);
        ViewBag.Models = await SelectAsync<AssetModel>(i.AssetModelId);
        ViewBag.Vendors = await SelectAsync<Vendor>(i.VendorId);
        ViewBag.Branches = await SelectAsync<Branch>(i.BranchId);
        ViewBag.Departments = await SelectAsync<Department>(i.DepartmentId);
        ViewBag.Locations = await SelectAsync<Location>(i.LocationId);
        ViewBag.Employees = await SelectAsync<Employee>(i.AssignedEmployeeId);
    }
}
