using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Application.Models;
using GlobalAssetManagement.Application.Services;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using GlobalAssetManagement.Domain.Logic;
using GlobalAssetManagement.Infrastructure.Identity;
using GlobalAssetManagement.Infrastructure.Persistence;
using GlobalAssetManagement.Web.Models;
using GlobalAssetManagement.Web.Security;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace GlobalAssetManagement.Web.Controllers;

[Permission(AppModule.Additions)]
public sealed class AdditionsController(AdditionService additions, ApprovalService approvals, AttachmentService attachments, AppDbContext db) : AppController
{
    public async Task<IActionResult> Index(AdditionStatus? status, string? q, int page = 1)
    {
        Crumbs("Asset Additions", ("Asset Additions", null));
        var query = db.AssetAdditions.AsNoTracking().Include(a => a.Asset).Include(a => a.Vendor).AsQueryable();
        if (CurrentUser.BranchId is { } b) query = query.Where(a => a.Asset!.BranchId == b);
        if (status is not null) query = query.Where(a => a.Status == status);
        if (!string.IsNullOrWhiteSpace(q)) query = query.Where(a => a.AdditionNo.Contains(q) || a.Asset!.AssetTag.Contains(q) || a.Description.Contains(q));
        int total = await query.CountAsync();
        var list = await query.OrderByDescending(a => a.AdditionDate).ThenByDescending(a => a.Id).Skip((Math.Max(1, page) - 1) * 25).Take(25).ToListAsync();
        ViewBag.Status = status; ViewBag.Q = q;
        ViewBag.Pager = new PagerModel(Math.Max(1, page), Math.Max(1, (int)Math.Ceiling(total / 25.0)), total, 25);
        return View(list);
    }

    [HttpGet, Permission(AppModule.Additions, PermissionAction.Create)]
    public async Task<IActionResult> Create(int? assetId)
    {
        Crumbs("Record Addition", ("Asset Additions", "/Additions"), ("New", null));
        var input = new AdditionInput { AssetId = assetId, AdditionDate = Clock.Today };
        ViewBag.Assets = await AssetSelectAsync(assetId);
        ViewBag.Vendors = await SelectAsync<Vendor>();
        return View(input);
    }

    [HttpPost, Permission(AppModule.Additions, PermissionAction.Create)]
    public async Task<IActionResult> Create(AdditionInput input)
    {
        AssetAddition? a = null;
        if (ModelState.IsValid && await TryAsync(async () => a = await additions.CreateAsync(input)))
        {
            Success($"{a!.AdditionNo} recorded. An authorized user must classify it as capital or revenue expenditure.");
            return RedirectToAction(nameof(Details), new { id = a.Id });
        }
        Crumbs("Record Addition", ("Asset Additions", "/Additions"), ("New", null));
        ViewBag.Assets = await AssetSelectAsync(input.AssetId);
        ViewBag.Vendors = await SelectAsync<Vendor>(input.VendorId);
        return View(input);
    }

    public async Task<IActionResult> Details(int id, [FromServices] PermissionChecker perm)
    {
        var a = await db.AssetAdditions.AsNoTracking().Include(x => x.Asset).Include(x => x.Vendor).FirstOrDefaultAsync(x => x.Id == id);
        if (a is null) return NotFound();
        Crumbs(a.AdditionNo, ("Asset Additions", "/Additions"), (a.AdditionNo, null));
        ViewBag.Approvals = new ApprovalPanelModel(await approvals.HistoryAsync(ApprovalModule.AssetAddition, id));
        ViewBag.Attachments = new AttachmentsPanelModel("AssetAddition", id, await attachments.ListAsync("AssetAddition", id), await perm.CanAsync(AppModule.Additions, PermissionAction.Create));
        return View(a);
    }

    [HttpPost, Permission(AppModule.Additions, PermissionAction.Edit)]
    public async Task<IActionResult> Classify(ClassifyAdditionInput input)
    {
        await additions.ClassifyAsync(input);
        Success("Classification saved.");
        return RedirectToAction(nameof(Details), new { id = input.Id });
    }
}

[Permission(AppModule.Maintenance)]
public sealed class ServiceRequestsController(MaintenanceService maintenance, ApprovalService approvals, AttachmentService attachments, AppDbContext db,
    UserManager<ApplicationUser> users) : AppController
{
    public async Task<IActionResult> Index(ServiceRequestStatus? status, Priority? priority, bool open = false, bool mine = false, string? q = null, int page = 1)
    {
        Crumbs("Service Requests", ("Maintenance & Repairs", null), ("Service Requests", null));
        var query = db.ServiceRequests.AsNoTracking().Include(s => s.Asset).Include(s => s.Department).AsQueryable();
        if (CurrentUser.BranchId is { } b) query = query.Where(s => s.Asset!.BranchId == b);
        if (status is not null) query = query.Where(s => s.Status == status);
        if (priority is not null) query = query.Where(s => s.Priority == priority);
        if (open) query = query.Where(s => s.Status != ServiceRequestStatus.Closed && s.Status != ServiceRequestStatus.Cancelled && s.Status != ServiceRequestStatus.Rejected);
        if (mine) { var u = CurrentUser.UserName; query = query.Where(s => s.RequestedByUser == u); }
        if (!string.IsNullOrWhiteSpace(q)) query = query.Where(s => s.TicketNo.Contains(q) || s.Asset!.AssetTag.Contains(q) || s.FaultDescription.Contains(q));
        int total = await query.CountAsync();
        var list = await query.OrderByDescending(s => s.Priority).ThenByDescending(s => s.RequestedAt).Skip((Math.Max(1, page) - 1) * 25).Take(25).ToListAsync();
        ViewBag.Status = status; ViewBag.Priority = priority; ViewBag.Open = open; ViewBag.Mine = mine; ViewBag.Q = q;
        ViewBag.Pager = new PagerModel(Math.Max(1, page), Math.Max(1, (int)Math.Ceiling(total / 25.0)), total, 25);
        return View(list);
    }

    [HttpGet, Permission(AppModule.Maintenance, PermissionAction.Create)]
    public async Task<IActionResult> Create(int? assetId)
    {
        Crumbs("Raise Service Request", ("Service Requests", "/ServiceRequests"), ("New", null));
        var input = new ServiceRequestInput { AssetId = assetId, RequestedByEmployeeId = CurrentUser.EmployeeId };
        ViewBag.Assets = await AssetSelectAsync(assetId);
        ViewBag.Employees = await SelectAsync<Employee>(input.RequestedByEmployeeId);
        return View(input);
    }

    [HttpPost, Permission(AppModule.Maintenance, PermissionAction.Create)]
    public async Task<IActionResult> Create(ServiceRequestInput input, List<IFormFile>? photos)
    {
        ServiceRequest? sr = null;
        if (ModelState.IsValid && await TryAsync(async () =>
            {
                sr = await maintenance.CreateRequestAsync(input);
                foreach (var p in (photos ?? new()).Where(p => p.Length > 0).Take(5))
                    await attachments.AddAttachmentAsync("ServiceRequest", sr.Id, p, "Photograph");
            }))
        {
            Success($"Ticket {sr!.TicketNo} raised.");
            return RedirectToAction(nameof(Details), new { id = sr.Id });
        }
        Crumbs("Raise Service Request", ("Service Requests", "/ServiceRequests"), ("New", null));
        ViewBag.Assets = await AssetSelectAsync(input.AssetId);
        ViewBag.Employees = await SelectAsync<Employee>(input.RequestedByEmployeeId);
        return View(input);
    }

    public async Task<IActionResult> Details(int id, [FromServices] PermissionChecker perm)
    {
        var sr = await db.ServiceRequests.AsNoTracking().Include(s => s.Asset!).ThenInclude(a => a.Branch).Include(s => s.Department).Include(s => s.Location)
            .Include(s => s.RequestedByEmployee).Include(s => s.Estimates).ThenInclude(e => e.ServiceProvider)
            .Include(s => s.WorkOrders).ThenInclude(w => w.ServiceProvider).AsSplitQuery().FirstOrDefaultAsync(s => s.Id == id);
        if (sr is null) return NotFound();
        CurrentUser.EnsureCanSee(sr.Asset!);
        Crumbs(sr.TicketNo, ("Service Requests", "/ServiceRequests"), (sr.TicketNo, null));
        var estimateIds = sr.Estimates.Select(e => e.Id).ToList();
        var estApprovals = new List<Approval>();
        foreach (var eid in estimateIds) estApprovals.AddRange(await approvals.HistoryAsync(ApprovalModule.RepairEstimate, eid));
        ViewBag.Approvals = new ApprovalPanelModel(estApprovals);
        ViewBag.Attachments = new AttachmentsPanelModel("ServiceRequest", id, await attachments.ListAsync("ServiceRequest", id), await perm.CanAsync(AppModule.Maintenance, PermissionAction.Create));
        ViewBag.Technicians = await TechniciansAsync();
        ViewBag.Providers = await SelectAsync<ServiceAgency>();
        return View(sr);
    }

    [HttpPost, Permission(AppModule.Maintenance, PermissionAction.Approve)]
    public async Task<IActionResult> Review(int id, string? remarks) { await maintenance.ReviewAsync(id, remarks); Success("Marked under review."); return RedirectToAction(nameof(Details), new { id }); }

    [HttpPost, Permission(AppModule.Maintenance, PermissionAction.Approve)]
    public async Task<IActionResult> Decide(int id, bool approve, string? remarks)
    {
        await maintenance.DecideRequestAsync(id, approve, remarks);
        Success(approve ? "Request approved." : "Request rejected.");
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost, Permission(AppModule.Maintenance, PermissionAction.Edit)]
    public async Task<IActionResult> Assign(int id, WorkOrderInput input)
    {
        ModelState.Clear();
        var wo = await maintenance.AssignAsync(id, input);
        Success($"Work order {wo.WorkOrderNo} created and assigned.");
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost, Permission(AppModule.Maintenance, PermissionAction.Edit)]
    public async Task<IActionResult> Estimate(EstimateInput input)
    {
        var est = await maintenance.SubmitEstimateAsync(input);
        Success(est.Status == ApprovalStatus.Approved ? "Estimate recorded and auto-approved (within limit)." : "Estimate submitted for approval.");
        return RedirectToAction(nameof(Details), new { id = input.ServiceRequestId });
    }

    [HttpPost, Permission(AppModule.Maintenance, PermissionAction.Edit)]
    public async Task<IActionResult> AwaitParts(int id) { await maintenance.MarkAwaitingPartsAsync(id); Success("Marked as awaiting spare parts."); return RedirectToAction(nameof(Details), new { id }); }

    [HttpPost]
    public async Task<IActionResult> Confirm(int id, bool satisfied, int? rating, string? feedback)
    {
        await maintenance.ConfirmAsync(id, satisfied, rating, feedback);
        Success(satisfied ? "Thank you. Repair confirmed." : "Repair reopened.");
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost, Permission(AppModule.Maintenance, PermissionAction.Approve)]
    public async Task<IActionResult> Close(int id) { await maintenance.CloseRequestAsync(id); Success("Service request closed."); return RedirectToAction(nameof(Details), new { id }); }

    [HttpPost, Permission(AppModule.Maintenance, PermissionAction.Edit)]
    public async Task<IActionResult> Cancel(int id, string reason) { await maintenance.CancelRequestAsync(id, reason); Success("Service request cancelled."); return RedirectToAction(nameof(Details), new { id }); }

    private async Task<SelectList> TechniciansAsync()
    {
        var techs = await users.GetUsersInRoleAsync(Roles.MaintenanceTechnician);
        return new SelectList(techs.Where(t => t.IsActive).Select(t => new { t.Id, Text = string.IsNullOrWhiteSpace(t.FullName) ? t.UserName : t.FullName }), "Id", "Text");
    }
}

[Permission(AppModule.Maintenance)]
public sealed class WorkOrdersController(MaintenanceService maintenance, AttachmentService attachments, AppDbContext db, UserManager<ApplicationUser> users) : AppController
{
    public async Task<IActionResult> Index(WorkOrderStatus? status, WorkType? type, bool overdue = false, bool mine = false, string? q = null, int page = 1)
    {
        Crumbs("Work Orders", ("Maintenance & Repairs", null), ("Work Orders", null));
        var today = Clock.Today;
        var query = db.WorkOrders.AsNoTracking().Include(w => w.Asset).Include(w => w.ServiceProvider).Include(w => w.ServiceRequest).AsQueryable();
        if (CurrentUser.BranchId is { } b) query = query.Where(w => w.Asset!.BranchId == b);
        if (status is not null) query = query.Where(w => w.Status == status);
        else query = query.Where(w => w.Status != WorkOrderStatus.Closed && w.Status != WorkOrderStatus.Cancelled);
        if (type is not null) query = query.Where(w => w.WorkType == type);
        if (overdue) query = query.Where(w => w.DueDate != null && w.DueDate < today && (w.Status == WorkOrderStatus.Open || w.Status == WorkOrderStatus.Assigned || w.Status == WorkOrderStatus.InProgress || w.Status == WorkOrderStatus.OnHold));
        if (mine || (CurrentUser.IsInRole(Roles.MaintenanceTechnician) && !CurrentUser.IsInRole(Roles.AssetManager) && !CurrentUser.IsInRole(Roles.Administrator) && !CurrentUser.IsInRole(Roles.SuperAdministrator)))
        {
            var uid = CurrentUser.UserId;
            query = query.Where(w => w.TechnicianUserId == uid || w.TechnicianUserId == null);
        }
        if (!string.IsNullOrWhiteSpace(q)) query = query.Where(w => w.WorkOrderNo.Contains(q) || w.Asset!.AssetTag.Contains(q) || w.Title.Contains(q));
        int total = await query.CountAsync();
        var list = await query.OrderBy(w => w.DueDate == null).ThenBy(w => w.DueDate).ThenByDescending(w => w.Priority).Skip((Math.Max(1, page) - 1) * 25).Take(25).ToListAsync();
        ViewBag.Status = status; ViewBag.Type = type; ViewBag.Overdue = overdue; ViewBag.Q = q;
        ViewBag.Pager = new PagerModel(Math.Max(1, page), Math.Max(1, (int)Math.Ceiling(total / 25.0)), total, 25);
        return View(list);
    }

    [HttpGet, Permission(AppModule.Maintenance, PermissionAction.Create)]
    public async Task<IActionResult> Create(int? assetId)
    {
        Crumbs("New Work Order", ("Work Orders", "/WorkOrders"), ("New", null));
        var input = new WorkOrderInput { AssetId = assetId, WorkType = WorkType.Preventive, DueDate = Clock.Today.AddDays(3) };
        await ListsAsync(input);
        return View(input);
    }

    [HttpPost, Permission(AppModule.Maintenance, PermissionAction.Create)]
    public async Task<IActionResult> Create(WorkOrderInput input)
    {
        WorkOrder? wo = null;
        if (input.WorkType == WorkType.Breakdown) ModelState.AddModelError(nameof(input.WorkType), "Breakdown repairs start with a service request.");
        if (ModelState.IsValid && await TryAsync(async () => wo = await maintenance.CreateWorkOrderAsync(input)))
        {
            Success($"Work order {wo!.WorkOrderNo} created.");
            return RedirectToAction(nameof(Details), new { id = wo.Id });
        }
        Crumbs("New Work Order", ("Work Orders", "/WorkOrders"), ("New", null));
        await ListsAsync(input);
        return View(input);
    }

    public async Task<IActionResult> Details(int id, [FromServices] PermissionChecker perm)
    {
        var wo = await db.WorkOrders.AsNoTracking().Include(w => w.Asset).Include(w => w.ServiceRequest).Include(w => w.ServiceProvider).Include(w => w.MaintenanceSchedule)
            .Include(w => w.AMContract).Include(w => w.Labour).Include(w => w.Parts).AsSplitQuery().FirstOrDefaultAsync(w => w.Id == id);
        if (wo is null) return NotFound();
        CurrentUser.EnsureCanSee(wo.Asset!);
        Crumbs(wo.WorkOrderNo, ("Work Orders", "/WorkOrders"), (wo.WorkOrderNo, null));
        ViewBag.Attachments = new AttachmentsPanelModel("WorkOrder", id, await attachments.ListAsync("WorkOrder", id), await perm.CanAsync(AppModule.Maintenance, PermissionAction.Edit));
        ViewBag.Technicians = await TechniciansAsync(wo.TechnicianUserId);
        ViewBag.Providers = await SelectAsync<ServiceAgency>(wo.ServiceProviderId);
        return View(wo);
    }

    public async Task<IActionResult> Report(int id, [FromServices] SettingsService settings)
    {
        var wo = await db.WorkOrders.AsNoTracking().Include(w => w.Asset!).ThenInclude(a => a.Location).Include(w => w.ServiceRequest).Include(w => w.ServiceProvider)
            .Include(w => w.Labour).Include(w => w.Parts).AsSplitQuery().FirstOrDefaultAsync(w => w.Id == id);
        if (wo is null) return NotFound();
        CurrentUser.EnsureCanSee(wo.Asset!);
        Crumbs($"Service Report {wo.WorkOrderNo}", ("Work Orders", "/WorkOrders"), (wo.WorkOrderNo, $"/WorkOrders/Details/{id}"), ("Service report", null));
        ViewBag.Company = await settings.GetCompanyAsync();
        return View(wo);
    }

    [HttpPost, Permission(AppModule.Maintenance, PermissionAction.Edit)]
    public async Task<IActionResult> AssignTechnician(int id, string? technicianUserId, string? technicianName, int? serviceProviderId)
    { await maintenance.AssignTechnicianAsync(id, technicianUserId, technicianName, serviceProviderId); Success("Assignment updated."); return Back(id); }

    [HttpPost, Permission(AppModule.Maintenance, PermissionAction.Edit)]
    public async Task<IActionResult> Diagnose(int id, string diagnosis, string? spareParts)
    { await maintenance.DiagnoseAsync(id, diagnosis, spareParts); Success("Diagnosis recorded."); return Back(id); }

    [HttpPost, Permission(AppModule.Maintenance, PermissionAction.Edit)]
    public async Task<IActionResult> Start(int id) { await maintenance.StartWorkAsync(id); Success("Work started."); return Back(id); }

    [HttpPost, Permission(AppModule.Maintenance, PermissionAction.Edit)]
    public async Task<IActionResult> AddLabour(int id, string? technicianName, decimal hours, decimal ratePerHour, DateTime? workDate, string? description)
    {
        await maintenance.AddLabourAsync(id, new WorkOrderLabour { TechnicianName = technicianName ?? "", Hours = hours, RatePerHour = ratePerHour, WorkDate = workDate ?? Clock.Today, Description = description });
        Success("Labour added."); return Back(id, "#costs");
    }

    [HttpPost, Permission(AppModule.Maintenance, PermissionAction.Edit)]
    public async Task<IActionResult> AddPart(int id, string partName, string? partNumber, decimal quantity, decimal unitCost, string? supplier)
    {
        await maintenance.AddPartAsync(id, new WorkOrderPart { PartName = partName, PartNumber = partNumber, Quantity = quantity, UnitCost = unitCost, Supplier = supplier });
        Success("Spare part added."); return Back(id, "#costs");
    }

    [HttpPost, Permission(AppModule.Maintenance, PermissionAction.Edit)]
    public async Task<IActionResult> RemoveLine(int id, int? labourId, int? partId) { await maintenance.RemoveLineAsync(id, labourId, partId); return Back(id, "#costs"); }

    [HttpPost, Permission(AppModule.Maintenance, PermissionAction.Edit)]
    public async Task<IActionResult> SubmitForTesting(int id) { await maintenance.SubmitForTestingAsync(id); Success("Sent for testing / quality verification."); return Back(id); }

    [HttpPost, Permission(AppModule.Maintenance, PermissionAction.Edit)]
    public async Task<IActionResult> QualityCheck(int id, bool passed, string? remarks) { await maintenance.RecordQualityCheckAsync(id, passed, remarks); Success(passed ? "Quality check passed." : "Quality check failed; work continues."); return Back(id); }

    [HttpPost, Permission(AppModule.Maintenance, PermissionAction.Edit)]
    public async Task<IActionResult> Complete(WorkOrderCompletionInput input)
    {
        if (!ModelState.IsValid) { Error("Enter the service report to complete the work."); return Back(input.WorkOrderId); }
        await maintenance.CompleteWorkAsync(input);
        Success("Work completed.");
        return Back(input.WorkOrderId);
    }

    [HttpPost, Permission(AppModule.Maintenance, PermissionAction.Approve)]
    public async Task<IActionResult> Close(int id) { await maintenance.CloseWorkOrderAsync(id); Success("Work order closed."); return Back(id); }

    [HttpPost, Permission(AppModule.Maintenance, PermissionAction.Edit)]
    public async Task<IActionResult> Cancel(int id, string reason) { await maintenance.CancelWorkOrderAsync(id, reason); Success("Work order cancelled."); return Back(id); }

    private IActionResult Back(int id, string? anchor = null) => Redirect($"/WorkOrders/Details/{id}{anchor}");

    private async Task ListsAsync(WorkOrderInput i)
    {
        ViewBag.Assets = await AssetSelectAsync(i.AssetId);
        ViewBag.Technicians = await TechniciansAsync(i.TechnicianUserId);
        ViewBag.Providers = await SelectAsync<ServiceAgency>(i.ServiceProviderId);
    }

    private async Task<SelectList> TechniciansAsync(string? selected)
    {
        var techs = await users.GetUsersInRoleAsync(Roles.MaintenanceTechnician);
        return new SelectList(techs.Where(t => t.IsActive).Select(t => new { t.Id, Text = string.IsNullOrWhiteSpace(t.FullName) ? t.UserName : t.FullName }), "Id", "Text", selected);
    }
}

[Permission(AppModule.Maintenance)]
public sealed class MaintenanceSchedulesController(MaintenanceService maintenance, AppDbContext db) : AppController
{
    public async Task<IActionResult> Index(WorkType? type, bool dueSoon = false, string? q = null, int page = 1)
    {
        Crumbs("Maintenance Schedules", ("Maintenance & Repairs", null), ("Schedules", null));
        var today = Clock.Today;
        var query = db.MaintenanceSchedules.AsNoTracking().Include(s => s.Asset).Include(s => s.ServiceProvider).Where(s => s.IsActive);
        if (CurrentUser.BranchId is { } b) query = query.Where(s => s.Asset!.BranchId == b);
        if (type is not null) query = query.Where(s => s.MaintenanceType == type);
        if (dueSoon) query = query.Where(s => s.NextDueDate <= today.AddDays(30));
        if (!string.IsNullOrWhiteSpace(q)) query = query.Where(s => s.Title.Contains(q) || s.Asset!.AssetTag.Contains(q) || s.Asset.Name.Contains(q));
        int total = await query.CountAsync();
        var list = await query.OrderBy(s => s.NextDueDate).Skip((Math.Max(1, page) - 1) * 25).Take(25).ToListAsync();
        ViewBag.Type = type; ViewBag.DueSoon = dueSoon; ViewBag.Q = q;
        ViewBag.Pager = new PagerModel(Math.Max(1, page), Math.Max(1, (int)Math.Ceiling(total / 25.0)), total, 25);
        return View(list);
    }

    [HttpGet, Permission(AppModule.Maintenance, PermissionAction.Create)]
    public async Task<IActionResult> Edit(int? id, int? assetId)
    {
        ScheduleInput input;
        if (id is { } sid)
        {
            var s = await db.MaintenanceSchedules.AsNoTracking().FirstOrDefaultAsync(x => x.Id == sid);
            if (s is null) return NotFound();
            input = new ScheduleInput
            {
                Id = s.Id, AssetId = s.AssetId, Title = s.Title, MaintenanceType = s.MaintenanceType, Frequency = s.Frequency, CustomIntervalDays = s.CustomIntervalDays,
                StartDate = s.StartDate, EndDate = s.EndDate, LeadDays = s.LeadDays, ServiceProviderId = s.ServiceProviderId, AMContractId = s.AMContractId,
                AssignedTechnician = s.AssignedTechnician, Checklist = s.Checklist, EstimatedCost = s.EstimatedCost, IsActive = s.IsActive
            };
            ViewBag.Upcoming = MaintenanceScheduler.Occurrences(s.StartDate, s.EndDate, s.Frequency, s.CustomIntervalDays, Clock.Today, Clock.Today.AddYears(1)).Take(12).ToList();
            ViewBag.History = await db.MaintenanceHistory.AsNoTracking().Include(h => h.WorkOrder).Where(h => h.MaintenanceScheduleId == sid).OrderByDescending(h => h.PerformedOn).Take(20).ToListAsync();
        }
        else input = new ScheduleInput { AssetId = assetId, StartDate = Clock.Today.AddDays(7) };
        Crumbs(input.Id == 0 ? "New Maintenance Schedule" : "Edit Maintenance Schedule", ("Maintenance Schedules", "/MaintenanceSchedules"), (input.Id == 0 ? "New" : "Edit", null));
        await ListsAsync(input);
        return View(input);
    }

    [HttpPost, Permission(AppModule.Maintenance, PermissionAction.Create)]
    public async Task<IActionResult> Edit(ScheduleInput input)
    {
        if (ModelState.IsValid && await TryAsync(() => maintenance.SaveScheduleAsync(input)))
        {
            Success("Schedule saved.");
            return RedirectToAction(nameof(Index));
        }
        Crumbs("Maintenance Schedule", ("Maintenance Schedules", "/MaintenanceSchedules"), ("Edit", null));
        await ListsAsync(input);
        return View(input);
    }

    [HttpPost, Permission(AppModule.Maintenance, PermissionAction.Create)]
    public async Task<IActionResult> Generate()
    {
        int n = await maintenance.GenerateDueWorkOrdersAsync();
        Success(n == 0 ? "No new work orders were due." : $"{n} work order(s) generated.");
        return RedirectToAction("Index", "WorkOrders");
    }

    private async Task ListsAsync(ScheduleInput i)
    {
        ViewBag.Assets = await AssetSelectAsync(i.AssetId);
        ViewBag.Providers = await SelectAsync<ServiceAgency>(i.ServiceProviderId);
        ViewBag.Contracts = await SelectAsync<AMContract>(i.AMContractId);
    }
}
