using System.ComponentModel.DataAnnotations;
using System.Reflection;
using GlobalAssetManagement.Application.Services;
using GlobalAssetManagement.Domain.Common;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using GlobalAssetManagement.Domain.Logic;
using GlobalAssetManagement.Infrastructure.Persistence;
using GlobalAssetManagement.Web.Security;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.EntityFrameworkCore;

namespace GlobalAssetManagement.Web.Controllers;

public sealed record MasterMeta(string Key, Type Type, string Title, string Singular, AppModule Module, string Section, string? Help = null);

public sealed record FieldMeta(PropertyInfo Prop, string Label, string Kind, bool Required, int? MaxLength, double? Min, double? Max,
    Type? LookupType, bool Grid, string? Hint)
{
    public string Name => Prop.Name;
    public Type UnderlyingType => Nullable.GetUnderlyingType(Prop.PropertyType) ?? Prop.PropertyType;
}

public sealed class MasterIndexViewModel
{
    public MasterMeta Meta { get; init; } = default!;
    public List<FieldMeta> Columns { get; init; } = new();
    public List<object> Rows { get; init; } = new();
    public Dictionary<string, Dictionary<int, string>> LookupTexts { get; init; } = new();
    public string? Search { get; init; }
    public Models.PagerModel Pager { get; init; } = default!;
    public bool CanCreate { get; init; }
    public bool CanEdit { get; init; }
    public bool CanDelete { get; init; }
}

public sealed class MasterEditViewModel
{
    public MasterMeta Meta { get; init; } = default!;
    public List<FieldMeta> Fields { get; init; } = new();
    public object Entity { get; init; } = default!;
    public int Id { get; init; }
    public Dictionary<string, IReadOnlyList<LookupItem>> Lookups { get; init; } = new();
    public IReadOnlyList<string> RoleNames { get; init; } = Roles.All;
}

/// <summary>Generic create / edit / delete screens for master data, driven by entity metadata (DataAnnotations).</summary>
public sealed class MastersController(AppDbContext db, LookupService lookups, PermissionChecker perm, SettingsService settings) : AppController
{
    public static readonly IReadOnlyDictionary<string, MasterMeta> Registry = new Dictionary<string, MasterMeta>(StringComparer.OrdinalIgnoreCase)
    {
        ["AssetCategory"] = new("AssetCategory", typeof(AssetCategory), "Asset Categories", "Asset Category", AppModule.Masters, "Categories & Locations",
            "Default useful life, depreciation method and residual % are applied to new assets of the category. Values are editable accounting settings."),
        ["AssetSubcategory"] = new("AssetSubcategory", typeof(AssetSubcategory), "Asset Subcategories", "Subcategory", AppModule.Masters, "Categories & Locations"),
        ["AssetType"] = new("AssetType", typeof(AssetType), "Asset Types", "Asset Type", AppModule.Masters, "Categories & Locations"),
        ["Manufacturer"] = new("Manufacturer", typeof(Manufacturer), "Manufacturers", "Manufacturer", AppModule.Masters, "Categories & Locations"),
        ["Brand"] = new("Brand", typeof(Brand), "Brands", "Brand", AppModule.Masters, "Categories & Locations"),
        ["AssetModel"] = new("AssetModel", typeof(AssetModel), "Asset Models", "Model", AppModule.Masters, "Categories & Locations"),
        ["Branch"] = new("Branch", typeof(Branch), "Branches", "Branch", AppModule.Masters, "Categories & Locations"),
        ["Department"] = new("Department", typeof(Department), "Departments", "Department", AppModule.Masters, "Categories & Locations"),
        ["Location"] = new("Location", typeof(Location), "Locations", "Location", AppModule.Masters, "Categories & Locations",
            "Building / floor / room within a branch. The rack or position is recorded on each asset."),
        ["Employee"] = new("Employee", typeof(Employee), "Employees", "Employee", AppModule.Masters, "Categories & Locations"),
        ["Vendor"] = new("Vendor", typeof(Vendor), "Vendors", "Vendor", AppModule.Procurement, "Vendors & Procurement"),
        ["ServiceProvider"] = new("ServiceProvider", typeof(ServiceAgency), "Service Providers", "Service Provider", AppModule.Maintenance, "Maintenance & Repairs"),
        ["ApprovalRule"] = new("ApprovalRule", typeof(ApprovalRule), "Approval Rules", "Approval Rule", AppModule.Settings, "Backup & System Settings",
            "A transaction needs approval at every active level whose amount range contains the transaction amount. Levels are approved in order. Super Administrators can approve any level."),
        ["NotificationSetting"] = new("NotificationSetting", typeof(NotificationSetting), "Reminder Settings", "Reminder Setting", AppModule.Notifications, "Notifications & Reminders",
            "Reminders are raised once per interval (e.g. 90, 60, 30, 15 and 7 days before expiry). Email / SMS / WhatsApp are sent only when those channels are configured in appsettings."),
    };

    private static readonly string[] Excluded = { "Id", "CreatedAt", "CreatedBy", "ModifiedAt", "ModifiedBy", "RowVersion", "DisplayName" };

    public static List<FieldMeta> FieldsFor(Type t) => t.GetProperties(BindingFlags.Public | BindingFlags.Instance)
        .Where(p => p.CanWrite && p.CanRead && !Excluded.Contains(p.Name) && p.GetCustomAttribute<ScaffoldColumnAttribute>()?.Scaffold != false)
        .Where(p => IsSimple(Nullable.GetUnderlyingType(p.PropertyType) ?? p.PropertyType))
        .Select(p =>
        {
            var type = Nullable.GetUnderlyingType(p.PropertyType) ?? p.PropertyType;
            var lookup = p.GetCustomAttribute<LookupAttribute>()?.EntityType;
            string kind = lookup is not null ? "lookup"
                : type.IsEnum ? "enum"
                : type == typeof(bool) ? "bool"
                : type == typeof(DateTime) ? "date"
                : type == typeof(int) || type == typeof(decimal) || type == typeof(double) ? "number"
                : p.GetCustomAttribute<MultilineAttribute>() is not null ? "textarea"
                : p.Name is "ApproverRole" or "EscalateToRole" ? "role"
                : p.Name is "RecipientRoles" ? "roles"
                : p.GetCustomAttribute<EmailAddressAttribute>() is not null ? "email"
                : p.GetCustomAttribute<UrlAttribute>() is not null ? "url"
                : p.GetCustomAttribute<PhoneAttribute>() is not null ? "tel"
                : "text";
            var display = p.GetCustomAttribute<DisplayAttribute>();
            var range = p.GetCustomAttribute<RangeAttribute>();
            bool required = p.GetCustomAttribute<RequiredAttribute>() is not null || (lookup is not null && Nullable.GetUnderlyingType(p.PropertyType) is null);
            return new FieldMeta(p, display?.GetName() ?? SplitCamel(p.Name), kind, required,
                p.GetCustomAttribute<StringLengthAttribute>()?.MaximumLength, range is null ? null : Convert.ToDouble(range.Minimum), range is null ? null : Convert.ToDouble(range.Maximum),
                lookup, p.GetCustomAttribute<GridColumnAttribute>() is not null, display?.GetDescription());
        }).ToList();

    private static bool IsSimple(Type t) => t.IsPrimitive || t.IsEnum || t == typeof(string) || t == typeof(decimal) || t == typeof(DateTime);

    private static string SplitCamel(string s) =>
        string.Concat(s.Select((ch, i) => i > 0 && char.IsUpper(ch) && !char.IsUpper(s[i - 1]) ? " " + ch : ch.ToString()));

    private async Task<List<object>> AllAsync(Type t)
    {
        var m = typeof(MastersController).GetMethod(nameof(AllTyped), BindingFlags.NonPublic | BindingFlags.Instance)!.MakeGenericMethod(t);
        return await (Task<List<object>>)m.Invoke(this, null)!;
    }

    private async Task<List<object>> AllTyped<T>() where T : class => (await db.Set<T>().AsNoTracking().ToListAsync()).Cast<object>().ToList();

    [HttpGet]
    public async Task<IActionResult> Index(string entity, string? q, int page = 1)
    {
        if (!Registry.TryGetValue(entity, out var meta)) return NotFound();
        if (!await perm.CanAsync(meta.Module)) return Forbid();
        Crumbs(meta.Title, (meta.Section, null), (meta.Title, null));

        var fields = FieldsFor(meta.Type);
        var columns = fields.Where(f => f.Grid).ToList();
        if (columns.Count == 0) columns = fields.Take(5).ToList();
        var rows = await AllAsync(meta.Type);
        if (!string.IsNullOrWhiteSpace(q))
        {
            var term = q.Trim();
            rows = rows.Where(r => fields.Any(f => f.Prop.GetValue(r) is string s && s.Contains(term, StringComparison.OrdinalIgnoreCase))
                                   || (r is IHasDisplayName dn && dn.DisplayName.Contains(term, StringComparison.OrdinalIgnoreCase))).ToList();
        }
        rows = rows.OrderBy(r => r is IHasDisplayName d ? d.DisplayName : columns.Count > 0 ? columns[0].Prop.GetValue(r)?.ToString() : "").ToList();

        var lookupTexts = new Dictionary<string, Dictionary<int, string>>();
        foreach (var c in columns.Where(c => c.LookupType is not null))
            lookupTexts[c.Name] = (await lookups.ForTypeAsync(c.LookupType!)).ToDictionary(i => i.Id, i => i.Text);

        const int size = 50;
        int total = rows.Count;
        page = Math.Max(1, page);
        return View(new MasterIndexViewModel
        {
            Meta = meta, Columns = columns, Rows = rows.Skip((page - 1) * size).Take(size).ToList(), LookupTexts = lookupTexts, Search = q,
            Pager = new Models.PagerModel(page, Math.Max(1, (int)Math.Ceiling(total / (double)size)), total, size),
            CanCreate = await perm.CanAsync(meta.Module, PermissionAction.Create),
            CanEdit = await perm.CanAsync(meta.Module, PermissionAction.Edit),
            CanDelete = await perm.CanAsync(meta.Module, PermissionAction.Delete)
        });
    }

    [HttpGet]
    public async Task<IActionResult> Create(string entity)
    {
        if (!Registry.TryGetValue(entity, out var meta)) return NotFound();
        if (!await perm.CanAsync(meta.Module, PermissionAction.Create)) return Forbid();
        var e = Activator.CreateInstance(meta.Type)!;
        if (e is Branch b) b.CompanyId = (await settings.GetCompanyAsync()).Id;
        return await EditView(meta, e, 0);
    }

    [HttpGet]
    public async Task<IActionResult> Edit(string entity, int id)
    {
        if (!Registry.TryGetValue(entity, out var meta)) return NotFound();
        if (!await perm.CanAsync(meta.Module, PermissionAction.Edit) && !await perm.CanAsync(meta.Module)) return Forbid();
        var e = await db.FindAsync(meta.Type, id);
        if (e is null) return NotFound();
        ViewData["ReadOnly"] = !await perm.CanAsync(meta.Module, PermissionAction.Edit);
        return await EditView(meta, e, id);
    }

    [HttpPost]
    public async Task<IActionResult> Save(string entity, int id)
    {
        if (!Registry.TryGetValue(entity, out var meta)) return NotFound();
        if (!await perm.CanAsync(meta.Module, id == 0 ? PermissionAction.Create : PermissionAction.Edit)) return Forbid();

        object? e = id == 0 ? Activator.CreateInstance(meta.Type) : await db.FindAsync(meta.Type, id);
        if (e is null) return NotFound();
        var editable = FieldsFor(meta.Type).Select(f => f.Name).ToHashSet();
        var valueProvider = await CompositeValueProvider.CreateAsync(ControllerContext);
        await TryUpdateModelAsync(e, meta.Type, string.Empty, valueProvider, m => m.PropertyName is not null && editable.Contains(m.PropertyName));

        foreach (var f in FieldsFor(meta.Type).Where(f => f.Kind == "text" && f.Prop.GetValue(e) is string))
            f.Prop.SetValue(e, ((string)f.Prop.GetValue(e)!).Trim());
        if (e is NotificationSetting ns && !string.IsNullOrWhiteSpace(ns.DaysBefore))
            ns.DaysBefore = string.Join(",", ReminderPlanner.ParseDays(ns.DaysBefore));

        if (!ModelState.IsValid) return await EditView(meta, e, id);
        if (id == 0) db.Add(e);
        try
        {
            await db.SaveChangesAsync();
        }
        catch (DbUpdateException ex)
        {
            ModelState.AddModelError(string.Empty, ex.InnerException?.Message.Contains("UNIQUE", StringComparison.OrdinalIgnoreCase) == true || ex.InnerException?.Message.Contains("duplicate", StringComparison.OrdinalIgnoreCase) == true
                ? "A record with the same code / name already exists."
                : "The record could not be saved: " + (ex.InnerException?.Message ?? ex.Message));
            if (id == 0) db.Entry(e).State = EntityState.Detached;
            return await EditView(meta, e, id);
        }
        if (e is Company) settings.Invalidate();
        Success($"{meta.Singular} saved.");
        return RedirectToAction(nameof(Index), new { entity = meta.Key });
    }

    [HttpPost]
    public async Task<IActionResult> Delete(string entity, int id)
    {
        if (!Registry.TryGetValue(entity, out var meta)) return NotFound();
        if (!await perm.CanAsync(meta.Module, PermissionAction.Delete)) return Forbid();
        var e = await db.FindAsync(meta.Type, id);
        if (e is null) return NotFound();
        db.Remove(e);
        try
        {
            await db.SaveChangesAsync();
            Success($"{meta.Singular} deleted.");
        }
        catch (DbUpdateException)
        {
            db.Entry(e).State = EntityState.Unchanged;
            if (e is IActivatable act)
            {
                act.IsActive = false;
                await db.SaveChangesAsync();
                Error($"This {meta.Singular.ToLowerInvariant()} is used by other records, so it was deactivated instead of deleted.");
            }
            else Error($"This {meta.Singular.ToLowerInvariant()} is used by other records and cannot be deleted.");
        }
        return RedirectToAction(nameof(Index), new { entity = meta.Key });
    }

    private async Task<IActionResult> EditView(MasterMeta meta, object e, int id)
    {
        Crumbs((id == 0 ? "New " : "Edit ") + meta.Singular, (meta.Section, null), (meta.Title, Url.Action(nameof(Index), new { entity = meta.Key })), (id == 0 ? "New" : "Edit", null));
        var fields = FieldsFor(meta.Type);
        var lk = new Dictionary<string, IReadOnlyList<LookupItem>>();
        foreach (var f in fields.Where(f => f.LookupType is not null))
            lk[f.Name] = await lookups.ForTypeAsync(f.LookupType!);
        return View("Edit", new MasterEditViewModel { Meta = meta, Fields = fields, Entity = e, Id = id, Lookups = lk });
    }
}
