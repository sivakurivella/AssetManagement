using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Application.Models;
using GlobalAssetManagement.Application.Services;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using GlobalAssetManagement.Domain.Logic;
using GlobalAssetManagement.Infrastructure.Persistence;
using GlobalAssetManagement.Web.Models;
using GlobalAssetManagement.Web.Security;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace GlobalAssetManagement.Web.Controllers;

[Permission(AppModule.WarrantyAmc)]
public sealed class WarrantiesController(WarrantyAmcService service, AppDbContext db) : AppController
{
    public async Task<IActionResult> Index(CoverageStatus? status, int? branchId)
    {
        Crumbs("Warranties", ("Warranty & AMC", null), ("Warranties", null));
        ViewBag.Status = status;
        ViewBag.Branches = await SelectAsync<Branch>(branchId);
        var rows = await service.WarrantiesAsync(status, branchId);
        ViewBag.Counts = (await service.WarrantiesAsync(null, branchId)).GroupBy(r => r.Status).ToDictionary(g => g.Key, g => g.Count());
        return View(rows);
    }

    [HttpGet, Permission(AppModule.WarrantyAmc, PermissionAction.Create)]
    public async Task<IActionResult> Edit(int? id, int? assetId)
    {
        WarrantyInput input;
        if (id is { } wid)
        {
            var w = await db.WarrantyRecords.AsNoTracking().FirstOrDefaultAsync(x => x.Id == wid);
            if (w is null) return NotFound();
            input = new WarrantyInput
            {
                Id = w.Id, AssetId = w.AssetId, WarrantyType = w.WarrantyType, Provider = w.Provider, StartDate = w.StartDate, ExpiryDate = w.ExpiryDate,
                Terms = w.Terms, CoverageDetails = w.CoverageDetails, ClaimContact = w.ClaimContact, CertificateNo = w.CertificateNo, IsPrimary = w.IsPrimary
            };
        }
        else input = new WarrantyInput { AssetId = assetId, StartDate = Clock.Today, ExpiryDate = Clock.Today.AddYears(1).AddDays(-1) };
        Crumbs(input.Id == 0 ? "Add Warranty" : "Edit Warranty", ("Warranties", "/Warranties"), (input.Id == 0 ? "New" : "Edit", null));
        ViewBag.Assets = await AssetSelectAsync(input.AssetId);
        return View(input);
    }

    [HttpPost, Permission(AppModule.WarrantyAmc, PermissionAction.Create)]
    public async Task<IActionResult> Edit(WarrantyInput input)
    {
        if (ModelState.IsValid && await TryAsync(() => service.SaveWarrantyAsync(input)))
        {
            Success("Warranty saved.");
            return RedirectToAction("Details", "Assets", new { id = input.AssetId });
        }
        Crumbs("Warranty", ("Warranties", "/Warranties"), ("Edit", null));
        ViewBag.Assets = await AssetSelectAsync(input.AssetId);
        return View(input);
    }

    [HttpPost, Permission(AppModule.WarrantyAmc, PermissionAction.Delete)]
    public async Task<IActionResult> Delete(int id)
    {
        await service.DeleteWarrantyAsync(id);
        Success("Warranty record deleted.");
        return RedirectToAction(nameof(Index));
    }
}

[Permission(AppModule.WarrantyAmc)]
public sealed class AmcController(WarrantyAmcService service, ApprovalService approvals, AttachmentService attachments, AppDbContext db) : AppController
{
    public async Task<IActionResult> Index(AmcRenewalStatus? status, int? providerId)
    {
        Crumbs("AMC Contracts", ("Warranty & AMC", null), ("AMC Contracts", null));
        var q = db.AMContracts.AsNoTracking().Include(c => c.ServiceProvider).Include(c => c.CoveredAssets).AsQueryable();
        if (status is not null) q = q.Where(c => c.RenewalStatus == status);
        if (providerId is not null) q = q.Where(c => c.ServiceProviderId == providerId);
        ViewBag.Status = status;
        ViewBag.Providers = await SelectAsync<ServiceAgency>(providerId);
        return View(await q.OrderBy(c => c.ExpiryDate).ToListAsync());
    }

    [HttpGet, Permission(AppModule.WarrantyAmc, PermissionAction.Create)]
    public async Task<IActionResult> Edit(int? id)
    {
        AmcInput input;
        if (id is { } cid)
        {
            var c = await db.AMContracts.AsNoTracking().Include(x => x.CoveredAssets).FirstOrDefaultAsync(x => x.Id == cid);
            if (c is null) return NotFound();
            input = new AmcInput
            {
                Id = c.Id, ContractNo = c.ContractNo, ServiceProviderId = c.ServiceProviderId, ContractType = c.ContractType, StartDate = c.StartDate, ExpiryDate = c.ExpiryDate,
                AnnualValue = c.AnnualValue, TaxAmount = c.TaxAmount, VisitsPerYear = c.VisitsPerYear, ResponseTimeHours = c.ResponseTimeHours,
                ResolutionTimeHours = c.ResolutionTimeHours, Coverage = c.Coverage, Terms = c.Terms, AssetIds = c.CoveredAssets.Select(a => a.AssetId).ToList(), GenerateVisits = false
            };
        }
        else input = new AmcInput { StartDate = Clock.Today, ExpiryDate = Clock.Today.AddYears(1).AddDays(-1) };
        Crumbs(input.Id == 0 ? "New AMC Contract" : "Edit AMC Contract", ("AMC Contracts", "/Amc"), (input.Id == 0 ? "New" : input.ContractNo, null));
        await ListsAsync(input);
        return View(input);
    }

    [HttpPost, Permission(AppModule.WarrantyAmc, PermissionAction.Create)]
    public async Task<IActionResult> Edit(AmcInput input)
    {
        AMContract? c = null;
        if (ModelState.IsValid && await TryAsync(async () => c = await service.SaveAmcAsync(input)))
        {
            Success($"Contract {c!.ContractNo} saved.");
            return RedirectToAction(nameof(Details), new { id = c.Id });
        }
        Crumbs("AMC Contract", ("AMC Contracts", "/Amc"), ("Edit", null));
        await ListsAsync(input);
        return View(input);
    }

    public async Task<IActionResult> Details(int id, [FromServices] PermissionChecker perm)
    {
        var c = await db.AMContracts.AsNoTracking().Include(x => x.ServiceProvider).Include(x => x.CoveredAssets).ThenInclude(a => a.Asset)
            .Include(x => x.Visits).ThenInclude(v => v.Asset).Include(x => x.RenewedFromContract).AsSplitQuery().FirstOrDefaultAsync(x => x.Id == id);
        if (c is null) return NotFound();
        Crumbs(c.ContractNo, ("AMC Contracts", "/Amc"), (c.ContractNo, null));
        ViewBag.Approvals = new ApprovalPanelModel(await approvals.HistoryAsync(ApprovalModule.AmcRenewal, id));
        ViewBag.Attachments = new AttachmentsPanelModel("AMContract", id, await attachments.ListAsync("AMContract", id), await perm.CanAsync(AppModule.WarrantyAmc, PermissionAction.Create));
        ViewBag.RenewedTo = await db.AMContracts.AsNoTracking().Where(x => x.RenewedFromContractId == id).ToListAsync();
        ViewBag.AssetItems = c.CoveredAssets.Select(a => new SelectListItem(a.Asset!.DisplayName, a.AssetId.ToString())).ToList();
        return View(c);
    }

    [HttpPost, Permission(AppModule.WarrantyAmc, PermissionAction.Edit)]
    public async Task<IActionResult> Visit(ServiceVisitInput input)
    {
        await service.SaveVisitAsync(input);
        Success("Service visit recorded.");
        return RedirectToAction(nameof(Details), new { id = input.AMContractId });
    }

    [HttpPost, Permission(AppModule.WarrantyAmc, PermissionAction.Edit)]
    public async Task<IActionResult> Renew(int id, decimal proposedCost)
    {
        await service.RequestRenewalAsync(id, proposedCost);
        Success("Renewal processed. If approval is required, the renewal is waiting for approval.");
        return RedirectToAction(nameof(Details), new { id });
    }

    private async Task ListsAsync(AmcInput i)
    {
        ViewBag.Providers = await SelectAsync<ServiceAgency>(i.ServiceProviderId);
        var items = await Lookups.AssetsAsync(CurrentUser, null, 3000);
        ViewBag.AssetItems = items.Select(a => new SelectListItem(a.Text, a.Id.ToString(), i.AssetIds.Contains(a.Id))).ToList();
    }
}

[Permission(AppModule.Verification)]
public sealed class VerificationController(VerificationService verification, ApprovalService approvals, AppDbContext db) : AppController
{
    public async Task<IActionResult> Index()
    {
        Crumbs("Physical Verification", ("Physical Verification", null));
        var q = db.PhysicalVerificationSessions.AsNoTracking().Include(s => s.Branch).Include(s => s.Department).Include(s => s.Location).AsQueryable();
        if (CurrentUser.BranchId is { } b) q = q.Where(s => s.BranchId == b);
        var list = await q.OrderByDescending(s => s.StartedAt).Take(100)
            .Select(s => new { Session = s, Expected = s.Items.Count(i => i.IsExpected), Found = s.Items.Count(i => i.Result == VerificationResult.Found || (i.IsExpected && i.Result == VerificationResult.WrongLocation)) })
            .ToListAsync();
        ViewBag.Progress = list.ToDictionary(x => x.Session.Id, x => (x.Found, x.Expected));
        return View(list.Select(x => x.Session).ToList());
    }

    [HttpGet, Permission(AppModule.Verification, PermissionAction.Create)]
    public async Task<IActionResult> Create()
    {
        Crumbs("New Verification Session", ("Physical Verification", "/Verification"), ("New", null));
        var input = new VerificationSessionInput { Title = $"Physical verification {Clock.Today:MMM yyyy}", BranchId = CurrentUser.BranchId };
        await ListsAsync(input);
        return View(input);
    }

    [HttpPost, Permission(AppModule.Verification, PermissionAction.Create)]
    public async Task<IActionResult> Create(VerificationSessionInput input)
    {
        PhysicalVerificationSession? s = null;
        if (ModelState.IsValid && await TryAsync(async () => s = await verification.CreateSessionAsync(input)))
        {
            Success($"{s!.SessionNo} started with {s.Items.Count} expected assets.");
            return RedirectToAction(nameof(Scan), new { id = s.Id });
        }
        Crumbs("New Verification Session", ("Physical Verification", "/Verification"), ("New", null));
        await ListsAsync(input);
        return View(input);
    }

    /// <summary>Mobile-friendly scanning page (camera or USB / Bluetooth barcode scanner).</summary>
    [HttpGet, Permission(AppModule.Verification, PermissionAction.Edit)]
    public async Task<IActionResult> Scan(int id)
    {
        var s = await db.PhysicalVerificationSessions.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        if (s is null) return NotFound();
        Crumbs($"Scan · {s.SessionNo}", ("Physical Verification", "/Verification"), (s.SessionNo, $"/Verification/Details/{id}"), ("Scan", null));
        ViewBag.Locations = await SelectAsync<Location>(s.LocationId);
        return View(s);
    }

    [HttpPost, Permission(AppModule.Verification, PermissionAction.Edit)]
    public async Task<IActionResult> ScanCode([FromForm] ScanInput input)
    {
        if (!ModelState.IsValid) return BadRequest(new { ok = false, message = "Invalid scan." });
        var r = await verification.ScanAsync(input);
        return Json(new { ok = r.Ok, result = r.Result.ToString(), resultText = r.Result.DisplayName(), message = r.Message, tag = r.AssetTag, name = r.AssetName, found = r.Found, expected = r.Expected });
    }

    public async Task<IActionResult> Details(int id, VerificationResult? result)
    {
        var s = await db.PhysicalVerificationSessions.AsNoTracking().Include(x => x.Branch).Include(x => x.Department).Include(x => x.Location)
            .Include(x => x.Items).ThenInclude(i => i.Asset).Include(x => x.Items).ThenInclude(i => i.ExpectedLocation)
            .Include(x => x.Items).ThenInclude(i => i.FoundLocation).AsSplitQuery().FirstOrDefaultAsync(x => x.Id == id);
        if (s is null) return NotFound();
        Crumbs(s.SessionNo, ("Physical Verification", "/Verification"), (s.SessionNo, null));
        ViewBag.Filter = result;
        ViewBag.Summary = VerificationService.Summary(s);
        ViewBag.Approvals = new ApprovalPanelModel(await approvals.HistoryAsync(ApprovalModule.PhysicalVerification, id));
        return View(s);
    }

    [HttpPost, Permission(AppModule.Verification, PermissionAction.Edit)]
    public async Task<IActionResult> UpdateItem(int id, int itemId, VerificationResult? result, AssetCondition? condition, string? remarks)
    {
        await verification.UpdateItemAsync(itemId, result, condition, remarks);
        return Redirect($"/Verification/Details/{id}#item{itemId}");
    }

    [HttpPost, Permission(AppModule.Verification, PermissionAction.Edit)]
    public async Task<IActionResult> Submit(int id)
    {
        await verification.SubmitAsync(id);
        Success("Session submitted. Unscanned assets are reported as missing.");
        return RedirectToAction(nameof(Details), new { id });
    }

    private async Task ListsAsync(VerificationSessionInput i)
    {
        ViewBag.Branches = await SelectAsync<Branch>(i.BranchId);
        ViewBag.Departments = await SelectAsync<Department>(i.DepartmentId);
        ViewBag.Locations = await SelectAsync<Location>(i.LocationId);
    }
}

[Permission(AppModule.Depreciation)]
public sealed class DepreciationController(DepreciationService depreciation, SettingsService settings, AppDbContext db) : AppController
{
    public async Task<IActionResult> Index()
    {
        Crumbs("Depreciation Runs", ("Depreciation & Valuation", null), ("Runs", null));
        return View(await db.DepreciationSchedules.AsNoTracking().Include(r => r.Branch).OrderByDescending(r => r.PeriodTo).ThenByDescending(r => r.Id).Take(200).ToListAsync());
    }

    [HttpGet, Permission(AppModule.Depreciation, PermissionAction.Create)]
    public async Task<IActionResult> Run(DateTime? from, DateTime? to, int? branchId, string? fy)
    {
        Crumbs("Run Depreciation", ("Depreciation & Valuation", "/Depreciation"), ("Run", null));
        var company = await settings.GetCompanyAsync();
        var cur = FinancialYear.For(Clock.Today, company.FinancialYearStartMonth);
        if (!string.IsNullOrWhiteSpace(fy)) { var f = FinancialYear.FromLabel(fy, company.FinancialYearStartMonth); from ??= f.Start; to ??= f.End; }
        from ??= cur.Start;
        to ??= Clock.Today < cur.End ? new DateTime(Clock.Today.Year, Clock.Today.Month, 1).AddDays(-1) : cur.End;
        if (to < from) to = from;
        ViewBag.From = from; ViewBag.To = to; ViewBag.BranchId = branchId;
        ViewBag.Branches = await SelectAsync<Branch>(branchId);
        ViewBag.Years = Enumerable.Range(0, 6).Select(i => FinancialYear.For(cur.Start.AddYears(-i), company.FinancialYearStartMonth).Label).ToList();
        return View(await depreciation.PreviewAsync(from.Value, to.Value, branchId));
    }

    [HttpPost, Permission(AppModule.Depreciation, PermissionAction.Approve)]
    public async Task<IActionResult> Post(DateTime from, DateTime to, int? branchId, string? remarks)
    {
        var run = await depreciation.PostAsync(from, to, branchId, remarks);
        Success($"{run.RunNo} posted: {run.AssetCount} assets, depreciation {run.TotalDepreciation:N2}.");
        return RedirectToAction(nameof(Details), new { id = run.Id });
    }

    public async Task<IActionResult> Details(int id)
    {
        var run = await db.DepreciationSchedules.AsNoTracking().Include(r => r.Branch).Include(r => r.Transactions).ThenInclude(t => t.Asset).AsSplitQuery().FirstOrDefaultAsync(r => r.Id == id);
        if (run is null) return NotFound();
        Crumbs(run.RunNo, ("Depreciation Runs", "/Depreciation"), (run.RunNo, null));
        return View(run);
    }

    [HttpPost, Permission(AppModule.Depreciation, PermissionAction.Approve)]
    public async Task<IActionResult> Reverse(int id, string reason)
    {
        await depreciation.ReverseAsync(id, reason);
        Success("Depreciation run reversed.");
        return RedirectToAction(nameof(Details), new { id });
    }

    public async Task<IActionResult> Valuation(string groupBy = "category", int? branchId = null)
    {
        Crumbs("Valuation Summary", ("Depreciation & Valuation", null), ("Valuation", null));
        ViewBag.GroupBy = groupBy;
        ViewBag.Branches = await SelectAsync<Branch>(branchId);
        return View(await depreciation.ValuationAsync(groupBy, branchId));
    }
}

[Permission(AppModule.Disposal)]
public sealed class DisposalsController(DisposalService disposals, ApprovalService approvals, AttachmentService attachments, AppDbContext db) : AppController
{
    public async Task<IActionResult> Index(DisposalStatus? status)
    {
        Crumbs("Disposals", ("Disposal & Retirement", null));
        var q = db.AssetDisposals.AsNoTracking().Include(d => d.Asset).AsQueryable();
        if (CurrentUser.BranchId is { } b) q = q.Where(d => d.Asset!.BranchId == b);
        if (status is not null) q = q.Where(d => d.Status == status);
        ViewBag.Status = status;
        return View(await q.OrderByDescending(d => d.RequestDate).ThenByDescending(d => d.Id).Take(300).ToListAsync());
    }

    [HttpGet, Permission(AppModule.Disposal, PermissionAction.Create)]
    public async Task<IActionResult> Create(int? assetId)
    {
        Crumbs("Dispose / Retire Asset", ("Disposals", "/Disposals"), ("New", null));
        ViewBag.Assets = await AssetSelectAsync(assetId);
        return View(new DisposalInput { AssetId = assetId, ProposedDisposalDate = Clock.Today });
    }

    [HttpPost, Permission(AppModule.Disposal, PermissionAction.Create)]
    public async Task<IActionResult> Create(DisposalInput input)
    {
        AssetDisposal? d = null;
        if (ModelState.IsValid && await TryAsync(async () => d = await disposals.RequestAsync(input)))
        {
            Success($"{d!.DisposalNo} {(d.Status == DisposalStatus.Approved ? "approved" : "submitted for approval")}.");
            return RedirectToAction(nameof(Details), new { id = d.Id });
        }
        Crumbs("Dispose / Retire Asset", ("Disposals", "/Disposals"), ("New", null));
        ViewBag.Assets = await AssetSelectAsync(input.AssetId);
        return View(input);
    }

    public async Task<IActionResult> Details(int id, DateTime? previewDate, decimal? previewValue, [FromServices] PermissionChecker perm = null!)
    {
        var d = await db.AssetDisposals.AsNoTracking().Include(x => x.Asset).FirstOrDefaultAsync(x => x.Id == id);
        if (d is null) return NotFound();
        Crumbs(d.DisposalNo, ("Disposals", "/Disposals"), (d.DisposalNo, null));
        ViewBag.Approvals = new ApprovalPanelModel(await approvals.HistoryAsync(ApprovalModule.AssetDisposal, id));
        ViewBag.Attachments = new AttachmentsPanelModel("AssetDisposal", id, await attachments.ListAsync("AssetDisposal", id), await perm.CanAsync(AppModule.Disposal, PermissionAction.Create));
        if (d.Status == DisposalStatus.Approved)
        {
            var date = previewDate ?? (d.ProposedDisposalDate > Clock.Today ? Clock.Today : d.ProposedDisposalDate);
            ViewBag.PreviewDate = date;
            ViewBag.PreviewValue = previewValue ?? d.ExpectedValue;
            ViewBag.Preview = await disposals.PreviewAsync(id, date, previewValue ?? d.ExpectedValue);
        }
        return View(d);
    }

    [HttpPost, Permission(AppModule.Disposal, PermissionAction.Edit)]
    public async Task<IActionResult> Complete(CompleteDisposalInput input)
    {
        await disposals.CompleteAsync(input);
        Success("Disposal completed and locked.");
        return RedirectToAction(nameof(Details), new { id = input.Id });
    }
}
