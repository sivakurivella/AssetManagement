using System.Text;
using System.Text.Encodings.Web;
using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Application.Common.Documents;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Infrastructure.Identity;
using GlobalAssetManagement.Infrastructure.Persistence;
using GlobalAssetManagement.Web.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.AspNetCore.WebUtilities;

namespace GlobalAssetManagement.Web.Controllers;

public sealed class AccountController(
    SignInManager<ApplicationUser> signIn,
    UserManager<ApplicationUser> users,
    AppDbContext db,
    IEmailSender email,
    IClock clock,
    ILogger<AccountController> logger) : AppController
{
    [AllowAnonymous, HttpGet]
    public IActionResult Login(string? returnUrl = null)
    {
        if (User.Identity?.IsAuthenticated == true) return RedirectToLocal(returnUrl, "Index");
        ViewData["Title"] = "Sign in";
        return View(new LoginViewModel { ReturnUrl = returnUrl });
    }

    [AllowAnonymous, HttpPost, EnableRateLimiting("login")]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        ViewData["Title"] = "Sign in";
        if (!ModelState.IsValid) return View(model);

        var user = await users.FindByNameAsync(model.UserName.Trim()) ?? await users.FindByEmailAsync(model.UserName.Trim());
        if (user is null || !user.IsActive)
        {
            await RecordLoginAsync(user, model.UserName, false, user is null ? "Unknown user" : "Inactive account");
            ModelState.AddModelError(string.Empty, "Invalid user name or password.");
            return View(model);
        }

        var result = await signIn.PasswordSignInAsync(user, model.Password, model.RememberMe, lockoutOnFailure: true);
        if (result.Succeeded)
        {
            user.LastLoginAt = clock.UtcNow;
            await users.UpdateAsync(user);
            await RecordLoginAsync(user, user.UserName!, true, null);
            logger.LogInformation("User {User} signed in", user.UserName);
            return RedirectToLocal(model.ReturnUrl, "Index");
        }
        if (result.RequiresTwoFactor)
            return RedirectToAction(nameof(LoginWith2fa), new { returnUrl = model.ReturnUrl, rememberMe = model.RememberMe });
        if (result.IsLockedOut)
        {
            await RecordLoginAsync(user, user.UserName!, false, "Locked out");
            logger.LogWarning("User {User} locked out", user.UserName);
            ModelState.AddModelError(string.Empty, "This account is locked after repeated failed attempts. Try again in 15 minutes or contact your administrator.");
            return View(model);
        }
        await RecordLoginAsync(user, user.UserName!, false, "Wrong password");
        ModelState.AddModelError(string.Empty, "Invalid user name or password.");
        return View(model);
    }

    [AllowAnonymous, HttpGet]
    public async Task<IActionResult> LoginWith2fa(bool rememberMe, string? returnUrl = null)
    {
        if (await signIn.GetTwoFactorAuthenticationUserAsync() is null) return RedirectToAction(nameof(Login));
        ViewData["Title"] = "Two-factor authentication";
        return View(new TwoFactorLoginViewModel { RememberMe = rememberMe, ReturnUrl = returnUrl });
    }

    [AllowAnonymous, HttpPost, EnableRateLimiting("login")]
    public async Task<IActionResult> LoginWith2fa(TwoFactorLoginViewModel model)
    {
        ViewData["Title"] = "Two-factor authentication";
        var user = await signIn.GetTwoFactorAuthenticationUserAsync();
        if (user is null) return RedirectToAction(nameof(Login));
        if (!ModelState.IsValid) return View(model);

        var code = model.Code.Replace(" ", "").Replace("-", "");
        var result = model.UseRecoveryCode
            ? await signIn.TwoFactorRecoveryCodeSignInAsync(code)
            : await signIn.TwoFactorAuthenticatorSignInAsync(code, model.RememberMe, model.RememberMachine);
        if (result.Succeeded)
        {
            user.LastLoginAt = clock.UtcNow;
            await users.UpdateAsync(user);
            await RecordLoginAsync(user, user.UserName!, true, null);
            return RedirectToLocal(model.ReturnUrl, "Index");
        }
        await RecordLoginAsync(user, user.UserName!, false, result.IsLockedOut ? "Locked out (2FA)" : "Invalid 2FA code");
        ModelState.AddModelError(string.Empty, result.IsLockedOut ? "Account locked. Try again later." : "Invalid code.");
        return View(model);
    }

    [HttpPost]
    public async Task<IActionResult> Logout()
    {
        var name = User.Identity?.Name;
        await signIn.SignOutAsync();
        if (name is not null)
        {
            var last = db.LoginHistory.Where(l => l.UserName == name && l.Succeeded && l.LoggedOutAt == null).OrderByDescending(l => l.AttemptedAt).FirstOrDefault();
            if (last is not null) { last.LoggedOutAt = clock.UtcNow; await db.SaveChangesAsync(); }
        }
        return RedirectToAction(nameof(Login));
    }

    [AllowAnonymous, HttpGet]
    public IActionResult ForgotPassword()
    {
        ViewData["Title"] = "Forgot password";
        ViewData["EmailConfigured"] = email.IsConfigured;
        return View(new ForgotPasswordViewModel());
    }

    [AllowAnonymous, HttpPost, EnableRateLimiting("login")]
    public async Task<IActionResult> ForgotPassword(ForgotPasswordViewModel model)
    {
        ViewData["Title"] = "Forgot password";
        ViewData["EmailConfigured"] = email.IsConfigured;
        if (!ModelState.IsValid) return View(model);
        var user = await users.FindByEmailAsync(model.Email);
        if (user is not null && user.IsActive && email.IsConfigured)
        {
            var token = WebEncoders.Base64UrlEncode(Encoding.UTF8.GetBytes(await users.GeneratePasswordResetTokenAsync(user)));
            var link = Url.Action(nameof(ResetPassword), "Account", new { token, email = user.Email }, Request.Scheme)!;
            await email.SendAsync(user.Email!, "Reset your Global Asset Management password",
                $"<p>Hello {HtmlEncoder.Default.Encode(user.FullName)},</p><p>Use the link below to set a new password. The link can be used once.</p><p><a href=\"{HtmlEncoder.Default.Encode(link)}\">Reset password</a></p><p>If you did not request this, ignore this email.</p>");
        }
        // Same response whether or not the account exists (prevents account enumeration).
        TempData["Success"] = email.IsConfigured
            ? "If the email belongs to an active account, a reset link has been sent."
            : "Email is not configured on this server. Please ask your administrator to reset your password.";
        return RedirectToAction(nameof(Login));
    }

    [AllowAnonymous, HttpGet]
    public IActionResult ResetPassword(string token, string email)
    {
        ViewData["Title"] = "Reset password";
        return View(new ResetPasswordViewModel { Token = token, Email = email });
    }

    [AllowAnonymous, HttpPost]
    public async Task<IActionResult> ResetPassword(ResetPasswordViewModel model)
    {
        ViewData["Title"] = "Reset password";
        if (!ModelState.IsValid) return View(model);
        var user = await users.FindByEmailAsync(model.Email);
        if (user is null) { TempData["Success"] = "Password has been reset."; return RedirectToAction(nameof(Login)); }
        string token;
        try { token = Encoding.UTF8.GetString(WebEncoders.Base64UrlDecode(model.Token)); }
        catch (FormatException) { ModelState.AddModelError(string.Empty, "The reset link is invalid."); return View(model); }
        var result = await users.ResetPasswordAsync(user, token, model.Password);
        if (result.Succeeded)
        {
            user.MustChangePassword = false;
            await users.UpdateAsync(user);
            await users.SetLockoutEndDateAsync(user, null);
            TempData["Success"] = "Password has been reset. Please sign in.";
            return RedirectToAction(nameof(Login));
        }
        foreach (var e in result.Errors) ModelState.AddModelError(string.Empty, e.Description);
        return View(model);
    }

    [HttpGet]
    public IActionResult ChangePassword()
    {
        Crumbs("Change Password", ("Change Password", null));
        return View(new ChangePasswordViewModel());
    }

    [HttpPost]
    public async Task<IActionResult> ChangePassword(ChangePasswordViewModel model)
    {
        Crumbs("Change Password", ("Change Password", null));
        if (!ModelState.IsValid) return View(model);
        var user = await users.GetUserAsync(User);
        if (user is null) return RedirectToAction(nameof(Login));
        var result = await users.ChangePasswordAsync(user, model.CurrentPassword, model.NewPassword);
        if (!result.Succeeded)
        {
            foreach (var e in result.Errors) ModelState.AddModelError(string.Empty, e.Description);
            return View(model);
        }
        user.MustChangePassword = false;
        await users.UpdateAsync(user);
        await signIn.RefreshSignInAsync(user);
        Success("Your password has been changed.");
        return RedirectToAction("Index", "Home");
    }

    [HttpGet]
    public async Task<IActionResult> TwoFactor()
    {
        Crumbs("Two-factor Authentication", ("Two-factor Authentication", null));
        var user = await users.GetUserAsync(User);
        if (user is null) return RedirectToAction(nameof(Login));
        ViewData["Enabled"] = user.TwoFactorEnabled;
        ViewData["RecoveryLeft"] = user.TwoFactorEnabled ? await users.CountRecoveryCodesAsync(user) : 0;
        return View();
    }

    [HttpGet]
    public async Task<IActionResult> EnableAuthenticator()
    {
        Crumbs("Enable Authenticator App", ("Two-factor Authentication", "/Account/TwoFactor"), ("Enable", null));
        var user = await users.GetUserAsync(User);
        if (user is null) return RedirectToAction(nameof(Login));
        return View(await BuildAuthenticatorModelAsync(user));
    }

    [HttpPost]
    public async Task<IActionResult> EnableAuthenticator(EnableAuthenticatorViewModel model)
    {
        Crumbs("Enable Authenticator App", ("Two-factor Authentication", "/Account/TwoFactor"), ("Enable", null));
        var user = await users.GetUserAsync(User);
        if (user is null) return RedirectToAction(nameof(Login));
        if (!ModelState.IsValid) return View(await BuildAuthenticatorModelAsync(user));
        var code = model.Code.Replace(" ", "").Replace("-", "");
        bool valid = await users.VerifyTwoFactorTokenAsync(user, users.Options.Tokens.AuthenticatorTokenProvider, code);
        if (!valid)
        {
            ModelState.AddModelError(nameof(model.Code), "The code is not valid. Check the time on your phone and try again.");
            return View(await BuildAuthenticatorModelAsync(user));
        }
        await users.SetTwoFactorEnabledAsync(user, true);
        var codes = await users.GenerateNewTwoFactorRecoveryCodesAsync(user, 10);
        TempData["RecoveryCodes"] = string.Join(" ", codes ?? Array.Empty<string>());
        Success("Two-factor authentication is now enabled.");
        return RedirectToAction(nameof(RecoveryCodes));
    }

    [HttpGet]
    public IActionResult RecoveryCodes()
    {
        Crumbs("Recovery Codes", ("Two-factor Authentication", "/Account/TwoFactor"), ("Recovery codes", null));
        if (TempData["RecoveryCodes"] is not string codes) return RedirectToAction(nameof(TwoFactor));
        return View(codes.Split(' ', StringSplitOptions.RemoveEmptyEntries));
    }

    [HttpPost]
    public async Task<IActionResult> DisableTwoFactor()
    {
        var user = await users.GetUserAsync(User);
        if (user is null) return RedirectToAction(nameof(Login));
        await users.SetTwoFactorEnabledAsync(user, false);
        await users.ResetAuthenticatorKeyAsync(user);
        await signIn.RefreshSignInAsync(user);
        Success("Two-factor authentication has been disabled.");
        return RedirectToAction(nameof(TwoFactor));
    }

    [AllowAnonymous, HttpGet]
    public IActionResult AccessDenied()
    {
        Response.StatusCode = 403;
        return View("~/Views/Shared/Status.cshtml", new ErrorViewModel { StatusCode = 403 });
    }

    private async Task<EnableAuthenticatorViewModel> BuildAuthenticatorModelAsync(ApplicationUser user)
    {
        var key = await users.GetAuthenticatorKeyAsync(user);
        if (string.IsNullOrEmpty(key))
        {
            await users.ResetAuthenticatorKeyAsync(user);
            key = await users.GetAuthenticatorKeyAsync(user);
        }
        string issuer = "Global Asset Management";
        string uri = $"otpauth://totp/{Uri.EscapeDataString(issuer)}:{Uri.EscapeDataString(user.Email ?? user.UserName!)}?secret={key}&issuer={Uri.EscapeDataString(issuer)}&digits=6";
        var formatted = string.Join(" ", Enumerable.Range(0, (key!.Length + 3) / 4).Select(i => key.Substring(i * 4, Math.Min(4, key.Length - i * 4)))).ToLowerInvariant();
        return new EnableAuthenticatorViewModel { SharedKey = formatted, QrSvg = QrCode.EncodeText(uri, QrErrorCorrection.L).ToSvg(5) };
    }

    private async Task RecordLoginAsync(ApplicationUser? user, string userName, bool ok, string? reason)
    {
        db.LoginHistory.Add(new LoginHistory
        {
            UserId = user?.Id, UserName = userName.Length > 256 ? userName[..256] : userName, AttemptedAt = clock.UtcNow, Succeeded = ok,
            FailureReason = reason, IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString(),
            UserAgent = Request.Headers.UserAgent.ToString() is { Length: > 500 } ua ? ua[..500] : Request.Headers.UserAgent.ToString()
        });
        await db.SaveChangesAsync();
    }
}
