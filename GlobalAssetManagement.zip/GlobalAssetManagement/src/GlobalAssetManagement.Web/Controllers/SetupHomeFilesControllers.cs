using System.Diagnostics;
using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Application.Services;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using GlobalAssetManagement.Domain.Logic;
using GlobalAssetManagement.Infrastructure.Identity;
using GlobalAssetManagement.Infrastructure.Persistence;
using GlobalAssetManagement.Web.Models;
using GlobalAssetManagement.Web.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;

namespace GlobalAssetManagement.Web.Controllers;

/// <summary>One-time creation of the first Super Administrator. Disabled as soon as any user exists.</summary>
[AllowAnonymous]
public sealed class SetupController(UserManager<ApplicationUser> users, AppDbContext db, SettingsService settings, IMemoryCache cache, IClock clock,
    ILogger<SetupController> logger) : AppController
{
    [HttpGet]
    public async Task<IActionResult> Index()
    {
        if (await users.Users.AnyAsync()) return RedirectToAction("Login", "Account");
        ViewData["Title"] = "First-time setup";
        var company = await db.Companies.OrderBy(c => c.Id).FirstOrDefaultAsync();
        return View(new SetupViewModel { OrganizationName = company?.Name ?? "", City = company?.City });
    }

    [HttpPost]
    public async Task<IActionResult> Index(SetupViewModel model)
    {
        if (await users.Users.AnyAsync()) return RedirectToAction("Login", "Account");
        ViewData["Title"] = "First-time setup";
        if (!ModelState.IsValid) return View(model);

        var user = new ApplicationUser
        {
            UserName = model.UserName.Trim(), Email = model.Email.Trim(), FullName = model.FullName.Trim(), PhoneNumber = model.Phone,
            EmailConfirmed = true, IsActive = true, CreatedAt = clock.UtcNow
        };
        var result = await users.CreateAsync(user, model.Password);
        if (!result.Succeeded)
        {
            foreach (var e in result.Errors) ModelState.AddModelError(string.Empty, e.Description);
            return View(model);
        }
        await users.AddToRoleAsync(user, Roles.SuperAdministrator);

        var company = await db.Companies.OrderBy(c => c.Id).FirstOrDefaultAsync();
        if (company is not null)
        {
            company.Name = model.OrganizationName.Trim();
            company.City = model.City;
            await db.SaveChangesAsync();
            settings.Invalidate();
        }
        cache.Remove(SetupRedirectFilter.CacheKey);
        logger.LogWarning("Initial Super Administrator {User} created from {Ip}", user.UserName, HttpContext.Connection.RemoteIpAddress);
        TempData["Success"] = "Administrator account created. Please sign in.";
        return RedirectToAction("Login", "Account");
    }
}

public sealed class HomeController(DashboardService dashboard, AppDbContext db, ICurrentUser user) : AppController
{
    [Permission(AppModule.Dashboard)]
    public async Task<IActionResult> Index([FromQuery] DashboardFilter filter)
    {
        Crumbs("Dashboard");
        ViewBag.Branches = await SelectAsync<Branch>(filter.BranchId);
        ViewBag.Departments = await SelectAsync<Department>(filter.DepartmentId);
        ViewBag.Categories = await SelectAsync<AssetCategory>(filter.CategoryId);
        ViewBag.Filter = filter;
        var data = await dashboard.GetAsync(filter);
        return View(data);
    }

    public async Task<IActionResult> Search(string? q)
    {
        Crumbs("Search", ("Search", null));
        var results = new List<SearchResult>();
        ViewBag.Query = q;
        if (string.IsNullOrWhiteSpace(q) || q.Trim().Length < 2) return View(results);
        q = q.Trim();

        var assets = await db.Assets.AsNoTracking().VisibleTo(user)
            .Where(a => a.AssetTag.Contains(q) || a.AssetCode.Contains(q) || a.Name.Contains(q) || (a.SerialNumber != null && a.SerialNumber.Contains(q)) || (a.InvoiceNumber != null && a.InvoiceNumber.Contains(q)))
            .OrderBy(a => a.AssetTag).Take(25).Select(a => new { a.Id, a.AssetTag, a.Name, a.SerialNumber, a.Status }).ToListAsync();
        if (assets.Count == 1 && (string.Equals(assets[0].AssetTag, q, StringComparison.OrdinalIgnoreCase)))
            return RedirectToAction("Details", "Assets", new { id = assets[0].Id });
        results.AddRange(assets.Select(a => new SearchResult("Asset", $"{a.AssetTag} - {a.Name}", $"S/N {a.SerialNumber} · {a.Status.DisplayName()}", $"/Assets/Details/{a.Id}", "bi-box-seam")));

        results.AddRange((await db.ServiceRequests.AsNoTracking().Where(s => s.TicketNo.Contains(q) || s.FaultDescription.Contains(q)).Take(10)
            .Select(s => new { s.Id, s.TicketNo, s.FaultDescription, s.Status }).ToListAsync())
            .Select(s => new SearchResult("Service Request", s.TicketNo, s.FaultDescription, $"/ServiceRequests/Details/{s.Id}", "bi-ticket-detailed")));
        results.AddRange((await db.WorkOrders.AsNoTracking().Where(w => w.WorkOrderNo.Contains(q)).Take(10).Select(w => new { w.Id, w.WorkOrderNo, w.Title }).ToListAsync())
            .Select(w => new SearchResult("Work Order", w.WorkOrderNo, w.Title, $"/WorkOrders/Details/{w.Id}", "bi-wrench")));
        results.AddRange((await db.PurchaseOrders.AsNoTracking().Where(p => p.PONumber.Contains(q)).Take(10).Select(p => new { p.Id, p.PONumber, Vendor = p.Vendor!.Name }).ToListAsync())
            .Select(p => new SearchResult("Purchase Order", p.PONumber, p.Vendor, $"/PurchaseOrders/Details/{p.Id}", "bi-cart3")));
        results.AddRange((await db.PurchaseRequests.AsNoTracking().Where(p => p.RequestNo.Contains(q)).Take(10).Select(p => new { p.Id, p.RequestNo, p.Purpose }).ToListAsync())
            .Select(p => new SearchResult("Purchase Request", p.RequestNo, p.Purpose, $"/PurchaseRequests/Details/{p.Id}", "bi-clipboard-check")));
        results.AddRange((await db.PurchaseInvoices.AsNoTracking().Where(p => p.InvoiceNumber.Contains(q)).Take(10).Select(p => new { p.Id, p.InvoiceNumber, Vendor = p.Vendor!.Name }).ToListAsync())
            .Select(p => new SearchResult("Purchase Invoice", p.InvoiceNumber, p.Vendor, $"/PurchaseInvoices/Details/{p.Id}", "bi-receipt")));
        results.AddRange((await db.Vendors.AsNoTracking().Where(v => v.Name.Contains(q) || v.Code.Contains(q) || (v.Gstin != null && v.Gstin.Contains(q))).Take(10).Select(v => new { v.Id, v.Code, v.Name, v.City }).ToListAsync())
            .Select(v => new SearchResult("Vendor", $"{v.Code} - {v.Name}", v.City, $"/Masters/Edit/Vendor/{v.Id}", "bi-shop")));
        results.AddRange((await db.Employees.AsNoTracking().Where(e => e.FullName.Contains(q) || e.EmployeeCode.Contains(q)).Take(10).Select(e => new { e.Id, e.EmployeeCode, e.FullName, e.Designation }).ToListAsync())
            .Select(e => new SearchResult("Employee", $"{e.EmployeeCode} - {e.FullName}", e.Designation, $"/Assets?EmployeeId={e.Id}", "bi-person")));
        results.AddRange((await db.AMContracts.AsNoTracking().Where(c => c.ContractNo.Contains(q)).Take(10).Select(c => new { c.Id, c.ContractNo, Provider = c.ServiceProvider!.CompanyName }).ToListAsync())
            .Select(c => new SearchResult("AMC Contract", c.ContractNo, c.Provider, $"/Amc/Details/{c.Id}", "bi-file-earmark-text")));
        return View(results);
    }

    [AllowAnonymous]
    public IActionResult Error() => View("~/Views/Shared/Error.cshtml", new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });

    [AllowAnonymous, Route("/Home/Status/{code:int}")]
    public IActionResult Status(int code) => View("~/Views/Shared/Status.cshtml", new ErrorViewModel { StatusCode = code });
}

/// <summary>Authorized streaming of uploaded documents (files are stored outside wwwroot).</summary>
public sealed class FilesController(AppDbContext db, AttachmentService attachments, ICurrentUser user) : AppController
{
    private static readonly Dictionary<string, AppModule> EntityModules = new(StringComparer.OrdinalIgnoreCase)
    {
        ["PurchaseRequest"] = AppModule.Procurement, ["PurchaseOrder"] = AppModule.Procurement, ["PurchaseInvoice"] = AppModule.Procurement,
        ["GoodsReceipt"] = AppModule.Procurement, ["ServiceRequest"] = AppModule.Maintenance, ["WorkOrder"] = AppModule.Maintenance,
        ["AssetAddition"] = AppModule.Additions, ["AssetDisposal"] = AppModule.Disposal, ["AMContract"] = AppModule.WarrantyAmc,
        ["WarrantyRecord"] = AppModule.WarrantyAmc, ["ServiceProvider"] = AppModule.Masters, ["AssetTransfer"] = AppModule.Allocation,
        ["AssetAllocation"] = AppModule.Allocation, ["PhysicalVerificationSession"] = AppModule.Verification
    };

    [HttpGet]
    public async Task<IActionResult> Attachment(int id, [FromServices] PermissionChecker perm)
    {
        var a = await db.Attachments.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        if (a is null) return NotFound();
        if (!EntityModules.TryGetValue(a.EntityName, out var module) || !await perm.CanAsync(module)) return Forbid();
        return Stream(AttachmentService.GeneralFolder, a.StoredFileName, a.ContentType, a.OriginalFileName);
    }

    [HttpPost]
    public async Task<IActionResult> Upload(string entityName, int entityId, IFormFile? file, string? description, string? returnUrl, [FromServices] PermissionChecker perm)
    {
        if (!EntityModules.TryGetValue(entityName, out var module) || !await perm.CanAsync(module, PermissionAction.Edit) && !await perm.CanAsync(module, PermissionAction.Create))
            return Forbid();
        if (file is null || file.Length == 0) Error("Choose a file to upload.");
        else
        {
            await attachments.AddAttachmentAsync(entityName, entityId, file, description);
            Success($"{file.FileName} uploaded.");
        }
        return RedirectToLocal(returnUrl, "Index");
    }

    [HttpGet, Permission(AppModule.Assets)]
    public async Task<IActionResult> AssetDocument(int id)
    {
        var d = await db.AssetDocuments.AsNoTracking().Include(x => x.Asset).FirstOrDefaultAsync(x => x.Id == id);
        if (d is null) return NotFound();
        user.EnsureCanSee(d.Asset!);
        return Stream(AttachmentService.AssetFolder, d.StoredFileName, d.ContentType, d.OriginalFileName);
    }

    [HttpGet, Permission(AppModule.Assets)]
    public async Task<IActionResult> AssetImage(int id)
    {
        var d = await db.AssetImages.AsNoTracking().Include(x => x.Asset).FirstOrDefaultAsync(x => x.Id == id);
        if (d is null) return NotFound();
        user.EnsureCanSee(d.Asset!);
        return Stream(AttachmentService.ImageFolder, d.StoredFileName, d.ContentType, null);
    }

    [HttpGet, Permission(AppModule.Verification)]
    public async Task<IActionResult> VerificationPhoto(int id)
    {
        var item = await db.PhysicalVerificationItems.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        if (item?.PhotoFileName is null) return NotFound();
        return Stream(AttachmentService.VerificationFolder, item.PhotoFileName, "image/jpeg", null);
    }

    private IActionResult Stream(string folder, string stored, string contentType, string? downloadName)
    {
        var s = attachments.Open(folder, stored);
        if (s is null) return NotFound();
        Response.Headers["X-Content-Type-Options"] = "nosniff";
        Response.Headers["Content-Security-Policy"] = "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; sandbox";
        bool inline = contentType.StartsWith("image/") || contentType == "application/pdf";
        return inline && downloadName is not null
            ? File(s, contentType, enableRangeProcessing: true)
            : downloadName is null ? File(s, contentType) : File(s, contentType, downloadName);
    }
}
