using GlobalAssetManagement.Application.Models;
using GlobalAssetManagement.Application.Services;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using GlobalAssetManagement.Infrastructure.Persistence;
using GlobalAssetManagement.Web.Models;
using GlobalAssetManagement.Web.Security;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace GlobalAssetManagement.Web.Controllers;

[Permission(AppModule.Procurement)]
public sealed class PurchaseRequestsController(ProcurementService procurement, ApprovalService approvals, AttachmentService attachments, AppDbContext db) : AppController
{
    public async Task<IActionResult> Index(PurchaseRequestStatus? status, string? q, int page = 1)
    {
        Crumbs("Purchase Requests", ("Vendors & Procurement", null), ("Purchase Requests", null));
        var query = db.PurchaseRequests.AsNoTracking().Include(p => p.Branch).Include(p => p.Department).Include(p => p.RequestedByEmployee).AsQueryable();
        if (CurrentUser.BranchId is { } b) query = query.Where(p => p.BranchId == b);
        if (status is not null) query = query.Where(p => p.Status == status);
        if (!string.IsNullOrWhiteSpace(q)) query = query.Where(p => p.RequestNo.Contains(q) || p.Purpose.Contains(q));
        int total = await query.CountAsync();
        var items = await query.OrderByDescending(p => p.RequestDate).ThenByDescending(p => p.Id).Skip((Math.Max(1, page) - 1) * 25).Take(25).ToListAsync();
        ViewBag.Status = status; ViewBag.Q = q;
        ViewBag.Pager = new PagerModel(Math.Max(1, page), Math.Max(1, (int)Math.Ceiling(total / 25.0)), total, 25);
        return View(items);
    }

    [HttpGet, Permission(AppModule.Procurement, PermissionAction.Create)]
    public async Task<IActionResult> Create()
    {
        Crumbs("New Purchase Request", ("Purchase Requests", "/PurchaseRequests"), ("New", null));
        var input = new PurchaseRequestInput { RequestDate = Clock.Today, BranchId = CurrentUser.BranchId, DepartmentId = CurrentUser.DepartmentId, RequestedByEmployeeId = CurrentUser.EmployeeId };
        input.Items.Add(new LineInput());
        await ListsAsync(input);
        return View("Form", input);
    }

    [HttpGet, Permission(AppModule.Procurement, PermissionAction.Create)]
    public async Task<IActionResult> Edit(int id)
    {
        var pr = await db.PurchaseRequests.AsNoTracking().Include(p => p.Items).FirstOrDefaultAsync(p => p.Id == id);
        if (pr is null) return NotFound();
        Crumbs("Edit Purchase Request", ("Purchase Requests", "/PurchaseRequests"), (pr.RequestNo, $"/PurchaseRequests/Details/{id}"), ("Edit", null));
        var input = new PurchaseRequestInput
        {
            Id = pr.Id, RequestDate = pr.RequestDate, RequestedByEmployeeId = pr.RequestedByEmployeeId, BranchId = pr.BranchId, DepartmentId = pr.DepartmentId,
            Purpose = pr.Purpose, RequiredByDate = pr.RequiredByDate, Priority = pr.Priority, Remarks = pr.Remarks,
            Items = pr.Items.Select(i => new LineInput { Description = i.Description, CategoryId = i.CategoryId, Quantity = i.Quantity, UnitPrice = i.EstimatedUnitCost, Specifications = i.Specifications }).ToList()
        };
        await ListsAsync(input);
        return View("Form", input);
    }

    [HttpPost, Permission(AppModule.Procurement, PermissionAction.Create)]
    public async Task<IActionResult> Save(PurchaseRequestInput input, string? submit)
    {
        Crumbs(input.Id == 0 ? "New Purchase Request" : "Edit Purchase Request", ("Purchase Requests", "/PurchaseRequests"), ("Edit", null));
        PurchaseRequest? pr = null;
        if (ModelState.IsValid && await TryAsync(async () =>
            {
                pr = await procurement.SavePurchaseRequestAsync(input);
                if (submit is not null) await procurement.SubmitPurchaseRequestAsync(pr.Id);
            }))
        {
            Success(submit is not null ? $"{pr!.RequestNo} submitted for approval." : $"{pr!.RequestNo} saved as draft.");
            return RedirectToAction(nameof(Details), new { id = pr.Id });
        }
        if (input.Items.Count == 0) input.Items.Add(new LineInput());
        await ListsAsync(input);
        return View("Form", input);
    }

    public async Task<IActionResult> Details(int id, [FromServices] PermissionChecker perm)
    {
        var pr = await db.PurchaseRequests.AsNoTracking().Include(p => p.Items).ThenInclude(i => i.Category).Include(p => p.Branch).Include(p => p.Department)
            .Include(p => p.RequestedByEmployee).Include(p => p.Quotations).ThenInclude(q => q.Vendor).FirstOrDefaultAsync(p => p.Id == id);
        if (pr is null) return NotFound();
        Crumbs(pr.RequestNo, ("Purchase Requests", "/PurchaseRequests"), (pr.RequestNo, null));
        ViewBag.Approvals = new ApprovalPanelModel(await approvals.HistoryAsync(ApprovalModule.PurchaseRequest, id));
        ViewBag.Attachments = new AttachmentsPanelModel("PurchaseRequest", id, await attachments.ListAsync("PurchaseRequest", id), await perm.CanAsync(AppModule.Procurement, PermissionAction.Create));
        ViewBag.Vendors = await SelectAsync<Vendor>();
        ViewBag.PurchaseOrders = await db.PurchaseOrders.AsNoTracking().Where(p => p.PurchaseRequestId == id).ToListAsync();
        return View(pr);
    }

    [HttpPost, Permission(AppModule.Procurement, PermissionAction.Create)]
    public async Task<IActionResult> Submit(int id)
    {
        await procurement.SubmitPurchaseRequestAsync(id);
        Success("Submitted for approval.");
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost, Permission(AppModule.Procurement, PermissionAction.Edit)]
    public async Task<IActionResult> Cancel(int id)
    {
        await procurement.CancelPurchaseRequestAsync(id);
        Success("Purchase request cancelled.");
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost, Permission(AppModule.Procurement, PermissionAction.Create)]
    public async Task<IActionResult> AddQuotation(QuotationInput input)
    {
        if (!ModelState.IsValid)
        {
            Error(string.Join(" ", ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage)));
            return RedirectToAction(nameof(Details), new { id = input.PurchaseRequestId });
        }
        await procurement.AddQuotationAsync(input);
        Success("Quotation recorded.");
        return RedirectToAction(nameof(Details), new { id = input.PurchaseRequestId });
    }

    [HttpPost, Permission(AppModule.Procurement, PermissionAction.Edit)]
    public async Task<IActionResult> SelectQuotation(int id, int quotationId, string? reason)
    {
        await procurement.SelectQuotationAsync(quotationId, reason);
        Success("Quotation selected.");
        return RedirectToAction(nameof(Details), new { id });
    }

    public async Task<IActionResult> Compare(int id)
    {
        var pr = await db.PurchaseRequests.AsNoTracking().FirstOrDefaultAsync(p => p.Id == id);
        if (pr is null) return NotFound();
        Crumbs("Quotation Comparison", ("Purchase Requests", "/PurchaseRequests"), (pr.RequestNo, $"/PurchaseRequests/Details/{id}"), ("Comparison", null));
        ViewBag.Request = pr;
        return View(await procurement.CompareAsync(id));
    }

    private async Task ListsAsync(PurchaseRequestInput i)
    {
        ViewBag.Branches = await SelectAsync<Branch>(i.BranchId);
        ViewBag.Departments = await SelectAsync<Department>(i.DepartmentId);
        ViewBag.Employees = await SelectAsync<Employee>(i.RequestedByEmployeeId);
        ViewBag.Categories = (await Lookups.ForAsync<AssetCategory>()).Select(c => new SelectListItem(c.Text, c.Id.ToString())).ToList();
    }
}

[Permission(AppModule.Procurement)]
public sealed class PurchaseOrdersController(ProcurementService procurement, ApprovalService approvals, AttachmentService attachments, SettingsService settings, AppDbContext db) : AppController
{
    public async Task<IActionResult> Index(PurchaseOrderStatus? status, int? vendorId, string? q, bool pending = false, int page = 1)
    {
        Crumbs("Purchase Orders", ("Vendors & Procurement", null), ("Purchase Orders", null));
        var query = db.PurchaseOrders.AsNoTracking().Include(p => p.Vendor).Include(p => p.Branch).AsQueryable();
        if (CurrentUser.BranchId is { } b) query = query.Where(p => p.BranchId == b);
        if (status is not null) query = query.Where(p => p.Status == status);
        if (pending) query = query.Where(p => p.Status == PurchaseOrderStatus.Issued || p.Status == PurchaseOrderStatus.PartiallyReceived || p.Status == PurchaseOrderStatus.PendingApproval || p.Status == PurchaseOrderStatus.Approved);
        if (vendorId is not null) query = query.Where(p => p.VendorId == vendorId);
        if (!string.IsNullOrWhiteSpace(q)) query = query.Where(p => p.PONumber.Contains(q) || p.Vendor!.Name.Contains(q));
        int total = await query.CountAsync();
        var items = await query.OrderByDescending(p => p.PODate).ThenByDescending(p => p.Id).Skip((Math.Max(1, page) - 1) * 25).Take(25).ToListAsync();
        ViewBag.Status = status; ViewBag.Q = q; ViewBag.Pending = pending;
        ViewBag.Vendors = await SelectAsync<Vendor>(vendorId);
        ViewBag.Pager = new PagerModel(Math.Max(1, page), Math.Max(1, (int)Math.Ceiling(total / 25.0)), total, 25);
        return View(items);
    }

    [HttpGet, Permission(AppModule.Procurement, PermissionAction.Create)]
    public async Task<IActionResult> Create(int? quotationId)
    {
        Crumbs("New Purchase Order", ("Purchase Orders", "/PurchaseOrders"), ("New", null));
        var input = quotationId is { } q ? await procurement.PurchaseOrderFromQuotationAsync(q) : new PurchaseOrderInput { PODate = Clock.Today, BranchId = CurrentUser.BranchId };
        if (input.Items.Count == 0) input.Items.Add(new LineInput { TaxRate = 18 });
        await ListsAsync(input);
        return View("Form", input);
    }

    [HttpGet, Permission(AppModule.Procurement, PermissionAction.Create)]
    public async Task<IActionResult> Edit(int id)
    {
        var po = await db.PurchaseOrders.AsNoTracking().Include(p => p.Items).FirstOrDefaultAsync(p => p.Id == id);
        if (po is null) return NotFound();
        Crumbs("Edit Purchase Order", ("Purchase Orders", "/PurchaseOrders"), (po.PONumber, $"/PurchaseOrders/Details/{id}"), ("Edit", null));
        var input = new PurchaseOrderInput
        {
            Id = po.Id, PODate = po.PODate, VendorId = po.VendorId, PurchaseRequestId = po.PurchaseRequestId, QuotationId = po.QuotationId, BranchId = po.BranchId,
            DeliveryAddress = po.DeliveryAddress, ExpectedDeliveryDate = po.ExpectedDeliveryDate, OtherCharges = po.OtherCharges, Terms = po.Terms, Remarks = po.Remarks,
            Items = po.Items.Select(i => new LineInput { Description = i.Description, CategoryId = i.CategoryId, AssetModelId = i.AssetModelId, Quantity = i.Quantity, UnitPrice = i.UnitPrice, TaxRate = i.TaxRate }).ToList()
        };
        await ListsAsync(input);
        return View("Form", input);
    }

    [HttpPost, Permission(AppModule.Procurement, PermissionAction.Create)]
    public async Task<IActionResult> Save(PurchaseOrderInput input, string? submit)
    {
        Crumbs("Purchase Order", ("Purchase Orders", "/PurchaseOrders"), ("Edit", null));
        PurchaseOrder? po = null;
        if (ModelState.IsValid && await TryAsync(async () =>
            {
                po = await procurement.SavePurchaseOrderAsync(input);
                if (submit is not null) await procurement.SubmitPurchaseOrderAsync(po.Id);
            }))
        {
            Success(submit is not null ? $"{po!.PONumber} submitted for approval." : $"{po!.PONumber} saved as draft.");
            return RedirectToAction(nameof(Details), new { id = po.Id });
        }
        if (input.Items.Count == 0) input.Items.Add(new LineInput());
        await ListsAsync(input);
        return View("Form", input);
    }

    public async Task<IActionResult> Details(int id, [FromServices] PermissionChecker perm)
    {
        var po = await Load(id);
        if (po is null) return NotFound();
        Crumbs(po.PONumber, ("Purchase Orders", "/PurchaseOrders"), (po.PONumber, null));
        ViewBag.Approvals = new ApprovalPanelModel(await approvals.HistoryAsync(ApprovalModule.PurchaseOrder, id));
        ViewBag.Attachments = new AttachmentsPanelModel("PurchaseOrder", id, await attachments.ListAsync("PurchaseOrder", id), await perm.CanAsync(AppModule.Procurement, PermissionAction.Create));
        ViewBag.Invoices = await db.PurchaseInvoices.AsNoTracking().Where(i => i.PurchaseOrderId == id).ToListAsync();
        return View(po);
    }

    public async Task<IActionResult> Print(int id)
    {
        var po = await Load(id);
        if (po is null) return NotFound();
        ViewBag.Company = await settings.GetCompanyAsync();
        return View(po);
    }

    [HttpPost, Permission(AppModule.Procurement, PermissionAction.Create)]
    public async Task<IActionResult> Submit(int id) { await procurement.SubmitPurchaseOrderAsync(id); Success("Submitted for approval."); return RedirectToAction(nameof(Details), new { id }); }

    [HttpPost, Permission(AppModule.Procurement, PermissionAction.Edit)]
    public async Task<IActionResult> Issue(int id) { await procurement.IssuePurchaseOrderAsync(id); Success("Purchase order issued to vendor."); return RedirectToAction(nameof(Details), new { id }); }

    [HttpPost, Permission(AppModule.Procurement, PermissionAction.Edit)]
    public async Task<IActionResult> Cancel(int id) { await procurement.CancelPurchaseOrderAsync(id); Success("Purchase order cancelled."); return RedirectToAction(nameof(Details), new { id }); }

    [HttpPost, Permission(AppModule.Procurement, PermissionAction.Edit)]
    public async Task<IActionResult> Close(int id) { await procurement.ClosePurchaseOrderAsync(id); Success("Purchase order closed."); return RedirectToAction(nameof(Details), new { id }); }

    private Task<PurchaseOrder?> Load(int id) => db.PurchaseOrders.AsNoTracking().Include(p => p.Items).ThenInclude(i => i.Category).Include(p => p.Vendor).Include(p => p.Branch)
        .Include(p => p.PurchaseRequest).Include(p => p.Quotation).Include(p => p.Receipts).FirstOrDefaultAsync(p => p.Id == id);

    private async Task ListsAsync(PurchaseOrderInput i)
    {
        ViewBag.Vendors = await SelectAsync<Vendor>(i.VendorId);
        ViewBag.Branches = await SelectAsync<Branch>(i.BranchId);
        ViewBag.Categories = (await Lookups.ForAsync<AssetCategory>()).Select(c => new SelectListItem(c.Text, c.Id.ToString())).ToList();
    }
}

[Permission(AppModule.Procurement)]
public sealed class GoodsReceiptsController(ProcurementService procurement, AppDbContext db) : AppController
{
    public async Task<IActionResult> Index(int page = 1)
    {
        Crumbs("Goods Receipts", ("Asset Acquisition", null), ("Goods Receipts", null));
        var q = db.GoodsReceipts.AsNoTracking().Include(g => g.PurchaseOrder!).ThenInclude(p => p.Vendor).Include(g => g.Items).AsQueryable();
        int total = await q.CountAsync();
        var items = await q.OrderByDescending(g => g.ReceiptDate).ThenByDescending(g => g.Id).Skip((Math.Max(1, page) - 1) * 25).Take(25).ToListAsync();
        ViewBag.Pager = new PagerModel(Math.Max(1, page), Math.Max(1, (int)Math.Ceiling(total / 25.0)), total, 25);
        ViewBag.PendingOrders = await db.PurchaseOrders.AsNoTracking().Include(p => p.Vendor)
            .Where(p => p.Status == PurchaseOrderStatus.Issued || p.Status == PurchaseOrderStatus.PartiallyReceived).OrderBy(p => p.ExpectedDeliveryDate).ToListAsync();
        return View(items);
    }

    [HttpGet, Permission(AppModule.Procurement, PermissionAction.Create)]
    public async Task<IActionResult> Create(int poId)
    {
        var po = await db.PurchaseOrders.AsNoTracking().Include(p => p.Vendor).FirstOrDefaultAsync(p => p.Id == poId);
        if (po is null) return NotFound();
        Crumbs("Receive Goods", ("Goods Receipts", "/GoodsReceipts"), (po.PONumber, $"/PurchaseOrders/Details/{poId}"), ("Receive", null));
        ViewBag.Order = po;
        return View(await procurement.NewGoodsReceiptAsync(poId));
    }

    [HttpPost, Permission(AppModule.Procurement, PermissionAction.Create)]
    public async Task<IActionResult> Create(GoodsReceiptInput input)
    {
        GoodsReceipt? grn = null;
        if (ModelState.IsValid && await TryAsync(async () => grn = await procurement.ReceiveGoodsAsync(input)))
        {
            Success($"{grn!.GrnNumber} recorded. Enter the vendor invoice to register the assets.");
            return RedirectToAction(nameof(Details), new { id = grn.Id });
        }
        var po = await db.PurchaseOrders.AsNoTracking().Include(p => p.Vendor).FirstAsync(p => p.Id == input.PurchaseOrderId);
        Crumbs("Receive Goods", ("Goods Receipts", "/GoodsReceipts"), ("Receive", null));
        ViewBag.Order = po;
        return View(input);
    }

    public async Task<IActionResult> Details(int id)
    {
        var g = await db.GoodsReceipts.AsNoTracking().Include(x => x.PurchaseOrder!).ThenInclude(p => p.Vendor).Include(x => x.Items).ThenInclude(i => i.PurchaseOrderItem)
            .FirstOrDefaultAsync(x => x.Id == id);
        if (g is null) return NotFound();
        Crumbs(g.GrnNumber, ("Goods Receipts", "/GoodsReceipts"), (g.GrnNumber, null));
        ViewBag.Invoice = await db.PurchaseInvoices.AsNoTracking().FirstOrDefaultAsync(i => i.GoodsReceiptId == id);
        return View(g);
    }
}

[Permission(AppModule.Procurement)]
public sealed class PurchaseInvoicesController(ProcurementService procurement, AttachmentService attachments, AppDbContext db) : AppController
{
    public async Task<IActionResult> Index(int? vendorId, string? q, int page = 1)
    {
        Crumbs("Purchase Invoices", ("Asset Acquisition", null), ("Purchase Invoices", null));
        var query = db.PurchaseInvoices.AsNoTracking().Include(i => i.Vendor).Include(i => i.PurchaseOrder).AsQueryable();
        if (vendorId is not null) query = query.Where(i => i.VendorId == vendorId);
        if (!string.IsNullOrWhiteSpace(q)) query = query.Where(i => i.InvoiceNumber.Contains(q) || i.Vendor!.Name.Contains(q));
        int total = await query.CountAsync();
        var items = await query.OrderByDescending(i => i.InvoiceDate).ThenByDescending(i => i.Id).Skip((Math.Max(1, page) - 1) * 25).Take(25)
            .Select(i => new { Invoice = i, Assets = i.Assets.Count }).ToListAsync();
        ViewBag.Counts = items.ToDictionary(x => x.Invoice.Id, x => x.Assets);
        ViewBag.Vendors = await SelectAsync<Vendor>(vendorId); ViewBag.Q = q;
        ViewBag.Pager = new PagerModel(Math.Max(1, page), Math.Max(1, (int)Math.Ceiling(total / 25.0)), total, 25);
        return View(items.Select(x => x.Invoice).ToList());
    }

    [HttpGet, Permission(AppModule.Procurement, PermissionAction.Create)]
    public async Task<IActionResult> Create(int? grnId, int? poId)
    {
        Crumbs("Enter Purchase Invoice", ("Purchase Invoices", "/PurchaseInvoices"), ("New", null));
        var input = new PurchaseInvoiceInput { InvoiceDate = Clock.Today };
        if (grnId is { } g && await db.GoodsReceipts.AsNoTracking().Include(x => x.PurchaseOrder).Include(x => x.Items).ThenInclude(i => i.PurchaseOrderItem).FirstOrDefaultAsync(x => x.Id == g) is { } grn)
        {
            input.GoodsReceiptId = grn.Id;
            input.PurchaseOrderId = grn.PurchaseOrderId;
            input.VendorId = grn.PurchaseOrder!.VendorId;
            input.SubTotal = grn.Items.Sum(i => i.QuantityAccepted * i.PurchaseOrderItem!.UnitPrice);
            input.TaxAmount = Math.Round(grn.Items.Sum(i => i.QuantityAccepted * i.PurchaseOrderItem!.UnitPrice * i.PurchaseOrderItem.TaxRate / 100m), 2);
        }
        else if (poId is { } p && await db.PurchaseOrders.AsNoTracking().FirstOrDefaultAsync(x => x.Id == p) is { } po)
        {
            input.PurchaseOrderId = po.Id; input.VendorId = po.VendorId; input.SubTotal = po.SubTotal; input.TaxAmount = po.TaxTotal; input.FreightCharges = po.OtherCharges;
        }
        await ListsAsync(input);
        return View("Form", input);
    }

    [HttpGet, Permission(AppModule.Procurement, PermissionAction.Edit)]
    public async Task<IActionResult> Edit(int id)
    {
        var i = await db.PurchaseInvoices.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        if (i is null) return NotFound();
        Crumbs("Edit Purchase Invoice", ("Purchase Invoices", "/PurchaseInvoices"), (i.InvoiceNumber, $"/PurchaseInvoices/Details/{id}"), ("Edit", null));
        var input = new PurchaseInvoiceInput
        {
            Id = i.Id, InvoiceNumber = i.InvoiceNumber, InvoiceDate = i.InvoiceDate, VendorId = i.VendorId, PurchaseOrderId = i.PurchaseOrderId, GoodsReceiptId = i.GoodsReceiptId,
            SubTotal = i.SubTotal, TaxAmount = i.TaxAmount, FreightCharges = i.FreightCharges, InstallationCharges = i.InstallationCharges, OtherCharges = i.OtherCharges,
            GstInputCreditClaimed = i.GstInputCreditClaimed, DueDate = i.DueDate, Remarks = i.Remarks
        };
        await ListsAsync(input);
        return View("Form", input);
    }

    [HttpPost, Permission(AppModule.Procurement, PermissionAction.Create)]
    public async Task<IActionResult> Save(PurchaseInvoiceInput input)
    {
        Crumbs("Purchase Invoice", ("Purchase Invoices", "/PurchaseInvoices"), ("Edit", null));
        PurchaseInvoice? inv = null;
        if (ModelState.IsValid && await TryAsync(async () => inv = await procurement.SaveInvoiceAsync(input)))
        {
            Success($"Invoice {inv!.InvoiceNumber} saved.");
            return RedirectToAction(nameof(Details), new { id = inv.Id });
        }
        await ListsAsync(input);
        return View("Form", input);
    }

    public async Task<IActionResult> Details(int id, [FromServices] PermissionChecker perm)
    {
        var inv = await db.PurchaseInvoices.AsNoTracking().Include(i => i.Vendor).Include(i => i.PurchaseOrder).Include(i => i.GoodsReceipt)
            .Include(i => i.Assets).ThenInclude(a => a.Category).FirstOrDefaultAsync(i => i.Id == id);
        if (inv is null) return NotFound();
        Crumbs($"Invoice {inv.InvoiceNumber}", ("Purchase Invoices", "/PurchaseInvoices"), (inv.InvoiceNumber, null));
        ViewBag.Attachments = new AttachmentsPanelModel("PurchaseInvoice", id, await attachments.ListAsync("PurchaseInvoice", id), await perm.CanAsync(AppModule.Procurement, PermissionAction.Create));
        return View(inv);
    }

    [HttpGet, Permission(AppModule.Assets, PermissionAction.Create)]
    public async Task<IActionResult> RegisterAssets(int id)
    {
        var inv = await db.PurchaseInvoices.AsNoTracking().Include(i => i.Vendor).FirstOrDefaultAsync(i => i.Id == id);
        if (inv is null) return NotFound();
        Crumbs("Register Assets from Invoice", ("Purchase Invoices", "/PurchaseInvoices"), (inv.InvoiceNumber, $"/PurchaseInvoices/Details/{id}"), ("Register assets", null));
        var input = await procurement.NewRegistrationAsync(id);
        await RegisterListsAsync(input, inv);
        return View(input);
    }

    [HttpPost, Permission(AppModule.Assets, PermissionAction.Create)]
    public async Task<IActionResult> RegisterAssets(RegisterAssetsInput input)
    {
        List<Asset>? created = null;
        if (ModelState.IsValid && await TryAsync(async () => created = await procurement.RegisterAssetsAsync(input)))
        {
            Success($"{created!.Count} asset(s) registered: {string.Join(", ", created.Take(10).Select(a => a.AssetTag))}{(created.Count > 10 ? "..." : "")}");
            return RedirectToAction(nameof(Details), new { id = input.PurchaseInvoiceId });
        }
        var inv = await db.PurchaseInvoices.AsNoTracking().Include(i => i.Vendor).FirstAsync(i => i.Id == input.PurchaseInvoiceId);
        Crumbs("Register Assets from Invoice", ("Purchase Invoices", "/PurchaseInvoices"), ("Register assets", null));
        await RegisterListsAsync(input, inv);
        return View(input);
    }

    private async Task ListsAsync(PurchaseInvoiceInput i)
    {
        ViewBag.Vendors = await SelectAsync<Vendor>(i.VendorId);
        ViewBag.Orders = new SelectList(await db.PurchaseOrders.AsNoTracking().Where(p => p.Status != PurchaseOrderStatus.Cancelled && p.Status != PurchaseOrderStatus.Draft)
            .OrderByDescending(p => p.Id).Take(500).Select(p => new { p.Id, Text = p.PONumber + " - " + p.Vendor!.Name }).ToListAsync(), "Id", "Text", i.PurchaseOrderId);
        ViewBag.Receipts = new SelectList(await db.GoodsReceipts.AsNoTracking().OrderByDescending(g => g.Id).Take(500)
            .Select(g => new { g.Id, Text = g.GrnNumber + " (" + g.PurchaseOrder!.PONumber + ")" }).ToListAsync(), "Id", "Text", i.GoodsReceiptId);
    }

    private async Task RegisterListsAsync(RegisterAssetsInput i, PurchaseInvoice inv)
    {
        ViewBag.Invoice = inv;
        ViewBag.Branches = await SelectAsync<Branch>(i.BranchId);
        ViewBag.Departments = await SelectAsync<Department>(i.DepartmentId);
        ViewBag.Locations = await SelectAsync<Location>(i.LocationId);
        ViewBag.CategoryItems = (await Lookups.ForAsync<AssetCategory>()).Select(c => new SelectListItem(c.Text, c.Id.ToString())).ToList();
        ViewBag.ManufacturerItems = (await Lookups.ForAsync<Manufacturer>()).Select(c => new SelectListItem(c.Text, c.Id.ToString())).ToList();
    }
}

public sealed class ApprovalsController(ApprovalService approvals, ApprovalWorkflow workflow) : AppController
{
    public async Task<IActionResult> Index(bool all = false, [FromServices] PermissionChecker perm = null!)
    {
        Crumbs("Approvals", ("Approvals", null));
        bool canSeeAll = await perm.CanAsync(AppModule.Reports);
        var list = all && canSeeAll ? await approvals.AllPendingAsync() : await approvals.MyPendingAsync();
        ViewBag.All = all && canSeeAll;
        ViewBag.Links = list.ToDictionary(a => a.Id, a => workflow.LinkFor(a.Module, a.EntityId));
        return View(list);
    }

    [HttpPost]
    public async Task<IActionResult> Decide(int id, bool approve, string? comments, string? returnUrl)
    {
        var (a, completed, _) = await workflow.DecideAsync(id, approve, comments);
        Success(approve
            ? completed ? $"{a.Module.DisplayName()} {a.ReferenceNo} fully approved." : $"Level {a.Level} approved; waiting for the next level."
            : $"{a.Module.DisplayName()} {a.ReferenceNo} rejected.");
        return RedirectToLocal(returnUrl);
    }
}
