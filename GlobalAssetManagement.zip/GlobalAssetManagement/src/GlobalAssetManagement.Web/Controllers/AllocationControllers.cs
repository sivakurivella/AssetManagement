using GlobalAssetManagement.Application.Models;
using GlobalAssetManagement.Application.Services;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using GlobalAssetManagement.Infrastructure.Persistence;
using GlobalAssetManagement.Web.Models;
using GlobalAssetManagement.Web.Security;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GlobalAssetManagement.Web.Controllers;

[Permission(AppModule.Allocation)]
public sealed class AllocationsController(AllocationService allocation, SettingsService settings, AppDbContext db) : AppController
{
    public async Task<IActionResult> Index(bool overdue = false, bool returned = false, int? employeeId = null, string? q = null, int page = 1)
    {
        Crumbs(overdue ? "Overdue Returns" : "Issued Assets", ("Asset Allocation", null), (overdue ? "Overdue Returns" : "Issued Assets", null));
        var today = Clock.Today;
        var query = db.AssetAllocations.AsNoTracking().Include(a => a.Asset).Include(a => a.Employee).Include(a => a.Department).Include(a => a.Location).AsQueryable();
        if (CurrentUser.BranchId is { } b) query = query.Where(a => a.Asset!.BranchId == b);
        query = returned ? query.Where(a => a.Status == AllocationStatus.Returned) : query.Where(a => a.Status == AllocationStatus.Active);
        if (overdue) query = query.Where(a => a.ExpectedReturnDate != null && a.ExpectedReturnDate < today);
        if (employeeId is not null) query = query.Where(a => a.EmployeeId == employeeId);
        if (!string.IsNullOrWhiteSpace(q)) query = query.Where(a => a.AllocationNo.Contains(q) || a.Asset!.AssetTag.Contains(q) || a.Asset.Name.Contains(q));
        int total = await query.CountAsync();
        var list = await query.OrderByDescending(a => a.IssueDate).Skip((Math.Max(1, page) - 1) * 25).Take(25).ToListAsync();
        ViewBag.Overdue = overdue; ViewBag.Returned = returned; ViewBag.Q = q;
        ViewBag.Employees = await SelectAsync<Employee>(employeeId);
        ViewBag.Pager = new PagerModel(Math.Max(1, page), Math.Max(1, (int)Math.Ceiling(total / 25.0)), total, 25);
        return View(list);
    }

    /// <summary>Assets currently held by the signed-in employee, with handover acknowledgement.</summary>
    public async Task<IActionResult> Mine()
    {
        Crumbs("My Assets", ("My Assets", null));
        var emp = CurrentUser.EmployeeId;
        var list = emp is null ? new List<AssetAllocation>() : await db.AssetAllocations.AsNoTracking().Include(a => a.Asset)
            .Where(a => a.EmployeeId == emp && a.Status == AllocationStatus.Active).OrderByDescending(a => a.IssueDate).ToListAsync();
        ViewBag.Linked = emp is not null;
        return View(list);
    }

    [HttpGet, Permission(AppModule.Allocation, PermissionAction.Create)]
    public async Task<IActionResult> Issue(int? assetId)
    {
        Crumbs("Issue Asset", ("Asset Allocation", "/Allocations"), ("Issue", null));
        var input = new IssueInput { AssetId = assetId };
        await ListsAsync(input);
        return View(input);
    }

    [HttpPost, Permission(AppModule.Allocation, PermissionAction.Create)]
    public async Task<IActionResult> Issue(IssueInput input)
    {
        Crumbs("Issue Asset", ("Asset Allocation", "/Allocations"), ("Issue", null));
        AssetAllocation? a = null;
        if (ModelState.IsValid && await TryAsync(async () => a = await allocation.IssueAsync(input)))
        {
            Success($"{a!.AllocationNo} recorded. Print the handover document for signature.");
            return RedirectToAction(nameof(Handover), new { id = a.Id });
        }
        await ListsAsync(input);
        return View(input);
    }

    /// <summary>Printable asset issue / handover document.</summary>
    public async Task<IActionResult> Handover(int id)
    {
        var a = await db.AssetAllocations.AsNoTracking().Include(x => x.Asset!).ThenInclude(x => x.Category).Include(x => x.Employee!).ThenInclude(e => e.Department)
            .Include(x => x.Department).Include(x => x.Location).Include(x => x.Branch).Include(x => x.Return).FirstOrDefaultAsync(x => x.Id == id);
        if (a is null) return NotFound();
        bool own = a.EmployeeId is not null && a.EmployeeId == CurrentUser.EmployeeId;
        CurrentUser.EnsureCanSee(a.Asset!);
        Crumbs(a.AllocationNo, ("Asset Allocation", "/Allocations"), (a.AllocationNo, null));
        ViewBag.Company = await settings.GetCompanyAsync();
        ViewBag.IsRecipient = own;
        return View(a);
    }

    [HttpPost]
    public async Task<IActionResult> Acknowledge(int id, string? remarks)
    {
        await allocation.AcknowledgeAsync(id, remarks);
        Success("Handover acknowledged.");
        return RedirectToAction(nameof(Handover), new { id });
    }

    [HttpGet, Permission(AppModule.Allocation, PermissionAction.Edit)]
    public async Task<IActionResult> Return(int id)
    {
        var a = await db.AssetAllocations.AsNoTracking().Include(x => x.Asset).Include(x => x.Employee).FirstOrDefaultAsync(x => x.Id == id);
        if (a is null) return NotFound();
        Crumbs("Return Asset", ("Asset Allocation", "/Allocations"), (a.AllocationNo, $"/Allocations/Handover/{id}"), ("Return", null));
        ViewBag.Allocation = a;
        return View(new ReturnInput { AllocationId = id, ReturnDate = Clock.Today, ReturnCondition = a.Asset!.Condition });
    }

    [HttpPost, Permission(AppModule.Allocation, PermissionAction.Edit)]
    public async Task<IActionResult> Return(ReturnInput input)
    {
        if (ModelState.IsValid && await TryAsync(() => allocation.ReturnAsync(input)))
        {
            Success("Return recorded.");
            return RedirectToAction(nameof(Index));
        }
        var a = await db.AssetAllocations.AsNoTracking().Include(x => x.Asset).Include(x => x.Employee).FirstAsync(x => x.Id == input.AllocationId);
        Crumbs("Return Asset", ("Asset Allocation", "/Allocations"), ("Return", null));
        ViewBag.Allocation = a;
        return View(input);
    }

    private async Task ListsAsync(IssueInput i)
    {
        ViewBag.Assets = await AssetSelectAsync(i.AssetId);
        ViewBag.Employees = await SelectAsync<Employee>(i.EmployeeId);
        ViewBag.Departments = await SelectAsync<Department>(i.DepartmentId);
        ViewBag.Locations = await SelectAsync<Location>(i.LocationId);
    }
}

[Permission(AppModule.Allocation)]
public sealed class TransfersController(AllocationService allocation, ApprovalService approvals, AttachmentService attachments, AppDbContext db) : AppController
{
    public async Task<IActionResult> Index(TransferStatus? status, TransferType? type, string? q, int page = 1)
    {
        Crumbs("Asset Transfers", ("Transfers & Returns", null), ("Transfers", null));
        var query = db.AssetTransfers.AsNoTracking().Include(t => t.Asset).Include(t => t.FromBranch).Include(t => t.ToBranch)
            .Include(t => t.FromEmployee).Include(t => t.ToEmployee).Include(t => t.FromLocation).Include(t => t.ToLocation).AsQueryable();
        if (CurrentUser.BranchId is { } b) query = query.Where(t => t.FromBranchId == b || t.ToBranchId == b);
        if (status is not null) query = query.Where(t => t.Status == status);
        if (type is not null) query = query.Where(t => t.TransferType == type);
        if (!string.IsNullOrWhiteSpace(q)) query = query.Where(t => t.TransferNo.Contains(q) || t.Asset!.AssetTag.Contains(q));
        int total = await query.CountAsync();
        var list = await query.OrderByDescending(t => t.TransferDate).Skip((Math.Max(1, page) - 1) * 25).Take(25).ToListAsync();
        ViewBag.Status = status; ViewBag.Type = type; ViewBag.Q = q;
        ViewBag.Pager = new PagerModel(Math.Max(1, page), Math.Max(1, (int)Math.Ceiling(total / 25.0)), total, 25);
        return View(list);
    }

    [HttpGet, Permission(AppModule.Allocation, PermissionAction.Create)]
    public async Task<IActionResult> Create(int? assetId)
    {
        Crumbs("New Transfer", ("Transfers", "/Transfers"), ("New", null));
        var input = new TransferInput { AssetId = assetId, TransferDate = Clock.Today };
        await ListsAsync(input);
        return View(input);
    }

    [HttpPost, Permission(AppModule.Allocation, PermissionAction.Create)]
    public async Task<IActionResult> Create(TransferInput input)
    {
        Crumbs("New Transfer", ("Transfers", "/Transfers"), ("New", null));
        AssetTransfer? t = null;
        if (ModelState.IsValid && await TryAsync(async () => t = await allocation.RequestTransferAsync(input)))
        {
            Success(t!.Status == TransferStatus.Completed ? $"{t.TransferNo} completed." : $"{t.TransferNo} submitted for approval.");
            return RedirectToAction(nameof(Details), new { id = t.Id });
        }
        await ListsAsync(input);
        return View(input);
    }

    public async Task<IActionResult> Details(int id, [FromServices] PermissionChecker perm)
    {
        var t = await db.AssetTransfers.AsNoTracking().Include(x => x.Asset).Include(x => x.FromBranch).Include(x => x.ToBranch).Include(x => x.FromEmployee).Include(x => x.ToEmployee)
            .Include(x => x.FromDepartment).Include(x => x.ToDepartment).Include(x => x.FromLocation).Include(x => x.ToLocation).FirstOrDefaultAsync(x => x.Id == id);
        if (t is null) return NotFound();
        Crumbs(t.TransferNo, ("Transfers", "/Transfers"), (t.TransferNo, null));
        ViewBag.Approvals = new ApprovalPanelModel(await approvals.HistoryAsync(ApprovalModule.AssetTransfer, id));
        ViewBag.Attachments = new AttachmentsPanelModel("AssetTransfer", id, await attachments.ListAsync("AssetTransfer", id), await perm.CanAsync(AppModule.Allocation, PermissionAction.Create));
        return View(t);
    }

    private async Task ListsAsync(TransferInput i)
    {
        ViewBag.Assets = await AssetSelectAsync(i.AssetId);
        ViewBag.Employees = await SelectAsync<Employee>(i.ToEmployeeId);
        ViewBag.Departments = await SelectAsync<Department>(i.ToDepartmentId);
        ViewBag.Branches = await SelectAsync<Branch>(i.ToBranchId);
        ViewBag.Locations = await SelectAsync<Location>(i.ToLocationId);
    }
}
