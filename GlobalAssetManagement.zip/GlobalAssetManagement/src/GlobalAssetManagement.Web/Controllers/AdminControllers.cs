using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Application.Common.Reporting;
using GlobalAssetManagement.Application.Services;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using GlobalAssetManagement.Domain.Logic;
using GlobalAssetManagement.Infrastructure.Identity;
using GlobalAssetManagement.Infrastructure.Persistence;
using GlobalAssetManagement.Infrastructure.Services;
using GlobalAssetManagement.Web.Models;
using GlobalAssetManagement.Web.Security;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace GlobalAssetManagement.Web.Controllers;

public sealed class ReportViewModel
{
    public ReportDefinition Definition { get; init; } = default!;
    public ReportFilter Filter { get; init; } = new();
    public ReportTable Table { get; init; } = default!;
    public int Page { get; init; }
    public int PageSize { get; init; }
}

[Permission(AppModule.Reports)]
public sealed class ReportsController(ReportService reports, PermissionChecker perm, AppDbContext db, SettingsService settings) : AppController
{
    public async Task<IActionResult> Index()
    {
        Crumbs("Reports", ("Reports & Analytics", null));
        var visible = new List<ReportDefinition>();
        foreach (var d in ReportService.Definitions)
            if (await perm.CanAsync(d.Module)) visible.Add(d);
        return View(visible);
    }

    [HttpGet("/Reports/View/{key}")]
    public async Task<IActionResult> Show(string key, [FromQuery] ReportFilter filter, int page = 1)
    {
        var def = ReportService.Find(key);
        if (def is null) return NotFound();
        if (!await perm.CanAsync(def.Module)) return Forbid();
        Crumbs(def.Title, ("Reports", "/Reports"), (def.Title, null));
        var table = await reports.RunAsync(key, filter, await perm.CanAsync(AppModule.FinancialReports));
        await FilterListsAsync(filter);
        ViewBag.CanExport = await perm.CanAsync(AppModule.Reports, PermissionAction.Export) || await perm.CanAsync(def.Module, PermissionAction.Export);
        int size = await settings.GetIntAsync("Reports.PageSize", 50);
        return View("Show", new ReportViewModel { Definition = def, Filter = filter, Table = table, Page = Math.Max(1, page), PageSize = size });
    }

    [HttpGet("/Reports/Export/{key}")]
    public async Task<IActionResult> Export(string key, [FromQuery] ReportFilter filter, string format = "xlsx")
    {
        var def = ReportService.Find(key);
        if (def is null) return NotFound();
        if (!await perm.CanAsync(def.Module) || !(await perm.CanAsync(AppModule.Reports, PermissionAction.Export) || await perm.CanAsync(def.Module, PermissionAction.Export)))
            return Forbid();
        var table = await reports.RunAsync(key, filter, await perm.CanAsync(AppModule.FinancialReports));
        db.AuditLogs.Add(new AuditLog { Timestamp = Clock.UtcNow, UserName = CurrentUser.UserName, Action = AuditAction.Export, EntityName = "Report", EntityId = key, ReferenceNo = format, IpAddress = CurrentUser.IpAddress, Changes = $"{table.Rows.Count} rows; {string.Join(" ", table.Filters)}" });
        await db.SaveChangesAsync();
        string file = $"{def.Title.Replace(' ', '_')}_{Clock.Now:yyyyMMdd_HHmm}";
        return format switch
        {
            "csv" => File(CsvExporter.Export(table), "text/csv", file + ".csv"),
            "pdf" => File(PdfExporter.Export(table), "application/pdf", file + ".pdf"),
            "print" => View("Print", table),
            _ => File(ExcelExporter.Export(table), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", file + ".xlsx")
        };
    }

    private async Task FilterListsAsync(ReportFilter f)
    {
        ViewBag.Branches = await SelectAsync<Branch>(f.BranchId);
        ViewBag.Departments = await SelectAsync<Department>(f.DepartmentId);
        ViewBag.Categories = await SelectAsync<AssetCategory>(f.CategoryId);
        ViewBag.Employees = await SelectAsync<Employee>(f.EmployeeId);
        ViewBag.Locations = await SelectAsync<Location>(f.LocationId);
        ViewBag.Vendors = await SelectAsync<Vendor>(f.VendorId);
    }
}

[Permission(AppModule.Notifications)]
public sealed class NotificationsController(NotificationInbox inbox, AppDbContext db) : AppController
{
    public async Task<IActionResult> Index(bool unread = false, AlertType? type = null, int page = 1)
    {
        Crumbs("Notifications", ("Notifications & Reminders", null), ("My Notifications", null));
        ViewBag.Unread = unread; ViewBag.Type = type;
        return View(await inbox.ListAsync(unread, type, page));
    }

    [HttpPost]
    public async Task<IActionResult> Acknowledge(List<int> ids, string? returnUrl)
    {
        await inbox.AcknowledgeAsync(ids);
        Success($"{ids.Count} notification(s) acknowledged.");
        return RedirectToLocal(returnUrl);
    }

    [HttpPost, Permission(AppModule.Notifications, PermissionAction.Edit)]
    public async Task<IActionResult> RunNow([FromServices] ScheduledJobsService jobs)
    {
        await jobs.RunOnceAsync(HttpContext.RequestAborted);
        Success("Reminder scan completed. New reminders (if any) are listed below.");
        return RedirectToAction(nameof(Index));
    }

    [Permission(AppModule.Notifications, PermissionAction.Edit)]
    public async Task<IActionResult> Logs(DeliveryStatus? status, NotificationChannel? channel, int page = 1)
    {
        Crumbs("Delivery Log", ("Notifications & Reminders", null), ("Delivery Log", null));
        var q = db.NotificationLogs.AsNoTracking().Include(l => l.Notification).AsQueryable();
        if (status is not null) q = q.Where(l => l.Status == status);
        if (channel is not null) q = q.Where(l => l.Channel == channel);
        int total = await q.CountAsync();
        var list = await q.OrderByDescending(l => l.AttemptedAt).Skip((Math.Max(1, page) - 1) * 50).Take(50).ToListAsync();
        ViewBag.Status = status; ViewBag.Channel = channel;
        ViewBag.Pager = new PagerModel(Math.Max(1, page), Math.Max(1, (int)Math.Ceiling(total / 50.0)), total, 50);
        ViewBag.Channels = new Dictionary<string, bool>
        {
            ["Email"] = HttpContext.RequestServices.GetRequiredService<IEmailSender>().IsConfigured,
            ["SMS"] = HttpContext.RequestServices.GetRequiredService<ISmsSender>().IsConfigured,
            ["WhatsApp"] = HttpContext.RequestServices.GetRequiredService<IWhatsAppSender>().IsConfigured
        };
        return View(list);
    }
}

[Permission(AppModule.Users)]
public sealed class UsersController(UserManager<ApplicationUser> users, AppDbContext db, IClock clock, ILogger<UsersController> logger) : AppController
{
    public async Task<IActionResult> Index(string? q, string? role)
    {
        Crumbs("Users", ("User & Role Management", null), ("Users", null));
        var query = users.Users.AsNoTracking().AsQueryable();
        if (!string.IsNullOrWhiteSpace(q)) query = query.Where(u => u.UserName!.Contains(q) || u.FullName.Contains(q) || u.Email!.Contains(q));
        var list = await query.OrderBy(u => u.UserName).Take(500).ToListAsync();
        var roles = new Dictionary<string, IList<string>>();
        foreach (var u in list) roles[u.Id] = await users.GetRolesAsync(u);
        if (!string.IsNullOrWhiteSpace(role)) list = list.Where(u => roles[u.Id].Contains(role)).ToList();
        ViewBag.Roles = roles; ViewBag.Q = q; ViewBag.Role = role;
        ViewBag.Branches = (await db.Branches.AsNoTracking().ToListAsync()).ToDictionary(b => b.Id, b => b.Name);
        return View(list);
    }

    [HttpGet, Permission(AppModule.Users, PermissionAction.Create)]
    public async Task<IActionResult> Create()
    {
        Crumbs("New User", ("Users", "/Users"), ("New", null));
        await ListsAsync(new UserEditViewModel());
        return View("Edit", new UserEditViewModel { Roles = new() { Roles.Employee } });
    }

    [HttpGet, Permission(AppModule.Users, PermissionAction.Edit)]
    public async Task<IActionResult> Edit(string id)
    {
        var u = await users.FindByIdAsync(id);
        if (u is null) return NotFound();
        Crumbs("Edit User", ("Users", "/Users"), (u.UserName!, null));
        var vm = new UserEditViewModel
        {
            Id = u.Id, UserName = u.UserName!, FullName = u.FullName, Email = u.Email!, Phone = u.PhoneNumber, EmployeeId = u.EmployeeId,
            BranchId = u.BranchId, DepartmentId = u.DepartmentId, IsActive = u.IsActive, Roles = (await users.GetRolesAsync(u)).ToList(),
            TwoFactorEnabled = u.TwoFactorEnabled, IsLockedOut = await users.IsLockedOutAsync(u)
        };
        await ListsAsync(vm);
        return View(vm);
    }

    [HttpPost, Permission(AppModule.Users, PermissionAction.Edit)]
    public async Task<IActionResult> Save(UserEditViewModel vm)
    {
        bool isNew = string.IsNullOrEmpty(vm.Id);
        if (isNew && string.IsNullOrWhiteSpace(vm.Password)) ModelState.AddModelError(nameof(vm.Password), "Enter a temporary password for the new user.");
        vm.Roles = vm.Roles.Where(r => Roles.All.Contains(r)).Distinct().ToList();
        if (vm.Roles.Count == 0) ModelState.AddModelError(nameof(vm.Roles), "Select at least one role.");
        if (vm.Roles.Contains(Roles.SuperAdministrator) && !CurrentUser.IsInRole(Roles.SuperAdministrator))
            ModelState.AddModelError(nameof(vm.Roles), "Only a Super Administrator can grant the Super Administrator role.");

        ApplicationUser? u = isNew ? new ApplicationUser { CreatedAt = clock.UtcNow, MustChangePassword = true, EmailConfirmed = true } : await users.FindByIdAsync(vm.Id!);
        if (u is null) return NotFound();
        if (!isNew && u.Id == CurrentUser.UserId && !vm.IsActive) ModelState.AddModelError(nameof(vm.IsActive), "You cannot deactivate your own account.");
        if (!isNew && (await users.GetRolesAsync(u)).Contains(Roles.SuperAdministrator) && !vm.Roles.Contains(Roles.SuperAdministrator)
            && (await users.GetUsersInRoleAsync(Roles.SuperAdministrator)).Count <= 1)
            ModelState.AddModelError(nameof(vm.Roles), "At least one Super Administrator must remain.");

        if (!ModelState.IsValid) { Crumbs(isNew ? "New User" : "Edit User", ("Users", "/Users"), ("Edit", null)); await ListsAsync(vm); return View("Edit", vm); }

        u.UserName = vm.UserName.Trim();
        u.Email = vm.Email.Trim();
        u.FullName = vm.FullName.Trim();
        u.PhoneNumber = vm.Phone;
        u.EmployeeId = vm.EmployeeId;
        u.BranchId = vm.BranchId;
        u.DepartmentId = vm.DepartmentId;
        u.IsActive = vm.IsActive;

        var result = isNew ? await users.CreateAsync(u, vm.Password!) : await users.UpdateAsync(u);
        if (!result.Succeeded)
        {
            foreach (var e in result.Errors) ModelState.AddModelError(string.Empty, e.Description);
            Crumbs("User", ("Users", "/Users"), ("Edit", null));
            await ListsAsync(vm);
            return View("Edit", vm);
        }
        var current = await users.GetRolesAsync(u);
        await users.RemoveFromRolesAsync(u, current.Except(vm.Roles));
        await users.AddToRolesAsync(u, vm.Roles.Except(current));
        if (vm.EmployeeId is { } emp && await db.Employees.FirstOrDefaultAsync(e => e.Id == emp) is { } employee) { employee.UserId = u.Id; await db.SaveChangesAsync(); }
        if (!isNew) await users.UpdateSecurityStampAsync(u);

        db.AuditLogs.Add(new AuditLog { Timestamp = clock.UtcNow, UserName = CurrentUser.UserName, Action = isNew ? AuditAction.Create : AuditAction.Update, EntityName = "User", EntityId = u.Id, ReferenceNo = u.UserName, IpAddress = CurrentUser.IpAddress, Changes = $"Roles: {string.Join(", ", vm.Roles)}; Active: {vm.IsActive}; Branch: {vm.BranchId}; Department: {vm.DepartmentId}" });
        await db.SaveChangesAsync();
        logger.LogInformation("User {User} saved by {Admin}", u.UserName, CurrentUser.UserName);
        Success(isNew ? $"User {u.UserName} created. They must change the temporary password at first sign-in." : "User updated.");
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, Permission(AppModule.Users, PermissionAction.Edit)]
    public async Task<IActionResult> ResetPassword(string id, string newPassword)
    {
        var u = await users.FindByIdAsync(id);
        if (u is null) return NotFound();
        var token = await users.GeneratePasswordResetTokenAsync(u);
        var r = await users.ResetPasswordAsync(u, token, newPassword);
        if (!r.Succeeded) { Error(string.Join(" ", r.Errors.Select(e => e.Description))); return RedirectToAction(nameof(Edit), new { id }); }
        u.MustChangePassword = true;
        await users.UpdateAsync(u);
        await users.SetLockoutEndDateAsync(u, null);
        await users.ResetAccessFailedCountAsync(u);
        db.AuditLogs.Add(new AuditLog { Timestamp = clock.UtcNow, UserName = CurrentUser.UserName, Action = AuditAction.Update, EntityName = "User", EntityId = u.Id, ReferenceNo = u.UserName, Changes = "Password reset by administrator", IpAddress = CurrentUser.IpAddress });
        await db.SaveChangesAsync();
        Success("Password reset. The user must change it at next sign-in.");
        return RedirectToAction(nameof(Edit), new { id });
    }

    [HttpPost, Permission(AppModule.Users, PermissionAction.Edit)]
    public async Task<IActionResult> Unlock(string id)
    {
        var u = await users.FindByIdAsync(id);
        if (u is null) return NotFound();
        await users.SetLockoutEndDateAsync(u, null);
        await users.ResetAccessFailedCountAsync(u);
        Success("Account unlocked.");
        return RedirectToAction(nameof(Edit), new { id });
    }

    [HttpPost, Permission(AppModule.Users, PermissionAction.Edit)]
    public async Task<IActionResult> Reset2fa(string id)
    {
        var u = await users.FindByIdAsync(id);
        if (u is null) return NotFound();
        await users.SetTwoFactorEnabledAsync(u, false);
        await users.ResetAuthenticatorKeyAsync(u);
        Success("Two-factor authentication reset for this user.");
        return RedirectToAction(nameof(Edit), new { id });
    }

    public async Task<IActionResult> LoginHistory(string? user, bool failedOnly = false, int page = 1)
    {
        Crumbs("Login History", ("User & Role Management", null), ("Login History", null));
        var q = db.LoginHistory.AsNoTracking().AsQueryable();
        if (!string.IsNullOrWhiteSpace(user)) q = q.Where(l => l.UserName.Contains(user));
        if (failedOnly) q = q.Where(l => !l.Succeeded);
        int total = await q.CountAsync();
        var list = await q.OrderByDescending(l => l.AttemptedAt).Skip((Math.Max(1, page) - 1) * 50).Take(50).ToListAsync();
        ViewBag.User = user; ViewBag.FailedOnly = failedOnly;
        ViewBag.Pager = new PagerModel(Math.Max(1, page), Math.Max(1, (int)Math.Ceiling(total / 50.0)), total, 50);
        return View(list);
    }

    private async Task ListsAsync(UserEditViewModel vm)
    {
        ViewBag.Employees = await SelectAsync<Employee>(vm.EmployeeId);
        ViewBag.Branches = await SelectAsync<Branch>(vm.BranchId);
        ViewBag.Departments = await SelectAsync<Department>(vm.DepartmentId);
    }
}

[Permission(AppModule.Users)]
public sealed class RolesController(PermissionService permissions, UserManager<ApplicationUser> users) : AppController
{
    public async Task<IActionResult> Index()
    {
        Crumbs("Roles & Permissions", ("User & Role Management", null), ("Roles", null));
        var counts = new Dictionary<string, int>();
        foreach (var r in Roles.All) counts[r] = (await users.GetUsersInRoleAsync(r)).Count;
        return View(counts);
    }

    public async Task<IActionResult> Permissions(string role)
    {
        if (!Roles.All.Contains(role)) return NotFound();
        Crumbs($"Permissions · {role}", ("Roles & Permissions", "/Roles"), (role, null));
        ViewBag.Role = role;
        return View(await permissions.GetMatrixAsync(role));
    }

    [HttpPost, Permission(AppModule.Users, PermissionAction.Edit)]
    public async Task<IActionResult> Permissions(string role, List<RolePermission> rows)
    {
        if (!Roles.All.Contains(role)) return NotFound();
        await permissions.SaveMatrixAsync(role, rows);
        Success($"Permissions for {role} saved. They apply immediately.");
        return RedirectToAction(nameof(Permissions), new { role });
    }
}

[Permission(AppModule.Audit)]
public sealed class AuditController(AppDbContext db) : AppController
{
    public async Task<IActionResult> Index(string? user, string? entity, AuditAction? action, DateTime? from, DateTime? to, string? q, int page = 1)
    {
        Crumbs("Audit Trail", ("Audit Trail", null));
        var query = db.AuditLogs.AsNoTracking().AsQueryable();
        if (!string.IsNullOrWhiteSpace(user)) query = query.Where(a => a.UserName != null && a.UserName.Contains(user));
        if (!string.IsNullOrWhiteSpace(entity)) query = query.Where(a => a.EntityName == entity);
        if (action is not null) query = query.Where(a => a.Action == action);
        if (from is not null) query = query.Where(a => a.Timestamp >= from.Value.AddHours(-6));
        if (to is not null) query = query.Where(a => a.Timestamp < to.Value.AddDays(1));
        if (!string.IsNullOrWhiteSpace(q)) query = query.Where(a => (a.ReferenceNo != null && a.ReferenceNo.Contains(q)) || (a.EntityId != null && a.EntityId == q) || (a.Changes != null && a.Changes.Contains(q)));
        int total = await query.CountAsync();
        var list = await query.OrderByDescending(a => a.Timestamp).ThenByDescending(a => a.Id).Skip((Math.Max(1, page) - 1) * 50).Take(50).ToListAsync();
        ViewBag.Entities = await db.AuditLogs.AsNoTracking().Select(a => a.EntityName).Distinct().OrderBy(x => x).ToListAsync();
        ViewBag.Filter = new AuditFilter(user, entity, action, from, to, q);
        ViewBag.Pager = new PagerModel(Math.Max(1, page), Math.Max(1, (int)Math.Ceiling(total / 50.0)), total, 50);
        return View(list);
    }
}

[Permission(AppModule.Settings)]
public sealed class SettingsController(AppDbContext db, SettingsService settings, BackupService backup, IFileStorage storage,
    Microsoft.Extensions.Options.IOptions<BackupOptions> backupOptions) : AppController
{
    public async Task<IActionResult> Index()
    {
        Crumbs("Application Settings", ("Backup & System Settings", null), ("Settings", null));
        return View(await db.ApplicationSettings.AsNoTracking().OrderBy(s => s.Group).ThenBy(s => s.Key).ToListAsync());
    }

    [HttpPost, Permission(AppModule.Settings, PermissionAction.Edit)]
    public async Task<IActionResult> Index(Dictionary<string, string?> values)
    {
        var all = await db.ApplicationSettings.ToListAsync();
        foreach (var s in all)
            if (values.TryGetValue(s.Key, out var v)) s.Value = v?.Trim();
        await db.SaveChangesAsync();
        settings.Invalidate();
        Success("Settings saved.");
        return RedirectToAction(nameof(Index));
    }

    [HttpGet, Permission(AppModule.Settings, PermissionAction.Edit)]
    public async Task<IActionResult> Company()
    {
        Crumbs("Organization", ("Backup & System Settings", null), ("Organization", null));
        return View(await db.Companies.OrderBy(c => c.Id).FirstAsync());
    }

    [HttpPost, Permission(AppModule.Settings, PermissionAction.Edit)]
    public async Task<IActionResult> Company(Company input)
    {
        var c = await db.Companies.OrderBy(x => x.Id).FirstAsync();
        if (!ModelState.IsValid) { Crumbs("Organization", ("Organization", null)); return View(input); }
        c.Name = input.Name.Trim(); c.Address = input.Address; c.City = input.City; c.State = input.State; c.Pincode = input.Pincode; c.Phone = input.Phone;
        c.Email = input.Email; c.Website = input.Website; c.Gstin = input.Gstin?.ToUpperInvariant(); c.Pan = input.Pan?.ToUpperInvariant();
        c.FinancialYearStartMonth = input.FinancialYearStartMonth; c.CurrencySymbol = string.IsNullOrWhiteSpace(input.CurrencySymbol) ? "₹" : input.CurrencySymbol;
        await db.SaveChangesAsync();
        settings.Invalidate();
        Success("Organization details saved.");
        return RedirectToAction(nameof(Company));
    }

    public async Task<IActionResult> Backup()
    {
        Crumbs("Backup & Restore", ("Backup & System Settings", null), ("Backup", null));
        ViewBag.Options = backupOptions.Value;
        ViewBag.UploadsPath = storage.RootPath;
        ViewBag.Database = db.Database.GetDbConnection().Database;
        ViewBag.DataSource = db.Database.GetDbConnection().DataSource;
        return View(await db.BackupLogs.AsNoTracking().OrderByDescending(b => b.StartedAt).Take(50).ToListAsync());
    }

    [HttpPost, Permission(AppModule.Settings, PermissionAction.Edit)]
    public async Task<IActionResult> RunBackup(bool files = true)
    {
        var dbLog = await backup.BackupDatabaseAsync(CurrentUser.UserName);
        var fileLog = files ? await backup.BackupFilesAsync(CurrentUser.UserName) : null;
        int removed = backup.ApplyRetention();
        if (dbLog.Succeeded && (fileLog?.Succeeded ?? true)) Success($"Backup completed: {dbLog.FilePath}{(fileLog is null ? "" : " and " + fileLog.FilePath)}. {removed} old backup file(s) removed by retention.");
        else Error($"Backup problem: {(dbLog.Succeeded ? "" : "database - " + dbLog.Message)} {(fileLog is { Succeeded: false } ? "files - " + fileLog.Message : "")}");
        return RedirectToAction(nameof(Backup));
    }
}

/// <summary>Small JSON API for scanners and integrations. Uses the same cookie authentication and permissions as the UI.</summary>
[ApiController, Route("api"), Permission(AppModule.Assets)]
public sealed class AssetsApiController(AssetService assets, AppDbContext db) : ControllerBase
{
    /// <summary>GET /api/assets/{code} — look up an asset by asset ID, asset code or QR URL.</summary>
    [HttpGet("assets/{code}")]
    public async Task<IActionResult> Get(string code, [FromServices] ICurrentUser user)
    {
        var a = await assets.FindByCodeAsync(code);
        if (a is null || !user.CanSee(a)) return NotFound(new { message = "Asset not found." });
        var full = await db.Assets.AsNoTracking().Include(x => x.Category).Include(x => x.Branch).Include(x => x.Department).Include(x => x.Location).Include(x => x.AssignedEmployee)
            .FirstAsync(x => x.Id == a.Id);
        return Ok(new
        {
            full.Id, full.AssetTag, full.AssetCode, full.Name, Category = full.Category?.Name, full.SerialNumber, full.ModelNumber,
            Status = full.Status.ToString(), Condition = full.Condition.ToString(), Branch = full.Branch?.Name, Department = full.Department?.Name,
            Location = full.Location?.DisplayName, AssignedTo = full.AssignedEmployee?.FullName, full.WarrantyExpiryDate, full.NextServiceDate,
            DetailsUrl = $"/Assets/Details/{full.Id}"
        });
    }

    /// <summary>GET /api/assets?q=term — search assets (max 50).</summary>
    [HttpGet("assets")]
    public async Task<IActionResult> Search(string? q, [FromServices] LookupService lookups, [FromServices] ICurrentUser user)
        => Ok((await lookups.AssetsAsync(user, q, 50)).Select(i => new { id = i.Id, text = i.Text }));
}
