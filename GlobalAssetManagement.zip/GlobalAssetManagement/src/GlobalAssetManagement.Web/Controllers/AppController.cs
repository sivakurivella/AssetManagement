using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Application.Services;
using GlobalAssetManagement.Domain.Common;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GlobalAssetManagement.Web.Controllers;

/// <summary>Common helpers for MVC controllers: flash messages, breadcrumbs and dropdown data.</summary>
public abstract class AppController : Controller
{
    protected ICurrentUser CurrentUser => HttpContext.RequestServices.GetRequiredService<ICurrentUser>();
    protected IClock Clock => HttpContext.RequestServices.GetRequiredService<IClock>();
    protected LookupService Lookups => HttpContext.RequestServices.GetRequiredService<LookupService>();

    protected void Success(string message) => TempData["Success"] = message;
    protected void Error(string message) => TempData["Error"] = message;

    protected void Crumbs(string title, params (string Text, string? Url)[] trail)
    {
        ViewData["Title"] = title;
        ViewData["Breadcrumb"] = trail.ToList();
    }

    protected async Task<SelectList> SelectAsync<T>(object? selected = null, bool activeOnly = true) where T : BaseEntity, IHasDisplayName
        => new(await Lookups.ForAsync<T>(activeOnly), nameof(LookupItem.Id), nameof(LookupItem.Text), selected);

    protected async Task<SelectList> AssetSelectAsync(object? selected = null, bool includeDisposed = false)
    {
        var items = (await Lookups.AssetsAsync(CurrentUser, null, 2000, !includeDisposed)).ToList();
        if (selected is int id && items.All(i => i.Id != id))
            items.AddRange(await Lookups.AssetsAsync(CurrentUser, null, 1, false));
        return new SelectList(items, nameof(LookupItem.Id), nameof(LookupItem.Text), selected);
    }

    /// <summary>Runs a business operation; on a business-rule failure adds the message to ModelState and returns false.</summary>
    protected async Task<bool> TryAsync(Func<Task> action)
    {
        try
        {
            await action();
            return true;
        }
        catch (BusinessException ex)
        {
            ModelState.AddModelError(string.Empty, ex.Message);
            return false;
        }
    }

    protected IActionResult RedirectToLocal(string? returnUrl, string fallbackAction = "Index")
        => !string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl) ? Redirect(returnUrl) : RedirectToAction(fallbackAction);
}
