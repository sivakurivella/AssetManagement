using GlobalAssetManagement.Application.Services;
using Microsoft.AspNetCore.Mvc;

namespace GlobalAssetManagement.Web.ViewComponents;

public sealed class NotificationBellViewComponent(NotificationInbox inbox) : ViewComponent
{
    public async Task<IViewComponentResult> InvokeAsync()
    {
        int count = await inbox.UnreadCountAsync();
        var latest = await inbox.LatestAsync(6);
        ViewData["Count"] = count;
        return View(latest);
    }
}
