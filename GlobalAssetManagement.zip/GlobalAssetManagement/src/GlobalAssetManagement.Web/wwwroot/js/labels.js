document.getElementById('printBtn')?.addEventListener('click', () => window.print());
window.addEventListener('load', () => setTimeout(() => window.print(), 400));
