// Global Asset Management — shared client behaviour (no inline handlers so the Content-Security-Policy stays strict).
(function () {
  'use strict';

  const token = () => document.querySelector('input[name="__RequestVerificationToken"]')?.value || '';

  // Searchable dropdowns
  function initSelects(root) {
    if (!window.TomSelect) return;
    root.querySelectorAll('select.searchable:not(.tomselected)').forEach(el => {
      const remote = el.dataset.remote;
      const opts = { allowEmptyOption: true, maxOptions: 500, plugins: el.multiple ? ['remove_button'] : [], placeholder: el.dataset.placeholder || 'Select...' };
      if (remote) {
        Object.assign(opts, {
          valueField: 'id', labelField: 'text', searchField: 'text', loadThrottle: 250,
          load: (q, cb) => fetch(remote + (remote.includes('?') ? '&' : '?') + 'q=' + encodeURIComponent(q), { headers: { 'Accept': 'application/json' } })
            .then(r => r.json()).then(cb).catch(() => cb())
        });
      }
      new TomSelect(el, opts);
    });
  }

  // Confirmation dialogs for destructive / important actions: <button data-confirm="Are you sure?">
  let pendingForm = null, pendingButton = null;
  document.addEventListener('click', e => {
    const btn = e.target.closest('[data-confirm]');
    if (!btn) return;
    const form = btn.closest('form');
    if (btn.dataset.confirmed === '1') { btn.dataset.confirmed = ''; return; }
    e.preventDefault();
    pendingForm = form; pendingButton = btn;
    const modalEl = document.getElementById('confirmModal');
    modalEl.querySelector('.modal-body').textContent = btn.dataset.confirm;
    bootstrap.Modal.getOrCreateInstance(modalEl).show();
  });
  document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('confirmOk')?.addEventListener('click', () => {
      const modalEl = document.getElementById('confirmModal');
      bootstrap.Modal.getInstance(modalEl)?.hide();
      if (pendingButton) {
        if (pendingButton.tagName === 'A') { window.location = pendingButton.href; return; }
        pendingButton.dataset.confirmed = '1';
        pendingButton.click();
      }
    });
  });

  // Loading indicator on form submit (skipped for downloads / new tabs)
  document.addEventListener('submit', e => {
    const f = e.target;
    if (e.defaultPrevented || f.target === '_blank' || f.dataset.noLoading !== undefined) return;
    if (window.jQuery && jQuery(f).data('validator') && !jQuery(f).valid()) return;
    document.getElementById('gam-loading')?.classList.add('show');
    f.querySelectorAll('button[type=submit]').forEach(b => setTimeout(() => b.disabled = true, 10));
  });
  window.addEventListener('pageshow', () => document.getElementById('gam-loading')?.classList.remove('show'));

  // Auto-submit filter forms when a select changes: <form data-autosubmit>
  document.addEventListener('change', e => {
    const f = e.target.closest('form[data-autosubmit]');
    if (f && e.target.matches('select, input[type=checkbox], input[type=date]')) f.requestSubmit();
  });

  // Select-all checkbox: <input type=checkbox data-check-all=".row-check">
  document.addEventListener('change', e => {
    const sel = e.target.dataset?.checkAll;
    if (sel) document.querySelectorAll(sel).forEach(c => c.checked = e.target.checked);
  });

  // Dynamic line items (purchase requests / orders): <tbody data-lines>, <template id=...>, <button data-add-line="#tpl">
  document.addEventListener('click', e => {
    const add = e.target.closest('[data-add-line]');
    if (add) {
      e.preventDefault();
      const tpl = document.querySelector(add.dataset.addLine);
      const body = document.querySelector(add.dataset.target);
      const idx = body.querySelectorAll('tr').length;
      const html = tpl.innerHTML.replace(/__i__/g, idx);
      body.insertAdjacentHTML('beforeend', html);
      initSelects(body);
      recalc(body.closest('form'));
    }
    const rm = e.target.closest('[data-remove-line]');
    if (rm) {
      e.preventDefault();
      const tr = rm.closest('tr');
      const form = tr.closest('form');
      tr.querySelectorAll('input.qty').forEach(i => i.value = 0);
      tr.querySelectorAll('[required]').forEach(i => i.removeAttribute('required'));
      tr.style.display = 'none';
      recalc(form);
    }
  });
  function recalc(form) {
    if (!form) return;
    let sub = 0, tax = 0;
    form.querySelectorAll('tr.line').forEach(tr => {
      const q = parseFloat(tr.querySelector('.qty')?.value || 0), p = parseFloat(tr.querySelector('.price')?.value || 0), t = parseFloat(tr.querySelector('.taxrate')?.value || 0);
      const amt = q * p; sub += amt; tax += amt * t / 100;
      const cell = tr.querySelector('.amount'); if (cell) cell.textContent = amt.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    });
    const other = parseFloat(form.querySelector('.othercharges')?.value || 0);
    const set = (s, v) => { const el = form.querySelector(s); if (el) el.textContent = v.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
    set('.sum-sub', sub); set('.sum-tax', tax); set('.sum-total', sub + tax + other);
  }
  document.addEventListener('input', e => { if (e.target.matches('.qty, .price, .taxrate, .othercharges')) recalc(e.target.closest('form')); });

  // GST amount helper on the asset form: data-gst-base / data-gst-rate / data-gst-amount
  document.addEventListener('input', e => {
    if (!e.target.matches('[data-gst-base], [data-gst-rate]')) return;
    const f = e.target.closest('form');
    const base = parseFloat(f.querySelector('[data-gst-base]')?.value || 0), rate = parseFloat(f.querySelector('[data-gst-rate]')?.value || 0);
    const amt = f.querySelector('[data-gst-amount]');
    if (amt) amt.value = (Math.round(base * rate) / 100).toFixed(2);
  });

  // Show/hide fields based on a select value: <div data-show-when="#TargetType" data-show-values="Employee,Branch">
  function applyConditional() {
    document.querySelectorAll('[data-show-when]').forEach(el => {
      const src = document.querySelector(el.dataset.showWhen);
      if (!src) return;
      const values = el.dataset.showValues.split(',');
      el.style.display = values.includes(src.value) ? '' : 'none';
    });
  }
  document.addEventListener('change', e => { if (e.target.id) applyConditional(); });

  // Keep the active sidebar group open
  function markActiveNav() {
    const path = location.pathname.toLowerCase();
    let best = null, bestLen = 0;
    document.querySelectorAll('.gam-nav a[href]').forEach(a => {
      const href = a.getAttribute('href').toLowerCase().split('?')[0];
      if (href !== '/' && path.startsWith(href) && href.length > bestLen) { best = a; bestLen = href.length; }
      if (href === '/' && path === '/') { best = a; bestLen = 1; }
    });
    if (best) {
      best.classList.add('active');
      const sub = best.closest('.collapse');
      if (sub) { sub.classList.add('show'); sub.previousElementSibling?.setAttribute('aria-expanded', 'true'); }
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    initSelects(document);
    applyConditional();
    markActiveNav();
    document.querySelectorAll('form').forEach(f => recalc(f));
    document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(el => new bootstrap.Tooltip(el));
    document.querySelectorAll('.alert-dismissible.auto-hide').forEach(a => setTimeout(() => bootstrap.Alert.getOrCreateInstance(a).close(), 6000));
    document.querySelectorAll('[data-print]').forEach(b => b.addEventListener('click', () => window.print()));
  });

  window.gam = { token, initSelects };
})();
