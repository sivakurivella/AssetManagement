// Physical verification scanning: keyboard-wedge barcode scanners and phone cameras (html5-qrcode).
(function () {
  const form = document.getElementById('scanForm');
  const code = document.getElementById('code');
  const result = document.getElementById('result');
  const history = document.getElementById('history');
  const useGps = document.getElementById('scanScript')?.dataset.gps === '1';
  let busy = false, last = '', lastAt = 0, scanner = null;

  if (useGps && navigator.geolocation) {
    navigator.geolocation.watchPosition(p => {
      document.getElementById('lat').value = p.coords.latitude.toFixed(6);
      document.getElementById('lng').value = p.coords.longitude.toFixed(6);
    }, () => {}, { enableHighAccuracy: true, maximumAge: 30000 });
  }

  const tones = { Found: 'success', WrongLocation: 'warning', Unregistered: 'purple', Missing: 'danger' };

  async function submit(value) {
    value = (value || '').trim();
    if (!value || busy) return;
    const now = Date.now();
    if (value === last && now - lastAt < 2500) return; // ignore camera repeats
    last = value; lastAt = now; busy = true;
    const data = new FormData(form);
    data.set('Code', value);
    try {
      const resp = await fetch('/Verification/ScanCode', { method: 'POST', body: data, headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json' } });
      const json = await resp.json();
      const tone = json.ok ? (tones[json.result] || 'primary') : 'danger';
      result.className = 'scan-result mt-3 text-bg-' + tone;
      result.textContent = json.message || 'Error';
      if (json.ok) {
        document.getElementById('found').textContent = json.found;
        document.getElementById('expected').textContent = json.expected;
        if (history.firstElementChild?.classList.contains('text-muted')) history.innerHTML = '';
        const li = document.createElement('li');
        li.className = 'list-group-item d-flex justify-content-between';
        const left = document.createElement('span');
        left.textContent = (json.tag || value) + (json.name ? ' — ' + json.name : '');
        const badge = document.createElement('span');
        badge.className = 'badge text-bg-' + tone;
        badge.textContent = json.resultText;
        li.append(left, badge);
        history.prepend(li);
        if (navigator.vibrate) navigator.vibrate(json.result === 'Found' ? 60 : [60, 60, 60]);
      }
    } catch (e) {
      result.className = 'scan-result mt-3 text-bg-danger';
      result.textContent = 'Could not reach the server. Check the connection and scan again.';
    } finally {
      busy = false;
      code.value = '';
      code.focus();
    }
  }

  form.addEventListener('submit', e => { e.preventDefault(); submit(code.value); });

  document.getElementById('camBtn').addEventListener('click', async () => {
    if (!window.Html5Qrcode) return;
    if (scanner) { await scanner.stop(); scanner = null; document.getElementById('camBtn').innerHTML = '<i class="bi bi-camera"></i> Use camera'; return; }
    scanner = new Html5Qrcode('reader', { formatsToSupport: [Html5QrcodeSupportedFormats.QR_CODE, Html5QrcodeSupportedFormats.CODE_128, Html5QrcodeSupportedFormats.CODE_39, Html5QrcodeSupportedFormats.EAN_13] });
    try {
      await scanner.start({ facingMode: 'environment' }, { fps: 10, qrbox: { width: 240, height: 240 } }, text => submit(text));
      document.getElementById('camBtn').innerHTML = '<i class="bi bi-stop-circle"></i> Stop camera';
    } catch (err) {
      scanner = null;
      result.className = 'scan-result mt-3 text-bg-warning';
      result.textContent = 'Camera not available: ' + err + '. HTTPS is required for camera access.';
    }
  });
})();
