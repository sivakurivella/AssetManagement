using System.ComponentModel.DataAnnotations;

namespace GlobalAssetManagement.Web.Models;

public sealed class LoginViewModel
{
    [Required, Display(Name = "User name or email")] public string UserName { get; set; } = "";
    [Required, DataType(DataType.Password)] public string Password { get; set; } = "";
    [Display(Name = "Keep me signed in")] public bool RememberMe { get; set; }
    public string? ReturnUrl { get; set; }
}

public sealed class TwoFactorLoginViewModel
{
    [Required, StringLength(8, MinimumLength = 6), Display(Name = "Authenticator code")] public string Code { get; set; } = "";
    public bool RememberMe { get; set; }
    [Display(Name = "Remember this device")] public bool RememberMachine { get; set; }
    public string? ReturnUrl { get; set; }
    [Display(Name = "Use a recovery code instead")] public bool UseRecoveryCode { get; set; }
}

public sealed class ForgotPasswordViewModel
{
    [Required, EmailAddress] public string Email { get; set; } = "";
}

public sealed class ResetPasswordViewModel
{
    [Required, EmailAddress] public string Email { get; set; } = "";
    [Required, StringLength(100, MinimumLength = 8), DataType(DataType.Password), Display(Name = "New password")] public string Password { get; set; } = "";
    [DataType(DataType.Password), Display(Name = "Confirm password"), Compare(nameof(Password), ErrorMessage = "Passwords do not match.")] public string ConfirmPassword { get; set; } = "";
    [Required] public string Token { get; set; } = "";
}

public sealed class ChangePasswordViewModel
{
    [Required, DataType(DataType.Password), Display(Name = "Current password")] public string CurrentPassword { get; set; } = "";
    [Required, StringLength(100, MinimumLength = 8), DataType(DataType.Password), Display(Name = "New password")] public string NewPassword { get; set; } = "";
    [DataType(DataType.Password), Display(Name = "Confirm new password"), Compare(nameof(NewPassword), ErrorMessage = "Passwords do not match.")] public string ConfirmPassword { get; set; } = "";
}

public sealed class EnableAuthenticatorViewModel
{
    public string SharedKey { get; set; } = "";
    public string QrSvg { get; set; } = "";
    [Required, StringLength(7, MinimumLength = 6), Display(Name = "Verification code")] public string Code { get; set; } = "";
}

public sealed class SetupViewModel
{
    [Required, StringLength(200), Display(Name = "Organization name")] public string OrganizationName { get; set; } = "";
    [StringLength(100)] public string? City { get; set; }
    [Required, StringLength(150), Display(Name = "Administrator full name")] public string FullName { get; set; } = "";
    [Required, StringLength(50), RegularExpression(@"^[A-Za-z0-9._@-]+$", ErrorMessage = "Use letters, digits, dot, dash, underscore or @."), Display(Name = "User name")] public string UserName { get; set; } = "";
    [Required, EmailAddress] public string Email { get; set; } = "";
    [Phone] public string? Phone { get; set; }
    [Required, StringLength(100, MinimumLength = 10), DataType(DataType.Password)] public string Password { get; set; } = "";
    [DataType(DataType.Password), Display(Name = "Confirm password"), Compare(nameof(Password), ErrorMessage = "Passwords do not match.")] public string ConfirmPassword { get; set; } = "";
}

public sealed class UserEditViewModel
{
    public string? Id { get; set; }
    [Required, StringLength(50), RegularExpression(@"^[A-Za-z0-9._@-]+$", ErrorMessage = "Use letters, digits, dot, dash, underscore or @."), Display(Name = "User name")] public string UserName { get; set; } = "";
    [Required, StringLength(150), Display(Name = "Full name")] public string FullName { get; set; } = "";
    [Required, EmailAddress] public string Email { get; set; } = "";
    [Phone, Display(Name = "Mobile (for SMS / WhatsApp alerts)")] public string? Phone { get; set; }
    [Display(Name = "Linked employee")] public int? EmployeeId { get; set; }
    [Display(Name = "Restrict to branch")] public int? BranchId { get; set; }
    [Display(Name = "Restrict to department")] public int? DepartmentId { get; set; }
    [Display(Name = "Active")] public bool IsActive { get; set; } = true;
    public List<string> Roles { get; set; } = new();
    [StringLength(100, MinimumLength = 8), DataType(DataType.Password), Display(Name = "Temporary password (new users)")] public string? Password { get; set; }
    public bool TwoFactorEnabled { get; set; }
    public bool IsLockedOut { get; set; }
}
