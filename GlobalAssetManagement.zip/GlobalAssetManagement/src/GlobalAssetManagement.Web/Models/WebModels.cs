namespace GlobalAssetManagement.Web.Models;

public sealed record PagerModel(int Page, int TotalPages, int TotalCount, int PageSize);

public sealed class ErrorViewModel
{
    public string? RequestId { get; set; }
    public int StatusCode { get; set; } = 500;
    public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
}

public sealed record AttachmentsPanelModel(string EntityName, int EntityId, IReadOnlyList<GlobalAssetManagement.Domain.Entities.Attachment> Items, bool CanUpload);

public sealed record ApprovalPanelModel(IReadOnlyList<GlobalAssetManagement.Domain.Entities.Approval> Items);

public sealed record SearchResult(string Kind, string Title, string? Subtitle, string Url, string Icon);

public sealed record AuditFilter(string? User, string? Entity, GlobalAssetManagement.Domain.Enums.AuditAction? Action, DateTime? From, DateTime? To, string? Q);
