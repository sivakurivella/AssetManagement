using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Domain.Common;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using GlobalAssetManagement.Domain.Logic;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;

namespace GlobalAssetManagement.Application.Services;

/// <summary>Organization profile and key/value application settings (cached).</summary>
public sealed class SettingsService(IAppDbContext db, IMemoryCache cache)
{
    private const string CompanyKey = "settings:company";
    private const string SettingsKey = "settings:all";

    public async Task<Company> GetCompanyAsync(CancellationToken ct = default)
    {
        if (cache.TryGetValue(CompanyKey, out Company? c) && c is not null) return c;
        c = await db.Companies.AsNoTracking().OrderBy(x => x.Id).FirstOrDefaultAsync(ct)
            ?? new Company { Name = "S.S. Solutions", City = "Guntur", FinancialYearStartMonth = 4 };
        cache.Set(CompanyKey, c, TimeSpan.FromMinutes(10));
        return c;
    }

    public async Task<IReadOnlyDictionary<string, string?>> GetAllAsync(CancellationToken ct = default)
    {
        if (cache.TryGetValue(SettingsKey, out Dictionary<string, string?>? d) && d is not null) return d;
        d = await db.ApplicationSettings.AsNoTracking().ToDictionaryAsync(s => s.Key, s => s.Value, StringComparer.OrdinalIgnoreCase, ct);
        cache.Set(SettingsKey, d, TimeSpan.FromMinutes(10));
        return d;
    }

    public async Task<string?> GetAsync(string key, string? fallback = null, CancellationToken ct = default)
    {
        var all = await GetAllAsync(ct);
        return all.TryGetValue(key, out var v) && !string.IsNullOrWhiteSpace(v) ? v : fallback;
    }

    public async Task<int> GetIntAsync(string key, int fallback, CancellationToken ct = default)
        => int.TryParse(await GetAsync(key, null, ct), out int v) ? v : fallback;

    public async Task SetAsync(string key, string? value, string group = "General", string? description = null, CancellationToken ct = default)
    {
        var s = await db.ApplicationSettings.FirstOrDefaultAsync(x => x.Key == key, ct);
        if (s is null) db.ApplicationSettings.Add(new ApplicationSetting { Key = key, Value = value, Group = group, Description = description });
        else s.Value = value;
        await db.SaveChangesAsync(ct);
        Invalidate();
    }

    public void Invalidate()
    {
        cache.Remove(CompanyKey);
        cache.Remove(SettingsKey);
    }

    public async Task<(DateTime Start, DateTime End, string Label)> FinancialYearForAsync(DateTime date, CancellationToken ct = default)
    {
        var company = await GetCompanyAsync(ct);
        return FinancialYear.For(date, company.FinancialYearStartMonth);
    }
}

/// <summary>Concurrency-safe document number series (PR/2026-27/0001 style).</summary>
public sealed class NumberingService(IAppDbContext db, IClock clock, SettingsService settings, ILogger<NumberingService> logger)
{
    public const string AssetTagScope = "ALL";

    public async Task<string> NextDocumentNoAsync(string prefix, CancellationToken ct = default)
    {
        var fy = await settings.FinancialYearForAsync(clock.Today, ct);
        int n = await NextAsync(prefix, fy.Label, ct);
        return DocumentNumbers.Document(prefix, fy.Label, n);
    }

    /// <summary>
    /// Increments and saves the sequence immediately. Call this BEFORE adding the business entity to the context,
    /// because the save also flushes any other pending changes.
    /// </summary>
    public async Task<int> NextAsync(string prefix, string scope, CancellationToken ct = default)
    {
        for (int attempt = 0; attempt < 10; attempt++)
        {
            var seq = await db.NumberSequences.FirstOrDefaultAsync(s => s.Prefix == prefix && s.Scope == scope, ct);
            if (seq is null)
            {
                seq = new NumberSequence { Prefix = prefix, Scope = scope, LastNumber = 0 };
                db.NumberSequences.Add(seq);
            }
            seq.LastNumber++;
            try
            {
                await db.SaveChangesAsync(ct);
                return seq.LastNumber;
            }
            catch (DbUpdateException ex)
            {
                logger.LogWarning(ex, "Number sequence {Prefix}/{Scope} conflict, retrying (attempt {Attempt})", prefix, scope, attempt + 1);
                db.Entry(seq).State = EntityState.Detached;
                await Task.Delay(20 * (attempt + 1), ct);
            }
        }
        throw new BusinessException($"Could not allocate a new number for {prefix}. Please try again.");
    }
}

/// <summary>Writes entries to the immutable asset life-cycle timeline.</summary>
public sealed class AssetHistory(IAppDbContext db, IClock clock, ICurrentUser user)
{
    public void Record(Asset asset, AssetEventType type, string description, string? referenceType = null,
        int? referenceId = null, string? referenceNo = null)
    {
        var ev = new AssetEvent
        {
            Asset = asset.Id == 0 ? asset : null,
            AssetId = asset.Id,
            EventAt = clock.UtcNow,
            EventType = type,
            Description = description.Length > 1000 ? description[..1000] : description,
            ReferenceType = referenceType,
            ReferenceId = referenceId,
            ReferenceNo = referenceNo,
            UserName = user.IsAuthenticated ? user.UserName : "system"
        };
        db.AssetEvents.Add(ev);
    }

    public void ChangeStatus(Asset asset, AssetStatus newStatus, string reason, string? referenceType = null, int? referenceId = null, string? referenceNo = null)
    {
        if (asset.Status == newStatus) return;
        var old = asset.Status;
        asset.Status = newStatus;
        Record(asset, AssetEventType.StatusChanged, $"Status changed from {old.DisplayName()} to {newStatus.DisplayName()}: {reason}",
            referenceType, referenceId, referenceNo);
    }
}

/// <summary>Branch / department data-visibility restrictions for the signed-in user.</summary>
public static class DataScope
{
    public static IQueryable<Asset> VisibleTo(this IQueryable<Asset> q, ICurrentUser user)
    {
        int? branch = user.BranchId, dept = user.DepartmentId;
        if (branch is not null) q = q.Where(a => a.BranchId == branch);
        if (dept is not null) q = q.Where(a => a.DepartmentId == dept);
        return q;
    }

    public static bool CanSee(this ICurrentUser user, Asset a) =>
        (user.BranchId is null || a.BranchId == user.BranchId) && (user.DepartmentId is null || a.DepartmentId == user.DepartmentId);

    public static void EnsureCanSee(this ICurrentUser user, Asset a)
    {
        if (!user.CanSee(a)) throw new UnauthorizedAccessException("This asset belongs to a branch or department you are not allowed to access.");
    }
}

public sealed record LookupItem(int Id, string Text);

/// <summary>Dropdown data for forms.</summary>
public sealed class LookupService(IAppDbContext db)
{
    public async Task<IReadOnlyList<LookupItem>> ForAsync<T>(bool activeOnly = true, CancellationToken ct = default)
        where T : BaseEntity, IHasDisplayName
    {
        IQueryable<T> q = db.Set<T>().AsNoTracking();
        var list = await q.ToListAsync(ct);
        return list.Where(x => !activeOnly || x is not IActivatable a || a.IsActive)
            .Select(x => new LookupItem(x.Id, x.DisplayName))
            .OrderBy(x => x.Text, StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    /// <summary>Non-generic variant used by the generic master screens.</summary>
    public async Task<IReadOnlyList<LookupItem>> ForTypeAsync(Type entityType, CancellationToken ct = default)
    {
        var method = typeof(LookupService).GetMethod(nameof(ForAsync))!.MakeGenericMethod(entityType);
        var task = (Task<IReadOnlyList<LookupItem>>)method.Invoke(this, new object[] { false, ct })!;
        return await task;
    }

    public async Task<IReadOnlyList<LookupItem>> AssetsAsync(ICurrentUser user, string? term = null, int take = 50, bool excludeDisposed = true, CancellationToken ct = default)
    {
        var q = db.Assets.AsNoTracking().VisibleTo(user);
        if (excludeDisposed) q = q.Where(a => a.Status != AssetStatus.Disposed && a.Status != AssetStatus.LostOrWrittenOff);
        if (!string.IsNullOrWhiteSpace(term))
        {
            term = term.Trim();
            q = q.Where(a => a.AssetTag.Contains(term) || a.AssetCode.Contains(term) || a.Name.Contains(term) || (a.SerialNumber != null && a.SerialNumber.Contains(term)));
        }
        return await q.OrderBy(a => a.AssetTag).Take(take)
            .Select(a => new LookupItem(a.Id, a.AssetTag + " - " + a.Name + (a.SerialNumber != null ? " (S/N " + a.SerialNumber + ")" : "")))
            .ToListAsync(ct);
    }
}

public static class EnumExtensions
{
    public static string DisplayName(this Enum value)
    {
        var member = value.GetType().GetMember(value.ToString()).FirstOrDefault();
        var attr = member?.GetCustomAttributes(typeof(System.ComponentModel.DataAnnotations.DisplayAttribute), false)
            .OfType<System.ComponentModel.DataAnnotations.DisplayAttribute>().FirstOrDefault();
        return attr?.GetName() ?? SplitCamel(value.ToString());
    }

    private static string SplitCamel(string s) =>
        string.Concat(s.Select((ch, i) => i > 0 && char.IsUpper(ch) && !char.IsUpper(s[i - 1]) ? " " + ch : ch.ToString()));
}
