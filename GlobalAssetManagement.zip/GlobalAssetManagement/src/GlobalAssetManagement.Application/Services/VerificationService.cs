using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Application.Models;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using GlobalAssetManagement.Domain.Logic;
using Microsoft.EntityFrameworkCore;

namespace GlobalAssetManagement.Application.Services;

public sealed record ScanOutcome(bool Ok, VerificationResult Result, string Message, string? AssetTag, string? AssetName, int Found, int Expected);

/// <summary>Physical verification (stock-taking) sessions with QR / barcode scanning and reconciliation.</summary>
public sealed class VerificationService(
    IAppDbContext db,
    NumberingService numbering,
    ApprovalService approvals,
    AssetService assets,
    AssetHistory history,
    ICurrentUser user,
    IClock clock) : IApprovalHandler
{
    public async Task<PhysicalVerificationSession> CreateSessionAsync(VerificationSessionInput input, CancellationToken ct = default)
    {
        int? branch = input.BranchId ?? user.BranchId;
        if (user.BranchId is { } ub && branch != ub) throw new BusinessException("You can only verify assets of your own branch.");

        var q = db.Assets.AsNoTracking().VisibleTo(user)
            .Where(a => a.Status != AssetStatus.Disposed && a.Status != AssetStatus.LostOrWrittenOff
                        && a.Status != AssetStatus.Requested && a.Status != AssetStatus.Ordered);
        if (branch is not null) q = q.Where(a => a.BranchId == branch);
        if (input.DepartmentId is { } d) q = q.Where(a => a.DepartmentId == d);
        if (input.LocationId is { } l) q = q.Where(a => a.LocationId == l);
        var expected = await q.Select(a => new { a.Id, a.LocationId }).ToListAsync(ct);
        if (expected.Count == 0) throw new BusinessException("No assets match the selected branch / department / location.");

        string no = await numbering.NextDocumentNoAsync("PV", ct);
        var s = new PhysicalVerificationSession
        {
            SessionNo = no, Title = input.Title.Trim(), BranchId = branch, DepartmentId = input.DepartmentId, LocationId = input.LocationId,
            StartedAt = clock.UtcNow, ConductedBy = user.UserName, CaptureGps = input.CaptureGps, Remarks = input.Remarks,
            Status = VerificationSessionStatus.Open
        };
        foreach (var e in expected)
            s.Items.Add(new PhysicalVerificationItem { AssetId = e.Id, IsExpected = true, ExpectedLocationId = e.LocationId, Result = VerificationResult.Pending });
        db.PhysicalVerificationSessions.Add(s);
        await db.SaveChangesAsync(ct);
        return s;
    }

    public async Task<ScanOutcome> ScanAsync(ScanInput input, CancellationToken ct = default)
    {
        var s = await db.PhysicalVerificationSessions.Include(x => x.Items).FirstOrDefaultAsync(x => x.Id == input.SessionId, ct)
                ?? throw new BusinessException("Verification session not found.");
        if (s.Status != VerificationSessionStatus.Open) throw new BusinessException("This verification session is closed for scanning.");
        string code = input.Code.Trim();
        if (code.Length == 0) throw new BusinessException("Empty code.");

        int? foundLocation = input.FoundLocationId ?? s.LocationId;
        var asset = await assets.FindByCodeAsync(code, ct);
        PhysicalVerificationItem item;
        string message;

        if (asset is null)
        {
            item = s.Items.FirstOrDefault(i => i.AssetId == null && string.Equals(i.ScannedCode, code, StringComparison.OrdinalIgnoreCase))
                   ?? AddItem(s, null, code);
            item.Result = VerificationResult.Unregistered;
            message = $"'{code}' is not in the asset register (recorded as unregistered).";
        }
        else
        {
            item = s.Items.FirstOrDefault(i => i.AssetId == asset.Id) ?? AddItem(s, asset.Id, code);
            bool wrong = !item.IsExpected || (item.ExpectedLocationId is { } el && foundLocation is { } fl && el != fl);
            item.Result = wrong ? VerificationResult.WrongLocation : VerificationResult.Found;
            message = wrong
                ? (item.IsExpected ? $"{asset.AssetTag} found at a different location than recorded." : $"{asset.AssetTag} is registered elsewhere (not expected in this session).")
                : $"{asset.AssetTag} verified.";
        }
        item.ScannedCode = code.Length > 100 ? code[..100] : code;
        item.FoundLocationId = foundLocation;
        item.ConditionObserved = input.Condition ?? item.ConditionObserved;
        item.Remarks = input.Remarks ?? item.Remarks;
        item.ScannedAt = clock.UtcNow;
        item.ScannedBy = user.UserName;
        if (s.CaptureGps && input.Latitude is { } lat && input.Longitude is { } lng && Math.Abs(lat) <= 90 && Math.Abs(lng) <= 180)
        {
            item.Latitude = Math.Round(lat, 6);
            item.Longitude = Math.Round(lng, 6);
        }
        await db.SaveChangesAsync(ct);

        int found = s.Items.Count(i => i.IsExpected && i.Result is VerificationResult.Found or VerificationResult.WrongLocation);
        return new ScanOutcome(true, item.Result, message, asset?.AssetTag, asset?.Name, found, s.Items.Count(i => i.IsExpected));
    }

    private PhysicalVerificationItem AddItem(PhysicalVerificationSession s, int? assetId, string code)
    {
        var item = new PhysicalVerificationItem { AssetId = assetId, IsExpected = false, ScannedCode = code };
        s.Items.Add(item);
        return item;
    }

    public async Task UpdateItemAsync(int itemId, VerificationResult? manualResult, AssetCondition? condition, string? remarks, CancellationToken ct = default)
    {
        var item = await db.PhysicalVerificationItems.Include(i => i.Session).FirstOrDefaultAsync(i => i.Id == itemId, ct)
                   ?? throw new BusinessException("Item not found.");
        if (item.Session!.Status != VerificationSessionStatus.Open) throw new BusinessException("The session is closed.");
        if (manualResult is { } r)
        {
            if (r == VerificationResult.Unregistered && item.AssetId is not null) throw new BusinessException("A registered asset cannot be marked unregistered.");
            item.Result = r;
            item.ScannedAt ??= clock.UtcNow;
            item.ScannedBy ??= user.UserName + " (manual)";
            if (r is VerificationResult.Found) item.FoundLocationId ??= item.ExpectedLocationId;
        }
        item.ConditionObserved = condition ?? item.ConditionObserved;
        item.Remarks = remarks ?? item.Remarks;
        await db.SaveChangesAsync(ct);
    }

    /// <summary>Finalizes the session: unscanned expected assets become Missing; then routes for approval.</summary>
    public async Task SubmitAsync(int sessionId, CancellationToken ct = default)
    {
        var s = await db.PhysicalVerificationSessions.Include(x => x.Items).FirstOrDefaultAsync(x => x.Id == sessionId, ct)
                ?? throw new BusinessException("Verification session not found.");
        if (s.Status != VerificationSessionStatus.Open) throw new BusinessException("This session has already been submitted.");

        // Manually confirmed items keep their result; everything else is reconciled from expectations and scans.
        var expected = s.Items.Where(i => i.IsExpected && i.AssetId is not null).Select(i => new ExpectedAsset(i.AssetId!.Value, i.ExpectedLocationId));
        var scans = s.Items.Where(i => i.ScannedAt is not null && i.Result != VerificationResult.Missing)
            .Select(i => new ScanRecord(i.AssetId, i.ScannedCode ?? "", i.FoundLocationId));
        var lines = VerificationReconciler.Reconcile(expected, scans, finalize: true);
        foreach (var line in lines)
        {
            var item = line.AssetId is { } aid
                ? s.Items.First(i => i.AssetId == aid)
                : s.Items.First(i => i.AssetId == null && string.Equals(i.ScannedCode?.Trim(), line.Code, StringComparison.OrdinalIgnoreCase));
            bool manualDecision = item.ScannedBy?.EndsWith("(manual)") == true && item.Result != VerificationResult.Pending;
            if (!manualDecision) item.Result = line.Result;
        }

        s.SubmittedAt = clock.UtcNow;
        s.Status = VerificationSessionStatus.Submitted;
        await db.SaveChangesAsync(ct);

        bool needs = await approvals.SubmitAsync(ApprovalModule.PhysicalVerification, s.Id, s.SessionNo, 0, ct);
        if (!needs) await ApplyAsync(s, ct);
        await db.SaveChangesAsync(ct);
    }

    private async Task ApplyAsync(PhysicalVerificationSession s, CancellationToken ct)
    {
        s.Status = VerificationSessionStatus.Approved;
        s.ApprovedAt = clock.UtcNow;
        s.ApprovedBy = user.UserName;
        var ids = s.Items.Where(i => i.AssetId is not null).Select(i => i.AssetId!.Value).ToList();
        var list = await db.Assets.Where(a => ids.Contains(a.Id)).ToListAsync(ct);
        foreach (var item in s.Items.Where(i => i.AssetId is not null))
        {
            var a = list.First(x => x.Id == item.AssetId);
            switch (item.Result)
            {
                case VerificationResult.Found:
                    history.Record(a, AssetEventType.Verified, $"Physically verified in {s.SessionNo}.", "PhysicalVerification", s.Id, s.SessionNo);
                    break;
                case VerificationResult.WrongLocation:
                    if (item.FoundLocationId is { } loc && loc != a.LocationId)
                    {
                        var locBranch = await db.Locations.Where(l => l.Id == loc).Select(l => l.BranchId).FirstAsync(ct);
                        history.Record(a, AssetEventType.Verified, $"Found at a different location in {s.SessionNo}; location record corrected.", "PhysicalVerification", s.Id, s.SessionNo);
                        a.LocationId = loc;
                        a.BranchId = locBranch;
                    }
                    else history.Record(a, AssetEventType.Verified, $"Found outside the verification scope in {s.SessionNo}.", "PhysicalVerification", s.Id, s.SessionNo);
                    break;
                case VerificationResult.Missing:
                    history.Record(a, AssetEventType.Verified, $"NOT FOUND during physical verification {s.SessionNo}. Investigate before writing off.", "PhysicalVerification", s.Id, s.SessionNo);
                    break;
            }
            if (item.ConditionObserved is { } cond && cond != a.Condition && item.Result != VerificationResult.Missing)
            {
                history.Record(a, AssetEventType.Updated, $"Condition updated to {cond.DisplayName()} during verification {s.SessionNo}.", "PhysicalVerification", s.Id, s.SessionNo);
                a.Condition = cond;
            }
        }
    }

    public bool Handles(ApprovalModule module) => module == ApprovalModule.PhysicalVerification;

    public async Task OnDecidedAsync(ApprovalModule module, int entityId, bool approved, string? comments, CancellationToken ct)
    {
        var s = await db.PhysicalVerificationSessions.Include(x => x.Items).FirstAsync(x => x.Id == entityId, ct);
        if (!approved)
        {
            s.Status = VerificationSessionStatus.Open;
            s.Remarks = (s.Remarks + $"\nReturned for re-verification: {comments}").Trim();
            return;
        }
        await ApplyAsync(s, ct);
    }

    public string LinkFor(ApprovalModule module, int entityId) => $"/Verification/Details/{entityId}";

    public static Dictionary<VerificationResult, int> Summary(PhysicalVerificationSession s) =>
        Enum.GetValues<VerificationResult>().ToDictionary(r => r, r => s.Items.Count(i => i.Result == r));
}
