using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using GlobalAssetManagement.Domain.Logic;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;

namespace GlobalAssetManagement.Application.Services;

public sealed class PermissionService(IAppDbContext db, IMemoryCache cache)
{
    private const string CacheKey = "permissions:all";

    public async Task<IReadOnlyList<RolePermission>> GetAllAsync(CancellationToken ct = default)
    {
        if (cache.TryGetValue(CacheKey, out List<RolePermission>? list) && list is not null) return list;
        list = await db.RolePermissions.AsNoTracking().ToListAsync(ct);
        cache.Set(CacheKey, list, TimeSpan.FromMinutes(5));
        return list;
    }

    public async Task<bool> IsAllowedAsync(IEnumerable<string> roles, AppModule module, PermissionAction action, CancellationToken ct = default)
        => PermissionEvaluator.IsAllowed(roles, await GetAllAsync(ct), module, action);

    public async Task<List<RolePermission>> GetMatrixAsync(string role, CancellationToken ct = default)
    {
        var existing = await db.RolePermissions.Where(p => p.RoleName == role).ToListAsync(ct);
        foreach (AppModule m in Enum.GetValues<AppModule>())
            if (existing.All(e => e.Module != m)) existing.Add(new RolePermission { RoleName = role, Module = m });
        return existing.OrderBy(e => e.Module).ToList();
    }

    public async Task SaveMatrixAsync(string role, IEnumerable<RolePermission> rows, CancellationToken ct = default)
    {
        if (string.Equals(role, Roles.SuperAdministrator, StringComparison.OrdinalIgnoreCase))
            throw new BusinessException("Super Administrator always has full access and cannot be restricted.");
        var existing = await db.RolePermissions.Where(p => p.RoleName == role).ToListAsync(ct);
        foreach (var r in rows)
        {
            var e = existing.FirstOrDefault(x => x.Module == r.Module);
            if (e is null) db.RolePermissions.Add(e = new RolePermission { RoleName = role, Module = r.Module });
            e.CanView = r.CanView || r.CanCreate || r.CanEdit || r.CanApprove || r.CanDelete || r.CanExport;
            e.CanCreate = r.CanCreate;
            e.CanEdit = r.CanEdit;
            e.CanApprove = r.CanApprove;
            e.CanDelete = r.CanDelete;
            e.CanExport = r.CanExport;
        }
        await db.SaveChangesAsync(ct);
        cache.Remove(CacheKey);
    }

    public void Invalidate() => cache.Remove(CacheKey);

    /// <summary>Default permission matrix. Letters: V view, C create, E edit, A approve, D delete, X export.</summary>
    public static IEnumerable<RolePermission> Defaults()
    {
        var m = new Dictionary<string, Dictionary<AppModule, string>>
        {
            [Roles.Administrator] = Enum.GetValues<AppModule>().ToDictionary(x => x, _ => "VCEADX"),
            [Roles.AssetManager] = new()
            {
                [AppModule.Dashboard] = "V", [AppModule.Assets] = "VCEADX", [AppModule.Masters] = "VCEX",
                [AppModule.Procurement] = "VX", [AppModule.Allocation] = "VCEAX", [AppModule.Additions] = "VCEX",
                [AppModule.Maintenance] = "VCEAX", [AppModule.WarrantyAmc] = "VCEAX", [AppModule.Verification] = "VCEAX",
                [AppModule.Depreciation] = "V", [AppModule.Disposal] = "VCX", [AppModule.Reports] = "VX",
                [AppModule.Notifications] = "VE"
            },
            [Roles.PurchaseManager] = new()
            {
                [AppModule.Dashboard] = "V", [AppModule.Assets] = "VCX", [AppModule.Masters] = "VCEX",
                [AppModule.Procurement] = "VCEADX", [AppModule.WarrantyAmc] = "VCE", [AppModule.Reports] = "VX",
                [AppModule.Notifications] = "VE"
            },
            [Roles.DepartmentManager] = new()
            {
                [AppModule.Dashboard] = "V", [AppModule.Assets] = "VX", [AppModule.Procurement] = "VCA",
                [AppModule.Allocation] = "VCEA", [AppModule.Maintenance] = "VCA", [AppModule.Verification] = "VC",
                [AppModule.Disposal] = "VC", [AppModule.Reports] = "VX", [AppModule.Notifications] = "VE"
            },
            [Roles.MaintenanceTechnician] = new()
            {
                [AppModule.Dashboard] = "V", [AppModule.Assets] = "V", [AppModule.Maintenance] = "VCE",
                [AppModule.WarrantyAmc] = "V", [AppModule.Verification] = "VCE", [AppModule.Notifications] = "VE"
            },
            [Roles.FinanceUser] = new()
            {
                [AppModule.Dashboard] = "V", [AppModule.Assets] = "VX", [AppModule.Procurement] = "VAX",
                [AppModule.Additions] = "VEAX", [AppModule.Depreciation] = "VCEAX", [AppModule.Disposal] = "VEAX",
                [AppModule.WarrantyAmc] = "VAX", [AppModule.Reports] = "VX", [AppModule.FinancialReports] = "VX",
                [AppModule.Notifications] = "VE"
            },
            [Roles.Employee] = new()
            {
                [AppModule.Dashboard] = "V", [AppModule.Assets] = "V", [AppModule.Allocation] = "V",
                [AppModule.Maintenance] = "VC", [AppModule.Notifications] = "V"
            },
            [Roles.Auditor] = Enum.GetValues<AppModule>()
                .Where(x => x is not (AppModule.Users or AppModule.Settings))
                .ToDictionary(x => x, _ => "VX"),
        };
        m[Roles.Auditor][AppModule.Audit] = "VX";

        foreach (var (role, modules) in m)
            foreach (var (module, letters) in modules)
                yield return new RolePermission
                {
                    RoleName = role, Module = module,
                    CanView = letters.Contains('V'), CanCreate = letters.Contains('C'), CanEdit = letters.Contains('E'),
                    CanApprove = letters.Contains('A'), CanDelete = letters.Contains('D'), CanExport = letters.Contains('X')
                };
    }
}

/// <summary>Implemented by module services that react when an approval chain completes.</summary>
public interface IApprovalHandler
{
    bool Handles(ApprovalModule module);
    Task OnDecidedAsync(ApprovalModule module, int entityId, bool approved, string? comments, CancellationToken ct);
    string LinkFor(ApprovalModule module, int entityId);
}

public sealed record PendingApprovalItem(Approval Approval, string Link);

/// <summary>Creates approval chains from the configured approval rules and answers "who must approve what".</summary>
public sealed class ApprovalService(IAppDbContext db, ICurrentUser user, IClock clock)
{
    /// <summary>
    /// Creates pending approvals for every active rule matching the amount. Returns false when no approval is
    /// required (the caller should then treat the transaction as approved). Does not save.
    /// </summary>
    public async Task<bool> SubmitAsync(ApprovalModule module, int entityId, string? referenceNo, decimal amount, CancellationToken ct = default)
    {
        var previous = await db.Approvals.Where(a => a.Module == module && a.EntityId == entityId && a.Status == ApprovalStatus.Pending).ToListAsync(ct);
        foreach (var p in previous) p.Status = ApprovalStatus.Cancelled;

        var rules = (await db.ApprovalRules.Where(r => r.Module == module && r.IsActive).ToListAsync(ct))
            .Where(r => r.AppliesTo(amount))
            .OrderBy(r => r.Level)
            .ToList();
        if (rules.Count == 0) return false;

        foreach (var r in rules)
        {
            db.Approvals.Add(new Approval
            {
                Module = module, EntityId = entityId, ReferenceNo = referenceNo, Level = r.Level,
                ApproverRole = r.ApproverRole, Amount = amount, Status = ApprovalStatus.Pending,
                RequestedBy = user.UserName, RequestedAt = clock.UtcNow
            });
        }
        return true;
    }

    public Task<List<Approval>> HistoryAsync(ApprovalModule module, int entityId, CancellationToken ct = default) =>
        db.Approvals.AsNoTracking().Where(a => a.Module == module && a.EntityId == entityId)
            .OrderBy(a => a.RequestedAt).ThenBy(a => a.Level).ToListAsync(ct);

    public Task<bool> HasPendingAsync(ApprovalModule module, int entityId, CancellationToken ct = default) =>
        db.Approvals.AnyAsync(a => a.Module == module && a.EntityId == entityId && a.Status == ApprovalStatus.Pending, ct);

    /// <summary>Approvals the current user can act on now (lowest pending level of each chain, matching role).</summary>
    public async Task<List<Approval>> MyPendingAsync(CancellationToken ct = default)
    {
        var pending = await db.Approvals.AsNoTracking().Where(a => a.Status == ApprovalStatus.Pending).ToListAsync(ct);
        bool superAdmin = user.IsInRole(Roles.SuperAdministrator);
        return pending
            .GroupBy(a => new { a.Module, a.EntityId })
            .Select(g => g.OrderBy(a => a.Level).First())
            .Where(a => superAdmin || user.IsInRole(a.ApproverRole))
            .OrderBy(a => a.RequestedAt)
            .ToList();
    }

    public async Task<List<Approval>> AllPendingAsync(CancellationToken ct = default) =>
        await db.Approvals.AsNoTracking().Where(a => a.Status == ApprovalStatus.Pending).OrderBy(a => a.RequestedAt).ToListAsync(ct);
}

/// <summary>Records an approver's decision and notifies the owning module when the chain is complete.</summary>
public sealed class ApprovalWorkflow(IAppDbContext db, ICurrentUser user, IClock clock, IEnumerable<IApprovalHandler> handlers)
{
    public async Task<(Approval Approval, bool ChainCompleted, bool Approved)> DecideAsync(int approvalId, bool approve, string? comments, CancellationToken ct = default)
    {
        var a = await db.Approvals.FirstOrDefaultAsync(x => x.Id == approvalId, ct)
                ?? throw new BusinessException("Approval not found.");
        if (a.Status != ApprovalStatus.Pending) throw new BusinessException("This approval has already been actioned.");

        int lowest = await db.Approvals.Where(x => x.Module == a.Module && x.EntityId == a.EntityId && x.Status == ApprovalStatus.Pending)
            .MinAsync(x => x.Level, ct);
        if (a.Level != lowest) throw new BusinessException($"Level {lowest} approval must be completed first.");

        bool superAdmin = user.IsInRole(Roles.SuperAdministrator);
        if (!superAdmin && !user.IsInRole(a.ApproverRole))
            throw new UnauthorizedAccessException($"Only users in the role '{a.ApproverRole}' can action this approval.");
        if (!superAdmin && string.Equals(a.RequestedBy, user.UserName, StringComparison.OrdinalIgnoreCase))
            throw new BusinessException("You cannot approve a transaction that you submitted yourself.");
        if (!approve && string.IsNullOrWhiteSpace(comments))
            throw new BusinessException("Please enter a reason for rejection.");

        a.Status = approve ? ApprovalStatus.Approved : ApprovalStatus.Rejected;
        a.ActionedBy = user.UserName;
        a.ActionedAt = clock.UtcNow;
        a.Comments = comments;

        bool completed;
        if (!approve)
        {
            var others = await db.Approvals.Where(x => x.Module == a.Module && x.EntityId == a.EntityId && x.Status == ApprovalStatus.Pending && x.Id != a.Id).ToListAsync(ct);
            foreach (var o in others) o.Status = ApprovalStatus.Cancelled;
            completed = true;
        }
        else
        {
            completed = !await db.Approvals.AnyAsync(x => x.Module == a.Module && x.EntityId == a.EntityId && x.Status == ApprovalStatus.Pending && x.Id != a.Id, ct);
        }

        if (completed)
        {
            var handler = handlers.FirstOrDefault(h => h.Handles(a.Module))
                          ?? throw new InvalidOperationException($"No approval handler registered for {a.Module}.");
            await handler.OnDecidedAsync(a.Module, a.EntityId, approve, comments, ct);
        }
        await db.SaveChangesAsync(ct);
        return (a, completed, approve);
    }

    public string LinkFor(ApprovalModule module, int entityId) =>
        handlers.FirstOrDefault(h => h.Handles(module))?.LinkFor(module, entityId) ?? "#";
}
