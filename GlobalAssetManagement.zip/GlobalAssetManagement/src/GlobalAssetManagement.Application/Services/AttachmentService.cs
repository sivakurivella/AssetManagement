using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Application.Common.Files;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace GlobalAssetManagement.Application.Services;

public sealed record StoredFile(string StoredName, string OriginalName, string ContentType, long Size);

/// <summary>Validates and stores uploaded files outside the web root; downloads go through authorized controller actions.</summary>
public sealed class AttachmentService(IAppDbContext db, IFileStorage storage, IOptions<UploadOptions> options, AssetHistory history)
{
    public const string AssetFolder = "assets";
    public const string ImageFolder = "asset-images";
    public const string GeneralFolder = "attachments";
    public const string VerificationFolder = "verification";

    private long MaxBytes => Math.Max(1, options.Value.MaxFileSizeMb) * 1024L * 1024L;

    public async Task<StoredFile> StoreAsync(IFormFile file, string folder, IReadOnlyCollection<string> allowed, CancellationToken ct = default)
    {
        var header = new byte[16];
        int read;
        await using (var s = file.OpenReadStream())
            read = await s.ReadAsync(header.AsMemory(0, header.Length), ct);

        var check = UploadValidator.Validate(file.FileName, file.Length, header.AsSpan(0, read), allowed, MaxBytes);
        if (!check.Ok) throw new BusinessException($"{Path.GetFileName(file.FileName)}: {check.Error}");

        string ext = Path.GetExtension(file.FileName).ToLowerInvariant();
        await using var stream = file.OpenReadStream();
        string stored = await storage.SaveAsync(stream, folder, ext, ct);
        string original = Path.GetFileName(file.FileName.Replace('\\', '/'));
        if (original.Length > 200) original = original[^200..];
        return new StoredFile(stored, original, UploadValidator.ContentTypeFor(ext), file.Length);
    }

    public async Task<AssetDocument> AddAssetDocumentAsync(Asset asset, IFormFile file, AssetDocumentType type, string? description, CancellationToken ct = default)
    {
        var f = await StoreAsync(file, AssetFolder, UploadValidator.DocumentExtensions, ct);
        var doc = new AssetDocument
        {
            AssetId = asset.Id, DocumentType = type, OriginalFileName = f.OriginalName, StoredFileName = f.StoredName,
            ContentType = f.ContentType, SizeBytes = f.Size, Description = description
        };
        db.AssetDocuments.Add(doc);
        history.Record(asset, AssetEventType.DocumentAdded, $"{type.DisplayName()} uploaded: {f.OriginalName}", "AssetDocument");
        await db.SaveChangesAsync(ct);
        return doc;
    }

    public async Task<AssetImage> AddAssetImageAsync(Asset asset, IFormFile file, string? caption, CancellationToken ct = default)
    {
        var f = await StoreAsync(file, ImageFolder, UploadValidator.ImageExtensions, ct);
        bool first = !await db.AssetImages.AnyAsync(i => i.AssetId == asset.Id, ct);
        var img = new AssetImage
        {
            AssetId = asset.Id, OriginalFileName = f.OriginalName, StoredFileName = f.StoredName,
            ContentType = f.ContentType, SizeBytes = f.Size, Caption = caption, IsPrimary = first
        };
        db.AssetImages.Add(img);
        history.Record(asset, AssetEventType.DocumentAdded, $"Photograph uploaded: {f.OriginalName}", "AssetImage");
        await db.SaveChangesAsync(ct);
        return img;
    }

    public async Task<Attachment> AddAttachmentAsync(string entityName, int entityId, IFormFile file, string? description, CancellationToken ct = default)
    {
        var f = await StoreAsync(file, GeneralFolder, UploadValidator.DocumentExtensions, ct);
        var a = new Attachment
        {
            EntityName = entityName, EntityId = entityId, OriginalFileName = f.OriginalName, StoredFileName = f.StoredName,
            ContentType = f.ContentType, SizeBytes = f.Size, Description = description
        };
        db.Attachments.Add(a);
        await db.SaveChangesAsync(ct);
        return a;
    }

    public Task<List<Attachment>> ListAsync(string entityName, int entityId, CancellationToken ct = default) =>
        db.Attachments.AsNoTracking().Where(a => a.EntityName == entityName && a.EntityId == entityId).OrderBy(a => a.CreatedAt).ToListAsync(ct);

    public Stream? Open(string folder, string storedName) => storage.OpenRead(folder, storedName);

    public async Task DeleteAttachmentAsync(int id, CancellationToken ct = default)
    {
        var a = await db.Attachments.FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new BusinessException("Attachment not found.");
        db.Attachments.Remove(a);
        await db.SaveChangesAsync(ct);
        storage.Delete(GeneralFolder, a.StoredFileName);
    }
}
