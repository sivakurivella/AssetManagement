using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Application.Models;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using GlobalAssetManagement.Domain.Logic;
using Microsoft.EntityFrameworkCore;

namespace GlobalAssetManagement.Application.Services;

public sealed record DisposalPreview(decimal GrossCost, decimal AccumulatedNow, decimal CatchUpDepreciation, decimal BookValue, decimal DisposalValue, decimal ProfitOrLoss);

public sealed class DisposalService(
    IAppDbContext db,
    NumberingService numbering,
    ApprovalService approvals,
    DepreciationService depreciation,
    AssetHistory history,
    ICurrentUser user,
    IClock clock) : IApprovalHandler
{
    public async Task<AssetDisposal> RequestAsync(DisposalInput input, CancellationToken ct = default)
    {
        var asset = await db.Assets.FirstOrDefaultAsync(a => a.Id == input.AssetId, ct) ?? throw new BusinessException("Asset not found.");
        user.EnsureCanSee(asset);
        if (asset.Status is AssetStatus.Disposed or AssetStatus.LostOrWrittenOff) throw new BusinessException("This asset has already been disposed of.");
        if (await db.AssetDisposals.AnyAsync(d => d.AssetId == asset.Id && d.Status != DisposalStatus.Rejected && d.Status != DisposalStatus.Completed, ct))
            throw new BusinessException("A disposal request for this asset is already in progress.");

        string no = await numbering.NextDocumentNoAsync("DSP", ct);
        var d = new AssetDisposal
        {
            DisposalNo = no, AssetId = asset.Id, RequestDate = clock.Today, ProposedDisposalDate = input.ProposedDisposalDate.Date,
            Method = input.Method, Reason = input.Reason.Trim(), ExpectedValue = DisposalCalculator.HasProceeds(input.Method) ? input.ExpectedValue : 0,
            BuyerOrRecipient = input.BuyerOrRecipient, Status = DisposalStatus.Requested,
            GrossCostAtDisposal = asset.GrossCost, AccumulatedDepreciationAtDisposal = asset.AccumulatedDepreciation, BookValueAtDisposal = asset.CurrentBookValue
        };
        db.AssetDisposals.Add(d);
        await db.SaveChangesAsync(ct);

        bool needs = await approvals.SubmitAsync(ApprovalModule.AssetDisposal, d.Id, no, asset.CurrentBookValue, ct);
        d.Status = needs ? DisposalStatus.PendingApproval : DisposalStatus.Approved;
        history.Record(asset, AssetEventType.Disposed, $"Disposal requested ({input.Method.DisplayName()}) under {no}: {d.Reason}", "AssetDisposal", d.Id, no);
        await db.SaveChangesAsync(ct);
        return d;
    }

    public async Task<DisposalPreview> PreviewAsync(int disposalId, DateTime disposalDate, decimal disposalValue, CancellationToken ct = default)
    {
        var d = await db.AssetDisposals.AsNoTracking().Include(x => x.Asset).FirstOrDefaultAsync(x => x.Id == disposalId, ct) ?? throw new BusinessException("Disposal not found.");
        var a = d.Asset!;
        decimal catchUp = 0;
        var to = disposalDate.Date.AddDays(-1);
        var from = a.DepreciatedUpTo is { } up ? up.AddDays(1) : (a.DepreciationStartDate ?? a.PurchaseDate ?? a.CreatedAt).Date;
        if (a.DepreciationMethod != DepreciationMethod.None && to >= from)
        {
            var adds = await db.AssetAdditions.AsNoTracking().Where(x => x.AssetId == a.Id && x.Status == AdditionStatus.Capitalized && x.CapitalizationDate != null).ToListAsync(ct);
            catchUp = DepreciationService.Calculate(a, from, to, adds)?.Result.Amount ?? 0;
        }
        decimal value = DisposalCalculator.HasProceeds(d.Method) ? disposalValue : 0;
        decimal book = a.GrossCost - a.AccumulatedDepreciation - catchUp;
        return new DisposalPreview(a.GrossCost, a.AccumulatedDepreciation, catchUp, book, value, DisposalCalculator.ProfitOrLoss(value, book));
    }

    public async Task<AssetDisposal> CompleteAsync(CompleteDisposalInput input, CancellationToken ct = default)
    {
        var d = await db.AssetDisposals.Include(x => x.Asset).FirstOrDefaultAsync(x => x.Id == input.Id, ct) ?? throw new BusinessException("Disposal not found.");
        if (d.IsLocked || d.Status == DisposalStatus.Completed) throw new BusinessException("This disposal is completed and locked.");
        if (d.Status != DisposalStatus.Approved) throw new BusinessException("The disposal must be approved before it can be completed.");
        var a = d.Asset!;
        user.EnsureCanSee(a);
        var date = input.DisposalDate.Date;
        if (date > clock.Today) throw new BusinessException("Disposal date cannot be in the future.");
        if (a.DepreciatedUpTo is { } up && date <= up)
            throw new BusinessException($"Depreciation is posted up to {up:dd-MM-yyyy}; the disposal date must be after that date (reverse the depreciation run if needed).");
        if (a.PurchaseDate is { } pd && date < pd) throw new BusinessException("Disposal date cannot be before the purchase date.");

        var tx = db.Database.IsRelational() ? await db.Database.BeginTransactionAsync(ct) : null;
        try
        {
            await depreciation.CatchUpForDisposalAsync(a, date, ct);

            decimal value = DisposalCalculator.HasProceeds(d.Method) ? input.DisposalValue : 0;
            d.DisposalDate = date;
            d.DisposalValue = value;
            d.BuyerOrRecipient = input.BuyerOrRecipient ?? d.BuyerOrRecipient;
            d.SaleInvoiceNo = input.SaleInvoiceNo;
            d.Remarks = input.Remarks;
            d.GrossCostAtDisposal = a.GrossCost;
            d.AccumulatedDepreciationAtDisposal = a.AccumulatedDepreciation;
            d.BookValueAtDisposal = a.GrossCost - a.AccumulatedDepreciation;
            d.ProfitOrLoss = DisposalCalculator.ProfitOrLoss(value, d.BookValueAtDisposal);
            d.Status = DisposalStatus.Completed;
            d.CompletedAt = clock.UtcNow;
            d.CompletedBy = user.UserName;
            d.IsLocked = true;

            history.ChangeStatus(a, DisposalCalculator.FinalAssetStatus(d.Method),
                $"{d.Method.DisplayName()} completed under {d.DisposalNo}. Book value {d.BookValueAtDisposal:N2}, proceeds {value:N2}, {(d.ProfitOrLoss >= 0 ? "profit" : "loss")} {Math.Abs(d.ProfitOrLoss):N2}.",
                "AssetDisposal", d.Id, d.DisposalNo);
            a.CurrentBookValue = 0;
            a.AssignedEmployeeId = null;

            foreach (var al in await db.AssetAllocations.Where(x => x.AssetId == a.Id && x.Status == AllocationStatus.Active).ToListAsync(ct))
            {
                al.Status = AllocationStatus.Returned;
                db.AssetReturns.Add(new AssetReturn
                {
                    AllocationId = al.Id, AssetId = a.Id, ReturnDate = clock.UtcNow, ReturnedByEmployeeId = al.EmployeeId, ReceivedBy = user.UserName,
                    ReturnCondition = a.Condition, Remarks = $"Closed by disposal {d.DisposalNo}"
                });
            }
            foreach (var s in await db.MaintenanceSchedules.Where(x => x.AssetId == a.Id && x.IsActive).ToListAsync(ct)) s.IsActive = false;

            await db.SaveChangesAsync(ct);
            if (tx is not null) await tx.CommitAsync(ct);
        }
        catch
        {
            if (tx is not null) await tx.RollbackAsync(ct);
            throw;
        }
        finally
        {
            if (tx is not null) await tx.DisposeAsync();
        }
        return d;
    }

    public bool Handles(ApprovalModule module) => module == ApprovalModule.AssetDisposal;

    public async Task OnDecidedAsync(ApprovalModule module, int entityId, bool approved, string? comments, CancellationToken ct)
    {
        var d = await db.AssetDisposals.FirstAsync(x => x.Id == entityId, ct);
        if (d.IsLocked) return;
        d.Status = approved ? DisposalStatus.Approved : DisposalStatus.Rejected;
        if (!approved) d.Remarks = $"Rejected: {comments}";
    }

    public string LinkFor(ApprovalModule module, int entityId) => $"/Disposals/Details/{entityId}";
}
