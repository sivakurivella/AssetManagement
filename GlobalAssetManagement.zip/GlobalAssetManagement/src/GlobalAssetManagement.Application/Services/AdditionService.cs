using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Application.Models;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace GlobalAssetManagement.Application.Services;

/// <summary>
/// Subsequent expenditure on an asset. Nothing is capitalized automatically: an authorized user classifies each
/// addition as a capital improvement or a revenue (repair) expense under the organization's accounting policy.
/// </summary>
public sealed class AdditionService(
    IAppDbContext db,
    NumberingService numbering,
    ApprovalService approvals,
    AssetHistory history,
    ICurrentUser user) : IApprovalHandler
{
    public async Task<AssetAddition> CreateAsync(AdditionInput input, CancellationToken ct = default)
    {
        var asset = await db.Assets.AsNoTracking().FirstOrDefaultAsync(a => a.Id == input.AssetId, ct) ?? throw new BusinessException("Asset not found.");
        user.EnsureCanSee(asset);
        if (asset.Status is AssetStatus.Disposed or AssetStatus.LostOrWrittenOff)
            throw new BusinessException("Additions cannot be recorded against a disposed asset.");

        string no = await numbering.NextDocumentNoAsync("ADD", ct);
        var add = new AssetAddition
        {
            AdditionNo = no, AssetId = asset.Id, AdditionDate = input.AdditionDate.Date, Description = input.Description.Trim(),
            VendorId = input.VendorId, InvoiceNumber = input.InvoiceNumber, InvoiceDate = input.InvoiceDate, Cost = input.Cost,
            TaxAmount = input.TaxAmount, GstInputCreditClaimed = input.GstInputCreditClaimed, Remarks = input.Remarks,
            Status = AdditionStatus.Pending, ExpenditureType = ExpenditureType.Unclassified
        };
        db.AssetAdditions.Add(add);
        await db.SaveChangesAsync(ct);
        return add;
    }

    public async Task ClassifyAsync(ClassifyAdditionInput input, CancellationToken ct = default)
    {
        var add = await db.AssetAdditions.Include(a => a.Asset).FirstOrDefaultAsync(a => a.Id == input.Id, ct) ?? throw new BusinessException("Addition not found.");
        if (add.Status is not (AdditionStatus.Pending or AdditionStatus.Rejected))
            throw new BusinessException("This addition has already been classified.");
        if (input.ExpenditureType == ExpenditureType.Unclassified) throw new BusinessException("Choose a classification.");

        add.ExpenditureType = input.ExpenditureType;
        add.ClassifiedBy = user.UserName;
        if (!string.IsNullOrWhiteSpace(input.Remarks)) add.Remarks = input.Remarks;

        if (input.ExpenditureType == ExpenditureType.RevenueExpense)
        {
            add.Status = AdditionStatus.Expensed;
            history.Record(add.Asset!, AssetEventType.Updated, $"Expenditure {add.AdditionNo} of {add.Cost:N2} treated as revenue expense (not capitalized).",
                "AssetAddition", add.Id, add.AdditionNo);
            await db.SaveChangesAsync(ct);
            return;
        }

        var capDate = (input.CapitalizationDate ?? add.AdditionDate).Date;
        if (add.Asset!.DepreciatedUpTo is { } upTo && capDate <= upTo.Date)
            throw new BusinessException($"Depreciation has already been posted up to {upTo:dd-MM-yyyy}. The capitalization date must be after that date.");
        add.CapitalizationDate = capDate;
        add.RevisedUsefulLifeYears = input.RevisedUsefulLifeYears;

        bool needs = await approvals.SubmitAsync(ApprovalModule.AssetAddition, add.Id, add.AdditionNo, add.CapitalizableAmount, ct);
        if (needs) add.Status = AdditionStatus.PendingApproval;
        else Capitalize(add, add.Asset!);
        await db.SaveChangesAsync(ct);
    }

    private void Capitalize(AssetAddition add, Asset asset)
    {
        add.PreviousGrossCost = asset.GrossCost;
        add.PreviousUsefulLifeYears = asset.UsefulLifeYears;
        asset.CapitalizedAdditions += add.CapitalizableAmount;
        if (add.RevisedUsefulLifeYears is { } life && life > 0) asset.UsefulLifeYears = life;
        asset.CurrentBookValue = asset.GrossCost - asset.AccumulatedDepreciation;
        add.RevisedGrossCost = asset.GrossCost;
        add.Status = AdditionStatus.Capitalized;
        history.Record(asset, AssetEventType.AdditionCapitalized,
            $"Capital addition {add.AdditionNo} of {add.CapitalizableAmount:N2} capitalized on {add.CapitalizationDate:dd-MM-yyyy}. Gross cost {add.PreviousGrossCost:N2} → {add.RevisedGrossCost:N2}." +
            (add.RevisedUsefulLifeYears is { } l ? $" Useful life revised to {l:0.##} years." : ""),
            "AssetAddition", add.Id, add.AdditionNo);
    }

    public bool Handles(ApprovalModule module) => module == ApprovalModule.AssetAddition;

    public async Task OnDecidedAsync(ApprovalModule module, int entityId, bool approved, string? comments, CancellationToken ct)
    {
        var add = await db.AssetAdditions.Include(a => a.Asset).FirstAsync(a => a.Id == entityId, ct);
        if (!approved)
        {
            add.Status = AdditionStatus.Rejected;
            add.Remarks = $"Rejected: {comments}";
            return;
        }
        if (add.Asset!.DepreciatedUpTo is { } upTo && add.CapitalizationDate <= upTo)
            add.CapitalizationDate = upTo.AddDays(1);
        Capitalize(add, add.Asset!);
    }

    public string LinkFor(ApprovalModule module, int entityId) => $"/Additions/Details/{entityId}";
}
