using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Application.Models;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using GlobalAssetManagement.Domain.Logic;
using Microsoft.EntityFrameworkCore;

namespace GlobalAssetManagement.Application.Services;

/// <summary>Service requests, the 13-step repair workflow, work orders and preventive maintenance schedules.</summary>
public sealed class MaintenanceService(
    IAppDbContext db,
    NumberingService numbering,
    ApprovalService approvals,
    AssetHistory history,
    IUserDirectory users,
    ICurrentUser user,
    IClock clock) : IApprovalHandler
{
    // ------------------------------------------------------------------ service requests

    public async Task<ServiceRequest> CreateRequestAsync(ServiceRequestInput input, CancellationToken ct = default)
    {
        var asset = await db.Assets.FirstOrDefaultAsync(a => a.Id == input.AssetId, ct) ?? throw new BusinessException("Asset not found.");
        user.EnsureCanSee(asset);
        if (asset.Status is AssetStatus.Disposed or AssetStatus.LostOrWrittenOff)
            throw new BusinessException("Service requests cannot be raised for disposed assets.");
        if (await db.ServiceRequests.AnyAsync(s => s.AssetId == asset.Id && s.ProblemCategory == input.ProblemCategory
                && s.Status != ServiceRequestStatus.Closed && s.Status != ServiceRequestStatus.Cancelled && s.Status != ServiceRequestStatus.Rejected, ct))
            throw new BusinessException("An open service request for the same problem already exists for this asset.");

        string no = await numbering.NextDocumentNoAsync("SR", ct);
        var sr = new ServiceRequest
        {
            TicketNo = no, AssetId = asset.Id, RequestedAt = clock.UtcNow,
            RequestedByEmployeeId = input.RequestedByEmployeeId ?? user.EmployeeId, RequestedByUser = user.UserName,
            DepartmentId = asset.DepartmentId, LocationId = asset.LocationId, ProblemCategory = input.ProblemCategory,
            FaultDescription = input.FaultDescription.Trim(), Priority = input.Priority, RequestedServiceDate = input.RequestedServiceDate,
            AssetDown = input.AssetDown, DownSince = input.AssetDown ? clock.UtcNow : null,
            Status = ServiceRequestStatus.Submitted, ApprovalStatus = ApprovalStatus.Pending
        };
        db.ServiceRequests.Add(sr);
        if (input.AssetDown && asset.Condition != AssetCondition.NotWorking)
            asset.Condition = AssetCondition.NotWorking;
        history.Record(asset, AssetEventType.ServiceRequest, $"Service request {no} raised ({input.Priority.DisplayName()}): {sr.FaultDescription}", "ServiceRequest", null, no);
        await db.SaveChangesAsync(ct);
        return sr;
    }

    private async Task<ServiceRequest> LoadRequestAsync(int id, CancellationToken ct)
    {
        var sr = await db.ServiceRequests.Include(s => s.Asset).Include(s => s.WorkOrders).FirstOrDefaultAsync(s => s.Id == id, ct)
                 ?? throw new BusinessException("Service request not found.");
        user.EnsureCanSee(sr.Asset!);
        return sr;
    }

    private void Move(ServiceRequest sr, ServiceRequestStatus to)
    {
        ServiceRequestWorkflow.EnsureTransition(sr.Status, to);
        sr.Status = to;
    }

    public async Task ReviewAsync(int id, string? remarks, CancellationToken ct = default)
    {
        var sr = await LoadRequestAsync(id, ct);
        Move(sr, ServiceRequestStatus.UnderReview);
        sr.ReviewedBy = user.UserName;
        sr.ReviewedAt = clock.UtcNow;
        sr.ReviewRemarks = remarks;
        await db.SaveChangesAsync(ct);
    }

    public async Task DecideRequestAsync(int id, bool approve, string? remarks, CancellationToken ct = default)
    {
        var sr = await LoadRequestAsync(id, ct);
        if (!approve && string.IsNullOrWhiteSpace(remarks)) throw new BusinessException("Enter the reason for rejecting the request.");
        Move(sr, approve ? ServiceRequestStatus.Approved : ServiceRequestStatus.Rejected);
        sr.ApprovalStatus = approve ? ApprovalStatus.Approved : ApprovalStatus.Rejected;
        sr.ReviewedBy = user.UserName;
        sr.ReviewedAt = clock.UtcNow;
        sr.ReviewRemarks = remarks ?? sr.ReviewRemarks;
        if (approve)
            history.ChangeStatus(sr.Asset!, AssetStatus.UnderRepair, $"Repair approved under {sr.TicketNo}", "ServiceRequest", sr.Id, sr.TicketNo);
        else
            history.Record(sr.Asset!, AssetEventType.ServiceRequest, $"Service request {sr.TicketNo} rejected: {remarks}", "ServiceRequest", sr.Id, sr.TicketNo);
        await db.SaveChangesAsync(ct);
    }

    public async Task<WorkOrder> AssignAsync(int requestId, WorkOrderInput input, CancellationToken ct = default)
    {
        var sr = await LoadRequestAsync(requestId, ct);
        Move(sr, ServiceRequestStatus.TechnicianAssigned);
        if (string.IsNullOrWhiteSpace(input.TechnicianUserId) && string.IsNullOrWhiteSpace(input.TechnicianName) && input.ServiceProviderId is null)
            throw new BusinessException("Select a technician or a service provider.");
        input.AssetId = sr.AssetId;
        input.ServiceRequestId = sr.Id;
        input.WorkType = WorkType.Breakdown;
        input.Priority = sr.Priority;
        if (string.IsNullOrWhiteSpace(input.Title)) input.Title = $"Repair: {Truncate(sr.FaultDescription, 250)}";
        var wo = await CreateWorkOrderInternalAsync(input, sr.Asset!, ct);
        await db.SaveChangesAsync(ct);
        return wo;
    }

    public async Task DiagnoseAsync(int workOrderId, string diagnosis, string? spareParts, CancellationToken ct = default)
    {
        var wo = await LoadWorkOrderAsync(workOrderId, ct);
        EnsureOpen(wo);
        if (string.IsNullOrWhiteSpace(diagnosis)) throw new BusinessException("Enter the diagnosis.");
        wo.Diagnosis = diagnosis.Trim();
        wo.SparePartsRequired = spareParts;
        if (wo.ServiceRequest is { } sr && sr.Status == ServiceRequestStatus.TechnicianAssigned) Move(sr, ServiceRequestStatus.Diagnosed);
        await db.SaveChangesAsync(ct);
    }

    public async Task<RepairEstimate> SubmitEstimateAsync(EstimateInput input, CancellationToken ct = default)
    {
        var sr = await LoadRequestAsync(input.ServiceRequestId, ct);
        Move(sr, ServiceRequestStatus.EstimateSubmitted);
        var est = new RepairEstimate
        {
            ServiceRequestId = sr.Id, EstimateDate = clock.UtcNow, ServiceProviderId = input.ServiceProviderId,
            LabourCharges = input.LabourCharges, PartsCost = input.PartsCost, TravelCharges = input.TravelCharges,
            OtherCharges = input.OtherCharges, TaxAmount = input.TaxAmount,
            TotalAmount = RepairCostCalculator.Total(input.LabourCharges, input.PartsCost, input.TravelCharges, input.OtherCharges, input.TaxAmount),
            Details = input.Details, Status = ApprovalStatus.Pending
        };
        db.RepairEstimates.Add(est);
        await db.SaveChangesAsync(ct);

        bool needs = await approvals.SubmitAsync(ApprovalModule.RepairEstimate, est.Id, sr.TicketNo, est.TotalAmount, ct);
        if (!needs)
        {
            est.Status = ApprovalStatus.Approved;
            est.DecidedAt = clock.UtcNow;
            est.DecidedBy = "Auto (within approval limit)";
            Move(sr, ServiceRequestStatus.EstimateApproved);
        }
        await db.SaveChangesAsync(ct);
        return est;
    }

    public async Task MarkAwaitingPartsAsync(int requestId, CancellationToken ct = default)
    {
        var sr = await LoadRequestAsync(requestId, ct);
        Move(sr, ServiceRequestStatus.AwaitingParts);
        foreach (var wo in sr.WorkOrders.Where(w => w.IsOpen)) wo.Status = WorkOrderStatus.OnHold;
        await db.SaveChangesAsync(ct);
    }

    public async Task CancelRequestAsync(int requestId, string reason, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(reason)) throw new BusinessException("Enter the reason for cancellation.");
        var sr = await LoadRequestAsync(requestId, ct);
        Move(sr, ServiceRequestStatus.Cancelled);
        sr.ReviewRemarks = $"Cancelled: {reason}";
        foreach (var wo in sr.WorkOrders.Where(w => w.IsOpen)) wo.Status = WorkOrderStatus.Cancelled;
        if (sr.Asset!.Status == AssetStatus.UnderRepair)
            history.ChangeStatus(sr.Asset, AssetStatus.InService, $"Service request {sr.TicketNo} cancelled", "ServiceRequest", sr.Id, sr.TicketNo);
        await db.SaveChangesAsync(ct);
    }

    public async Task ConfirmAsync(int requestId, bool satisfied, int? rating, string? feedback, CancellationToken ct = default)
    {
        var sr = await LoadRequestAsync(requestId, ct);
        bool isRequester = string.Equals(sr.RequestedByUser, user.UserName, StringComparison.OrdinalIgnoreCase)
                           || (sr.RequestedByEmployeeId is not null && sr.RequestedByEmployeeId == user.EmployeeId);
        bool isManager = user.IsInRole(Roles.SuperAdministrator) || user.IsInRole(Roles.Administrator) || user.IsInRole(Roles.AssetManager) || user.IsInRole(Roles.DepartmentManager);
        if (!isRequester && !isManager) throw new UnauthorizedAccessException("Only the requester or a manager can confirm the repair.");

        if (!satisfied)
        {
            Move(sr, ServiceRequestStatus.InProgress);
            foreach (var wo in sr.WorkOrders.Where(w => w.Status is WorkOrderStatus.Completed or WorkOrderStatus.Verified))
            {
                wo.Status = WorkOrderStatus.InProgress;
                wo.QualityPassed = null;
            }
            history.ChangeStatus(sr.Asset!, AssetStatus.UnderRepair, $"Repair not accepted by user: {feedback}", "ServiceRequest", sr.Id, sr.TicketNo);
        }
        else
        {
            Move(sr, ServiceRequestStatus.UserConfirmed);
            sr.ConfirmedAt = clock.UtcNow;
            sr.ConfirmedBy = user.UserName;
        }
        sr.FeedbackRating = rating is >= 1 and <= 5 ? rating : null;
        sr.Feedback = feedback;
        await db.SaveChangesAsync(ct);
    }

    public async Task CloseRequestAsync(int requestId, CancellationToken ct = default)
    {
        var sr = await LoadRequestAsync(requestId, ct);
        Move(sr, ServiceRequestStatus.Closed);
        sr.ClosedAt = clock.UtcNow;
        foreach (var wo in sr.WorkOrders.Where(w => w.Status is WorkOrderStatus.Completed or WorkOrderStatus.Verified))
            wo.Status = WorkOrderStatus.Closed;
        history.Record(sr.Asset!, AssetEventType.ServiceRequest, $"Service request {sr.TicketNo} closed.", "ServiceRequest", sr.Id, sr.TicketNo);
        await db.SaveChangesAsync(ct);
    }

    // ------------------------------------------------------------------ work orders

    public async Task<WorkOrder> CreateWorkOrderAsync(WorkOrderInput input, CancellationToken ct = default)
    {
        var asset = await db.Assets.FirstOrDefaultAsync(a => a.Id == input.AssetId, ct) ?? throw new BusinessException("Asset not found.");
        user.EnsureCanSee(asset);
        var wo = await CreateWorkOrderInternalAsync(input, asset, ct);
        await db.SaveChangesAsync(ct);
        return wo;
    }

    private async Task<WorkOrder> CreateWorkOrderInternalAsync(WorkOrderInput input, Asset asset, CancellationToken ct)
    {
        string? techName = input.TechnicianName;
        if (!string.IsNullOrWhiteSpace(input.TechnicianUserId))
        {
            var tech = await users.FindAsync(input.TechnicianUserId!, ct) ?? throw new BusinessException("Technician not found.");
            techName ??= tech.FullName ?? tech.UserName;
        }
        string no = await numbering.NextDocumentNoAsync("WO", ct);
        var wo = new WorkOrder
        {
            WorkOrderNo = no, AssetId = asset.Id, ServiceRequestId = input.ServiceRequestId, WorkType = input.WorkType,
            Priority = input.Priority, Title = input.Title.Trim(), TechnicianUserId = input.TechnicianUserId, TechnicianName = techName,
            ServiceProviderId = input.ServiceProviderId, DueDate = input.DueDate,
            AssignedAt = techName is not null || input.ServiceProviderId is not null ? clock.UtcNow : null,
            Status = techName is not null || input.ServiceProviderId is not null ? WorkOrderStatus.Assigned : WorkOrderStatus.Open
        };
        db.WorkOrders.Add(wo);
        history.Record(asset, AssetEventType.WorkOrder, $"Work order {no} created ({input.WorkType.DisplayName()}){(techName is null ? "" : $", assigned to {techName}")}.", "WorkOrder", null, no);
        return wo;
    }

    public async Task<WorkOrder> LoadWorkOrderAsync(int id, CancellationToken ct = default)
    {
        var wo = await db.WorkOrders.Include(w => w.Asset).Include(w => w.ServiceRequest).Include(w => w.Labour).Include(w => w.Parts)
                     .Include(w => w.MaintenanceSchedule).FirstOrDefaultAsync(w => w.Id == id, ct)
                 ?? throw new BusinessException("Work order not found.");
        user.EnsureCanSee(wo.Asset!);
        return wo;
    }

    private static void EnsureOpen(WorkOrder wo)
    {
        if (wo.Status is WorkOrderStatus.Completed or WorkOrderStatus.Verified or WorkOrderStatus.Closed or WorkOrderStatus.Cancelled)
            throw new BusinessException($"Work order {wo.WorkOrderNo} is {wo.Status.DisplayName()} and cannot be changed.");
    }

    public async Task AssignTechnicianAsync(int workOrderId, string? technicianUserId, string? technicianName, int? serviceProviderId, CancellationToken ct = default)
    {
        var wo = await LoadWorkOrderAsync(workOrderId, ct);
        EnsureOpen(wo);
        if (!string.IsNullOrWhiteSpace(technicianUserId))
        {
            var tech = await users.FindAsync(technicianUserId, ct) ?? throw new BusinessException("Technician not found.");
            technicianName ??= tech.FullName ?? tech.UserName;
        }
        wo.TechnicianUserId = technicianUserId;
        wo.TechnicianName = technicianName;
        wo.ServiceProviderId = serviceProviderId;
        wo.AssignedAt = clock.UtcNow;
        if (wo.Status == WorkOrderStatus.Open) wo.Status = WorkOrderStatus.Assigned;
        await db.SaveChangesAsync(ct);
    }

    public async Task StartWorkAsync(int workOrderId, CancellationToken ct = default)
    {
        var wo = await LoadWorkOrderAsync(workOrderId, ct);
        EnsureOpen(wo);
        if (wo.ServiceRequest is { } sr)
        {
            if (sr.Status is ServiceRequestStatus.EstimateSubmitted)
                throw new BusinessException("The repair estimate is awaiting approval.");
            if (sr.Status != ServiceRequestStatus.InProgress) Move(sr, ServiceRequestStatus.InProgress);
        }
        wo.Status = WorkOrderStatus.InProgress;
        wo.WorkStartedAt ??= clock.UtcNow;
        var target = wo.WorkType == WorkType.Breakdown ? AssetStatus.UnderRepair : AssetStatus.UnderMaintenance;
        history.ChangeStatus(wo.Asset!, target, $"Work started on {wo.WorkOrderNo}", "WorkOrder", wo.Id, wo.WorkOrderNo);
        await db.SaveChangesAsync(ct);
    }

    public async Task AddLabourAsync(int workOrderId, WorkOrderLabour line, CancellationToken ct = default)
    {
        var wo = await LoadWorkOrderAsync(workOrderId, ct);
        EnsureOpen(wo);
        if (line.Hours <= 0) throw new BusinessException("Hours must be greater than zero.");
        if (string.IsNullOrWhiteSpace(line.TechnicianName)) line.TechnicianName = wo.TechnicianName ?? user.UserName;
        line.Amount = RepairCostCalculator.Line(line.Hours, line.RatePerHour);
        line.WorkOrderId = wo.Id;
        if (line.WorkDate == default) line.WorkDate = clock.Today;
        wo.Labour.Add(line);
        RecalculateCosts(wo);
        await db.SaveChangesAsync(ct);
    }

    public async Task AddPartAsync(int workOrderId, WorkOrderPart part, CancellationToken ct = default)
    {
        var wo = await LoadWorkOrderAsync(workOrderId, ct);
        EnsureOpen(wo);
        if (part.Quantity <= 0) throw new BusinessException("Quantity must be greater than zero.");
        if (string.IsNullOrWhiteSpace(part.PartName)) throw new BusinessException("Enter the part name.");
        part.Amount = RepairCostCalculator.Line(part.Quantity, part.UnitCost);
        part.WorkOrderId = wo.Id;
        wo.Parts.Add(part);
        RecalculateCosts(wo);
        await db.SaveChangesAsync(ct);
    }

    public async Task RemoveLineAsync(int workOrderId, int? labourId, int? partId, CancellationToken ct = default)
    {
        var wo = await LoadWorkOrderAsync(workOrderId, ct);
        EnsureOpen(wo);
        if (labourId is { } l && wo.Labour.FirstOrDefault(x => x.Id == l) is { } lab) { wo.Labour.Remove(lab); db.WorkOrderLabour.Remove(lab); }
        if (partId is { } p && wo.Parts.FirstOrDefault(x => x.Id == p) is { } part) { wo.Parts.Remove(part); db.WorkOrderParts.Remove(part); }
        RecalculateCosts(wo);
        await db.SaveChangesAsync(ct);
    }

    private static void RecalculateCosts(WorkOrder wo)
    {
        wo.LabourCharges = wo.Labour.Sum(x => x.Amount);
        wo.PartsCost = wo.Parts.Sum(x => x.Amount);
        wo.TotalCost = RepairCostCalculator.Total(wo.LabourCharges, wo.PartsCost, wo.TravelCharges, wo.OtherExpenses, wo.TaxAmount);
    }

    public async Task SubmitForTestingAsync(int workOrderId, CancellationToken ct = default)
    {
        var wo = await LoadWorkOrderAsync(workOrderId, ct);
        if (wo.Status != WorkOrderStatus.InProgress) throw new BusinessException("Start the work before sending it for testing.");
        if (wo.ServiceRequest is { } sr) Move(sr, ServiceRequestStatus.Testing);
        wo.QualityPassed = null;
        await db.SaveChangesAsync(ct);
    }

    public async Task RecordQualityCheckAsync(int workOrderId, bool passed, string? remarks, CancellationToken ct = default)
    {
        var wo = await LoadWorkOrderAsync(workOrderId, ct);
        if (wo.Status != WorkOrderStatus.InProgress) throw new BusinessException("Quality checks are recorded while work is in progress.");
        if (!passed && string.IsNullOrWhiteSpace(remarks)) throw new BusinessException("Describe why the quality check failed.");
        wo.QualityPassed = passed;
        wo.QualityRemarks = remarks;
        wo.VerifiedBy = user.UserName;
        wo.VerifiedAt = clock.UtcNow;
        if (!passed && wo.ServiceRequest is { Status: ServiceRequestStatus.Testing } sr) Move(sr, ServiceRequestStatus.InProgress);
        await db.SaveChangesAsync(ct);
    }

    public async Task CompleteWorkAsync(WorkOrderCompletionInput input, CancellationToken ct = default)
    {
        var wo = await LoadWorkOrderAsync(input.WorkOrderId, ct);
        if (wo.Status != WorkOrderStatus.InProgress) throw new BusinessException("Only work in progress can be completed.");
        if (wo.WorkType == WorkType.Breakdown && wo.QualityPassed != true)
            throw new BusinessException("Record a passed testing / quality check before completing a repair.");

        var now = clock.UtcNow;
        wo.TravelCharges = input.TravelCharges;
        wo.OtherExpenses = input.OtherExpenses;
        wo.TaxAmount = input.TaxAmount;
        wo.RepairWarrantyMonths = input.RepairWarrantyMonths;
        wo.ServiceReport = input.ServiceReport.Trim();
        wo.WorkCompletedAt = now;
        RecalculateCosts(wo);
        wo.Status = WorkOrderStatus.Completed;

        var asset = wo.Asset!;
        if (wo.ServiceRequest is { } sr)
        {
            Move(sr, ServiceRequestStatus.Completed);
            sr.CompletedAt = now;
            wo.DowntimeHours = RepairCostCalculator.DowntimeHours(sr.DownSince, now);
        }
        else
        {
            wo.DowntimeHours = RepairCostCalculator.DowntimeHours(wo.WorkStartedAt, now);
        }

        asset.Condition = input.ConditionAfter;
        asset.LastServiceDate = now.Date;
        if (asset.Status is AssetStatus.UnderRepair or AssetStatus.UnderMaintenance)
            history.ChangeStatus(asset, AssetStatus.InService, $"{wo.WorkOrderNo} completed", "WorkOrder", wo.Id, wo.WorkOrderNo);

        if (input.RepairWarrantyMonths > 0)
            db.WarrantyRecords.Add(new WarrantyRecord
            {
                AssetId = asset.Id, WarrantyType = WarrantyType.Repair, IsPrimary = false,
                Provider = wo.TechnicianName ?? "Service provider", StartDate = now.Date,
                ExpiryDate = now.Date.AddMonths(input.RepairWarrantyMonths).AddDays(-1),
                Terms = $"Repair warranty on work order {wo.WorkOrderNo}"
            });

        DateTime? nextDue = null;
        if (wo.MaintenanceSchedule is { } sch)
        {
            sch.LastDoneDate = now.Date;
            var after = wo.DueDate is { } due && due > now.Date ? due : now.Date;
            nextDue = MaintenanceScheduler.NextAfter(sch.StartDate, sch.EndDate, sch.Frequency, sch.CustomIntervalDays, after);
            if (nextDue is { } nd) sch.NextDueDate = nd;
            else sch.IsActive = false;
        }

        db.MaintenanceHistory.Add(new MaintenanceHistory
        {
            AssetId = asset.Id, MaintenanceScheduleId = wo.MaintenanceScheduleId, WorkOrderId = wo.Id, PerformedOn = now.Date,
            MaintenanceType = wo.WorkType, PerformedBy = wo.TechnicianName, Cost = wo.TotalCost,
            Findings = Truncate(wo.ServiceReport, 2000), NextDueDate = nextDue
        });
        await db.SaveChangesAsync(ct);
        await RefreshNextServiceDateAsync(asset, ct);
        history.Record(asset, AssetEventType.Maintenance, $"{wo.WorkType.DisplayName()} completed under {wo.WorkOrderNo}; cost {wo.TotalCost:N2}.", "WorkOrder", wo.Id, wo.WorkOrderNo);
        await db.SaveChangesAsync(ct);
    }

    public async Task CloseWorkOrderAsync(int workOrderId, CancellationToken ct = default)
    {
        var wo = await LoadWorkOrderAsync(workOrderId, ct);
        if (wo.ServiceRequest is not null) throw new BusinessException("Repair work orders close together with their service request.");
        if (wo.Status is not (WorkOrderStatus.Completed or WorkOrderStatus.Verified)) throw new BusinessException("Only completed work orders can be closed.");
        wo.Status = WorkOrderStatus.Closed;
        await db.SaveChangesAsync(ct);
    }

    public async Task CancelWorkOrderAsync(int workOrderId, string reason, CancellationToken ct = default)
    {
        var wo = await LoadWorkOrderAsync(workOrderId, ct);
        EnsureOpen(wo);
        if (wo.ServiceRequest is not null) throw new BusinessException("Cancel the service request instead.");
        wo.Status = WorkOrderStatus.Cancelled;
        wo.ServiceReport = $"Cancelled: {reason}";
        if (wo.Asset!.Status == AssetStatus.UnderMaintenance)
            history.ChangeStatus(wo.Asset, AssetStatus.InService, $"{wo.WorkOrderNo} cancelled", "WorkOrder", wo.Id, wo.WorkOrderNo);
        await db.SaveChangesAsync(ct);
    }

    // ------------------------------------------------------------------ schedules

    public async Task<MaintenanceSchedule> SaveScheduleAsync(ScheduleInput input, CancellationToken ct = default)
    {
        var asset = await db.Assets.AsNoTracking().FirstOrDefaultAsync(a => a.Id == input.AssetId, ct) ?? throw new BusinessException("Asset not found.");
        user.EnsureCanSee(asset);
        if (input.Frequency == MaintenanceFrequency.CustomDays && (input.CustomIntervalDays ?? 0) <= 0)
            throw new BusinessException("Enter the custom interval in days.");
        if (input.EndDate is { } end && end < input.StartDate) throw new BusinessException("End date cannot be before the first due date.");

        MaintenanceSchedule s;
        if (input.Id == 0) { s = new MaintenanceSchedule(); db.MaintenanceSchedules.Add(s); }
        else s = await db.MaintenanceSchedules.FirstOrDefaultAsync(x => x.Id == input.Id, ct) ?? throw new BusinessException("Schedule not found.");

        bool timingChanged = s.Id == 0 || s.StartDate != input.StartDate.Date || s.Frequency != input.Frequency || s.CustomIntervalDays != input.CustomIntervalDays;
        s.AssetId = asset.Id;
        s.Title = input.Title.Trim();
        s.MaintenanceType = input.MaintenanceType;
        s.Frequency = input.Frequency;
        s.CustomIntervalDays = input.Frequency == MaintenanceFrequency.CustomDays ? input.CustomIntervalDays : null;
        s.StartDate = input.StartDate.Date;
        s.EndDate = input.EndDate?.Date;
        s.LeadDays = input.LeadDays;
        s.ServiceProviderId = input.ServiceProviderId;
        s.AMContractId = input.AMContractId;
        s.AssignedTechnician = input.AssignedTechnician;
        s.Checklist = input.Checklist;
        s.EstimatedCost = input.EstimatedCost;
        s.IsActive = input.IsActive;
        if (timingChanged)
        {
            var reference = s.LastDoneDate ?? clock.Today.AddDays(-1);
            s.NextDueDate = s.StartDate >= clock.Today
                ? s.StartDate
                : MaintenanceScheduler.NextAfter(s.StartDate, s.EndDate, s.Frequency, s.CustomIntervalDays, reference) ?? s.StartDate;
        }
        await db.SaveChangesAsync(ct);
        var tracked = await db.Assets.FirstAsync(a => a.Id == asset.Id, ct);
        await RefreshNextServiceDateAsync(tracked, ct);
        await db.SaveChangesAsync(ct);
        return s;
    }

    /// <summary>Creates work orders for schedules falling due within their lead time. Idempotent per schedule and due date.</summary>
    public async Task<int> GenerateDueWorkOrdersAsync(CancellationToken ct = default)
    {
        var today = clock.Today;
        var schedules = await db.MaintenanceSchedules.Include(s => s.Asset)
            .Where(s => s.IsActive && s.Asset!.Status != AssetStatus.Disposed && s.Asset.Status != AssetStatus.LostOrWrittenOff)
            .ToListAsync(ct);
        int created = 0;
        foreach (var s in schedules.Where(s => s.NextDueDate.AddDays(-s.LeadDays) <= today))
        {
            if (s.EndDate is { } end && s.NextDueDate > end) { s.IsActive = false; continue; }
            bool exists = await db.WorkOrders.AnyAsync(w => w.MaintenanceScheduleId == s.Id && w.DueDate == s.NextDueDate, ct);
            if (exists) continue;
            string no = await numbering.NextDocumentNoAsync("WO", ct);
            db.WorkOrders.Add(new WorkOrder
            {
                WorkOrderNo = no, AssetId = s.AssetId, MaintenanceScheduleId = s.Id, AMContractId = s.AMContractId,
                WorkType = s.MaintenanceType, Priority = Priority.Normal, Title = s.Title, DueDate = s.NextDueDate,
                TechnicianName = s.AssignedTechnician, ServiceProviderId = s.ServiceProviderId, Checklist = Truncate(s.Checklist, 1000),
                Status = s.AssignedTechnician is not null || s.ServiceProviderId is not null ? WorkOrderStatus.Assigned : WorkOrderStatus.Open,
                AssignedAt = s.AssignedTechnician is not null || s.ServiceProviderId is not null ? clock.UtcNow : null
            });
            history.Record(s.Asset!, AssetEventType.WorkOrder, $"Scheduled {s.MaintenanceType.DisplayName()} work order {no} generated for {s.NextDueDate:dd-MM-yyyy}.", "WorkOrder", null, no);
            created++;
        }
        await db.SaveChangesAsync(ct);
        return created;
    }

    private async Task RefreshNextServiceDateAsync(Asset asset, CancellationToken ct)
    {
        var next = await db.MaintenanceSchedules.Where(s => s.AssetId == asset.Id && s.IsActive)
            .Select(s => (DateTime?)s.NextDueDate).MinAsync(ct);
        if (next is not null) asset.NextServiceDate = next;
    }

    // ------------------------------------------------------------------ approvals (repair estimates)

    public bool Handles(ApprovalModule module) => module == ApprovalModule.RepairEstimate;

    public async Task OnDecidedAsync(ApprovalModule module, int entityId, bool approved, string? comments, CancellationToken ct)
    {
        var est = await db.RepairEstimates.Include(e => e.ServiceRequest).FirstAsync(e => e.Id == entityId, ct);
        est.Status = approved ? ApprovalStatus.Approved : ApprovalStatus.Rejected;
        est.DecidedAt = clock.UtcNow;
        est.DecidedBy = user.UserName;
        var sr = est.ServiceRequest!;
        if (sr.Status == ServiceRequestStatus.EstimateSubmitted)
            Move(sr, approved ? ServiceRequestStatus.EstimateApproved : ServiceRequestStatus.Diagnosed);
        if (!approved) sr.ReviewRemarks = $"Estimate rejected: {comments}";
    }

    public string LinkFor(ApprovalModule module, int entityId)
    {
        var srId = db.RepairEstimates.Where(e => e.Id == entityId).Select(e => e.ServiceRequestId).FirstOrDefault();
        return $"/ServiceRequests/Details/{srId}";
    }

    private static string Truncate(string? s, int max) => s is null ? "" : s.Length <= max ? s : s[..max];
}
