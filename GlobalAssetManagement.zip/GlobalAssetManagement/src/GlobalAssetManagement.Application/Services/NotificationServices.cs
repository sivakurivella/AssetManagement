using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using GlobalAssetManagement.Domain.Logic;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace GlobalAssetManagement.Application.Services;

/// <summary>Scans the database for due events and raises de-duplicated alerts, escalations and outbound messages.</summary>
public sealed class ReminderService(
    IAppDbContext db,
    IUserDirectory directory,
    IEmailSender email,
    ISmsSender sms,
    IWhatsAppSender whatsApp,
    SettingsService settings,
    IClock clock,
    ILogger<ReminderService> logger)
{
    private HashSet<string> _existingKeys = new();
    private readonly List<Notification> _new = new();

    public sealed record RunSummary(int Raised, int Escalated, int Sent, int Failed, int Skipped);

    public async Task<RunSummary> RunAsync(CancellationToken ct = default)
    {
        int raised = await GenerateAsync(ct);
        int escalated = await EscalateAsync(ct);
        var (sent, failed, skipped) = await DispatchAsync(ct);
        return new RunSummary(raised, escalated, sent, failed, skipped);
    }

    public async Task<int> GenerateAsync(CancellationToken ct = default)
    {
        var today = clock.Today;
        var cfg = await db.NotificationSettings.AsNoTracking().ToDictionaryAsync(s => s.AlertType, ct);
        var since = clock.UtcNow.AddDays(-800);
        _existingKeys = (await db.Notifications.AsNoTracking().Where(n => n.CreatedAt >= since).Select(n => n.DedupKey).ToListAsync(ct)).ToHashSet();
        _new.Clear();

        bool On(AlertType t) => !cfg.TryGetValue(t, out var s) || s.IsEnabled;
        IReadOnlyList<int> Days(AlertType t, params int[] fallback) =>
            cfg.TryGetValue(t, out var s) && !string.IsNullOrWhiteSpace(s.DaysBefore) ? ReminderPlanner.ParseDays(s.DaysBefore) : (fallback.Length > 0 ? fallback : ReminderPlanner.DefaultDays);
        string? Roles(AlertType t) => cfg.TryGetValue(t, out var s) ? s.RecipientRoles : null;

        // Warranty expiry
        if (On(AlertType.WarrantyExpiry))
        {
            var days = Days(AlertType.WarrantyExpiry);
            var horizon = today.AddDays(days.Max());
            var assets = await db.Assets.AsNoTracking()
                .Where(a => a.WarrantyExpiryDate != null && a.WarrantyExpiryDate <= horizon && a.WarrantyExpiryDate >= today.AddDays(-30)
                            && a.Status != AssetStatus.Disposed && a.Status != AssetStatus.LostOrWrittenOff)
                .Select(a => new { a.Id, a.AssetTag, a.Name, a.BranchId, Expiry = a.WarrantyExpiryDate!.Value }).ToListAsync(ct);
            foreach (var a in assets)
                if (ReminderPlanner.Bucket(a.Expiry, today, days) is { } b)
                    Raise(AlertType.WarrantyExpiry, b == 0 ? AlertSeverity.Warning : b <= 15 ? AlertSeverity.Warning : AlertSeverity.Info,
                        b == 0 ? $"Warranty expired: {a.AssetTag}" : $"Warranty expiring in {(a.Expiry - today).Days} days: {a.AssetTag}",
                        $"{a.AssetTag} - {a.Name}: warranty {(b == 0 ? "expired on" : "expires on")} {a.Expiry:dd-MM-yyyy}.",
                        "Asset", a.Id, $"/Assets/Details/{a.Id}", ReminderPlanner.DedupKey(AlertType.WarrantyExpiry, "Asset", a.Id, a.Expiry, b),
                        Roles(AlertType.WarrantyExpiry), a.BranchId, a.Expiry);
        }

        // AMC expiry
        if (On(AlertType.AmcExpiry))
        {
            var days = Days(AlertType.AmcExpiry);
            var horizon = today.AddDays(days.Max());
            var contracts = await db.AMContracts.AsNoTracking().Include(c => c.ServiceProvider)
                .Where(c => (c.RenewalStatus == AmcRenewalStatus.Active || c.RenewalStatus == AmcRenewalStatus.RenewalDue || c.RenewalStatus == AmcRenewalStatus.Expired)
                            && c.ExpiryDate <= horizon && c.ExpiryDate >= today.AddDays(-30)).ToListAsync(ct);
            foreach (var c in contracts)
                if (ReminderPlanner.Bucket(c.ExpiryDate, today, days) is { } b)
                    Raise(AlertType.AmcExpiry, b <= 15 ? AlertSeverity.Warning : AlertSeverity.Info,
                        b == 0 ? $"AMC expired: {c.ContractNo}" : $"AMC renewal due: {c.ContractNo}",
                        $"AMC {c.ContractNo} with {c.ServiceProvider?.CompanyName} {(b == 0 ? "expired on" : "expires on")} {c.ExpiryDate:dd-MM-yyyy}. Annual value {c.AnnualValue:N2}.",
                        "AMContract", c.Id, $"/Amc/Details/{c.Id}", ReminderPlanner.DedupKey(AlertType.AmcExpiry, "AMContract", c.Id, c.ExpiryDate, b),
                        Roles(AlertType.AmcExpiry), null, c.ExpiryDate);
        }

        // Service-provider contract renewal
        if (On(AlertType.ContractRenewalDue))
        {
            var days = Days(AlertType.ContractRenewalDue);
            var horizon = today.AddDays(days.Max());
            var providers = await db.ServiceProviders.AsNoTracking()
                .Where(p => p.IsActive && p.ContractEnd != null && p.ContractEnd <= horizon && p.ContractEnd >= today.AddDays(-30)).ToListAsync(ct);
            foreach (var p in providers)
                if (ReminderPlanner.Bucket(p.ContractEnd!.Value, today, days) is { } b)
                    Raise(AlertType.ContractRenewalDue, AlertSeverity.Info, $"Service contract renewal: {p.CompanyName}",
                        $"Service agreement {p.ServiceAgreementRef} with {p.CompanyName} ends on {p.ContractEnd:dd-MM-yyyy}.",
                        "ServiceProvider", p.Id, $"/Masters/Edit/ServiceProvider/{p.Id}",
                        ReminderPlanner.DedupKey(AlertType.ContractRenewalDue, "ServiceProvider", p.Id, p.ContractEnd.Value, b),
                        Roles(AlertType.ContractRenewalDue), null, p.ContractEnd);
        }

        // Maintenance, inspection and calibration due
        var schedules = await db.MaintenanceSchedules.AsNoTracking().Include(s => s.Asset)
            .Where(s => s.IsActive && s.NextDueDate <= today.AddDays(60)).ToListAsync(ct);
        foreach (var s in schedules)
        {
            var type = s.MaintenanceType switch
            {
                WorkType.Calibration => AlertType.CalibrationDue,
                WorkType.PeriodicInspection or WorkType.SafetyInspection => AlertType.InspectionDue,
                _ => AlertType.MaintenanceDue
            };
            if (!On(type)) continue;
            if (ReminderPlanner.Bucket(s.NextDueDate, today, Days(type, 15, 7, 1)) is { } b)
                Raise(type, b == 0 ? AlertSeverity.Warning : AlertSeverity.Info,
                    b == 0 ? $"{type.DisplayName()} overdue: {s.Asset!.AssetTag}" : $"{type.DisplayName()}: {s.Asset!.AssetTag} on {s.NextDueDate:dd-MM-yyyy}",
                    $"{s.Title} for {s.Asset.AssetTag} - {s.Asset.Name} is due on {s.NextDueDate:dd-MM-yyyy}.",
                    "MaintenanceSchedule", s.Id, "/MaintenanceSchedules", ReminderPlanner.DedupKey(type, "MaintenanceSchedule", s.Id, s.NextDueDate, b),
                    Roles(type), s.Asset.BranchId, s.NextDueDate);
        }

        // Repairs pending review / overdue
        if (On(AlertType.RepairPending))
        {
            var cutoff = clock.UtcNow.AddHours(-24);
            var pending = await db.ServiceRequests.AsNoTracking().Include(r => r.Asset)
                .Where(r => (r.Status == ServiceRequestStatus.Submitted || r.Status == ServiceRequestStatus.UnderReview) && r.RequestedAt < cutoff).ToListAsync(ct);
            foreach (var r in pending)
                Raise(AlertType.RepairPending, r.Priority >= Priority.High ? AlertSeverity.Warning : AlertSeverity.Info,
                    $"Service request awaiting review: {r.TicketNo}", $"{r.TicketNo} for {r.Asset!.AssetTag} ({r.Priority.DisplayName()}) has been waiting since {clock.ToLocal(r.RequestedAt):dd-MM-yyyy HH:mm}.",
                    "ServiceRequest", r.Id, $"/ServiceRequests/Details/{r.Id}", $"RepairPending:SR:{r.Id}", Roles(AlertType.RepairPending), r.Asset.BranchId, null);
        }
        if (On(AlertType.RepairOverdue))
        {
            var overdue = await db.WorkOrders.AsNoTracking().Include(w => w.Asset)
                .Where(w => w.DueDate != null && w.DueDate < today && (w.Status == WorkOrderStatus.Open || w.Status == WorkOrderStatus.Assigned
                            || w.Status == WorkOrderStatus.InProgress || w.Status == WorkOrderStatus.OnHold)).ToListAsync(ct);
            foreach (var w in overdue)
                Raise(AlertType.RepairOverdue, AlertSeverity.Warning, $"Work order overdue: {w.WorkOrderNo}",
                    $"{w.WorkOrderNo} ({w.Title}) for {w.Asset!.AssetTag} was due on {w.DueDate:dd-MM-yyyy}.",
                    "WorkOrder", w.Id, $"/WorkOrders/Details/{w.Id}", $"RepairOverdue:WO:{w.Id}:{w.DueDate:yyyyMMdd}", Roles(AlertType.RepairOverdue), w.Asset.BranchId, w.DueDate);
        }

        // Critical asset downtime
        if (On(AlertType.CriticalDowntime))
        {
            var down = await db.ServiceRequests.AsNoTracking().Include(r => r.Asset)
                .Where(r => r.AssetDown && r.Asset!.IsCritical && r.Status != ServiceRequestStatus.Closed && r.Status != ServiceRequestStatus.Cancelled
                            && r.Status != ServiceRequestStatus.Rejected && r.Status != ServiceRequestStatus.Completed && r.Status != ServiceRequestStatus.UserConfirmed)
                .ToListAsync(ct);
            foreach (var r in down)
                Raise(AlertType.CriticalDowntime, AlertSeverity.Critical, $"Critical asset down: {r.Asset!.AssetTag}",
                    $"{r.Asset.AssetTag} - {r.Asset.Name} has been down since {clock.ToLocal(r.DownSince ?? r.RequestedAt):dd-MM-yyyy HH:mm} ({r.TicketNo}).",
                    "ServiceRequest", r.Id, $"/ServiceRequests/Details/{r.Id}", $"CriticalDowntime:SR:{r.Id}", Roles(AlertType.CriticalDowntime), r.Asset.BranchId, null);
        }

        // Asset return due
        if (On(AlertType.AssetReturnDue))
        {
            var days = Days(AlertType.AssetReturnDue, 3, 1);
            var horizon = today.AddDays(days.Max());
            var allocations = await db.AssetAllocations.AsNoTracking().Include(a => a.Asset).Include(a => a.Employee)
                .Where(a => a.Status == AllocationStatus.Active && a.ExpectedReturnDate != null && a.ExpectedReturnDate <= horizon).ToListAsync(ct);
            foreach (var al in allocations)
                if (ReminderPlanner.Bucket(al.ExpectedReturnDate!.Value, today, days) is { } b)
                    Raise(AlertType.AssetReturnDue, b == 0 ? AlertSeverity.Warning : AlertSeverity.Info,
                        b == 0 ? $"Asset not returned: {al.Asset!.AssetTag}" : $"Asset return due: {al.Asset!.AssetTag}",
                        $"{al.Asset.AssetTag} issued to {al.Employee?.FullName ?? "department/location"} under {al.AllocationNo} is due back on {al.ExpectedReturnDate:dd-MM-yyyy}.",
                        "AssetAllocation", al.Id, "/Allocations?overdue=true", ReminderPlanner.DedupKey(AlertType.AssetReturnDue, "AssetAllocation", al.Id, al.ExpectedReturnDate.Value, b),
                        Roles(AlertType.AssetReturnDue), al.BranchId, al.ExpectedReturnDate, al.Employee?.UserId);
        }

        // Approvals waiting
        var approvalsPending = await db.Approvals.AsNoTracking().Where(a => a.Status == ApprovalStatus.Pending).ToListAsync(ct);
        foreach (var a in approvalsPending.GroupBy(x => new { x.Module, x.EntityId }).Select(g => g.OrderBy(x => x.Level).First()))
        {
            var type = a.Module is ApprovalModule.PurchaseRequest or ApprovalModule.PurchaseOrder ? AlertType.PurchaseApprovalPending : AlertType.ApprovalPending;
            if (!On(type)) continue;
            Raise(type, AlertSeverity.Info, $"{a.Module.DisplayName()} awaiting your approval: {a.ReferenceNo}",
                $"{a.Module.DisplayName()} {a.ReferenceNo} for {a.Amount:N2} submitted by {a.RequestedBy} needs level {a.Level} approval.",
                "Approval", a.Id, "/Approvals", $"Approval:{a.Id}", a.ApproverRole, null, null);
        }

        // Verification pending
        if (On(AlertType.VerificationPending))
        {
            var old = clock.UtcNow.AddDays(-7);
            var sessions = await db.PhysicalVerificationSessions.AsNoTracking()
                .Where(s => s.Status == VerificationSessionStatus.Open && s.StartedAt < old).ToListAsync(ct);
            foreach (var s in sessions)
                Raise(AlertType.VerificationPending, AlertSeverity.Info, $"Verification still open: {s.SessionNo}",
                    $"Physical verification {s.SessionNo} ({s.Title}) started on {clock.ToLocal(s.StartedAt):dd-MM-yyyy} has not been submitted.",
                    "PhysicalVerificationSession", s.Id, $"/Verification/Details/{s.Id}", $"VerificationPending:{s.Id}", Roles(AlertType.VerificationPending), s.BranchId, null);
        }

        if (_new.Count > 0)
        {
            db.Notifications.AddRange(_new);
            try { await db.SaveChangesAsync(ct); }
            catch (DbUpdateException ex)
            {
                // Another instance raised the same reminders concurrently; the unique DedupKey index prevented duplicates.
                logger.LogWarning(ex, "Duplicate reminders skipped");
                foreach (var n in _new) db.Entry(n).State = EntityState.Detached;
                return 0;
            }
        }
        return _new.Count;
    }

    private void Raise(AlertType type, AlertSeverity severity, string title, string message, string entityName, int entityId, string link,
        string dedupKey, string? roles, int? branchId, DateTime? dueDate, string? targetUserId = null)
    {
        if (!_existingKeys.Add(dedupKey)) return;
        _new.Add(new Notification
        {
            AlertType = type, Severity = severity, Title = Cut(title, 200), Message = Cut(message, 2000), EntityName = entityName, EntityId = entityId,
            Link = link, DedupKey = Cut(dedupKey, 200), TargetRole = string.IsNullOrWhiteSpace(roles) ? $"{Domain.Logic.Roles.Administrator},{Domain.Logic.Roles.AssetManager}" : Cut(roles, 100),
            TargetUserId = targetUserId, BranchId = branchId, DueDate = dueDate, CreatedAt = clock.UtcNow
        });
    }

    public async Task<int> EscalateAsync(CancellationToken ct = default)
    {
        var cfg = await db.NotificationSettings.AsNoTracking().Where(s => s.EscalateAfterDays > 0 && s.EscalateToRole != null).ToListAsync(ct);
        int count = 0;
        foreach (var s in cfg)
        {
            var cutoff = clock.UtcNow.AddDays(-s.EscalateAfterDays);
            var stale = await db.Notifications.Where(n => n.AlertType == s.AlertType && !n.IsAcknowledged && !n.IsEscalated && n.CreatedAt < cutoff
                                                          && !n.DedupKey.StartsWith("ESC:")).ToListAsync(ct);
            foreach (var n in stale)
            {
                n.IsEscalated = true;
                n.EscalatedAt = clock.UtcNow;
                string key = Cut("ESC:" + n.DedupKey, 200);
                if (await db.Notifications.AnyAsync(x => x.DedupKey == key, ct)) continue;
                db.Notifications.Add(new Notification
                {
                    AlertType = n.AlertType, Severity = AlertSeverity.Critical, Title = Cut("ESCALATED: " + n.Title, 200),
                    Message = Cut($"Not acknowledged for {s.EscalateAfterDays} day(s). {n.Message}", 2000), EntityName = n.EntityName,
                    EntityId = n.EntityId, Link = n.Link, DedupKey = key, TargetRole = s.EscalateToRole, BranchId = n.BranchId,
                    DueDate = n.DueDate, CreatedAt = clock.UtcNow
                });
                count++;
            }
        }
        await db.SaveChangesAsync(ct);
        return count;
    }

    /// <summary>Delivers new notifications through the configured external channels and records every attempt.</summary>
    public async Task<(int Sent, int Failed, int Skipped)> DispatchAsync(CancellationToken ct = default)
    {
        var cfg = await db.NotificationSettings.AsNoTracking().ToDictionaryAsync(s => s.AlertType, ct);
        var pending = await db.Notifications.Where(n => !n.Logs.Any()).OrderBy(n => n.Id).Take(500).ToListAsync(ct);
        int sent = 0, failed = 0, skipped = 0;
        var company = await settings.GetCompanyAsync(ct);

        foreach (var n in pending)
        {
            db.NotificationLogs.Add(new NotificationLog { NotificationId = n.Id, Channel = NotificationChannel.InApp, Recipient = n.TargetRole ?? n.TargetUserId ?? "all", Status = DeliveryStatus.Sent, AttemptedAt = clock.UtcNow, Attempts = 1 });
            if (!cfg.TryGetValue(n.AlertType, out var s) || !(s.SendEmail || s.SendSms || s.SendWhatsApp)) continue;

            var recipients = new List<DirectoryUser>();
            foreach (var role in (n.TargetRole ?? "").Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
                recipients.AddRange((await directory.GetUsersInRoleAsync(role, ct)).Where(u => n.BranchId is null || u.BranchId is null || u.BranchId == n.BranchId));
            if (n.TargetUserId is { } uid && await directory.FindAsync(uid, ct) is { } tu) recipients.Add(tu);
            recipients = recipients.GroupBy(r => r.UserId).Select(g => g.First()).ToList();

            if (s.SendEmail)
            {
                var emails = recipients.Select(r => r.Email).Concat((s.ExtraEmails ?? "").Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
                    .Where(e => !string.IsNullOrWhiteSpace(e)).Distinct(StringComparer.OrdinalIgnoreCase);
                foreach (var to in emails)
                {
                    var r = await email.SendAsync(to!, $"[{company.Name}] {n.Title}",
                        $"<p>{System.Net.WebUtility.HtmlEncode(n.Message)}</p><p style=\"color:#666;font-size:12px\">Global Asset Management - {System.Net.WebUtility.HtmlEncode(company.Name)}</p>", ct);
                    Log(n, NotificationChannel.Email, to!, r, ref sent, ref failed, ref skipped);
                }
            }
            if (s.SendSms)
                foreach (var phone in recipients.Select(r => r.Phone).Where(p => !string.IsNullOrWhiteSpace(p)).Distinct())
                {
                    var r = await sms.SendAsync(phone!, $"{n.Title}. {n.Message}", ct);
                    Log(n, NotificationChannel.Sms, phone!, r, ref sent, ref failed, ref skipped);
                }
            if (s.SendWhatsApp)
                foreach (var phone in recipients.Select(r => r.Phone).Where(p => !string.IsNullOrWhiteSpace(p)).Distinct())
                {
                    var r = await whatsApp.SendAsync(phone!, $"{n.Title}\n{n.Message}", ct);
                    Log(n, NotificationChannel.WhatsApp, phone!, r, ref sent, ref failed, ref skipped);
                }
        }
        await db.SaveChangesAsync(ct);
        return (sent, failed, skipped);
    }

    private void Log(Notification n, NotificationChannel channel, string recipient, SendResult r, ref int sent, ref int failed, ref int skipped)
    {
        var status = r.Success ? DeliveryStatus.Sent : r.Skipped ? DeliveryStatus.Skipped : DeliveryStatus.Failed;
        if (status == DeliveryStatus.Sent) sent++; else if (status == DeliveryStatus.Failed) failed++; else skipped++;
        db.NotificationLogs.Add(new NotificationLog
        {
            NotificationId = n.Id, Channel = channel, Recipient = Cut(recipient, 256), Status = status, AttemptedAt = clock.UtcNow,
            Attempts = 1, Error = r.Error is null ? null : Cut(r.Error, 2000)
        });
    }

    private static string Cut(string s, int max) => s.Length <= max ? s : s[..max];
}

/// <summary>In-app notification inbox for the signed-in user.</summary>
public sealed class NotificationInbox(IAppDbContext db, ICurrentUser user, IClock clock)
{
    private IQueryable<Notification> Mine()
    {
        var roles = user.Roles.ToList();
        string? uid = user.UserId;
        int? branch = user.BranchId;
        bool super = user.IsInRole(Roles.SuperAdministrator);
        var q = db.Notifications.AsNoTracking();
        if (branch is not null) q = q.Where(n => n.BranchId == null || n.BranchId == branch);
        if (super) return q;
        // TargetRole holds a comma separated role list; build "user id matches OR any of my roles appears in the list".
        System.Linq.Expressions.Expression<Func<Notification, bool>> predicate = n => uid != null && n.TargetUserId == uid;
        foreach (var role in roles)
        {
            string token = "," + role + ",";
            predicate = Or(predicate, n => n.TargetRole != null && ("," + n.TargetRole + ",").Contains(token));
        }
        return q.Where(predicate);
    }

    private static System.Linq.Expressions.Expression<Func<T, bool>> Or<T>(
        System.Linq.Expressions.Expression<Func<T, bool>> a, System.Linq.Expressions.Expression<Func<T, bool>> b)
    {
        var p = a.Parameters[0];
        var bBody = new ReplaceParameter(b.Parameters[0], p).Visit(b.Body)!;
        return System.Linq.Expressions.Expression.Lambda<Func<T, bool>>(System.Linq.Expressions.Expression.OrElse(a.Body, bBody), p);
    }

    private sealed class ReplaceParameter(System.Linq.Expressions.ParameterExpression from, System.Linq.Expressions.ParameterExpression to)
        : System.Linq.Expressions.ExpressionVisitor
    {
        protected override System.Linq.Expressions.Expression VisitParameter(System.Linq.Expressions.ParameterExpression node) =>
            node == from ? to : base.VisitParameter(node);
    }

    public Task<int> UnreadCountAsync(CancellationToken ct = default) => Mine().CountAsync(n => !n.IsAcknowledged, ct);

    public async Task<PagedResult<Notification>> ListAsync(bool unreadOnly, AlertType? type, int page, int pageSize = 30, CancellationToken ct = default)
    {
        var q = Mine();
        if (unreadOnly) q = q.Where(n => !n.IsAcknowledged);
        if (type is not null) q = q.Where(n => n.AlertType == type);
        int total = await q.CountAsync(ct);
        page = Math.Max(1, page);
        var items = await q.OrderByDescending(n => n.CreatedAt).ThenByDescending(n => n.Id).Skip((page - 1) * pageSize).Take(pageSize).ToListAsync(ct);
        return new PagedResult<Notification> { Items = items, Page = page, PageSize = pageSize, TotalCount = total };
    }

    public Task<List<Notification>> LatestAsync(int take, CancellationToken ct = default) =>
        Mine().Where(n => !n.IsAcknowledged).OrderByDescending(n => n.Severity).ThenByDescending(n => n.CreatedAt).Take(take).ToListAsync(ct);

    public async Task AcknowledgeAsync(IEnumerable<int> ids, CancellationToken ct = default)
    {
        var allowed = await Mine().Where(n => ids.Contains(n.Id) && !n.IsAcknowledged).Select(n => n.Id).ToListAsync(ct);
        var list = await db.Notifications.Where(n => allowed.Contains(n.Id)).ToListAsync(ct);
        foreach (var n in list)
        {
            n.IsAcknowledged = true;
            n.AcknowledgedAt = clock.UtcNow;
            n.AcknowledgedBy = user.UserName;
        }
        await db.SaveChangesAsync(ct);
    }
}
