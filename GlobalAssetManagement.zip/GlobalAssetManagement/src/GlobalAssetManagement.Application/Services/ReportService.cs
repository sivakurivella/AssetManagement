using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Application.Common.Reporting;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using GlobalAssetManagement.Domain.Logic;
using Microsoft.EntityFrameworkCore;

namespace GlobalAssetManagement.Application.Services;

[Flags]
public enum ReportFilters
{
    None = 0, DateRange = 1, Branch = 2, Department = 4, Category = 8, Employee = 16, Location = 32,
    Vendor = 64, Status = 128, Search = 256, GroupBy = 512,
    Org = Branch | Department | Category
}

public sealed record ReportDefinition(string Key, string Title, string Group, ReportFilters Filters, AppModule Module, string Description,
    string? DateLabel = null, string[]? StatusOptions = null, string[]? GroupOptions = null);

public sealed class ReportFilter
{
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
    public int? BranchId { get; set; }
    public int? DepartmentId { get; set; }
    public int? CategoryId { get; set; }
    public int? EmployeeId { get; set; }
    public int? LocationId { get; set; }
    public int? VendorId { get; set; }
    public string? Status { get; set; }
    public string? Search { get; set; }
    public string? GroupBy { get; set; }
}

/// <summary>All 28 operational and financial reports. Every report runs against live, filtered database data.</summary>
public sealed class ReportService(IAppDbContext db, ICurrentUser user, IClock clock, SettingsService settings, DepreciationService depreciation)
{
    private static readonly string[] AssetStatuses = Enum.GetNames<AssetStatus>();

    public static readonly IReadOnlyList<ReportDefinition> Definitions = new List<ReportDefinition>
    {
        new("asset-register", "Complete Asset Register", "Asset Registers", ReportFilters.Org | ReportFilters.Location | ReportFilters.Status | ReportFilters.Search | ReportFilters.DateRange | ReportFilters.Vendor, AppModule.Reports, "Every asset with classification, placement, purchase and value details.", "Purchase date", AssetStatuses),
        new("category-register", "Category-wise Asset Register", "Asset Registers", ReportFilters.Org | ReportFilters.Status, AppModule.Reports, "Assets grouped and sub-totalled by category.", null, AssetStatuses),
        new("department-register", "Department-wise Asset Register", "Asset Registers", ReportFilters.Org | ReportFilters.Status, AppModule.Reports, "Assets grouped by department.", null, AssetStatuses),
        new("branch-register", "Branch-wise Asset Register", "Asset Registers", ReportFilters.Org | ReportFilters.Status, AppModule.Reports, "Assets grouped by branch.", null, AssetStatuses),
        new("employee-register", "Employee-wise Asset Register", "Asset Registers", ReportFilters.Branch | ReportFilters.Department | ReportFilters.Employee, AppModule.Reports, "Assets currently held by each employee."),
        new("location-register", "Location-wise Asset Register", "Asset Registers", ReportFilters.Branch | ReportFilters.Location | ReportFilters.Category, AppModule.Reports, "Assets by building / floor / room."),
        new("purchase-register", "Asset Purchase Register", "Procurement", ReportFilters.DateRange | ReportFilters.Branch | ReportFilters.Vendor, AppModule.FinancialReports, "Purchase invoices with linked PO and registered assets.", "Invoice date"),
        new("addition-register", "Asset Addition Register", "Procurement", ReportFilters.DateRange | ReportFilters.Branch | ReportFilters.Category, AppModule.FinancialReports, "Subsequent expenditure and its classification.", "Addition date"),
        new("transfer-register", "Asset Transfer Register", "Movements", ReportFilters.DateRange | ReportFilters.Branch, AppModule.Reports, "All transfers between employees, departments, branches and locations.", "Transfer date"),
        new("issue-return-register", "Asset Issue and Return Register", "Movements", ReportFilters.DateRange | ReportFilters.Branch | ReportFilters.Employee | ReportFilters.Status, AppModule.Reports, "Handover, acknowledgement and return details.", "Issue date", new[] { "Active", "Returned", "Overdue" }),
        new("maintenance-schedule", "Asset Maintenance Schedule", "Maintenance", ReportFilters.Org | ReportFilters.Search, AppModule.Reports, "Active preventive / inspection / calibration schedules."),
        new("repair-history", "Repair and Service History", "Maintenance", ReportFilters.DateRange | ReportFilters.Org | ReportFilters.Search, AppModule.Reports, "Work orders with diagnosis, costs and outcome.", "Completed date"),
        new("repair-cost-analysis", "Repair Cost Analysis", "Maintenance", ReportFilters.DateRange | ReportFilters.Org | ReportFilters.GroupBy, AppModule.Reports, "Repair cost and downtime summarised by asset, category or department.", "Completed date", null, new[] { "asset", "category", "department", "provider" }),
        new("maintenance-expense", "Maintenance Expense Register", "Maintenance", ReportFilters.DateRange | ReportFilters.Org, AppModule.Reports, "Completed scheduled maintenance with expenses.", "Completed date"),
        new("amc-register", "AMC Register", "Warranty & AMC", ReportFilters.Status | ReportFilters.Vendor, AppModule.Reports, "Annual maintenance contracts with value, coverage and SLA.", null, Enum.GetNames<AmcRenewalStatus>()),
        new("warranty-expiry", "Warranty Expiry Report", "Warranty & AMC", ReportFilters.DateRange | ReportFilters.Org | ReportFilters.Status, AppModule.Reports, "Warranties by expiry date with remaining days.", "Expiry date", new[] { "Active", "ExpiringSoon", "Expired" }),
        new("maintenance-due", "Maintenance Due Report", "Maintenance", ReportFilters.DateRange | ReportFilters.Org, AppModule.Reports, "Schedules falling due (or overdue) in the period.", "Due date"),
        new("downtime", "Asset Downtime Report", "Maintenance", ReportFilters.DateRange | ReportFilters.Org, AppModule.Reports, "Downtime hours per breakdown, including assets still down.", "Request date"),
        new("verification", "Physical Verification Report", "Verification", ReportFilters.DateRange | ReportFilters.Branch, AppModule.Reports, "Verification sessions with found / missing / wrong-location counts.", "Session date"),
        new("missing-assets", "Missing Assets Report", "Verification", ReportFilters.DateRange | ReportFilters.Branch, AppModule.Reports, "Assets not found during physical verification.", "Session date"),
        new("depreciation-register", "Asset Depreciation Register", "Accounting", ReportFilters.DateRange | ReportFilters.Org, AppModule.FinancialReports, "Posted depreciation by asset and period.", "Period end"),
        new("valuation", "Asset Valuation Report", "Accounting", ReportFilters.Org | ReportFilters.GroupBy, AppModule.FinancialReports, "Cost, additions, accumulated depreciation and book value.", null, null, new[] { "asset", "category", "branch", "department", "year" }),
        new("disposal-register", "Asset Disposal Register", "Accounting", ReportFilters.DateRange | ReportFilters.Org, AppModule.FinancialReports, "Disposals with book value, proceeds and profit / loss.", "Disposal date"),
        new("vendor-purchases", "Vendor-wise Purchase Report", "Procurement", ReportFilters.DateRange | ReportFilters.Vendor, AppModule.FinancialReports, "Purchase value and asset count per vendor.", "Invoice date"),
        new("provider-performance", "Service Provider Performance Report", "Maintenance", ReportFilters.DateRange, AppModule.Reports, "Jobs, turnaround, cost, SLA compliance and feedback per provider.", "Completed date"),
        new("pending-approvals", "Pending Approvals Report", "Control", ReportFilters.None, AppModule.Reports, "Transactions waiting for approval, by level and role."),
        new("utilization", "Asset Utilization Report", "Asset Registers", ReportFilters.DateRange | ReportFilters.Org, AppModule.Reports, "Days allocated and availability (downtime) per asset in the period.", "Period"),
        new("audit-trail", "Audit Trail Report", "Control", ReportFilters.DateRange | ReportFilters.Search, AppModule.Audit, "Who changed what and when.", "Date"),
    };

    public static ReportDefinition? Find(string key) => Definitions.FirstOrDefault(d => d.Key.Equals(key, StringComparison.OrdinalIgnoreCase));

    public async Task<ReportTable> RunAsync(string key, ReportFilter f, bool includeFinancial, CancellationToken ct = default)
    {
        var def = Find(key) ?? throw new BusinessException("Unknown report.");
        var company = await settings.GetCompanyAsync(ct);
        var t = new ReportTable
        {
            Title = def.Title, OrganizationName = company.Name,
            OrganizationAddress = string.Join(", ", new[] { company.Address, company.City, company.State, company.Gstin is null ? null : "GSTIN " + company.Gstin }.Where(s => !string.IsNullOrWhiteSpace(s))),
            GeneratedAt = clock.Now, GeneratedBy = user.UserName
        };
        await DescribeFiltersAsync(t, def, f, ct);

        switch (def.Key)
        {
            case "asset-register": await AssetRegister(t, f, null, includeFinancial, ct); break;
            case "category-register": await AssetRegister(t, f, "category", includeFinancial, ct); break;
            case "department-register": await AssetRegister(t, f, "department", includeFinancial, ct); break;
            case "branch-register": await AssetRegister(t, f, "branch", includeFinancial, ct); break;
            case "employee-register": await EmployeeRegister(t, f, ct); break;
            case "location-register": await LocationRegister(t, f, ct); break;
            case "purchase-register": await PurchaseRegister(t, f, ct); break;
            case "addition-register": await AdditionRegister(t, f, ct); break;
            case "transfer-register": await TransferRegister(t, f, ct); break;
            case "issue-return-register": await IssueReturnRegister(t, f, ct); break;
            case "maintenance-schedule": await ScheduleReport(t, f, false, ct); break;
            case "repair-history": await RepairHistory(t, f, ct); break;
            case "repair-cost-analysis": await RepairCostAnalysis(t, f, ct); break;
            case "maintenance-expense": await MaintenanceExpense(t, f, ct); break;
            case "amc-register": await AmcRegister(t, f, ct); break;
            case "warranty-expiry": await WarrantyExpiry(t, f, ct); break;
            case "maintenance-due": await ScheduleReport(t, f, true, ct); break;
            case "downtime": await Downtime(t, f, ct); break;
            case "verification": await VerificationReport(t, f, ct); break;
            case "missing-assets": await MissingAssets(t, f, ct); break;
            case "depreciation-register": await DepreciationRegister(t, f, ct); break;
            case "valuation": await Valuation(t, f, ct); break;
            case "disposal-register": await DisposalRegister(t, f, ct); break;
            case "vendor-purchases": await VendorPurchases(t, f, ct); break;
            case "provider-performance": await ProviderPerformance(t, f, ct); break;
            case "pending-approvals": await PendingApprovals(t, ct); break;
            case "utilization": await Utilization(t, f, ct); break;
            case "audit-trail": await AuditTrail(t, f, ct); break;
        }
        return t;
    }

    // ------------------------------------------------------------------ helpers

    private async Task DescribeFiltersAsync(ReportTable t, ReportDefinition def, ReportFilter f, CancellationToken ct)
    {
        var parts = new List<string>();
        if (def.Filters.HasFlag(ReportFilters.DateRange) && (f.From is not null || f.To is not null))
            parts.Add($"{def.DateLabel ?? "Date"}: {(f.From is { } a ? a.ToString("dd-MM-yyyy") : "start")} to {(f.To is { } b ? b.ToString("dd-MM-yyyy") : "date")}");
        if (f.BranchId is { } br) parts.Add("Branch: " + await db.Branches.Where(x => x.Id == br).Select(x => x.Name).FirstOrDefaultAsync(ct));
        if (f.DepartmentId is { } d) parts.Add("Department: " + await db.Departments.Where(x => x.Id == d).Select(x => x.Name).FirstOrDefaultAsync(ct));
        if (f.CategoryId is { } c) parts.Add("Category: " + await db.AssetCategories.Where(x => x.Id == c).Select(x => x.Name).FirstOrDefaultAsync(ct));
        if (f.EmployeeId is { } e) parts.Add("Employee: " + await db.Employees.Where(x => x.Id == e).Select(x => x.FullName).FirstOrDefaultAsync(ct));
        if (f.LocationId is { } l) parts.Add("Location: " + await db.Locations.Where(x => x.Id == l).Select(x => x.Code).FirstOrDefaultAsync(ct));
        if (f.VendorId is { } v) parts.Add("Vendor: " + await db.Vendors.Where(x => x.Id == v).Select(x => x.Name).FirstOrDefaultAsync(ct));
        if (!string.IsNullOrWhiteSpace(f.Status)) parts.Add("Status: " + f.Status);
        if (!string.IsNullOrWhiteSpace(f.Search)) parts.Add($"Search: \"{f.Search}\"");
        if (!string.IsNullOrWhiteSpace(f.GroupBy)) parts.Add("Grouped by: " + f.GroupBy);
        if (user.BranchId is not null) parts.Add("Restricted to your branch");
        if (parts.Count > 0) t.Filters.Add("Filters - " + string.Join(" | ", parts));
    }

    private IQueryable<Asset> Assets(ReportFilter f, bool includeDisposed = false)
    {
        var q = db.Assets.AsNoTracking().VisibleTo(user);
        if (f.BranchId is { } b) q = q.Where(a => a.BranchId == b);
        if (f.DepartmentId is { } d) q = q.Where(a => a.DepartmentId == d);
        if (f.CategoryId is { } c) q = q.Where(a => a.CategoryId == c);
        if (f.LocationId is { } l) q = q.Where(a => a.LocationId == l);
        if (!includeDisposed) q = q.Where(a => a.Status != AssetStatus.Disposed && a.Status != AssetStatus.LostOrWrittenOff);
        return q;
    }

    private (DateTime From, DateTime To) Range(ReportFilter f, int defaultMonthsBack = 12)
    {
        var to = (f.To ?? clock.Today).Date;
        var from = (f.From ?? to.AddMonths(-defaultMonthsBack).AddDays(1)).Date;
        return (from, to);
    }

    private DateTime L(DateTime utc) => clock.ToLocal(utc);

    // ------------------------------------------------------------------ registers

    private async Task AssetRegister(ReportTable t, ReportFilter f, string? groupBy, bool fin, CancellationToken ct)
    {
        bool includeDisposed = !string.IsNullOrWhiteSpace(f.Status) && f.Status is nameof(AssetStatus.Disposed) or nameof(AssetStatus.LostOrWrittenOff);
        var q = Assets(f, includeDisposed);
        if (Enum.TryParse<AssetStatus>(f.Status, out var st)) q = q.Where(a => a.Status == st);
        if (f.VendorId is { } v) q = q.Where(a => a.VendorId == v);
        if (f.From is { } from) q = q.Where(a => a.PurchaseDate >= from);
        if (f.To is { } to) q = q.Where(a => a.PurchaseDate <= to);
        if (!string.IsNullOrWhiteSpace(f.Search))
        {
            var s = f.Search.Trim();
            q = q.Where(a => a.AssetTag.Contains(s) || a.AssetCode.Contains(s) || a.Name.Contains(s) || (a.SerialNumber != null && a.SerialNumber.Contains(s)));
        }
        var rows = await q.Select(a => new
        {
            a.Id, a.AssetTag, a.AssetCode, a.Name, Category = a.Category!.Name, Sub = a.Subcategory != null ? a.Subcategory.Name : null,
            Make = a.Manufacturer != null ? a.Manufacturer.Name : null, a.ModelNumber, a.SerialNumber,
            Branch = a.Branch!.Name, Department = a.Department != null ? a.Department.Name : null,
            Location = a.Location != null ? a.Location.Code : null, Employee = a.AssignedEmployee != null ? a.AssignedEmployee.FullName : null,
            a.Status, a.Condition, a.PurchaseDate, Vendor = a.Vendor != null ? a.Vendor.Name : null, a.InvoiceNumber,
            Gross = a.OriginalCost + a.CapitalizedAdditions, a.AccumulatedDepreciation, a.WarrantyExpiryDate
        }).ToListAsync(ct);

        string Key(string category, string? department, string branch) => groupBy switch
        {
            "category" => category,
            "department" => department ?? "(No department)",
            "branch" => branch,
            _ => ""
        };
        if (groupBy is not null) t.AddColumn(groupBy switch { "category" => "Category", "department" => "Department", _ => "Branch" });
        t.AddColumn("Asset ID").AddColumn("Asset Code").AddColumn("Asset Name");
        if (groupBy != "category") t.AddColumn("Category");
        t.AddColumn("Make / Model").AddColumn("Serial No.");
        if (groupBy != "branch") t.AddColumn("Branch");
        if (groupBy != "department") t.AddColumn("Department");
        t.AddColumn("Location").AddColumn("Assigned To").AddColumn("Status").AddColumn("Condition")
         .AddColumn("Purchase Date", ColumnKind.Date).AddColumn("Vendor").AddColumn("Invoice No.").AddColumn("Warranty Expiry", ColumnKind.Date);
        if (fin) t.AddColumn("Gross Cost", ColumnKind.Money, true).AddColumn("Acc. Depreciation", ColumnKind.Money, true).AddColumn("Book Value", ColumnKind.Money, true);

        foreach (var r in rows.OrderBy(r => Key(r.Category, r.Department, r.Branch)).ThenBy(r => r.AssetTag))
        {
            var cells = new List<object?>();
            if (groupBy is not null) cells.Add(Key(r.Category, r.Department, r.Branch));
            cells.AddRange(new object?[] { r.AssetTag, r.AssetCode, r.Name });
            if (groupBy != "category") cells.Add(r.Category);
            cells.Add(string.Join(" ", new[] { r.Make, r.ModelNumber }.Where(x => !string.IsNullOrWhiteSpace(x))));
            cells.Add(r.SerialNumber);
            if (groupBy != "branch") cells.Add(r.Branch);
            if (groupBy != "department") cells.Add(r.Department);
            cells.AddRange(new object?[] { r.Location, r.Employee, r.Status.DisplayName(), r.Condition.DisplayName(), r.PurchaseDate, r.Vendor, r.InvoiceNumber, r.WarrantyExpiryDate });
            if (fin) cells.AddRange(new object?[] { r.Gross, r.AccumulatedDepreciation, r.Gross - r.AccumulatedDepreciation });
            t.AddRow($"/Assets/Details/{r.Id}", cells.ToArray());
        }
    }

    private async Task EmployeeRegister(ReportTable t, ReportFilter f, CancellationToken ct)
    {
        var q = db.AssetAllocations.AsNoTracking().Where(a => a.Status == AllocationStatus.Active && a.EmployeeId != null);
        int? ub = user.BranchId;
        if (ub is not null) q = q.Where(a => a.Asset!.BranchId == ub);
        if (f.BranchId is { } b) q = q.Where(a => a.Asset!.BranchId == b);
        if (f.DepartmentId is { } d) q = q.Where(a => a.Employee!.DepartmentId == d);
        if (f.EmployeeId is { } e) q = q.Where(a => a.EmployeeId == e);
        var rows = await q.Select(a => new
        {
            a.AssetId, Emp = a.Employee!.EmployeeCode + " - " + a.Employee.FullName, Dept = a.Employee.Department != null ? a.Employee.Department.Name : null,
            a.Asset!.AssetTag, a.Asset.Name, a.Asset.SerialNumber, Category = a.Asset.Category!.Name, a.AllocationNo, a.IssueDate,
            a.ExpectedReturnDate, a.IsAcknowledged, a.Asset.Condition
        }).ToListAsync(ct);
        t.AddColumn("Employee").AddColumn("Department").AddColumn("Asset ID").AddColumn("Asset Name").AddColumn("Category").AddColumn("Serial No.")
         .AddColumn("Issue No.").AddColumn("Issued On", ColumnKind.Date).AddColumn("Return Due", ColumnKind.Date).AddColumn("Acknowledged").AddColumn("Condition")
         .AddColumn("Qty", ColumnKind.Integer, true);
        foreach (var r in rows.OrderBy(r => r.Emp).ThenBy(r => r.AssetTag))
            t.AddRow($"/Assets/Details/{r.AssetId}", r.Emp, r.Dept, r.AssetTag, r.Name, r.Category, r.SerialNumber, r.AllocationNo, L(r.IssueDate), r.ExpectedReturnDate, r.IsAcknowledged, r.Condition.DisplayName(), 1);
    }

    private async Task LocationRegister(ReportTable t, ReportFilter f, CancellationToken ct)
    {
        var rows = await Assets(f).Select(a => new
        {
            a.Id, Branch = a.Branch!.Name, Loc = a.Location != null ? a.Location.Code : "(No location)",
            Building = a.Location != null ? a.Location.Building : null, Floor = a.Location != null ? a.Location.Floor : null,
            Room = a.Location != null ? a.Location.Room : null, a.RackPosition, a.AssetTag, a.Name, Category = a.Category!.Name, a.Status
        }).ToListAsync(ct);
        t.AddColumn("Branch").AddColumn("Location").AddColumn("Building").AddColumn("Floor").AddColumn("Room").AddColumn("Rack")
         .AddColumn("Asset ID").AddColumn("Asset Name").AddColumn("Category").AddColumn("Status").AddColumn("Qty", ColumnKind.Integer, true);
        foreach (var r in rows.OrderBy(r => r.Branch).ThenBy(r => r.Loc).ThenBy(r => r.AssetTag))
            t.AddRow($"/Assets/Details/{r.Id}", r.Branch, r.Loc, r.Building, r.Floor, r.Room, r.RackPosition, r.AssetTag, r.Name, r.Category, r.Status.DisplayName(), 1);
    }

    // ------------------------------------------------------------------ procurement

    private async Task PurchaseRegister(ReportTable t, ReportFilter f, CancellationToken ct)
    {
        var (from, to) = Range(f);
        var q = db.PurchaseInvoices.AsNoTracking().Where(i => i.InvoiceDate >= from && i.InvoiceDate <= to);
        if (f.VendorId is { } v) q = q.Where(i => i.VendorId == v);
        if (f.BranchId is { } b) q = q.Where(i => i.PurchaseOrder != null && i.PurchaseOrder.BranchId == b);
        var rows = await q.Select(i => new
        {
            i.Id, i.InvoiceNumber, i.InvoiceDate, Vendor = i.Vendor!.Name, i.Vendor.Gstin, Po = i.PurchaseOrder != null ? i.PurchaseOrder.PONumber : null,
            Grn = i.GoodsReceipt != null ? i.GoodsReceipt.GrnNumber : null, i.SubTotal, i.TaxAmount, Charges = i.FreightCharges + i.InstallationCharges + i.OtherCharges,
            i.TotalAmount, Assets = i.Assets.Count
        }).ToListAsync(ct);
        t.AddColumn("Invoice No.").AddColumn("Invoice Date", ColumnKind.Date).AddColumn("Vendor").AddColumn("GSTIN").AddColumn("PO No.").AddColumn("GRN No.")
         .AddColumn("Taxable Value", ColumnKind.Money, true).AddColumn("GST", ColumnKind.Money, true).AddColumn("Other Charges", ColumnKind.Money, true)
         .AddColumn("Invoice Total", ColumnKind.Money, true).AddColumn("Assets Registered", ColumnKind.Integer, true);
        foreach (var r in rows.OrderBy(r => r.InvoiceDate).ThenBy(r => r.InvoiceNumber))
            t.AddRow($"/PurchaseInvoices/Details/{r.Id}", r.InvoiceNumber, r.InvoiceDate, r.Vendor, r.Gstin, r.Po, r.Grn, r.SubTotal, r.TaxAmount, r.Charges, r.TotalAmount, r.Assets);
    }

    private async Task AdditionRegister(ReportTable t, ReportFilter f, CancellationToken ct)
    {
        var (from, to) = Range(f, 24);
        var ids = Assets(f, true).Select(a => a.Id);
        var rows = await db.AssetAdditions.AsNoTracking().Where(x => ids.Contains(x.AssetId) && x.AdditionDate >= from && x.AdditionDate <= to)
            .Select(x => new
            {
                x.Id, x.AdditionNo, x.AdditionDate, x.Asset!.AssetTag, AssetName = x.Asset.Name, x.Description, Vendor = x.Vendor != null ? x.Vendor.Name : null,
                x.InvoiceNumber, x.Cost, x.TaxAmount, x.ExpenditureType, x.Status, x.CapitalizationDate, x.PreviousGrossCost, x.RevisedGrossCost
            }).ToListAsync(ct);
        t.AddColumn("Addition No.").AddColumn("Date", ColumnKind.Date).AddColumn("Asset ID").AddColumn("Asset").AddColumn("Description").AddColumn("Supplier").AddColumn("Invoice")
         .AddColumn("Cost", ColumnKind.Money, true).AddColumn("Tax", ColumnKind.Money, true).AddColumn("Classification").AddColumn("Status")
         .AddColumn("Capitalized On", ColumnKind.Date).AddColumn("Cost Before", ColumnKind.Money).AddColumn("Revised Cost", ColumnKind.Money);
        foreach (var r in rows.OrderBy(r => r.AdditionDate))
            t.AddRow($"/Additions/Details/{r.Id}", r.AdditionNo, r.AdditionDate, r.AssetTag, r.AssetName, r.Description, r.Vendor, r.InvoiceNumber, r.Cost, r.TaxAmount,
                r.ExpenditureType.DisplayName(), r.Status.DisplayName(), r.CapitalizationDate,
                r.Status == AdditionStatus.Capitalized ? r.PreviousGrossCost : null, r.Status == AdditionStatus.Capitalized ? r.RevisedGrossCost : null);
    }

    private async Task VendorPurchases(ReportTable t, ReportFilter f, CancellationToken ct)
    {
        var (from, to) = Range(f);
        var q = db.PurchaseInvoices.AsNoTracking().Where(i => i.InvoiceDate >= from && i.InvoiceDate <= to);
        if (f.VendorId is { } v) q = q.Where(i => i.VendorId == v);
        var data = await q.Select(i => new { i.VendorId, Vendor = i.Vendor!.Code + " - " + i.Vendor.Name, i.SubTotal, i.TaxAmount, i.TotalAmount, Assets = i.Assets.Count }).ToListAsync(ct);
        var pos = await db.PurchaseOrders.AsNoTracking().Where(p => p.PODate >= from && p.PODate <= to && p.Status != PurchaseOrderStatus.Cancelled)
            .Select(p => new { p.VendorId, p.GrandTotal }).ToListAsync(ct);
        t.AddColumn("Vendor").AddColumn("Purchase Orders", ColumnKind.Integer, true).AddColumn("PO Value", ColumnKind.Money, true).AddColumn("Invoices", ColumnKind.Integer, true)
         .AddColumn("Taxable Value", ColumnKind.Money, true).AddColumn("GST", ColumnKind.Money, true).AddColumn("Invoice Total", ColumnKind.Money, true).AddColumn("Assets", ColumnKind.Integer, true);
        foreach (var g in data.GroupBy(x => new { x.VendorId, x.Vendor }).OrderByDescending(g => g.Sum(x => x.TotalAmount)))
            t.AddRow(null, g.Key.Vendor, pos.Count(p => p.VendorId == g.Key.VendorId), pos.Where(p => p.VendorId == g.Key.VendorId).Sum(p => p.GrandTotal),
                g.Count(), g.Sum(x => x.SubTotal), g.Sum(x => x.TaxAmount), g.Sum(x => x.TotalAmount), g.Sum(x => x.Assets));
    }

    // ------------------------------------------------------------------ movements

    private async Task TransferRegister(ReportTable t, ReportFilter f, CancellationToken ct)
    {
        var (from, to) = Range(f);
        var q = db.AssetTransfers.AsNoTracking().Where(x => x.TransferDate >= from && x.TransferDate < to.AddDays(1));
        if (f.BranchId is { } b) q = q.Where(x => x.FromBranchId == b || x.ToBranchId == b);
        int? ub = user.BranchId;
        if (ub is not null) q = q.Where(x => x.FromBranchId == ub || x.ToBranchId == ub);
        var rows = await q.Select(x => new
        {
            x.Id, x.TransferNo, x.TransferDate, x.TransferType, x.Asset!.AssetTag, AssetName = x.Asset.Name,
            FromEmp = x.FromEmployee != null ? x.FromEmployee.FullName : null, ToEmp = x.ToEmployee != null ? x.ToEmployee.FullName : null,
            FromDept = x.FromDepartment != null ? x.FromDepartment.Name : null, ToDept = x.ToDepartment != null ? x.ToDepartment.Name : null,
            FromBranch = x.FromBranch!.Name, ToBranch = x.ToBranch!.Name,
            FromLoc = x.FromLocation != null ? x.FromLocation.Code : null, ToLoc = x.ToLocation != null ? x.ToLocation.Code : null,
            x.Reason, x.Status, x.CreatedBy, x.CompletedBy
        }).ToListAsync(ct);
        t.AddColumn("Transfer No.").AddColumn("Date", ColumnKind.Date).AddColumn("Type").AddColumn("Asset ID").AddColumn("Asset").AddColumn("From").AddColumn("To")
         .AddColumn("Reason").AddColumn("Status").AddColumn("Requested By").AddColumn("Completed By");
        foreach (var r in rows.OrderBy(r => r.TransferDate))
        {
            string From() => string.Join(" / ", new[] { r.FromBranch, r.FromDept, r.FromLoc, r.FromEmp }.Where(s => !string.IsNullOrWhiteSpace(s)));
            string To() => string.Join(" / ", new[] { r.ToBranch, r.ToDept, r.ToLoc, r.ToEmp }.Where(s => !string.IsNullOrWhiteSpace(s)));
            t.AddRow($"/Transfers/Details/{r.Id}", r.TransferNo, L(r.TransferDate), r.TransferType.DisplayName(), r.AssetTag, r.AssetName, From(), To(), r.Reason, r.Status.DisplayName(), r.CreatedBy, r.CompletedBy);
        }
    }

    private async Task IssueReturnRegister(ReportTable t, ReportFilter f, CancellationToken ct)
    {
        var (from, to) = Range(f);
        var today = clock.Today;
        var q = db.AssetAllocations.AsNoTracking().Where(a => a.IssueDate >= from && a.IssueDate < to.AddDays(1));
        int? ub = user.BranchId;
        if (ub is not null) q = q.Where(a => a.Asset!.BranchId == ub);
        if (f.BranchId is { } b) q = q.Where(a => a.Asset!.BranchId == b);
        if (f.EmployeeId is { } e) q = q.Where(a => a.EmployeeId == e);
        if (f.Status == "Active") q = q.Where(a => a.Status == AllocationStatus.Active);
        if (f.Status == "Returned") q = q.Where(a => a.Status == AllocationStatus.Returned);
        if (f.Status == "Overdue") q = q.Where(a => a.Status == AllocationStatus.Active && a.ExpectedReturnDate != null && a.ExpectedReturnDate < today);
        var rows = await q.Select(a => new
        {
            a.Id, a.AllocationNo, a.IssueDate, a.Asset!.AssetTag, AssetName = a.Asset.Name, a.TargetType,
            To = a.Employee != null ? a.Employee.FullName : a.Department != null ? a.Department.Name : a.Location != null ? a.Location.Code : null,
            a.IsTemporaryLoan, a.ExpectedReturnDate, a.IsAcknowledged, a.AcknowledgedAt, a.Status,
            ReturnDate = a.Return != null ? (DateTime?)a.Return.ReturnDate : null, ReturnCondition = a.Return != null ? (AssetCondition?)a.Return.ReturnCondition : null,
            Late = a.Return != null && a.Return.ReturnedLate, a.IssuedBy
        }).ToListAsync(ct);
        t.AddColumn("Issue No.").AddColumn("Issued On", ColumnKind.Date).AddColumn("Asset ID").AddColumn("Asset").AddColumn("Issued To").AddColumn("Loan")
         .AddColumn("Return Due", ColumnKind.Date).AddColumn("Acknowledged").AddColumn("Status").AddColumn("Returned On", ColumnKind.Date).AddColumn("Return Condition")
         .AddColumn("Late / Overdue").AddColumn("Issued By");
        foreach (var r in rows.OrderBy(r => r.IssueDate))
        {
            bool overdue = r.Status == AllocationStatus.Active && r.ExpectedReturnDate is { } d && d < today;
            t.AddRow(null, r.AllocationNo, L(r.IssueDate), r.AssetTag, r.AssetName, r.To, r.IsTemporaryLoan, r.ExpectedReturnDate, r.IsAcknowledged,
                r.Status.DisplayName(), r.ReturnDate is { } rd ? L(rd) : null, r.ReturnCondition?.DisplayName(), r.Late || overdue, r.IssuedBy);
        }
    }

    // ------------------------------------------------------------------ maintenance

    private async Task ScheduleReport(ReportTable t, ReportFilter f, bool dueOnly, CancellationToken ct)
    {
        var ids = Assets(f).Select(a => a.Id);
        var q = db.MaintenanceSchedules.AsNoTracking().Where(s => s.IsActive && ids.Contains(s.AssetId));
        var today = clock.Today;
        if (dueOnly)
        {
            var to = (f.To ?? today.AddDays(30)).Date;
            q = q.Where(s => s.NextDueDate <= to);
            if (f.From is { } fr) q = q.Where(s => s.NextDueDate >= fr);
        }
        if (!string.IsNullOrWhiteSpace(f.Search)) q = q.Where(s => s.Title.Contains(f.Search) || s.Asset!.AssetTag.Contains(f.Search));
        var rows = await q.Select(s => new
        {
            s.Id, s.Asset!.AssetTag, AssetName = s.Asset.Name, Branch = s.Asset.Branch!.Name, s.Title, s.MaintenanceType, s.Frequency, s.CustomIntervalDays,
            s.LastDoneDate, s.NextDueDate, Provider = s.ServiceProvider != null ? s.ServiceProvider.CompanyName : s.AssignedTechnician, s.EstimatedCost, s.AssetId
        }).ToListAsync(ct);
        t.AddColumn("Asset ID").AddColumn("Asset").AddColumn("Branch").AddColumn("Schedule").AddColumn("Type").AddColumn("Frequency").AddColumn("Last Done", ColumnKind.Date)
         .AddColumn("Next Due", ColumnKind.Date).AddColumn("Days Left", ColumnKind.Integer).AddColumn("Provider / Technician").AddColumn("Est. Cost", ColumnKind.Money, true);
        foreach (var r in rows.OrderBy(r => r.NextDueDate))
            t.AddRow($"/Assets/Details/{r.AssetId}", r.AssetTag, r.AssetName, r.Branch, r.Title, r.MaintenanceType.DisplayName(),
                r.Frequency == MaintenanceFrequency.CustomDays ? $"Every {r.CustomIntervalDays} days" : r.Frequency.DisplayName(),
                r.LastDoneDate, r.NextDueDate, (r.NextDueDate - today).Days, r.Provider, r.EstimatedCost);
    }

    private async Task RepairHistory(ReportTable t, ReportFilter f, CancellationToken ct)
    {
        var (from, to) = Range(f);
        var ids = Assets(f, true).Select(a => a.Id);
        var fromUtc = from.AddDays(-1);
        var toUtc = to.AddDays(1);
        var q = db.WorkOrders.AsNoTracking().Where(w => ids.Contains(w.AssetId) && w.WorkCompletedAt != null && w.WorkCompletedAt >= fromUtc && w.WorkCompletedAt < toUtc);
        if (!string.IsNullOrWhiteSpace(f.Search)) q = q.Where(w => w.Asset!.AssetTag.Contains(f.Search) || w.Title.Contains(f.Search) || w.WorkOrderNo.Contains(f.Search));
        var rows = await q.Select(w => new
        {
            w.Id, w.WorkOrderNo, Ticket = w.ServiceRequest != null ? w.ServiceRequest.TicketNo : null, w.Asset!.AssetTag, AssetName = w.Asset.Name, w.WorkType,
            w.Title, w.Diagnosis, Tech = w.ServiceProvider != null ? w.ServiceProvider.CompanyName : w.TechnicianName, w.WorkStartedAt, w.WorkCompletedAt,
            w.LabourCharges, w.PartsCost, Other = w.TravelCharges + w.OtherExpenses + w.TaxAmount, w.TotalCost, w.DowntimeHours, w.Status
        }).ToListAsync(ct);
        t.AddColumn("Work Order").AddColumn("Ticket").AddColumn("Asset ID").AddColumn("Asset").AddColumn("Type").AddColumn("Work").AddColumn("Diagnosis").AddColumn("Technician / Provider")
         .AddColumn("Completed", ColumnKind.Date).AddColumn("Labour", ColumnKind.Money, true).AddColumn("Parts", ColumnKind.Money, true).AddColumn("Other + Tax", ColumnKind.Money, true)
         .AddColumn("Total", ColumnKind.Money, true).AddColumn("Downtime (h)", ColumnKind.Number, true).AddColumn("Status");
        foreach (var r in rows.OrderBy(r => r.WorkCompletedAt))
            t.AddRow($"/WorkOrders/Details/{r.Id}", r.WorkOrderNo, r.Ticket, r.AssetTag, r.AssetName, r.WorkType.DisplayName(), r.Title, r.Diagnosis, r.Tech,
                L(r.WorkCompletedAt!.Value), r.LabourCharges, r.PartsCost, r.Other, r.TotalCost, r.DowntimeHours, r.Status.DisplayName());
    }

    private async Task RepairCostAnalysis(ReportTable t, ReportFilter f, CancellationToken ct)
    {
        var (from, to) = Range(f);
        var ids = Assets(f, true).Select(a => a.Id);
        var fromUtc = from.AddDays(-1);
        var toUtc = to.AddDays(1);
        var rows = await db.WorkOrders.AsNoTracking()
            .Where(w => ids.Contains(w.AssetId) && w.WorkType == WorkType.Breakdown && w.WorkCompletedAt != null && w.WorkCompletedAt >= fromUtc && w.WorkCompletedAt < toUtc)
            .Select(w => new
            {
                Asset = w.Asset!.AssetTag + " - " + w.Asset.Name, Category = w.Asset.Category!.Name,
                Department = w.Asset.Department != null ? w.Asset.Department.Name : "(No department)",
                Provider = w.ServiceProvider != null ? w.ServiceProvider.CompanyName : (w.TechnicianName ?? "(In-house)"),
                w.LabourCharges, w.PartsCost, Other = w.TravelCharges + w.OtherExpenses + w.TaxAmount, w.TotalCost, w.DowntimeHours,
                Value = w.Asset.OriginalCost + w.Asset.CapitalizedAdditions
            }).ToListAsync(ct);
        string group = f.GroupBy ?? "asset";
        t.AddColumn(group switch { "category" => "Category", "department" => "Department", "provider" => "Technician / Provider", _ => "Asset" })
         .AddColumn("Repairs", ColumnKind.Integer, true).AddColumn("Labour", ColumnKind.Money, true).AddColumn("Parts", ColumnKind.Money, true)
         .AddColumn("Other + Tax", ColumnKind.Money, true).AddColumn("Total Cost", ColumnKind.Money, true).AddColumn("Avg per Repair", ColumnKind.Money)
         .AddColumn("Downtime (h)", ColumnKind.Number, true);
        if (group == "asset") t.AddColumn("Repair Cost % of Asset Cost", ColumnKind.Percent);
        foreach (var g in rows.GroupBy(r => group switch { "category" => r.Category, "department" => r.Department, "provider" => r.Provider, _ => r.Asset })
                     .OrderByDescending(g => g.Sum(x => x.TotalCost)))
        {
            var cells = new List<object?> { g.Key, g.Count(), g.Sum(x => x.LabourCharges), g.Sum(x => x.PartsCost), g.Sum(x => x.Other), g.Sum(x => x.TotalCost),
                Math.Round(g.Average(x => x.TotalCost), 2), g.Sum(x => x.DowntimeHours) };
            if (group == "asset") cells.Add(g.First().Value > 0 ? Math.Round(g.Sum(x => x.TotalCost) / g.First().Value * 100, 2) : null);
            t.AddRow(null, cells.ToArray());
        }
    }

    private async Task MaintenanceExpense(ReportTable t, ReportFilter f, CancellationToken ct)
    {
        var (from, to) = Range(f);
        var ids = Assets(f, true).Select(a => a.Id);
        var rows = await db.MaintenanceHistory.AsNoTracking().Where(h => ids.Contains(h.AssetId) && h.PerformedOn >= from && h.PerformedOn <= to && h.MaintenanceType != WorkType.Breakdown)
            .Select(h => new
            {
                h.PerformedOn, h.Asset!.AssetTag, AssetName = h.Asset.Name, Department = h.Asset.Department != null ? h.Asset.Department.Name : null, h.MaintenanceType,
                Schedule = h.MaintenanceSchedule != null ? h.MaintenanceSchedule.Title : null, Wo = h.WorkOrder != null ? h.WorkOrder.WorkOrderNo : null,
                h.PerformedBy, h.Cost, h.NextDueDate, h.WorkOrderId
            }).ToListAsync(ct);
        t.AddColumn("Date", ColumnKind.Date).AddColumn("Asset ID").AddColumn("Asset").AddColumn("Department").AddColumn("Type").AddColumn("Schedule").AddColumn("Work Order")
         .AddColumn("Performed By").AddColumn("Expense", ColumnKind.Money, true).AddColumn("Next Due", ColumnKind.Date);
        foreach (var r in rows.OrderBy(r => r.PerformedOn))
            t.AddRow(r.WorkOrderId is { } w ? $"/WorkOrders/Details/{w}" : null, r.PerformedOn, r.AssetTag, r.AssetName, r.Department, r.MaintenanceType.DisplayName(), r.Schedule, r.Wo, r.PerformedBy, r.Cost, r.NextDueDate);
    }

    private async Task Downtime(ReportTable t, ReportFilter f, CancellationToken ct)
    {
        var (from, to) = Range(f);
        var ids = Assets(f, true).Select(a => a.Id);
        var fromUtc = from.AddDays(-1);
        var toUtc = to.AddDays(1);
        var rows = await db.ServiceRequests.AsNoTracking().Where(s => ids.Contains(s.AssetId) && s.AssetDown && s.RequestedAt >= fromUtc && s.RequestedAt < toUtc)
            .Select(s => new { s.Id, s.TicketNo, s.Asset!.AssetTag, AssetName = s.Asset.Name, s.Asset.IsCritical, s.Priority, s.DownSince, s.CompletedAt, s.Status, s.FaultDescription })
            .ToListAsync(ct);
        t.AddColumn("Ticket").AddColumn("Asset ID").AddColumn("Asset").AddColumn("Critical").AddColumn("Priority").AddColumn("Down Since", ColumnKind.DateTime)
         .AddColumn("Restored", ColumnKind.DateTime).AddColumn("Downtime (h)", ColumnKind.Number, true).AddColumn("Status").AddColumn("Fault");
        var now = clock.UtcNow;
        foreach (var r in rows.OrderByDescending(r => RepairCostCalculator.DowntimeHours(r.DownSince, r.CompletedAt ?? now)))
            t.AddRow($"/ServiceRequests/Details/{r.Id}", r.TicketNo, r.AssetTag, r.AssetName, r.IsCritical, r.Priority.DisplayName(),
                r.DownSince is { } ds ? L(ds) : null, r.CompletedAt is { } ca ? L(ca) : null,
                RepairCostCalculator.DowntimeHours(r.DownSince, r.CompletedAt ?? now), r.CompletedAt is null ? "Still down" : r.Status.DisplayName(), r.FaultDescription);
    }

    private async Task ProviderPerformance(ReportTable t, ReportFilter f, CancellationToken ct)
    {
        var (from, to) = Range(f);
        var fromUtc = from.AddDays(-1);
        var toUtc = to.AddDays(1);
        var wos = await db.WorkOrders.AsNoTracking().Where(w => w.ServiceProviderId != null && w.WorkCompletedAt != null && w.WorkCompletedAt >= fromUtc && w.WorkCompletedAt < toUtc)
            .Select(w => new { w.ServiceProviderId, w.AssignedAt, w.WorkCompletedAt, w.TotalCost, w.DueDate, Rating = w.ServiceRequest != null ? w.ServiceRequest.FeedbackRating : null })
            .ToListAsync(ct);
        var visits = await db.ServiceVisits.AsNoTracking().Where(v => v.ServiceProviderId != null && v.ScheduledDate >= from && v.ScheduledDate <= to)
            .Select(v => new { v.ServiceProviderId, v.Status, v.SlaMet }).ToListAsync(ct);
        var providers = await db.ServiceProviders.AsNoTracking().ToListAsync(ct);
        t.AddColumn("Service Provider").AddColumn("Jobs Completed", ColumnKind.Integer, true).AddColumn("Avg Turnaround (h)", ColumnKind.Number)
         .AddColumn("On-time %", ColumnKind.Percent).AddColumn("Total Cost", ColumnKind.Money, true).AddColumn("AMC Visits Done", ColumnKind.Integer, true)
         .AddColumn("Visits Missed", ColumnKind.Integer, true).AddColumn("SLA Met %", ColumnKind.Percent).AddColumn("Avg Feedback (1-5)", ColumnKind.Number).AddColumn("Master Rating", ColumnKind.Number);
        foreach (var p in providers)
        {
            var w = wos.Where(x => x.ServiceProviderId == p.Id).ToList();
            var v = visits.Where(x => x.ServiceProviderId == p.Id).ToList();
            if (w.Count == 0 && v.Count == 0) continue;
            var tat = w.Where(x => x.AssignedAt != null).Select(x => (decimal)(x.WorkCompletedAt!.Value - x.AssignedAt!.Value).TotalHours).ToList();
            var dueKnown = w.Where(x => x.DueDate != null).ToList();
            var sla = v.Where(x => x.SlaMet != null).ToList();
            var ratings = w.Where(x => x.Rating != null).Select(x => (decimal)x.Rating!.Value).ToList();
            t.AddRow(null, p.CompanyName, w.Count, tat.Count > 0 ? Math.Round(tat.Average(), 1) : null,
                dueKnown.Count > 0 ? Math.Round(100m * dueKnown.Count(x => x.WorkCompletedAt!.Value.Date <= x.DueDate!.Value) / dueKnown.Count, 1) : null,
                w.Sum(x => x.TotalCost), v.Count(x => x.Status == ServiceVisitStatus.Completed), v.Count(x => x.Status == ServiceVisitStatus.Missed),
                sla.Count > 0 ? Math.Round(100m * sla.Count(x => x.SlaMet == true) / sla.Count, 1) : null,
                ratings.Count > 0 ? Math.Round(ratings.Average(), 2) : null, p.Rating);
        }
    }

    // ------------------------------------------------------------------ warranty / AMC

    private async Task AmcRegister(ReportTable t, ReportFilter f, CancellationToken ct)
    {
        var q = db.AMContracts.AsNoTracking().AsQueryable();
        if (Enum.TryParse<AmcRenewalStatus>(f.Status, out var st)) q = q.Where(c => c.RenewalStatus == st);
        var rows = await q.Select(c => new
        {
            c.Id, c.ContractNo, Provider = c.ServiceProvider!.CompanyName, c.ContractType, c.StartDate, c.ExpiryDate, c.AnnualValue, c.TaxAmount,
            Assets = c.CoveredAssets.Count, c.VisitsPerYear, Done = c.Visits.Count(v => v.Status == ServiceVisitStatus.Completed),
            Missed = c.Visits.Count(v => v.Status == ServiceVisitStatus.Missed), c.ResponseTimeHours, c.RenewalStatus
        }).ToListAsync(ct);
        var today = clock.Today;
        t.AddColumn("Contract No.").AddColumn("Provider").AddColumn("Type").AddColumn("Start", ColumnKind.Date).AddColumn("Expiry", ColumnKind.Date).AddColumn("Days Left", ColumnKind.Integer)
         .AddColumn("Annual Value", ColumnKind.Money, true).AddColumn("GST", ColumnKind.Money, true).AddColumn("Assets Covered", ColumnKind.Integer, true)
         .AddColumn("Visits / Year", ColumnKind.Integer).AddColumn("Visits Done", ColumnKind.Integer).AddColumn("Missed", ColumnKind.Integer).AddColumn("Response SLA (h)", ColumnKind.Integer).AddColumn("Status");
        foreach (var r in rows.OrderBy(r => r.ExpiryDate))
            t.AddRow($"/Amc/Details/{r.Id}", r.ContractNo, r.Provider, r.ContractType.DisplayName(), r.StartDate, r.ExpiryDate, (r.ExpiryDate - today).Days, r.AnnualValue, r.TaxAmount,
                r.Assets, r.VisitsPerYear, r.Done, r.Missed, r.ResponseTimeHours, r.RenewalStatus.DisplayName());
    }

    private async Task WarrantyExpiry(ReportTable t, ReportFilter f, CancellationToken ct)
    {
        var ids = Assets(f).Select(a => a.Id);
        var q = db.WarrantyRecords.AsNoTracking().Where(w => ids.Contains(w.AssetId));
        if (f.From is { } fr) q = q.Where(w => w.ExpiryDate >= fr);
        if (f.To is { } to) q = q.Where(w => w.ExpiryDate <= to);
        var rows = await q.Select(w => new { w.AssetId, w.Asset!.AssetTag, AssetName = w.Asset.Name, w.Asset.SerialNumber, Branch = w.Asset.Branch!.Name, w.WarrantyType, w.Provider, w.StartDate, w.ExpiryDate, w.IsPrimary })
            .ToListAsync(ct);
        var today = clock.Today;
        int soon = 30;
        t.AddColumn("Asset ID").AddColumn("Asset").AddColumn("Serial No.").AddColumn("Branch").AddColumn("Warranty Type").AddColumn("Provider").AddColumn("Start", ColumnKind.Date)
         .AddColumn("Expiry", ColumnKind.Date).AddColumn("Days Left", ColumnKind.Integer).AddColumn("Status");
        foreach (var r in rows.OrderBy(r => r.ExpiryDate))
        {
            var status = CoverageEvaluator.Evaluate(r.ExpiryDate, today, soon);
            if (!string.IsNullOrWhiteSpace(f.Status) && !string.Equals(status.ToString(), f.Status, StringComparison.OrdinalIgnoreCase)) continue;
            t.AddRow($"/Assets/Details/{r.AssetId}", r.AssetTag, r.AssetName, r.SerialNumber, r.Branch, r.WarrantyType.DisplayName() + (r.IsPrimary ? "" : " (additional)"),
                r.Provider, r.StartDate, r.ExpiryDate, (r.ExpiryDate - today).Days, status.DisplayName());
        }
    }

    // ------------------------------------------------------------------ verification

    private async Task VerificationReport(ReportTable t, ReportFilter f, CancellationToken ct)
    {
        var (from, to) = Range(f, 24);
        var q = db.PhysicalVerificationSessions.AsNoTracking().Where(s => s.StartedAt >= from.AddDays(-1) && s.StartedAt < to.AddDays(1));
        int? ub = user.BranchId;
        if (ub is not null) q = q.Where(s => s.BranchId == ub);
        if (f.BranchId is { } b) q = q.Where(s => s.BranchId == b);
        var rows = await q.Select(s => new
        {
            s.Id, s.SessionNo, s.Title, s.StartedAt, Branch = s.Branch != null ? s.Branch.Name : "All", s.ConductedBy, s.Status,
            Expected = s.Items.Count(i => i.IsExpected), Found = s.Items.Count(i => i.Result == VerificationResult.Found),
            Wrong = s.Items.Count(i => i.Result == VerificationResult.WrongLocation), Missing = s.Items.Count(i => i.Result == VerificationResult.Missing),
            Unreg = s.Items.Count(i => i.Result == VerificationResult.Unregistered), Pending = s.Items.Count(i => i.Result == VerificationResult.Pending), s.ApprovedBy
        }).ToListAsync(ct);
        t.AddColumn("Session").AddColumn("Title").AddColumn("Started", ColumnKind.Date).AddColumn("Branch").AddColumn("Conducted By").AddColumn("Expected", ColumnKind.Integer, true)
         .AddColumn("Found", ColumnKind.Integer, true).AddColumn("Wrong Location", ColumnKind.Integer, true).AddColumn("Missing", ColumnKind.Integer, true)
         .AddColumn("Unregistered", ColumnKind.Integer, true).AddColumn("Not Scanned", ColumnKind.Integer, true).AddColumn("Verified %", ColumnKind.Percent).AddColumn("Status").AddColumn("Approved By");
        foreach (var r in rows.OrderByDescending(r => r.StartedAt))
            t.AddRow($"/Verification/Details/{r.Id}", r.SessionNo, r.Title, L(r.StartedAt), r.Branch, r.ConductedBy, r.Expected, r.Found, r.Wrong, r.Missing, r.Unreg, r.Pending,
                r.Expected > 0 ? Math.Round(100m * (r.Found + r.Wrong) / r.Expected, 1) : null, r.Status.DisplayName(), r.ApprovedBy);
    }

    private async Task MissingAssets(ReportTable t, ReportFilter f, CancellationToken ct)
    {
        var (from, to) = Range(f, 24);
        var q = db.PhysicalVerificationItems.AsNoTracking().Where(i => i.Result == VerificationResult.Missing && i.Session!.StartedAt >= from.AddDays(-1) && i.Session.StartedAt < to.AddDays(1));
        int? ub = user.BranchId;
        if (ub is not null) q = q.Where(i => i.Asset!.BranchId == ub);
        if (f.BranchId is { } b) q = q.Where(i => i.Asset!.BranchId == b);
        var rows = await q.Select(i => new
        {
            i.AssetId, i.Session!.SessionNo, i.Session.StartedAt, i.Asset!.AssetTag, AssetName = i.Asset.Name, i.Asset.SerialNumber, Branch = i.Asset.Branch!.Name,
            Loc = i.ExpectedLocation != null ? i.ExpectedLocation.Code : null, Holder = i.Asset.AssignedEmployee != null ? i.Asset.AssignedEmployee.FullName : null,
            BookValue = i.Asset.CurrentBookValue, i.Asset.Status
        }).ToListAsync(ct);
        t.AddColumn("Session").AddColumn("Date", ColumnKind.Date).AddColumn("Asset ID").AddColumn("Asset").AddColumn("Serial No.").AddColumn("Branch").AddColumn("Expected Location")
         .AddColumn("Custodian").AddColumn("Current Status").AddColumn("Book Value", ColumnKind.Money, true);
        foreach (var r in rows.OrderByDescending(r => r.StartedAt).ThenBy(r => r.AssetTag))
            t.AddRow($"/Assets/Details/{r.AssetId}", r.SessionNo, L(r.StartedAt), r.AssetTag, r.AssetName, r.SerialNumber, r.Branch, r.Loc, r.Holder, r.Status.DisplayName(), r.BookValue);
    }

    // ------------------------------------------------------------------ accounting

    private async Task DepreciationRegister(ReportTable t, ReportFilter f, CancellationToken ct)
    {
        var (from, to) = Range(f);
        var ids = Assets(f, true).Select(a => a.Id);
        var rows = await db.DepreciationTransactions.AsNoTracking().Where(x => ids.Contains(x.AssetId) && x.PeriodTo >= from && x.PeriodTo <= to)
            .Select(x => new
            {
                x.AssetId, x.Asset!.AssetTag, AssetName = x.Asset.Name, Category = x.Asset.Category!.Name, Run = x.DepreciationSchedule != null ? x.DepreciationSchedule.RunNo : "Disposal",
                x.PeriodFrom, x.PeriodTo, x.Days, x.Method, x.Rate, x.OpeningGrossCost, x.AdditionsInPeriod, x.OpeningAccumulated, x.DepreciationAmount, x.ClosingAccumulated, x.ClosingBookValue
            }).ToListAsync(ct);
        t.AddColumn("Asset ID").AddColumn("Asset").AddColumn("Category").AddColumn("Run").AddColumn("From", ColumnKind.Date).AddColumn("To", ColumnKind.Date).AddColumn("Days", ColumnKind.Integer)
         .AddColumn("Method").AddColumn("Rate %", ColumnKind.Number).AddColumn("Opening Cost", ColumnKind.Money).AddColumn("Additions", ColumnKind.Money, true)
         .AddColumn("Opening Acc. Dep.", ColumnKind.Money).AddColumn("Depreciation", ColumnKind.Money, true).AddColumn("Closing Acc. Dep.", ColumnKind.Money).AddColumn("Closing Book Value", ColumnKind.Money);
        foreach (var r in rows.OrderBy(r => r.AssetTag).ThenBy(r => r.PeriodFrom))
            t.AddRow($"/Assets/Details/{r.AssetId}", r.AssetTag, r.AssetName, r.Category, r.Run, r.PeriodFrom, r.PeriodTo, r.Days, r.Method.DisplayName(), r.Rate,
                r.OpeningGrossCost, r.AdditionsInPeriod, r.OpeningAccumulated, r.DepreciationAmount, r.ClosingAccumulated, r.ClosingBookValue);
    }

    private async Task Valuation(ReportTable t, ReportFilter f, CancellationToken ct)
    {
        string group = f.GroupBy ?? "asset";
        if (group != "asset")
        {
            var summary = await depreciation.ValuationAsync(group, f.BranchId, ct);
            t.AddColumn(group switch { "branch" => "Branch", "department" => "Department", "year" => "Financial Year of Purchase", _ => "Category" })
             .AddColumn("Assets", ColumnKind.Integer, true).AddColumn("Original Cost", ColumnKind.Money, true).AddColumn("Capitalized Additions", ColumnKind.Money, true)
             .AddColumn("Accumulated Depreciation", ColumnKind.Money, true).AddColumn("Book Value", ColumnKind.Money, true);
            foreach (var r in summary) t.AddRow(null, r.Group, r.Count, r.OriginalCost, r.Additions, r.Accumulated, r.BookValue);
            return;
        }
        var rows = await Assets(f).Select(a => new
        {
            a.Id, a.AssetTag, a.Name, Category = a.Category!.Name, Branch = a.Branch!.Name, a.PurchaseDate, a.DepreciationMethod, a.DepreciationRate, a.UsefulLifeYears,
            a.OriginalCost, a.CapitalizedAdditions, a.ResidualValue, a.AccumulatedDepreciation, a.DepreciatedUpTo
        }).ToListAsync(ct);
        t.AddColumn("Asset ID").AddColumn("Asset").AddColumn("Category").AddColumn("Branch").AddColumn("Purchase Date", ColumnKind.Date).AddColumn("Method").AddColumn("Rate %", ColumnKind.Number)
         .AddColumn("Life (yrs)", ColumnKind.Number).AddColumn("Original Cost", ColumnKind.Money, true).AddColumn("Additions", ColumnKind.Money, true).AddColumn("Residual", ColumnKind.Money, true)
         .AddColumn("Acc. Depreciation", ColumnKind.Money, true).AddColumn("Book Value", ColumnKind.Money, true).AddColumn("Depreciated Up To", ColumnKind.Date);
        foreach (var r in rows.OrderBy(r => r.AssetTag))
            t.AddRow($"/Assets/Details/{r.Id}", r.AssetTag, r.Name, r.Category, r.Branch, r.PurchaseDate, r.DepreciationMethod.DisplayName(), r.DepreciationRate, r.UsefulLifeYears,
                r.OriginalCost, r.CapitalizedAdditions, r.ResidualValue, r.AccumulatedDepreciation, r.OriginalCost + r.CapitalizedAdditions - r.AccumulatedDepreciation, r.DepreciatedUpTo);
    }

    private async Task DisposalRegister(ReportTable t, ReportFilter f, CancellationToken ct)
    {
        var (from, to) = Range(f, 24);
        var ids = Assets(f, true).Select(a => a.Id);
        var rows = await db.AssetDisposals.AsNoTracking().Where(d => ids.Contains(d.AssetId) && d.Status == DisposalStatus.Completed && d.DisposalDate >= from && d.DisposalDate <= to)
            .Select(d => new
            {
                d.Id, d.DisposalNo, d.DisposalDate, d.Asset!.AssetTag, AssetName = d.Asset.Name, d.Method, d.Reason, d.BuyerOrRecipient, d.SaleInvoiceNo,
                d.GrossCostAtDisposal, d.AccumulatedDepreciationAtDisposal, d.BookValueAtDisposal, d.DisposalValue, d.ProfitOrLoss, d.CompletedBy
            }).ToListAsync(ct);
        t.AddColumn("Disposal No.").AddColumn("Date", ColumnKind.Date).AddColumn("Asset ID").AddColumn("Asset").AddColumn("Method").AddColumn("Reason").AddColumn("Buyer / Recipient")
         .AddColumn("Sale Invoice").AddColumn("Gross Cost", ColumnKind.Money, true).AddColumn("Acc. Depreciation", ColumnKind.Money, true).AddColumn("Book Value", ColumnKind.Money, true)
         .AddColumn("Proceeds", ColumnKind.Money, true).AddColumn("Profit / (Loss)", ColumnKind.Money, true).AddColumn("Completed By");
        foreach (var r in rows.OrderBy(r => r.DisposalDate))
            t.AddRow($"/Disposals/Details/{r.Id}", r.DisposalNo, r.DisposalDate, r.AssetTag, r.AssetName, r.Method.DisplayName(), r.Reason, r.BuyerOrRecipient, r.SaleInvoiceNo,
                r.GrossCostAtDisposal, r.AccumulatedDepreciationAtDisposal, r.BookValueAtDisposal, r.DisposalValue, r.ProfitOrLoss, r.CompletedBy);
    }

    // ------------------------------------------------------------------ control

    private async Task PendingApprovals(ReportTable t, CancellationToken ct)
    {
        var rows = await db.Approvals.AsNoTracking().Where(a => a.Status == ApprovalStatus.Pending).OrderBy(a => a.RequestedAt).ToListAsync(ct);
        var now = clock.UtcNow;
        t.AddColumn("Module").AddColumn("Reference").AddColumn("Level", ColumnKind.Integer).AddColumn("Approver Role").AddColumn("Amount", ColumnKind.Money, true)
         .AddColumn("Requested By").AddColumn("Requested On", ColumnKind.DateTime).AddColumn("Waiting (days)", ColumnKind.Number);
        foreach (var a in rows)
            t.AddRow("/Approvals", a.Module.DisplayName(), a.ReferenceNo, a.Level, a.ApproverRole, a.Amount, a.RequestedBy, L(a.RequestedAt), Math.Round((decimal)(now - a.RequestedAt).TotalDays, 1));
    }

    private async Task Utilization(ReportTable t, ReportFilter f, CancellationToken ct)
    {
        var (from, to) = Range(f, 3);
        var assetsList = await Assets(f).Select(a => new { a.Id, a.AssetTag, a.Name, Category = a.Category!.Name, a.Status, a.PurchaseDate }).ToListAsync(ct);
        var ids = assetsList.Select(a => a.Id).ToList();
        var fromUtc = from;
        var toEx = to.AddDays(1);
        var allocs = await db.AssetAllocations.AsNoTracking().Where(a => ids.Contains(a.AssetId) && a.IssueDate < toEx && (a.Status == AllocationStatus.Active || a.Return!.ReturnDate >= fromUtc))
            .Select(a => new { a.AssetId, a.IssueDate, End = a.Return != null ? (DateTime?)a.Return.ReturnDate : null }).ToListAsync(ct);
        var downs = await db.ServiceRequests.AsNoTracking().Where(s => ids.Contains(s.AssetId) && s.AssetDown && s.DownSince != null && s.DownSince < toEx && (s.CompletedAt == null || s.CompletedAt >= fromUtc))
            .Select(s => new { s.AssetId, s.DownSince, s.CompletedAt }).ToListAsync(ct);
        var now = clock.UtcNow;
        t.AddColumn("Asset ID").AddColumn("Asset").AddColumn("Category").AddColumn("Status").AddColumn("Days in Period", ColumnKind.Integer).AddColumn("Days Allocated", ColumnKind.Integer, true)
         .AddColumn("Utilization %", ColumnKind.Percent).AddColumn("Downtime (h)", ColumnKind.Number, true).AddColumn("Availability %", ColumnKind.Percent);
        foreach (var a in assetsList.OrderBy(x => x.AssetTag))
        {
            var start = a.PurchaseDate is { } p && p > from ? p : from;
            int days = Math.Max(0, (to - start).Days + 1);
            int allocated = 0;
            for (var d = start; d <= to; d = d.AddDays(1))
                if (allocs.Any(x => x.AssetId == a.Id && x.IssueDate.Date <= d && (x.End == null || x.End.Value.Date >= d))) allocated++;
            decimal downHours = downs.Where(x => x.AssetId == a.Id).Sum(x =>
            {
                var s = x.DownSince!.Value < start ? start : x.DownSince.Value;
                var e = x.CompletedAt ?? now;
                if (e > toEx) e = toEx;
                return RepairCostCalculator.DowntimeHours(s, e);
            });
            decimal hours = days * 24m;
            t.AddRow($"/Assets/Details/{a.Id}", a.AssetTag, a.Name, a.Category, a.Status.DisplayName(), days, allocated,
                days > 0 ? Math.Round(100m * allocated / days, 1) : null, downHours, hours > 0 ? Math.Round(100m * (1 - Math.Min(downHours, hours) / hours), 1) : null);
        }
    }

    private async Task AuditTrail(ReportTable t, ReportFilter f, CancellationToken ct)
    {
        var (from, to) = Range(f, 1);
        var q = db.AuditLogs.AsNoTracking().Where(a => a.Timestamp >= from.AddDays(-1) && a.Timestamp < to.AddDays(1));
        if (!string.IsNullOrWhiteSpace(f.Search))
            q = q.Where(a => (a.UserName != null && a.UserName.Contains(f.Search)) || a.EntityName.Contains(f.Search) || (a.ReferenceNo != null && a.ReferenceNo.Contains(f.Search)));
        var rows = await q.OrderByDescending(a => a.Timestamp).Take(5000).ToListAsync(ct);
        t.AddColumn("Date / Time", ColumnKind.DateTime).AddColumn("User").AddColumn("Action").AddColumn("Entity").AddColumn("Record Id").AddColumn("Reference").AddColumn("IP Address").AddColumn("Changes");
        foreach (var a in rows)
            t.AddRow(null, L(a.Timestamp), a.UserName, a.Action.DisplayName(), a.EntityName, a.EntityId, a.ReferenceNo, a.IpAddress,
                a.Changes is { Length: > 300 } c ? c[..300] + "..." : a.Changes);
    }
}
