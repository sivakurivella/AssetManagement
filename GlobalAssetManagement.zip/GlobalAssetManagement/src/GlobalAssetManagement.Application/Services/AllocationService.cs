using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Application.Models;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using GlobalAssetManagement.Domain.Logic;
using Microsoft.EntityFrameworkCore;

namespace GlobalAssetManagement.Application.Services;

/// <summary>Issue / acknowledge / return of assets and transfers between employees, departments, branches and locations.</summary>
public sealed class AllocationService(
    IAppDbContext db,
    NumberingService numbering,
    ApprovalService approvals,
    AssetHistory history,
    ICurrentUser user,
    IClock clock) : IApprovalHandler
{
    public async Task<AssetAllocation> IssueAsync(IssueInput input, CancellationToken ct = default)
    {
        var asset = await db.Assets.FirstOrDefaultAsync(a => a.Id == input.AssetId, ct) ?? throw new BusinessException("Asset not found.");
        user.EnsureCanSee(asset);
        if (asset.Status is AssetStatus.Disposed or AssetStatus.LostOrWrittenOff or AssetStatus.UnderRepair)
            throw new BusinessException($"An asset that is {asset.Status.DisplayName()} cannot be issued.");
        if (await db.AssetAllocations.AnyAsync(x => x.AssetId == asset.Id && x.Status == AllocationStatus.Active, ct))
            throw new BusinessException("This asset is already issued. Record its return or use Transfer instead.");

        switch (input.TargetType)
        {
            case AllocationTargetType.Employee when input.EmployeeId is null:
                throw new BusinessException("Select the employee receiving the asset.");
            case AllocationTargetType.Department when input.DepartmentId is null:
                throw new BusinessException("Select the department receiving the asset.");
            case AllocationTargetType.Location when input.LocationId is null:
                throw new BusinessException("Select the location.");
        }
        if (input.IsTemporaryLoan && input.ExpectedReturnDate is null)
            throw new BusinessException("Enter the expected return date for a temporary loan.");
        if (input.ExpectedReturnDate is { } erd && erd.Date < clock.Today)
            throw new BusinessException("Expected return date cannot be in the past.");

        Employee? employee = null;
        if (input.EmployeeId is { } eid)
            employee = await db.Employees.FirstOrDefaultAsync(e => e.Id == eid && e.IsActive, ct) ?? throw new BusinessException("Employee not found or inactive.");

        string no = await numbering.NextDocumentNoAsync("ALC", ct);
        var alloc = new AssetAllocation
        {
            AllocationNo = no, AssetId = asset.Id, TargetType = input.TargetType,
            EmployeeId = input.TargetType == AllocationTargetType.Employee ? input.EmployeeId : null,
            DepartmentId = input.DepartmentId ?? employee?.DepartmentId ?? asset.DepartmentId,
            BranchId = asset.BranchId,
            LocationId = input.LocationId ?? asset.LocationId,
            IssueDate = clock.UtcNow, ExpectedReturnDate = input.ExpectedReturnDate, IsTemporaryLoan = input.IsTemporaryLoan,
            Purpose = input.Purpose, ConditionAtIssue = input.ConditionAtIssue, AccessoriesIssued = input.AccessoriesIssued,
            IssuedBy = user.UserName, Status = AllocationStatus.Active
        };
        db.AssetAllocations.Add(alloc);

        asset.AssignedEmployeeId = alloc.EmployeeId;
        if (alloc.DepartmentId is not null) asset.DepartmentId = alloc.DepartmentId;
        if (alloc.LocationId is not null) asset.LocationId = alloc.LocationId;
        asset.Condition = input.ConditionAtIssue;
        if (asset.Status is AssetStatus.Received or AssetStatus.UnderInstallation or AssetStatus.Inactive)
            history.ChangeStatus(asset, AssetStatus.InService, $"Issued under {no}", "AssetAllocation", null, no);

        string target = input.TargetType switch
        {
            AllocationTargetType.Employee => employee!.FullName,
            AllocationTargetType.Department => (await db.Departments.FindAsync(new object[] { alloc.DepartmentId! }, ct))?.Name ?? "department",
            _ => (await db.Locations.FindAsync(new object[] { alloc.LocationId! }, ct))?.DisplayName ?? "location"
        };
        history.Record(asset, AssetEventType.Allocated,
            $"Issued to {target}{(input.IsTemporaryLoan ? $" on temporary loan until {input.ExpectedReturnDate:dd-MM-yyyy}" : "")}.", "AssetAllocation", null, no);
        await db.SaveChangesAsync(ct);
        return alloc;
    }

    /// <summary>Employee acceptance of the handover. The receiving employee (or an administrator) records it.</summary>
    public async Task AcknowledgeAsync(int allocationId, string? remarks, CancellationToken ct = default)
    {
        var a = await db.AssetAllocations.Include(x => x.Asset).FirstOrDefaultAsync(x => x.Id == allocationId, ct) ?? throw new BusinessException("Issue record not found.");
        if (a.IsAcknowledged) throw new BusinessException("This handover has already been acknowledged.");
        bool isRecipient = a.EmployeeId is not null && a.EmployeeId == user.EmployeeId;
        bool isAdmin = user.IsInRole(Roles.SuperAdministrator) || user.IsInRole(Roles.Administrator) || user.IsInRole(Roles.AssetManager);
        if (!isRecipient && !isAdmin) throw new UnauthorizedAccessException("Only the receiving employee or an asset manager can acknowledge this handover.");
        a.IsAcknowledged = true;
        a.AcknowledgedAt = clock.UtcNow;
        a.AcknowledgedBy = user.UserName + (isRecipient ? "" : " (on behalf of employee)");
        a.AcknowledgementRemarks = remarks;
        history.Record(a.Asset!, AssetEventType.Allocated, $"Handover {a.AllocationNo} acknowledged by {a.AcknowledgedBy}.", "AssetAllocation", a.Id, a.AllocationNo);
        await db.SaveChangesAsync(ct);
    }

    public async Task<AssetReturn> ReturnAsync(ReturnInput input, CancellationToken ct = default)
    {
        var alloc = await db.AssetAllocations.Include(a => a.Asset).FirstOrDefaultAsync(a => a.Id == input.AllocationId, ct)
                    ?? throw new BusinessException("Issue record not found.");
        if (alloc.Status != AllocationStatus.Active) throw new BusinessException("This asset has already been returned.");
        var asset = alloc.Asset!;
        user.EnsureCanSee(asset);
        if (input.ReturnDate.Date < alloc.IssueDate.Date.AddDays(-1)) throw new BusinessException("Return date cannot be before the issue date.");

        bool late = alloc.ExpectedReturnDate is { } exp && input.ReturnDate.Date > exp.Date;
        var ret = new AssetReturn
        {
            AllocationId = alloc.Id, AssetId = asset.Id, ReturnDate = input.ReturnDate.Date.Add(clock.Now.TimeOfDay),
            ReturnedByEmployeeId = alloc.EmployeeId, ReceivedBy = user.UserName, ReturnCondition = input.ReturnCondition,
            Remarks = input.Remarks, ReturnedLate = late
        };
        db.AssetReturns.Add(ret);
        alloc.Status = AllocationStatus.Returned;
        if (asset.AssignedEmployeeId == alloc.EmployeeId) asset.AssignedEmployeeId = null;
        asset.Condition = input.ReturnCondition;
        history.Record(asset, AssetEventType.Returned,
            $"Returned against {alloc.AllocationNo} in {input.ReturnCondition.DisplayName()} condition{(late ? " (late)" : "")}. {input.Remarks}".Trim(),
            "AssetAllocation", alloc.Id, alloc.AllocationNo);
        if (input.SendForRepair || input.ReturnCondition is AssetCondition.Damaged or AssetCondition.NotWorking)
            history.ChangeStatus(asset, AssetStatus.UnderRepair, "Returned damaged / not working", "AssetAllocation", alloc.Id, alloc.AllocationNo);
        await db.SaveChangesAsync(ct);
        return ret;
    }

    public async Task<List<AssetAllocation>> OverdueAsync(CancellationToken ct = default)
    {
        var today = clock.Today;
        return await db.AssetAllocations.AsNoTracking().Include(a => a.Asset).Include(a => a.Employee)
            .Where(a => a.Status == AllocationStatus.Active && a.ExpectedReturnDate != null && a.ExpectedReturnDate < today)
            .OrderBy(a => a.ExpectedReturnDate).ToListAsync(ct);
    }

    // ------------------------------------------------------------------ transfers

    public async Task<AssetTransfer> RequestTransferAsync(TransferInput input, CancellationToken ct = default)
    {
        var asset = await db.Assets.FirstOrDefaultAsync(a => a.Id == input.AssetId, ct) ?? throw new BusinessException("Asset not found.");
        user.EnsureCanSee(asset);
        if (asset.Status is AssetStatus.Disposed or AssetStatus.LostOrWrittenOff)
            throw new BusinessException("Disposed assets cannot be transferred.");
        if (await db.AssetTransfers.AnyAsync(t => t.AssetId == asset.Id && t.Status == TransferStatus.PendingApproval, ct))
            throw new BusinessException("A transfer for this asset is already awaiting approval.");

        var t = new AssetTransfer
        {
            AssetId = asset.Id, TransferType = input.TransferType, TransferDate = input.TransferDate.Date.Add(clock.Now.TimeOfDay), Reason = input.Reason.Trim(),
            FromEmployeeId = asset.AssignedEmployeeId, FromDepartmentId = asset.DepartmentId, FromBranchId = asset.BranchId, FromLocationId = asset.LocationId,
            ToEmployeeId = asset.AssignedEmployeeId, ToDepartmentId = asset.DepartmentId, ToBranchId = asset.BranchId, ToLocationId = asset.LocationId
        };
        switch (input.TransferType)
        {
            case TransferType.Employee:
                if (input.ToEmployeeId is null) throw new BusinessException("Select the employee receiving the asset.");
                if (input.ToEmployeeId == asset.AssignedEmployeeId) throw new BusinessException("The asset is already assigned to this employee.");
                var emp = await db.Employees.FirstOrDefaultAsync(e => e.Id == input.ToEmployeeId && e.IsActive, ct) ?? throw new BusinessException("Employee not found or inactive.");
                t.ToEmployeeId = emp.Id;
                t.ToDepartmentId = input.ToDepartmentId ?? emp.DepartmentId ?? asset.DepartmentId;
                break;
            case TransferType.Department:
                if (input.ToDepartmentId is null) throw new BusinessException("Select the receiving department.");
                if (input.ToDepartmentId == asset.DepartmentId) throw new BusinessException("The asset already belongs to this department.");
                t.ToDepartmentId = input.ToDepartmentId;
                t.ToEmployeeId = input.ToEmployeeId;
                break;
            case TransferType.Branch:
                if (input.ToBranchId is null) throw new BusinessException("Select the receiving branch.");
                if (input.ToBranchId == asset.BranchId) throw new BusinessException("The asset is already at this branch.");
                t.ToBranchId = input.ToBranchId.Value;
                t.ToLocationId = input.ToLocationId;
                t.ToDepartmentId = input.ToDepartmentId;
                t.ToEmployeeId = input.ToEmployeeId;
                break;
            case TransferType.Location:
                if (input.ToLocationId is null) throw new BusinessException("Select the new location.");
                if (input.ToLocationId == asset.LocationId) throw new BusinessException("The asset is already at this location.");
                t.ToLocationId = input.ToLocationId;
                break;
        }
        if (t.ToLocationId is { } locId)
        {
            var loc = await db.Locations.AsNoTracking().FirstOrDefaultAsync(l => l.Id == locId, ct) ?? throw new BusinessException("Location not found.");
            if (loc.BranchId != t.ToBranchId) throw new BusinessException("The selected location does not belong to the destination branch.");
        }

        t.TransferNo = await numbering.NextDocumentNoAsync("TRF", ct);
        db.AssetTransfers.Add(t);
        await db.SaveChangesAsync(ct);

        bool needs = await approvals.SubmitAsync(ApprovalModule.AssetTransfer, t.Id, t.TransferNo, asset.CurrentBookValue, ct);
        if (!needs) await CompleteTransferAsync(t, asset, ct);
        await db.SaveChangesAsync(ct);
        return t;
    }

    private async Task CompleteTransferAsync(AssetTransfer t, Asset asset, CancellationToken ct)
    {
        // Close the active issue record when the custodian changes.
        if (t.ToEmployeeId != t.FromEmployeeId || t.TransferType == TransferType.Branch)
        {
            var active = await db.AssetAllocations.Where(a => a.AssetId == asset.Id && a.Status == AllocationStatus.Active).ToListAsync(ct);
            foreach (var a in active)
            {
                a.Status = AllocationStatus.Returned;
                db.AssetReturns.Add(new AssetReturn
                {
                    AllocationId = a.Id, AssetId = asset.Id, ReturnDate = clock.UtcNow, ReturnedByEmployeeId = a.EmployeeId,
                    ReceivedBy = user.UserName, ReturnCondition = asset.Condition, Remarks = $"Closed by transfer {t.TransferNo}"
                });
            }
            if (t.ToEmployeeId is { } toEmp)
            {
                string no = await numbering.NextDocumentNoAsync("ALC", ct);
                db.AssetAllocations.Add(new AssetAllocation
                {
                    AllocationNo = no, AssetId = asset.Id, TargetType = AllocationTargetType.Employee, EmployeeId = toEmp,
                    DepartmentId = t.ToDepartmentId, BranchId = t.ToBranchId, LocationId = t.ToLocationId, IssueDate = clock.UtcNow,
                    ConditionAtIssue = asset.Condition, IssuedBy = user.UserName, Purpose = $"Transfer {t.TransferNo}"
                });
            }
        }

        asset.AssignedEmployeeId = t.ToEmployeeId;
        asset.DepartmentId = t.ToDepartmentId;
        asset.BranchId = t.ToBranchId;
        asset.LocationId = t.ToLocationId;
        t.Status = TransferStatus.Completed;
        t.CompletedAt = clock.UtcNow;
        t.CompletedBy = user.UserName;
        history.Record(asset, AssetEventType.Transferred, $"{t.TransferType.DisplayName()} transfer completed. Reason: {t.Reason}", "AssetTransfer", t.Id, t.TransferNo);
    }

    public bool Handles(ApprovalModule module) => module == ApprovalModule.AssetTransfer;

    public async Task OnDecidedAsync(ApprovalModule module, int entityId, bool approved, string? comments, CancellationToken ct)
    {
        var t = await db.AssetTransfers.FirstAsync(x => x.Id == entityId, ct);
        if (t.Status != TransferStatus.PendingApproval) return;
        if (!approved)
        {
            t.Status = TransferStatus.Rejected;
            return;
        }
        var asset = await db.Assets.FirstAsync(a => a.Id == t.AssetId, ct);
        await CompleteTransferAsync(t, asset, ct);
    }

    public string LinkFor(ApprovalModule module, int entityId) => $"/Transfers/Details/{entityId}";
}
