using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Domain.Enums;
using GlobalAssetManagement.Domain.Logic;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace GlobalAssetManagement.Application.Services;

public sealed class DashboardFilter
{
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
    public int? BranchId { get; set; }
    public int? DepartmentId { get; set; }
    public int? CategoryId { get; set; }
}

public sealed record Kpi(string Key, string Label, decimal Value, bool IsMoney, string Icon, string Tone, string? Link);
public sealed record ChartSeries(string Label, List<decimal> Values);
public sealed record ChartData(string Key, string Title, string Type, List<string> Labels, List<ChartSeries> Series, List<string?>? Links = null);
public sealed record DashboardData(List<Kpi> Kpis, List<ChartData> Charts, DateTime From, DateTime To);

/// <summary>Dashboard metrics computed from live database data (no hard-coded statistics).</summary>
public sealed class DashboardService(IAppDbContext db, ICurrentUser user, IClock clock, SettingsService settings, IOptions<AppOptions> options)
{
    public async Task<DashboardData> GetAsync(DashboardFilter f, CancellationToken ct = default)
    {
        var today = clock.Today;
        var to = (f.To ?? today).Date;
        var from = (f.From ?? new DateTime(to.Year, to.Month, 1).AddMonths(-11)).Date;
        if (from > to) (from, to) = (to, from);
        int soon = options.Value.ExpiringSoonDays;

        var assetsQ = db.Assets.AsNoTracking().VisibleTo(user);
        if (f.BranchId is { } b) assetsQ = assetsQ.Where(a => a.BranchId == b);
        if (f.DepartmentId is { } d) assetsQ = assetsQ.Where(a => a.DepartmentId == d);
        if (f.CategoryId is { } c) assetsQ = assetsQ.Where(a => a.CategoryId == c);

        var assets = await assetsQ.Select(a => new
        {
            a.Id, a.Status, a.CategoryId, Category = a.Category!.Name, a.BranchId, Branch = a.Branch!.Name, a.DepartmentId,
            Department = a.Department != null ? a.Department.Name : null, a.PurchaseDate, Gross = a.OriginalCost + a.CapitalizedAdditions,
            a.AccumulatedDepreciation, a.CurrentBookValue, a.WarrantyExpiryDate
        }).ToListAsync(ct);
        var ids = assets.Select(a => a.Id).ToHashSet();
        var active = assets.Where(a => a.Status is not (AssetStatus.Disposed or AssetStatus.LostOrWrittenOff)).ToList();

        var openSr = await db.ServiceRequests.AsNoTracking()
            .Where(s => s.Status != ServiceRequestStatus.Closed && s.Status != ServiceRequestStatus.Cancelled && s.Status != ServiceRequestStatus.Rejected
                        && s.Status != ServiceRequestStatus.Completed && s.Status != ServiceRequestStatus.UserConfirmed)
            .Select(s => s.AssetId).ToListAsync(ct);
        var overdueWo = await db.WorkOrders.AsNoTracking()
            .Where(w => w.DueDate != null && w.DueDate < today && (w.Status == WorkOrderStatus.Open || w.Status == WorkOrderStatus.Assigned || w.Status == WorkOrderStatus.InProgress || w.Status == WorkOrderStatus.OnHold))
            .Select(w => w.AssetId).ToListAsync(ct);
        var upcoming = await db.MaintenanceSchedules.AsNoTracking()
            .Where(s => s.IsActive && s.NextDueDate >= today && s.NextDueDate <= today.AddDays(30)).Select(s => s.AssetId).ToListAsync(ct);
        var amcDue = await db.AMContracts.AsNoTracking()
            .Where(c => c.RenewalStatus == AmcRenewalStatus.RenewalDue || c.RenewalStatus == AmcRenewalStatus.RenewalPendingApproval
                        || (c.RenewalStatus == AmcRenewalStatus.Expired && c.ExpiryDate >= today.AddDays(-30)))
            .Select(c => new { c.Id, Assets = c.CoveredAssets.Select(x => x.AssetId).ToList() }).ToListAsync(ct);
        bool filtered = f.BranchId is not null || f.DepartmentId is not null || f.CategoryId is not null || user.BranchId is not null || user.DepartmentId is not null;

        string Q(string extra) => $"/Assets?{extra}{(f.BranchId is { } bb ? $"&BranchId={bb}" : "")}{(f.DepartmentId is { } dd ? $"&DepartmentId={dd}" : "")}{(f.CategoryId is { } cc ? $"&CategoryId={cc}" : "")}";
        var kpis = new List<Kpi>
        {
            new("total", "Total Assets", active.Count, false, "bi-box-seam", "primary", Q("")),
            new("inservice", "In Service", active.Count(a => a.Status == AssetStatus.InService), false, "bi-check2-circle", "success", Q("Status=InService")),
            new("repair", "Under Repair", active.Count(a => a.Status == AssetStatus.UnderRepair), false, "bi-tools", "orange", Q("Status=UnderRepair")),
            new("maint", "Under Maintenance", active.Count(a => a.Status == AssetStatus.UnderMaintenance), false, "bi-gear", "purple", Q("Status=UnderMaintenance")),
            new("disposed", "Assets Disposed", assets.Count(a => a.Status is AssetStatus.Disposed or AssetStatus.LostOrWrittenOff), false, "bi-trash3", "secondary", Q("IncludeDisposed=true&Status=Disposed")),
            new("warranty", "Under Warranty", active.Count(a => a.WarrantyExpiryDate >= today), false, "bi-shield-check", "cyan", Q("Warranty=Active")),
            new("wsoon", "Warranty Expiring Soon", active.Count(a => a.WarrantyExpiryDate >= today && a.WarrantyExpiryDate <= today.AddDays(soon)), false, "bi-shield-exclamation", "orange", Q("Warranty=ExpiringSoon")),
            new("amc", "AMC Renewal Due", filtered ? amcDue.Count(c => c.Assets.Any(ids.Contains)) : amcDue.Count, false, "bi-file-earmark-text", "orange", "/Amc?status=RenewalDue"),
            new("sr", "Pending Service Requests", openSr.Count(ids.Contains), false, "bi-ticket-detailed", "primary", "/ServiceRequests?open=true"),
            new("overdue", "Overdue Repairs", overdueWo.Count(ids.Contains), false, "bi-alarm", "danger", "/WorkOrders?overdue=true"),
            new("upcoming", "Upcoming Maintenance (30 days)", upcoming.Count(ids.Contains), false, "bi-calendar-check", "purple", "/MaintenanceSchedules"),
            new("cost", "Total Acquisition Cost", active.Sum(a => a.Gross), true, "bi-currency-rupee", "primary", "/Reports/View/asset-register"),
            new("accdep", "Accumulated Depreciation", active.Sum(a => a.AccumulatedDepreciation), true, "bi-graph-down-arrow", "secondary", "/Reports/View/depreciation-register"),
            new("bv", "Current Book Value", active.Sum(a => a.Gross - a.AccumulatedDepreciation), true, "bi-wallet2", "success", "/Reports/View/valuation"),
        };

        var charts = new List<ChartData>();

        var byCat = active.GroupBy(a => new { a.CategoryId, a.Category }).OrderByDescending(g => g.Count()).ToList();
        charts.Add(new("category", "Assets by Category", "doughnut", byCat.Select(g => g.Key.Category).ToList(),
            new() { new("Assets", byCat.Select(g => (decimal)g.Count()).ToList()) }, byCat.Select(g => (string?)Q($"CategoryId={g.Key.CategoryId}")).ToList()));

        var byDept = active.GroupBy(a => new { a.DepartmentId, Name = a.Department ?? "(Unassigned)" }).OrderByDescending(g => g.Count()).Take(12).ToList();
        charts.Add(new("department", "Assets by Department", "bar", byDept.Select(g => g.Key.Name).ToList(),
            new() { new("Assets", byDept.Select(g => (decimal)g.Count()).ToList()) },
            byDept.Select(g => g.Key.DepartmentId is { } id ? (string?)Q($"DepartmentId={id}") : null).ToList()));

        var byBranch = active.GroupBy(a => new { a.BranchId, a.Branch }).OrderByDescending(g => g.Count()).ToList();
        charts.Add(new("branch", "Assets by Branch", "bar", byBranch.Select(g => g.Key.Branch).ToList(),
            new()
            {
                new("Assets", byBranch.Select(g => (decimal)g.Count()).ToList()),
            }, byBranch.Select(g => (string?)Q($"BranchId={g.Key.BranchId}")).ToList()));

        var byStatus = assets.GroupBy(a => a.Status).OrderBy(g => g.Key).ToList();
        charts.Add(new("status", "Asset Status Distribution", "pie", byStatus.Select(g => g.Key.DisplayName()).ToList(),
            new() { new("Assets", byStatus.Select(g => (decimal)g.Count()).ToList()) },
            byStatus.Select(g => (string?)Q($"Status={g.Key}&IncludeDisposed=true")).ToList()));

        var months = new List<DateTime>();
        for (var m = new DateTime(from.Year, from.Month, 1); m <= to; m = m.AddMonths(1)) months.Add(m);
        if (months.Count > 36) months = months.TakeLast(36).ToList();
        var monthLabels = months.Select(m => m.ToString("MMM yy")).ToList();

        var acq = assets.Where(a => a.PurchaseDate >= from && a.PurchaseDate <= to).ToList();
        charts.Add(new("acquisitions", "Monthly Asset Acquisitions", "bar", monthLabels, new()
        {
            new("Assets acquired", months.Select(m => (decimal)acq.Count(a => a.PurchaseDate!.Value.Year == m.Year && a.PurchaseDate.Value.Month == m.Month)).ToList()),
            new("Cost", months.Select(m => acq.Where(a => a.PurchaseDate!.Value.Year == m.Year && a.PurchaseDate.Value.Month == m.Month).Sum(a => a.Gross)).ToList()),
        }));

        var fromUtc = from.AddDays(-1);
        var toUtc = to.AddDays(1);
        var work = (await db.WorkOrders.AsNoTracking()
            .Where(w => w.WorkCompletedAt != null && w.WorkCompletedAt >= fromUtc && w.WorkCompletedAt < toUtc)
            .Select(w => new { w.AssetId, w.WorkType, w.TotalCost, w.WorkCompletedAt }).ToListAsync(ct))
            .Where(w => ids.Contains(w.AssetId)).ToList();
        charts.Add(new("maintenance", "Maintenance Expenses", "line", monthLabels, new()
        {
            new("Preventive / scheduled", months.Select(m => work.Where(w => w.WorkType != WorkType.Breakdown && clock.ToLocal(w.WorkCompletedAt!.Value).Year == m.Year && clock.ToLocal(w.WorkCompletedAt!.Value).Month == m.Month).Sum(w => w.TotalCost)).ToList())
        }));
        charts.Add(new("repairs", "Repair Costs", "line", monthLabels, new()
        {
            new("Breakdown repairs", months.Select(m => work.Where(w => w.WorkType == WorkType.Breakdown && clock.ToLocal(w.WorkCompletedAt!.Value).Year == m.Year && clock.ToLocal(w.WorkCompletedAt!.Value).Month == m.Month).Sum(w => w.TotalCost)).ToList())
        }));

        var forecastMonths = Enumerable.Range(0, 12).Select(i => new DateTime(today.Year, today.Month, 1).AddMonths(i)).ToList();
        charts.Add(new("warrantyForecast", "Warranty Expiry Forecast (next 12 months)", "bar", forecastMonths.Select(m => m.ToString("MMM yy")).ToList(), new()
        {
            new("Warranties expiring", forecastMonths.Select(m => (decimal)active.Count(a => a.WarrantyExpiryDate is { } e && e.Year == m.Year && e.Month == m.Month)).ToList())
        }));

        var amc = await db.AMContracts.AsNoTracking().Where(c => c.StartDate <= to && c.ExpiryDate >= from && c.RenewalStatus != AmcRenewalStatus.Cancelled)
            .Select(c => new { Provider = c.ServiceProvider!.CompanyName, c.AnnualValue, Assets = c.CoveredAssets.Select(x => x.AssetId).ToList() }).ToListAsync(ct);
        if (filtered) amc = amc.Where(c => c.Assets.Any(ids.Contains)).ToList();
        var amcBy = amc.GroupBy(c => c.Provider).OrderByDescending(g => g.Sum(x => x.AnnualValue)).ToList();
        charts.Add(new("amc", "AMC Expenses by Provider", "bar", amcBy.Select(g => g.Key).ToList(),
            new() { new("Annual contract value", amcBy.Select(g => g.Sum(x => x.AnnualValue)).ToList()) }));

        int fyStart = (await settings.GetCompanyAsync(ct)).FinancialYearStartMonth;
        var dep = (await db.DepreciationTransactions.AsNoTracking().Select(t => new { t.AssetId, t.PeriodTo, t.DepreciationAmount }).ToListAsync(ct))
            .Where(t => ids.Contains(t.AssetId))
            .GroupBy(t => FinancialYear.For(t.PeriodTo, fyStart).Label).OrderBy(g => g.Key).TakeLast(6).ToList();
        charts.Add(new("depreciation", "Depreciation Summary by Financial Year", "bar", dep.Select(g => "FY " + g.Key).ToList(),
            new() { new("Depreciation", dep.Select(g => g.Sum(x => x.DepreciationAmount)).ToList()) }));

        return new DashboardData(kpis, charts, from, to);
    }
}
