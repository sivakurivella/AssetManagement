using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using GlobalAssetManagement.Domain.Logic;
using Microsoft.EntityFrameworkCore;

namespace GlobalAssetManagement.Application.Services;

public sealed record DepreciationLine(Asset Asset, DateTime EffectiveFrom, DepreciationResult Result);

public sealed record ValuationRow(string Group, int Count, decimal OriginalCost, decimal Additions, decimal Accumulated, decimal BookValue);

/// <summary>Period depreciation runs (preview → post → optional reversal) and disposal catch-up depreciation.</summary>
public sealed class DepreciationService(
    IAppDbContext db,
    NumberingService numbering,
    SettingsService settings,
    AssetHistory history,
    ICurrentUser user,
    IClock clock)
{
    public async Task<List<DepreciationLine>> PreviewAsync(DateTime periodFrom, DateTime periodTo, int? branchId, CancellationToken ct = default)
    {
        periodFrom = periodFrom.Date;
        periodTo = periodTo.Date;
        if (periodTo < periodFrom) throw new BusinessException("Period end is before period start.");
        if (periodTo > clock.Today.AddYears(1)) throw new BusinessException("Depreciation cannot be calculated that far into the future.");

        var q = db.Assets.VisibleTo(user)
            .Where(a => a.Status != AssetStatus.Disposed && a.Status != AssetStatus.LostOrWrittenOff
                        && a.Status != AssetStatus.Requested && a.Status != AssetStatus.Ordered
                        && a.DepreciationMethod != DepreciationMethod.None
                        && (a.DepreciatedUpTo == null || a.DepreciatedUpTo < periodTo));
        if (branchId is not null) q = q.Where(a => a.BranchId == branchId);
        var list = await q.Include(a => a.Category).OrderBy(a => a.AssetTag).ToListAsync(ct);

        var ids = list.Select(a => a.Id).ToList();
        var additions = await db.AssetAdditions.AsNoTracking()
            .Where(x => ids.Contains(x.AssetId) && x.Status == AdditionStatus.Capitalized && x.CapitalizationDate != null)
            .ToListAsync(ct);

        var lines = new List<DepreciationLine>();
        foreach (var a in list)
        {
            var line = Calculate(a, periodFrom, periodTo, additions.Where(x => x.AssetId == a.Id).ToList());
            if (line is not null) lines.Add(line);
        }
        return lines;
    }

    public static DepreciationLine? Calculate(Asset a, DateTime periodFrom, DateTime periodTo, IReadOnlyList<AssetAddition> capitalized)
    {
        var depStart = (a.DepreciationStartDate ?? a.CommissioningDate ?? a.InstallationDate ?? a.PurchaseDate ?? a.CreatedAt).Date;
        var effectiveFrom = periodFrom;
        if (a.DepreciatedUpTo is { } upTo && upTo.Date >= effectiveFrom) effectiveFrom = upTo.Date.AddDays(1);
        if (effectiveFrom > periodTo || depStart > periodTo) return null;

        var later = capitalized.Where(x => x.CapitalizationDate!.Value.Date >= effectiveFrom).OrderBy(x => x.CapitalizationDate).ToList();
        decimal grossAtStart = a.GrossCost - later.Sum(x => x.CapitalizableAmount);
        decimal life = later.FirstOrDefault(x => x.RevisedUsefulLifeYears is > 0) is { } firstRevision ? firstRevision.PreviousUsefulLifeYears : a.UsefulLifeYears;

        var profile = new DepreciationProfile(a.DepreciationMethod, a.DepreciationRate, life, a.ResidualValue, depStart, grossAtStart, a.AccumulatedDepreciation);
        var inPeriod = later.Where(x => x.CapitalizationDate!.Value.Date <= periodTo)
            .Select(x => new CapitalAddition(x.CapitalizationDate!.Value, x.CapitalizableAmount, x.RevisedUsefulLifeYears is > 0 ? x.RevisedUsefulLifeYears : null));
        var result = DepreciationCalculator.Calculate(profile, effectiveFrom, periodTo, inPeriod);
        return new DepreciationLine(a, effectiveFrom, result);
    }

    public async Task<DepreciationSchedule> PostAsync(DateTime periodFrom, DateTime periodTo, int? branchId, string? remarks, CancellationToken ct = default)
    {
        var lines = (await PreviewAsync(periodFrom, periodTo, branchId, ct)).Where(l => l.Result.Amount > 0 || l.Result.Days > 0).ToList();
        if (lines.Count == 0) throw new BusinessException("There is no depreciation to post for this period (assets may already be depreciated up to the period end).");

        var fy = await settings.FinancialYearForAsync(periodFrom, ct);
        string no = await numbering.NextDocumentNoAsync("DEP", ct);
        var tx = db.Database.IsRelational() ? await db.Database.BeginTransactionAsync(ct) : null;
        try
        {
            var run = new DepreciationSchedule
            {
                RunNo = no, FinancialYear = fy.Label, PeriodFrom = periodFrom.Date, PeriodTo = periodTo.Date, BranchId = branchId,
                Status = DepreciationRunStatus.Posted, PostedAt = clock.UtcNow, PostedBy = user.UserName, Remarks = remarks
            };
            foreach (var l in lines)
            {
                var a = l.Asset;
                var r = l.Result;
                run.Transactions.Add(new DepreciationTransaction
                {
                    AssetId = a.Id, PeriodFrom = l.EffectiveFrom, PeriodTo = periodTo.Date, Days = r.Days, Method = a.DepreciationMethod,
                    Rate = a.DepreciationRate, OpeningGrossCost = r.OpeningGross, AdditionsInPeriod = r.Additions,
                    OpeningAccumulated = r.OpeningAccumulated, OpeningBookValue = r.OpeningBookValue, DepreciationAmount = r.Amount,
                    ClosingAccumulated = r.ClosingAccumulated, ClosingBookValue = r.ClosingBookValue, PostedAt = clock.UtcNow
                });
                a.AccumulatedDepreciation = r.ClosingAccumulated;
                a.CurrentBookValue = a.GrossCost - a.AccumulatedDepreciation;
                a.DepreciatedUpTo = periodTo.Date;
                if (r.Amount > 0)
                    history.Record(a, AssetEventType.Depreciation, $"Depreciation {r.Amount:N2} for {l.EffectiveFrom:dd-MM-yyyy} to {periodTo:dd-MM-yyyy} ({no}). Book value {a.CurrentBookValue:N2}.", "DepreciationSchedule", null, no);
            }
            run.AssetCount = run.Transactions.Count;
            run.TotalDepreciation = run.Transactions.Sum(t => t.DepreciationAmount);
            db.DepreciationSchedules.Add(run);
            await db.SaveChangesAsync(ct);
            if (tx is not null) await tx.CommitAsync(ct);
            return run;
        }
        catch
        {
            if (tx is not null) await tx.RollbackAsync(ct);
            throw;
        }
        finally
        {
            if (tx is not null) await tx.DisposeAsync();
        }
    }

    /// <summary>Reverses a posted run when none of its assets has a later depreciation entry.</summary>
    public async Task ReverseAsync(int runId, string reason, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(reason)) throw new BusinessException("Enter the reason for reversal.");
        var run = await db.DepreciationSchedules.Include(r => r.Transactions).FirstOrDefaultAsync(r => r.Id == runId, ct)
                  ?? throw new BusinessException("Depreciation run not found.");
        if (run.Status != DepreciationRunStatus.Posted) throw new BusinessException("Only posted runs can be reversed.");
        var ids = run.Transactions.Select(t => t.AssetId).ToList();
        bool later = await db.DepreciationTransactions.AnyAsync(t => ids.Contains(t.AssetId) && t.PeriodFrom > run.PeriodTo, ct);
        if (later) throw new BusinessException("Later depreciation has been posted for some of these assets. Reverse the later runs first.");
        if (await db.AssetDisposals.AnyAsync(d => ids.Contains(d.AssetId) && d.Status == DisposalStatus.Completed, ct))
            throw new BusinessException("Some assets in this run have since been disposed of; the run can no longer be reversed.");

        var assetsList = await db.Assets.Where(a => ids.Contains(a.Id)).ToListAsync(ct);
        foreach (var t in run.Transactions)
        {
            var a = assetsList.First(x => x.Id == t.AssetId);
            a.AccumulatedDepreciation -= t.DepreciationAmount;
            a.CurrentBookValue = a.GrossCost - a.AccumulatedDepreciation;
            a.DepreciatedUpTo = t.PeriodFrom.AddDays(-1) < (a.DepreciationStartDate ?? DateTime.MinValue) ? null : t.PeriodFrom.AddDays(-1);
            if (a.AccumulatedDepreciation == 0) a.DepreciatedUpTo = null;
            history.Record(a, AssetEventType.Depreciation, $"Depreciation run {run.RunNo} reversed: {reason}", "DepreciationSchedule", run.Id, run.RunNo);
        }
        run.Status = DepreciationRunStatus.Reversed;
        run.Remarks = (run.Remarks + $"\nReversed by {user.UserName}: {reason}").Trim();
        db.DepreciationTransactions.RemoveRange(run.Transactions);
        await db.SaveChangesAsync(ct);
    }

    /// <summary>Posts depreciation from the last posted date up to the day before disposal. Does not save.</summary>
    public async Task<DepreciationTransaction?> CatchUpForDisposalAsync(Asset a, DateTime disposalDate, CancellationToken ct = default)
    {
        if (a.DepreciationMethod == DepreciationMethod.None) return null;
        var to = disposalDate.Date.AddDays(-1);
        var from = a.DepreciatedUpTo is { } up ? up.AddDays(1) : (a.DepreciationStartDate ?? a.PurchaseDate ?? a.CreatedAt).Date;
        if (to < from) return null;
        var additions = await db.AssetAdditions.AsNoTracking()
            .Where(x => x.AssetId == a.Id && x.Status == AdditionStatus.Capitalized && x.CapitalizationDate != null).ToListAsync(ct);
        var line = Calculate(a, from, to, additions);
        if (line is null) return null;
        var r = line.Result;
        var t = new DepreciationTransaction
        {
            AssetId = a.Id, PeriodFrom = line.EffectiveFrom, PeriodTo = to, Days = r.Days, Method = a.DepreciationMethod, Rate = a.DepreciationRate,
            OpeningGrossCost = r.OpeningGross, AdditionsInPeriod = r.Additions, OpeningAccumulated = r.OpeningAccumulated,
            OpeningBookValue = r.OpeningBookValue, DepreciationAmount = r.Amount, ClosingAccumulated = r.ClosingAccumulated,
            ClosingBookValue = r.ClosingBookValue, IsDisposalCatchUp = true, PostedAt = clock.UtcNow
        };
        db.DepreciationTransactions.Add(t);
        a.AccumulatedDepreciation = r.ClosingAccumulated;
        a.CurrentBookValue = a.GrossCost - a.AccumulatedDepreciation;
        a.DepreciatedUpTo = to;
        return t;
    }

    public async Task<List<ValuationRow>> ValuationAsync(string groupBy, int? branchId, CancellationToken ct = default)
    {
        var q = db.Assets.AsNoTracking().VisibleTo(user)
            .Where(a => a.Status != AssetStatus.Disposed && a.Status != AssetStatus.LostOrWrittenOff);
        if (branchId is not null) q = q.Where(a => a.BranchId == branchId);
        var data = await q.Select(a => new
        {
            Category = a.Category!.Name, Branch = a.Branch!.Name, Department = a.Department != null ? a.Department.Name : "(No department)",
            a.PurchaseDate, a.OriginalCost, a.CapitalizedAdditions, a.AccumulatedDepreciation
        }).ToListAsync(ct);
        int fyMonth = (await settings.GetCompanyAsync(ct)).FinancialYearStartMonth;
        return data.GroupBy(d => groupBy switch
            {
                "branch" => d.Branch,
                "department" => d.Department,
                "year" => d.PurchaseDate is { } p ? "FY " + FinancialYear.For(p, fyMonth).Label : "(No purchase date)",
                _ => d.Category
            })
            .Select(g => new ValuationRow(g.Key, g.Count(), g.Sum(x => x.OriginalCost), g.Sum(x => x.CapitalizedAdditions),
                g.Sum(x => x.AccumulatedDepreciation), g.Sum(x => x.OriginalCost + x.CapitalizedAdditions - x.AccumulatedDepreciation)))
            .OrderBy(r => r.Group).ToList();
    }
}
