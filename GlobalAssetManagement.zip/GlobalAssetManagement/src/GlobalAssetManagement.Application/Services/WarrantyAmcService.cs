using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Application.Models;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using GlobalAssetManagement.Domain.Logic;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace GlobalAssetManagement.Application.Services;

public sealed record WarrantyRow(WarrantyRecord Record, string AssetTag, string AssetName, CoverageStatus Status, int DaysLeft);

public sealed class WarrantyAmcService(
    IAppDbContext db,
    ApprovalService approvals,
    AssetHistory history,
    ICurrentUser user,
    IClock clock,
    IOptions<AppOptions> options) : IApprovalHandler
{
    private readonly AppOptions _opt = options.Value;

    // ------------------------------------------------------------------ warranty

    public async Task<List<WarrantyRow>> WarrantiesAsync(CoverageStatus? status, int? branchId, CancellationToken ct = default)
    {
        var q = db.WarrantyRecords.AsNoTracking().Include(w => w.Asset)
            .Where(w => w.Asset!.Status != AssetStatus.Disposed && w.Asset.Status != AssetStatus.LostOrWrittenOff);
        int? ub = user.BranchId;
        if (ub is not null) q = q.Where(w => w.Asset!.BranchId == ub);
        if (branchId is not null) q = q.Where(w => w.Asset!.BranchId == branchId);
        var today = clock.Today;
        var rows = (await q.OrderBy(w => w.ExpiryDate).ToListAsync(ct))
            .Select(w => new WarrantyRow(w, w.Asset!.AssetTag, w.Asset.Name,
                CoverageEvaluator.Evaluate(w.ExpiryDate, today, _opt.ExpiringSoonDays), (w.ExpiryDate.Date - today).Days))
            .ToList();
        return status is null ? rows : rows.Where(r => r.Status == status).ToList();
    }

    public async Task<WarrantyRecord> SaveWarrantyAsync(WarrantyInput input, CancellationToken ct = default)
    {
        if (input.ExpiryDate < input.StartDate) throw new BusinessException("Expiry date cannot be before the start date.");
        var asset = await db.Assets.FirstOrDefaultAsync(a => a.Id == input.AssetId, ct) ?? throw new BusinessException("Asset not found.");
        user.EnsureCanSee(asset);

        WarrantyRecord w;
        if (input.Id == 0) { w = new WarrantyRecord(); db.WarrantyRecords.Add(w); }
        else w = await db.WarrantyRecords.FirstOrDefaultAsync(x => x.Id == input.Id, ct) ?? throw new BusinessException("Warranty record not found.");

        w.AssetId = asset.Id;
        w.WarrantyType = input.WarrantyType;
        w.Provider = input.Provider.Trim();
        w.StartDate = input.StartDate.Date;
        w.ExpiryDate = input.ExpiryDate.Date;
        w.Terms = input.Terms;
        w.CoverageDetails = input.CoverageDetails;
        w.ClaimContact = input.ClaimContact;
        w.CertificateNo = input.CertificateNo;
        w.IsPrimary = input.IsPrimary;

        if (input.IsPrimary)
        {
            foreach (var other in await db.WarrantyRecords.Where(x => x.AssetId == asset.Id && x.IsPrimary && x.Id != w.Id).ToListAsync(ct))
                other.IsPrimary = false;
            asset.WarrantyStartDate = w.StartDate;
            asset.WarrantyExpiryDate = w.ExpiryDate;
        }
        history.Record(asset, AssetEventType.Warranty, $"{w.WarrantyType.DisplayName()} warranty by {w.Provider} recorded: {w.StartDate:dd-MM-yyyy} to {w.ExpiryDate:dd-MM-yyyy}.", "WarrantyRecord");
        await db.SaveChangesAsync(ct);
        return w;
    }

    public async Task DeleteWarrantyAsync(int id, CancellationToken ct = default)
    {
        var w = await db.WarrantyRecords.Include(x => x.Asset).FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new BusinessException("Warranty record not found.");
        user.EnsureCanSee(w.Asset!);
        db.WarrantyRecords.Remove(w);
        if (w.IsPrimary)
        {
            var next = await db.WarrantyRecords.Where(x => x.AssetId == w.AssetId && x.Id != id).OrderByDescending(x => x.ExpiryDate).FirstOrDefaultAsync(ct);
            if (next is not null) next.IsPrimary = true;
            w.Asset!.WarrantyStartDate = next?.StartDate;
            w.Asset.WarrantyExpiryDate = next?.ExpiryDate;
        }
        await db.SaveChangesAsync(ct);
    }

    // ------------------------------------------------------------------ AMC

    public async Task<AMContract> SaveAmcAsync(AmcInput input, CancellationToken ct = default)
    {
        if (input.ExpiryDate <= input.StartDate) throw new BusinessException("Expiry date must be after the start date.");
        string no = input.ContractNo.Trim();
        if (await db.AMContracts.AnyAsync(c => c.ContractNo == no && c.Id != input.Id, ct))
            throw new BusinessException($"Contract number {no} already exists.");

        AMContract c;
        if (input.Id == 0) { c = new AMContract(); db.AMContracts.Add(c); }
        else c = await db.AMContracts.Include(x => x.CoveredAssets).FirstOrDefaultAsync(x => x.Id == input.Id, ct) ?? throw new BusinessException("Contract not found.");

        c.ContractNo = no;
        c.ServiceProviderId = input.ServiceProviderId!.Value;
        c.ContractType = input.ContractType;
        c.StartDate = input.StartDate.Date;
        c.ExpiryDate = input.ExpiryDate.Date;
        c.AnnualValue = input.AnnualValue;
        c.TaxAmount = input.TaxAmount;
        c.VisitsPerYear = input.VisitsPerYear;
        c.ResponseTimeHours = input.ResponseTimeHours;
        c.ResolutionTimeHours = input.ResolutionTimeHours;
        c.Coverage = input.Coverage;
        c.Terms = input.Terms;
        c.RenewalStatus = CoverageEvaluator.EvaluateAmc(c.Id == 0 ? AmcRenewalStatus.Active : c.RenewalStatus, c.ExpiryDate, clock.Today, _opt.AmcRenewalWindowDays);

        var ids = input.AssetIds.Distinct().ToList();
        var assets = await db.Assets.Where(a => ids.Contains(a.Id)).ToListAsync(ct);
        foreach (var gone in c.CoveredAssets.Where(x => !ids.Contains(x.AssetId)).ToList())
        {
            c.CoveredAssets.Remove(gone);
            db.AMContractAssets.Remove(gone);
        }
        foreach (var a in assets.Where(a => c.CoveredAssets.All(x => x.AssetId != a.Id)))
        {
            c.CoveredAssets.Add(new AMContractAsset { AssetId = a.Id });
            history.Record(a, AssetEventType.Amc, $"Covered by AMC {no} ({c.StartDate:dd-MM-yyyy} to {c.ExpiryDate:dd-MM-yyyy}).", "AMContract", null, no);
        }
        await db.SaveChangesAsync(ct);

        if (input.GenerateVisits && input.VisitsPerYear > 0 && !await db.ServiceVisits.AnyAsync(v => v.AMContractId == c.Id, ct))
        {
            var span = (c.ExpiryDate - c.StartDate).TotalDays;
            int visits = Math.Max(1, (int)Math.Round(input.VisitsPerYear * span / 365.0));
            for (int i = 0; i < visits; i++)
            {
                var date = c.StartDate.AddDays(span / visits * (i + 0.5)).Date;
                db.ServiceVisits.Add(new ServiceVisit { AMContractId = c.Id, ServiceProviderId = c.ServiceProviderId, ScheduledDate = date, Status = ServiceVisitStatus.Scheduled });
            }
            await db.SaveChangesAsync(ct);
        }
        return c;
    }

    public async Task<ServiceVisit> SaveVisitAsync(ServiceVisitInput input, CancellationToken ct = default)
    {
        ServiceVisit v;
        if (input.Id == 0) { v = new ServiceVisit(); db.ServiceVisits.Add(v); }
        else v = await db.ServiceVisits.FirstOrDefaultAsync(x => x.Id == input.Id, ct) ?? throw new BusinessException("Visit not found.");

        AMContract? contract = null;
        if ((input.AMContractId ?? v.AMContractId) is { } cid)
            contract = await db.AMContracts.FirstOrDefaultAsync(c => c.Id == cid, ct);
        if (input.RespondedAt is { } r && input.CallLoggedAt is { } l && r < l) throw new BusinessException("Response time cannot be before the call was logged.");
        if (input.ResolvedAt is { } rs && input.RespondedAt is { } rp && rs < rp) throw new BusinessException("Resolution cannot be before the response.");

        v.AMContractId = input.AMContractId ?? v.AMContractId;
        v.AssetId = input.AssetId;
        v.ServiceProviderId = contract?.ServiceProviderId ?? v.ServiceProviderId;
        v.ScheduledDate = input.ScheduledDate.Date;
        v.CallLoggedAt = input.CallLoggedAt;
        v.RespondedAt = input.RespondedAt;
        v.ResolvedAt = input.ResolvedAt;
        v.EngineerName = input.EngineerName;
        v.WorkDone = input.WorkDone;
        v.Status = input.Status;
        v.SlaMet = contract is not null && v.CallLoggedAt is { } logged && v.RespondedAt is { } resp
            ? (resp - logged).TotalHours <= contract.ResponseTimeHours
            : null;
        if (v.Status == ServiceVisitStatus.Completed && v.AssetId is { } aid)
        {
            var asset = await db.Assets.FirstAsync(a => a.Id == aid, ct);
            asset.LastServiceDate = (v.ResolvedAt ?? v.RespondedAt ?? clock.Now).Date;
            history.Record(asset, AssetEventType.Amc, $"AMC service visit by {v.EngineerName ?? "provider"}: {v.WorkDone}", "ServiceVisit");
        }
        await db.SaveChangesAsync(ct);
        return v;
    }

    public async Task RequestRenewalAsync(int contractId, decimal proposedCost, CancellationToken ct = default)
    {
        var c = await db.AMContracts.FirstOrDefaultAsync(x => x.Id == contractId, ct) ?? throw new BusinessException("Contract not found.");
        if (c.RenewalStatus is AmcRenewalStatus.Renewed or AmcRenewalStatus.Cancelled or AmcRenewalStatus.RenewalPendingApproval)
            throw new BusinessException($"This contract is {c.RenewalStatus.DisplayName()}.");
        if (proposedCost <= 0) throw new BusinessException("Enter the renewal cost.");
        c.ProposedRenewalCost = proposedCost;
        bool needs = await approvals.SubmitAsync(ApprovalModule.AmcRenewal, c.Id, c.ContractNo, proposedCost, ct);
        if (needs) c.RenewalStatus = AmcRenewalStatus.RenewalPendingApproval;
        else await RenewAsync(c, ct);
        await db.SaveChangesAsync(ct);
    }

    private async Task<AMContract> RenewAsync(AMContract old, CancellationToken ct)
    {
        await db.Entry(old).Collection(x => x.CoveredAssets).LoadAsync(ct);
        int n = await db.AMContracts.CountAsync(x => x.ContractNo.StartsWith(old.ContractNo + "/R"), ct) + 1;
        var start = old.ExpiryDate.AddDays(1);
        var renewed = new AMContract
        {
            ContractNo = $"{old.ContractNo}/R{n}", ServiceProviderId = old.ServiceProviderId, ContractType = old.ContractType,
            StartDate = start, ExpiryDate = start.AddYears(1).AddDays(-1), AnnualValue = old.ProposedRenewalCost ?? old.AnnualValue,
            VisitsPerYear = old.VisitsPerYear, ResponseTimeHours = old.ResponseTimeHours, ResolutionTimeHours = old.ResolutionTimeHours,
            Coverage = old.Coverage, Terms = old.Terms, RenewedFromContractId = old.Id, RenewalStatus = AmcRenewalStatus.Active,
            RenewalApprovedBy = user.UserName, RenewalApprovedAt = clock.UtcNow
        };
        foreach (var a in old.CoveredAssets) renewed.CoveredAssets.Add(new AMContractAsset { AssetId = a.AssetId });
        db.AMContracts.Add(renewed);
        old.RenewalStatus = AmcRenewalStatus.Renewed;
        old.RenewalApprovedBy = user.UserName;
        old.RenewalApprovedAt = clock.UtcNow;
        await db.SaveChangesAsync(ct);

        if (renewed.VisitsPerYear > 0)
        {
            var span = (renewed.ExpiryDate - renewed.StartDate).TotalDays;
            for (int i = 0; i < renewed.VisitsPerYear; i++)
                db.ServiceVisits.Add(new ServiceVisit
                {
                    AMContractId = renewed.Id, ServiceProviderId = renewed.ServiceProviderId,
                    ScheduledDate = renewed.StartDate.AddDays(span / renewed.VisitsPerYear * (i + 0.5)).Date, Status = ServiceVisitStatus.Scheduled
                });
        }
        return renewed;
    }

    /// <summary>Daily refresh of AMC renewal statuses; missed visits are flagged.</summary>
    public async Task<int> RefreshStatusesAsync(CancellationToken ct = default)
    {
        var today = clock.Today;
        int changed = 0;
        foreach (var c in await db.AMContracts.Where(c => c.RenewalStatus == AmcRenewalStatus.Active || c.RenewalStatus == AmcRenewalStatus.RenewalDue).ToListAsync(ct))
        {
            var s = CoverageEvaluator.EvaluateAmc(c.RenewalStatus, c.ExpiryDate, today, _opt.AmcRenewalWindowDays);
            if (s != c.RenewalStatus) { c.RenewalStatus = s; changed++; }
        }
        foreach (var v in await db.ServiceVisits.Where(v => v.Status == ServiceVisitStatus.Scheduled && v.ScheduledDate < today.AddDays(-7)).ToListAsync(ct))
        {
            v.Status = ServiceVisitStatus.Missed;
            changed++;
        }
        await db.SaveChangesAsync(ct);
        return changed;
    }

    public bool Handles(ApprovalModule module) => module == ApprovalModule.AmcRenewal;

    public async Task OnDecidedAsync(ApprovalModule module, int entityId, bool approved, string? comments, CancellationToken ct)
    {
        var c = await db.AMContracts.FirstAsync(x => x.Id == entityId, ct);
        if (!approved)
        {
            c.RenewalStatus = CoverageEvaluator.EvaluateAmc(AmcRenewalStatus.Active, c.ExpiryDate, clock.Today, _opt.AmcRenewalWindowDays);
            c.Terms = (c.Terms + $"\nRenewal rejected: {comments}").Trim();
            return;
        }
        await RenewAsync(c, ct);
    }

    public string LinkFor(ApprovalModule module, int entityId) => $"/Amc/Details/{entityId}";
}
