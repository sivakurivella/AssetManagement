using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Application.Models;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace GlobalAssetManagement.Application.Services;

/// <summary>Purchase request → quotations → purchase order → goods receipt → invoice → asset registration.</summary>
public sealed class ProcurementService(
    IAppDbContext db,
    NumberingService numbering,
    ApprovalService approvals,
    AssetService assets,
    AssetHistory history,
    ICurrentUser user,
    IClock clock) : IApprovalHandler
{
    // ------------------------------------------------------------------ purchase requests

    public async Task<PurchaseRequest> SavePurchaseRequestAsync(PurchaseRequestInput input, CancellationToken ct = default)
    {
        var lines = input.Items.Where(i => !string.IsNullOrWhiteSpace(i.Description) && i.Quantity > 0).ToList();
        if (lines.Count == 0) throw new BusinessException("Add at least one item to the purchase request.");

        PurchaseRequest pr;
        if (input.Id == 0)
        {
            string no = await numbering.NextDocumentNoAsync("PR", ct);
            pr = new PurchaseRequest { RequestNo = no, Status = PurchaseRequestStatus.Draft };
            db.PurchaseRequests.Add(pr);
        }
        else
        {
            pr = await db.PurchaseRequests.Include(p => p.Items).FirstOrDefaultAsync(p => p.Id == input.Id, ct)
                 ?? throw new BusinessException("Purchase request not found.");
            if (pr.Status is not (PurchaseRequestStatus.Draft or PurchaseRequestStatus.Rejected))
                throw new BusinessException("Only draft or rejected purchase requests can be edited.");
            db.PurchaseRequestItems.RemoveRange(pr.Items);
            pr.Items.Clear();
            pr.Status = PurchaseRequestStatus.Draft;
        }

        pr.RequestDate = input.RequestDate.Date;
        pr.RequestedByEmployeeId = input.RequestedByEmployeeId ?? user.EmployeeId;
        pr.BranchId = input.BranchId!.Value;
        pr.DepartmentId = input.DepartmentId;
        pr.Purpose = input.Purpose.Trim();
        pr.RequiredByDate = input.RequiredByDate;
        pr.Priority = input.Priority;
        pr.Remarks = input.Remarks;
        foreach (var l in lines)
            pr.Items.Add(new PurchaseRequestItem
            {
                Description = l.Description!.Trim(), CategoryId = l.CategoryId, Quantity = l.Quantity,
                EstimatedUnitCost = l.UnitPrice, Specifications = l.Specifications
            });
        pr.EstimatedTotal = pr.Items.Sum(i => Math.Round(i.Quantity * i.EstimatedUnitCost, 2));
        await db.SaveChangesAsync(ct);
        return pr;
    }

    public async Task SubmitPurchaseRequestAsync(int id, CancellationToken ct = default)
    {
        var pr = await db.PurchaseRequests.FirstOrDefaultAsync(p => p.Id == id, ct) ?? throw new BusinessException("Purchase request not found.");
        if (pr.Status is not (PurchaseRequestStatus.Draft or PurchaseRequestStatus.Rejected))
            throw new BusinessException("Only draft purchase requests can be submitted.");
        bool needs = await approvals.SubmitAsync(ApprovalModule.PurchaseRequest, pr.Id, pr.RequestNo, pr.EstimatedTotal, ct);
        pr.Status = needs ? PurchaseRequestStatus.PendingApproval : PurchaseRequestStatus.Approved;
        await db.SaveChangesAsync(ct);
    }

    public async Task CancelPurchaseRequestAsync(int id, CancellationToken ct = default)
    {
        var pr = await db.PurchaseRequests.FirstOrDefaultAsync(p => p.Id == id, ct) ?? throw new BusinessException("Purchase request not found.");
        if (pr.Status is PurchaseRequestStatus.Ordered or PurchaseRequestStatus.Closed)
            throw new BusinessException("An ordered purchase request cannot be cancelled.");
        pr.Status = PurchaseRequestStatus.Cancelled;
        foreach (var a in await db.Approvals.Where(a => a.Module == ApprovalModule.PurchaseRequest && a.EntityId == id && a.Status == ApprovalStatus.Pending).ToListAsync(ct))
            a.Status = ApprovalStatus.Cancelled;
        await db.SaveChangesAsync(ct);
    }

    public async Task<Quotation> AddQuotationAsync(QuotationInput input, CancellationToken ct = default)
    {
        var pr = await db.PurchaseRequests.FirstOrDefaultAsync(p => p.Id == input.PurchaseRequestId, ct) ?? throw new BusinessException("Purchase request not found.");
        if (pr.Status is not (PurchaseRequestStatus.Approved or PurchaseRequestStatus.QuotationsInvited))
            throw new BusinessException("Quotations can be recorded only after the purchase request is approved.");
        if (await db.Quotations.AnyAsync(q => q.PurchaseRequestId == pr.Id && q.VendorId == input.VendorId && q.QuotationNo == input.QuotationNo, ct))
            throw new BusinessException("This quotation has already been recorded.");
        var q = new Quotation
        {
            PurchaseRequestId = pr.Id, VendorId = input.VendorId!.Value, QuotationNo = input.QuotationNo.Trim(),
            QuotationDate = input.QuotationDate.Date, ValidUntil = input.ValidUntil, SubTotal = input.SubTotal,
            TaxAmount = input.TaxAmount, OtherCharges = input.OtherCharges,
            TotalAmount = Math.Round(input.SubTotal + input.TaxAmount + input.OtherCharges, 2),
            DeliveryDays = input.DeliveryDays, WarrantyMonths = input.WarrantyMonths, Terms = input.Terms
        };
        db.Quotations.Add(q);
        pr.Status = PurchaseRequestStatus.QuotationsInvited;
        await db.SaveChangesAsync(ct);
        return q;
    }

    public async Task SelectQuotationAsync(int quotationId, string? reason, CancellationToken ct = default)
    {
        var q = await db.Quotations.FirstOrDefaultAsync(x => x.Id == quotationId, ct) ?? throw new BusinessException("Quotation not found.");
        var all = await db.Quotations.Where(x => x.PurchaseRequestId == q.PurchaseRequestId).ToListAsync(ct);
        var lowest = all.OrderBy(x => x.TotalAmount).First();
        if (lowest.Id != q.Id && string.IsNullOrWhiteSpace(reason))
            throw new BusinessException("The selected quotation is not the lowest. Please record the reason for selecting it.");
        foreach (var x in all) { x.IsSelected = x.Id == q.Id; x.SelectionReason = x.Id == q.Id ? reason : null; }
        await db.SaveChangesAsync(ct);
    }

    /// <summary>Quotations ranked for comparison (price, then delivery, then warranty).</summary>
    public Task<List<Quotation>> CompareAsync(int purchaseRequestId, CancellationToken ct = default) =>
        db.Quotations.AsNoTracking().Include(q => q.Vendor).Where(q => q.PurchaseRequestId == purchaseRequestId)
            .OrderBy(q => q.TotalAmount).ThenBy(q => q.DeliveryDays).ThenByDescending(q => q.WarrantyMonths).ToListAsync(ct);

    // ------------------------------------------------------------------ purchase orders

    public async Task<PurchaseOrderInput> PurchaseOrderFromQuotationAsync(int quotationId, CancellationToken ct = default)
    {
        var q = await db.Quotations.Include(x => x.PurchaseRequest!).ThenInclude(p => p.Items).FirstOrDefaultAsync(x => x.Id == quotationId, ct)
                ?? throw new BusinessException("Quotation not found.");
        var pr = q.PurchaseRequest!;
        decimal estTotal = pr.Items.Sum(i => i.Quantity * i.EstimatedUnitCost);
        decimal ratio = estTotal > 0 ? q.SubTotal / estTotal : 1;
        decimal taxRate = q.SubTotal > 0 ? Math.Round(q.TaxAmount / q.SubTotal * 100m, 2) : 0;
        return new PurchaseOrderInput
        {
            VendorId = q.VendorId, PurchaseRequestId = pr.Id, QuotationId = q.Id, BranchId = pr.BranchId,
            OtherCharges = q.OtherCharges, PODate = clock.Today,
            ExpectedDeliveryDate = q.DeliveryDays > 0 ? clock.Today.AddDays(q.DeliveryDays) : null,
            Terms = q.Terms, Remarks = $"Against {pr.RequestNo}, quotation {q.QuotationNo}",
            Items = pr.Items.Select(i => new LineInput
            {
                Description = i.Description, CategoryId = i.CategoryId, Quantity = i.Quantity,
                UnitPrice = Math.Round(i.EstimatedUnitCost * ratio, 2), TaxRate = taxRate, Specifications = i.Specifications
            }).ToList()
        };
    }

    public async Task<PurchaseOrder> SavePurchaseOrderAsync(PurchaseOrderInput input, CancellationToken ct = default)
    {
        var lines = input.Items.Where(i => !string.IsNullOrWhiteSpace(i.Description) && i.Quantity > 0).ToList();
        if (lines.Count == 0) throw new BusinessException("Add at least one item to the purchase order.");

        PurchaseOrder po;
        if (input.Id == 0)
        {
            string no = await numbering.NextDocumentNoAsync("PO", ct);
            po = new PurchaseOrder { PONumber = no, Status = PurchaseOrderStatus.Draft };
            db.PurchaseOrders.Add(po);
        }
        else
        {
            po = await db.PurchaseOrders.Include(p => p.Items).FirstOrDefaultAsync(p => p.Id == input.Id, ct)
                 ?? throw new BusinessException("Purchase order not found.");
            if (po.Status is not (PurchaseOrderStatus.Draft or PurchaseOrderStatus.Rejected))
                throw new BusinessException("Only draft or rejected purchase orders can be edited.");
            db.PurchaseOrderItems.RemoveRange(po.Items);
            po.Items.Clear();
            po.Status = PurchaseOrderStatus.Draft;
        }
        po.PODate = input.PODate.Date;
        po.VendorId = input.VendorId!.Value;
        po.PurchaseRequestId = input.PurchaseRequestId;
        po.QuotationId = input.QuotationId;
        po.BranchId = input.BranchId!.Value;
        po.DeliveryAddress = input.DeliveryAddress;
        po.ExpectedDeliveryDate = input.ExpectedDeliveryDate;
        po.OtherCharges = input.OtherCharges;
        po.Terms = input.Terms;
        po.Remarks = input.Remarks;
        foreach (var l in lines)
            po.Items.Add(new PurchaseOrderItem
            {
                Description = l.Description!.Trim(), CategoryId = l.CategoryId, AssetModelId = l.AssetModelId,
                Quantity = l.Quantity, UnitPrice = l.UnitPrice, TaxRate = l.TaxRate
            });
        po.RecalculateTotals();
        await db.SaveChangesAsync(ct);
        return po;
    }

    public async Task SubmitPurchaseOrderAsync(int id, CancellationToken ct = default)
    {
        var po = await db.PurchaseOrders.FirstOrDefaultAsync(p => p.Id == id, ct) ?? throw new BusinessException("Purchase order not found.");
        if (po.Status is not (PurchaseOrderStatus.Draft or PurchaseOrderStatus.Rejected))
            throw new BusinessException("Only draft purchase orders can be submitted.");
        bool needs = await approvals.SubmitAsync(ApprovalModule.PurchaseOrder, po.Id, po.PONumber, po.GrandTotal, ct);
        po.Status = needs ? PurchaseOrderStatus.PendingApproval : PurchaseOrderStatus.Approved;
        await db.SaveChangesAsync(ct);
    }

    public async Task IssuePurchaseOrderAsync(int id, CancellationToken ct = default)
    {
        var po = await db.PurchaseOrders.FirstOrDefaultAsync(p => p.Id == id, ct) ?? throw new BusinessException("Purchase order not found.");
        if (po.Status != PurchaseOrderStatus.Approved) throw new BusinessException("Only approved purchase orders can be issued to the vendor.");
        po.Status = PurchaseOrderStatus.Issued;
        if (po.PurchaseRequestId is { } prId)
        {
            var pr = await db.PurchaseRequests.FirstOrDefaultAsync(p => p.Id == prId, ct);
            if (pr is not null) pr.Status = PurchaseRequestStatus.Ordered;
        }
        await db.SaveChangesAsync(ct);
    }

    public async Task CancelPurchaseOrderAsync(int id, CancellationToken ct = default)
    {
        var po = await db.PurchaseOrders.Include(p => p.Items).FirstOrDefaultAsync(p => p.Id == id, ct) ?? throw new BusinessException("Purchase order not found.");
        if (po.Items.Any(i => i.ReceivedQuantity > 0)) throw new BusinessException("Goods have been received against this order; it can only be closed.");
        po.Status = PurchaseOrderStatus.Cancelled;
        foreach (var a in await db.Approvals.Where(a => a.Module == ApprovalModule.PurchaseOrder && a.EntityId == id && a.Status == ApprovalStatus.Pending).ToListAsync(ct))
            a.Status = ApprovalStatus.Cancelled;
        await db.SaveChangesAsync(ct);
    }

    public async Task ClosePurchaseOrderAsync(int id, CancellationToken ct = default)
    {
        var po = await db.PurchaseOrders.FirstOrDefaultAsync(p => p.Id == id, ct) ?? throw new BusinessException("Purchase order not found.");
        if (po.Status is not (PurchaseOrderStatus.PartiallyReceived or PurchaseOrderStatus.Received or PurchaseOrderStatus.Issued))
            throw new BusinessException("Only issued or received purchase orders can be closed.");
        po.Status = PurchaseOrderStatus.Closed;
        await db.SaveChangesAsync(ct);
    }

    // ------------------------------------------------------------------ goods receipt

    public async Task<GoodsReceiptInput> NewGoodsReceiptAsync(int poId, CancellationToken ct = default)
    {
        var po = await db.PurchaseOrders.AsNoTracking().Include(p => p.Items).FirstOrDefaultAsync(p => p.Id == poId, ct)
                 ?? throw new BusinessException("Purchase order not found.");
        return new GoodsReceiptInput
        {
            PurchaseOrderId = po.Id, ReceiptDate = clock.Today, ReceivedBy = user.UserName,
            Lines = po.Items.Select(i => new GoodsReceiptLineInput
            {
                PurchaseOrderItemId = i.Id, Description = i.Description, Ordered = i.Quantity, AlreadyReceived = i.ReceivedQuantity,
                QuantityReceived = Math.Max(0, i.Quantity - i.ReceivedQuantity)
            }).ToList()
        };
    }

    public async Task<GoodsReceipt> ReceiveGoodsAsync(GoodsReceiptInput input, CancellationToken ct = default)
    {
        var po = await db.PurchaseOrders.Include(p => p.Items).FirstOrDefaultAsync(p => p.Id == input.PurchaseOrderId, ct)
                 ?? throw new BusinessException("Purchase order not found.");
        if (po.Status is not (PurchaseOrderStatus.Issued or PurchaseOrderStatus.PartiallyReceived))
            throw new BusinessException("Goods can be received only against an issued purchase order.");
        var lines = input.Lines.Where(l => l.QuantityReceived > 0).ToList();
        if (lines.Count == 0) throw new BusinessException("Enter the quantity received for at least one item.");

        foreach (var l in lines)
        {
            var item = po.Items.FirstOrDefault(i => i.Id == l.PurchaseOrderItemId) ?? throw new BusinessException("Invalid purchase order line.");
            if (l.QuantityRejected > l.QuantityReceived) throw new BusinessException($"{item.Description}: rejected quantity exceeds received quantity.");
            decimal accepted = l.QuantityReceived - l.QuantityRejected;
            if (item.ReceivedQuantity + accepted > item.Quantity)
                throw new BusinessException($"{item.Description}: accepted quantity exceeds the quantity still pending ({item.PendingQuantity:0.###}).");
        }

        string no = await numbering.NextDocumentNoAsync("GRN", ct);
        var grn = new GoodsReceipt
        {
            GrnNumber = no, PurchaseOrderId = po.Id, ReceiptDate = input.ReceiptDate.Date,
            DeliveryChallanNo = input.DeliveryChallanNo, ReceivedBy = input.ReceivedBy ?? user.UserName, Remarks = input.Remarks
        };
        foreach (var l in lines)
        {
            var item = po.Items.First(i => i.Id == l.PurchaseOrderItemId);
            decimal accepted = l.QuantityReceived - l.QuantityRejected;
            item.ReceivedQuantity += accepted;
            grn.Items.Add(new GoodsReceiptItem
            {
                PurchaseOrderItemId = item.Id, QuantityReceived = l.QuantityReceived, QuantityAccepted = accepted,
                QuantityRejected = l.QuantityRejected, Remarks = l.Remarks
            });
        }
        po.Status = po.Items.All(i => i.ReceivedQuantity >= i.Quantity) ? PurchaseOrderStatus.Received : PurchaseOrderStatus.PartiallyReceived;
        db.GoodsReceipts.Add(grn);
        await db.SaveChangesAsync(ct);
        return grn;
    }

    // ------------------------------------------------------------------ invoice & asset registration

    public async Task<PurchaseInvoice> SaveInvoiceAsync(PurchaseInvoiceInput input, CancellationToken ct = default)
    {
        string invNo = input.InvoiceNumber.Trim();
        if (await db.PurchaseInvoices.AnyAsync(i => i.VendorId == input.VendorId && i.InvoiceNumber == invNo && i.Id != input.Id, ct))
            throw new BusinessException($"Invoice {invNo} from this vendor has already been entered.");
        if (input.PurchaseOrderId is { } poId)
        {
            var po = await db.PurchaseOrders.AsNoTracking().FirstOrDefaultAsync(p => p.Id == poId, ct) ?? throw new BusinessException("Purchase order not found.");
            if (po.VendorId != input.VendorId) throw new BusinessException("The invoice vendor does not match the purchase order vendor.");
        }

        PurchaseInvoice inv;
        if (input.Id == 0) { inv = new PurchaseInvoice(); db.PurchaseInvoices.Add(inv); }
        else
        {
            inv = await db.PurchaseInvoices.FirstOrDefaultAsync(i => i.Id == input.Id, ct) ?? throw new BusinessException("Invoice not found.");
            if (await db.Assets.AnyAsync(a => a.PurchaseInvoiceId == inv.Id, ct))
                throw new BusinessException("Assets have been registered from this invoice; it can no longer be edited.");
        }
        inv.InvoiceNumber = invNo;
        inv.InvoiceDate = input.InvoiceDate.Date;
        inv.VendorId = input.VendorId!.Value;
        inv.PurchaseOrderId = input.PurchaseOrderId;
        inv.GoodsReceiptId = input.GoodsReceiptId;
        inv.SubTotal = input.SubTotal;
        inv.TaxAmount = input.TaxAmount;
        inv.FreightCharges = input.FreightCharges;
        inv.InstallationCharges = input.InstallationCharges;
        inv.OtherCharges = input.OtherCharges;
        inv.GstInputCreditClaimed = input.GstInputCreditClaimed;
        inv.DueDate = input.DueDate;
        inv.Remarks = input.Remarks;
        inv.RecalculateTotal();
        await db.SaveChangesAsync(ct);
        return inv;
    }

    public async Task<RegisterAssetsInput> NewRegistrationAsync(int invoiceId, CancellationToken ct = default)
    {
        var inv = await db.PurchaseInvoices.AsNoTracking().Include(i => i.PurchaseOrder!).ThenInclude(p => p.Items).ThenInclude(i => i.AssetModel)
                      .FirstOrDefaultAsync(i => i.Id == invoiceId, ct) ?? throw new BusinessException("Invoice not found.");
        var input = new RegisterAssetsInput { PurchaseInvoiceId = inv.Id, BranchId = inv.PurchaseOrder?.BranchId, InstallationDate = inv.InvoiceDate };
        if (inv.PurchaseOrder is { } po)
        {
            int warranty = po.QuotationId is { } qid ? await db.Quotations.Where(q => q.Id == qid).Select(q => q.WarrantyMonths).FirstOrDefaultAsync(ct) : 0;
            foreach (var i in po.Items.Where(i => i.ReceivedQuantity - i.RegisteredQuantity > 0))
                input.Lines.Add(new RegisterAssetLine
                {
                    PurchaseOrderItemId = i.Id, Name = i.Description, CategoryId = i.CategoryId, AssetModelId = i.AssetModelId,
                    ModelNumber = i.AssetModel?.ModelNumber, UnitCost = i.UnitPrice, TaxRate = i.TaxRate,
                    PendingQuantity = i.ReceivedQuantity - i.RegisteredQuantity, Quantity = (int)(i.ReceivedQuantity - i.RegisteredQuantity),
                    WarrantyMonths = i.AssetModel?.StandardWarrantyMonths > 0 ? i.AssetModel.StandardWarrantyMonths : warranty
                });
        }
        if (input.Lines.Count == 0) input.Lines.Add(new RegisterAssetLine { Quantity = 1, UnitCost = inv.SubTotal });
        return input;
    }

    /// <summary>
    /// Creates one asset record per unit on the invoice. Freight, installation and other invoice charges are
    /// apportioned to the assets in proportion to their unit cost; every asset links back to the invoice, PO and GRN.
    /// </summary>
    public async Task<List<Asset>> RegisterAssetsAsync(RegisterAssetsInput input, CancellationToken ct = default)
    {
        var inv = await db.PurchaseInvoices.Include(i => i.PurchaseOrder!).ThenInclude(p => p.Items)
                      .FirstOrDefaultAsync(i => i.Id == input.PurchaseInvoiceId, ct) ?? throw new BusinessException("Invoice not found.");
        var lines = input.Lines.Where(l => l.Quantity > 0).ToList();
        if (lines.Count == 0) throw new BusinessException("Enter the quantity to register for at least one line.");
        foreach (var l in lines)
        {
            if (l.CategoryId is null) throw new BusinessException($"Select a category for '{l.Name}'.");
            if (l.PurchaseOrderItemId is { } pid)
            {
                var poi = inv.PurchaseOrder?.Items.FirstOrDefault(i => i.Id == pid) ?? throw new BusinessException("Invalid purchase order line.");
                if (poi.RegisteredQuantity + l.Quantity > Math.Max(poi.ReceivedQuantity, 0))
                    throw new BusinessException($"'{l.Name}': only {poi.ReceivedQuantity - poi.RegisteredQuantity:0.###} received units remain to be registered.");
            }
        }

        decimal totalValue = lines.Sum(l => l.UnitCost * l.Quantity);
        decimal alreadyAllocatedBase = await db.Assets.Where(a => a.PurchaseInvoiceId == inv.Id).SumAsync(a => (decimal?)a.PurchaseCost, ct) ?? 0;
        decimal invoiceBase = Math.Max(inv.SubTotal, alreadyAllocatedBase + totalValue);
        decimal freightShareRate = invoiceBase > 0 ? (inv.FreightCharges + inv.OtherCharges) / invoiceBase : 0;
        decimal installShareRate = invoiceBase > 0 ? inv.InstallationCharges / invoiceBase : 0;

        var created = new List<Asset>();
        var tx = db.Database.IsRelational() ? await db.Database.BeginTransactionAsync(ct) : null;
        try
        {
            foreach (var l in lines)
            {
                var serials = (l.SerialNumbers ?? "").Split(new[] { '\r', '\n', ',' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
                for (int n = 0; n < l.Quantity; n++)
                {
                    var a = await assets.CreateAsync(new AssetInput
                    {
                        Name = l.Name, CategoryId = l.CategoryId, SubcategoryId = l.SubcategoryId, AssetModelId = l.AssetModelId,
                        ManufacturerId = l.ManufacturerId, BrandId = l.BrandId, ModelNumber = l.ModelNumber,
                        SerialNumber = n < serials.Length ? serials[n] : null,
                        PurchaseDate = inv.InvoiceDate, VendorId = inv.VendorId, InvoiceNumber = inv.InvoiceNumber, InvoiceDate = inv.InvoiceDate,
                        PurchaseCost = l.UnitCost, TaxRate = l.TaxRate, TaxAmount = Math.Round(l.UnitCost * l.TaxRate / 100m, 2),
                        GstInputCreditClaimed = inv.GstInputCreditClaimed,
                        AdditionalCharges = Math.Round(l.UnitCost * freightShareRate, 2),
                        InstallationCharges = Math.Round(l.UnitCost * installShareRate, 2),
                        InstallationDate = input.InstallationDate,
                        BranchId = input.BranchId, DepartmentId = input.DepartmentId, LocationId = input.LocationId,
                        Status = input.Status, Condition = AssetCondition.New,
                        WarrantyStartDate = l.WarrantyMonths > 0 ? inv.InvoiceDate : null,
                        WarrantyExpiryDate = l.WarrantyMonths > 0 ? inv.InvoiceDate.AddMonths(l.WarrantyMonths).AddDays(-1) : null,
                        WarrantyProvider = l.WarrantyMonths > 0 ? "Manufacturer / Vendor" : null
                    }, ct);
                    a.PurchaseInvoiceId = inv.Id;
                    a.PurchaseOrderId = inv.PurchaseOrderId;
                    a.PurchaseOrderItemId = l.PurchaseOrderItemId;
                    a.GoodsReceiptId = inv.GoodsReceiptId;
                    history.Record(a, AssetEventType.Registered, $"Registered from invoice {inv.InvoiceNumber}" +
                        (inv.PurchaseOrder is { } po ? $" / PO {po.PONumber}" : ""), "PurchaseInvoice", inv.Id, inv.InvoiceNumber);
                    created.Add(a);
                }
                if (l.PurchaseOrderItemId is { } pid2)
                    inv.PurchaseOrder!.Items.First(i => i.Id == pid2).RegisteredQuantity += l.Quantity;
            }
            await db.SaveChangesAsync(ct);
            if (tx is not null) await tx.CommitAsync(ct);
        }
        catch
        {
            if (tx is not null) await tx.RollbackAsync(ct);
            throw;
        }
        finally
        {
            if (tx is not null) await tx.DisposeAsync();
        }
        return created;
    }

    // ------------------------------------------------------------------ approvals

    public bool Handles(ApprovalModule module) => module is ApprovalModule.PurchaseRequest or ApprovalModule.PurchaseOrder;

    public async Task OnDecidedAsync(ApprovalModule module, int entityId, bool approved, string? comments, CancellationToken ct)
    {
        if (module == ApprovalModule.PurchaseRequest)
        {
            var pr = await db.PurchaseRequests.FirstAsync(p => p.Id == entityId, ct);
            pr.Status = approved ? PurchaseRequestStatus.Approved : PurchaseRequestStatus.Rejected;
            if (!approved) pr.Remarks = $"Rejected: {comments}";
        }
        else
        {
            var po = await db.PurchaseOrders.FirstAsync(p => p.Id == entityId, ct);
            po.Status = approved ? PurchaseOrderStatus.Approved : PurchaseOrderStatus.Rejected;
            if (!approved) po.Remarks = $"Rejected: {comments}";
        }
    }

    public string LinkFor(ApprovalModule module, int entityId) =>
        module == ApprovalModule.PurchaseRequest ? $"/PurchaseRequests/Details/{entityId}" : $"/PurchaseOrders/Details/{entityId}";
}
