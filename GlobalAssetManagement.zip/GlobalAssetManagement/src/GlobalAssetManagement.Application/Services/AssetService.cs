using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Application.Models;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using GlobalAssetManagement.Domain.Logic;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace GlobalAssetManagement.Application.Services;

public sealed class AssetService(
    IAppDbContext db,
    NumberingService numbering,
    AssetHistory history,
    ICurrentUser user,
    IClock clock,
    IOptions<AppOptions> options)
{
    private readonly AppOptions _opt = options.Value;

    public async Task<PagedResult<AssetListItem>> SearchAsync(AssetFilter f, CancellationToken ct = default)
    {
        var q = Filter(db.Assets.AsNoTracking().VisibleTo(user), f);

        q = f.Sort switch
        {
            "name" => q.OrderBy(a => a.Name),
            "code" => q.OrderBy(a => a.AssetCode),
            "purchase" => q.OrderByDescending(a => a.PurchaseDate),
            "cost" => q.OrderByDescending(a => a.OriginalCost + a.CapitalizedAdditions),
            "status" => q.OrderBy(a => a.Status).ThenBy(a => a.AssetTag),
            "warranty" => q.OrderBy(a => a.WarrantyExpiryDate == null).ThenBy(a => a.WarrantyExpiryDate),
            _ => q.OrderBy(a => a.AssetTag)
        };

        int page = Math.Max(1, f.Page), size = Math.Clamp(f.PageSize, 5, 500);
        int total = await q.CountAsync(ct);
        var items = await q.Skip((page - 1) * size).Take(size)
            .Select(a => new AssetListItem(a.Id, a.AssetTag, a.AssetCode, a.Name, a.Category!.Name,
                a.Branch!.Name, a.Department != null ? a.Department.Name : null,
                a.Location != null ? a.Location.Code + " / " + a.Location.Building : null,
                a.AssignedEmployee != null ? a.AssignedEmployee.FullName : null,
                a.SerialNumber, a.Status, a.Condition, a.PurchaseDate,
                a.OriginalCost + a.CapitalizedAdditions, a.CurrentBookValue, a.WarrantyExpiryDate))
            .ToListAsync(ct);
        return new PagedResult<AssetListItem> { Items = items, Page = page, PageSize = size, TotalCount = total };
    }

    public IQueryable<Asset> Filter(IQueryable<Asset> q, AssetFilter f)
    {
        if (!string.IsNullOrWhiteSpace(f.Search))
        {
            var s = f.Search.Trim();
            q = q.Where(a => a.AssetTag.Contains(s) || a.AssetCode.Contains(s) || a.Name.Contains(s)
                             || (a.SerialNumber != null && a.SerialNumber.Contains(s))
                             || (a.ModelNumber != null && a.ModelNumber.Contains(s))
                             || (a.InvoiceNumber != null && a.InvoiceNumber.Contains(s)));
        }
        if (f.CategoryId is { } c) q = q.Where(a => a.CategoryId == c);
        if (f.BranchId is { } b) q = q.Where(a => a.BranchId == b);
        if (f.DepartmentId is { } d) q = q.Where(a => a.DepartmentId == d);
        if (f.LocationId is { } l) q = q.Where(a => a.LocationId == l);
        if (f.EmployeeId is { } e) q = q.Where(a => a.AssignedEmployeeId == e);
        if (f.VendorId is { } v) q = q.Where(a => a.VendorId == v);
        if (f.Status is { } st) q = q.Where(a => a.Status == st);
        else if (!f.IncludeDisposed) q = q.Where(a => a.Status != AssetStatus.Disposed && a.Status != AssetStatus.LostOrWrittenOff);
        if (f.Condition is { } cond) q = q.Where(a => a.Condition == cond);
        if (f.Warranty is { } w)
        {
            var today = clock.Today;
            var soon = today.AddDays(_opt.ExpiringSoonDays);
            q = w switch
            {
                CoverageStatus.Active => q.Where(a => a.WarrantyExpiryDate != null && a.WarrantyExpiryDate > soon),
                CoverageStatus.ExpiringSoon => q.Where(a => a.WarrantyExpiryDate != null && a.WarrantyExpiryDate >= today && a.WarrantyExpiryDate <= soon),
                CoverageStatus.Expired => q.Where(a => a.WarrantyExpiryDate != null && a.WarrantyExpiryDate < today),
                _ => q.Where(a => a.WarrantyExpiryDate == null)
            };
        }
        return q;
    }

    public async Task<Asset?> GetForDetailsAsync(int id, CancellationToken ct = default)
    {
        var a = await db.Assets.AsNoTracking()
            .Include(x => x.Category).Include(x => x.Subcategory).Include(x => x.AssetType)
            .Include(x => x.Manufacturer).Include(x => x.Brand).Include(x => x.AssetModel)
            .Include(x => x.Vendor).Include(x => x.Branch).Include(x => x.Department).Include(x => x.Location)
            .Include(x => x.AssignedEmployee).Include(x => x.PurchaseOrder).Include(x => x.PurchaseInvoice)
            .Include(x => x.Documents).Include(x => x.Images)
            .AsSplitQuery()
            .FirstOrDefaultAsync(x => x.Id == id, ct);
        if (a is not null) user.EnsureCanSee(a);
        return a;
    }

    public async Task<Asset?> FindByCodeAsync(string code, CancellationToken ct = default)
    {
        code = code.Trim();
        var a = await db.Assets.AsNoTracking().FirstOrDefaultAsync(x => x.AssetTag == code || x.AssetCode == code, ct);
        if (a is null && code.Contains('/'))
        {
            // QR codes contain a URL ending in the asset tag.
            var tail = code.TrimEnd('/').Split('/').Last();
            a = await db.Assets.AsNoTracking().FirstOrDefaultAsync(x => x.AssetTag == tail || x.AssetCode == tail, ct);
        }
        return a;
    }

    public async Task<AssetInput> NewInputAsync(CancellationToken ct = default)
    {
        var input = new AssetInput { PurchaseDate = clock.Today, BranchId = user.BranchId, DepartmentId = user.DepartmentId };
        if (input.BranchId is null)
        {
            var branches = await db.Branches.Where(b => b.IsActive).Select(b => b.Id).Take(2).ToListAsync(ct);
            if (branches.Count == 1) input.BranchId = branches[0];
        }
        return input;
    }

    public async Task<AssetInput> ToInputAsync(int id, CancellationToken ct = default)
    {
        var a = await db.Assets.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new BusinessException("Asset not found.");
        user.EnsureCanSee(a);
        var w = await db.WarrantyRecords.AsNoTracking().Where(x => x.AssetId == id && x.IsPrimary).OrderByDescending(x => x.ExpiryDate).FirstOrDefaultAsync(ct);
        return new AssetInput
        {
            Id = a.Id, AssetCode = a.AssetCode, Name = a.Name, CategoryId = a.CategoryId, SubcategoryId = a.SubcategoryId,
            AssetTypeId = a.AssetTypeId, ManufacturerId = a.ManufacturerId, BrandId = a.BrandId, AssetModelId = a.AssetModelId,
            ModelNumber = a.ModelNumber, SerialNumber = a.SerialNumber, PurchaseDate = a.PurchaseDate, VendorId = a.VendorId,
            InvoiceNumber = a.InvoiceNumber, InvoiceDate = a.InvoiceDate, PurchaseCost = a.PurchaseCost, TaxRate = a.TaxRate,
            TaxAmount = a.TaxAmount, GstInputCreditClaimed = a.GstInputCreditClaimed, AdditionalCharges = a.AdditionalCharges,
            InstallationCharges = a.InstallationCharges, InstallationDate = a.InstallationDate, CommissioningDate = a.CommissioningDate,
            BranchId = a.BranchId, DepartmentId = a.DepartmentId, LocationId = a.LocationId, RackPosition = a.RackPosition,
            AssignedEmployeeId = a.AssignedEmployeeId, Condition = a.Condition, Status = a.Status, IsCritical = a.IsCritical,
            WarrantyStartDate = a.WarrantyStartDate, WarrantyExpiryDate = a.WarrantyExpiryDate, WarrantyProvider = w?.Provider,
            UsefulLifeYears = a.UsefulLifeYears, DepreciationMethod = a.DepreciationMethod, DepreciationRate = a.DepreciationRate,
            ResidualValue = a.ResidualValue, DepreciationStartDate = a.DepreciationStartDate, NextServiceDate = a.NextServiceDate,
            Description = a.Description, Specifications = a.Specifications, Remarks = a.Remarks,
            RowVersion = a.RowVersion is null ? null : Convert.ToBase64String(a.RowVersion),
            FinancialsLocked = IsFinancialsLocked(a)
        };
    }

    public static bool IsFinancialsLocked(Asset a) => a.AccumulatedDepreciation != 0 || a.CapitalizedAdditions != 0 || a.DepreciatedUpTo is not null;

    public async Task<Asset> CreateAsync(AssetInput input, CancellationToken ct = default)
    {
        var category = await db.AssetCategories.FirstOrDefaultAsync(c => c.Id == input.CategoryId, ct) ?? throw new BusinessException("Select a valid category.");
        var branch = await db.Branches.FirstOrDefaultAsync(b => b.Id == input.BranchId, ct) ?? throw new BusinessException("Select a valid branch.");
        if (user.BranchId is { } ub && ub != branch.Id) throw new BusinessException("You can only register assets for your own branch.");

        string? code = string.IsNullOrWhiteSpace(input.AssetCode) ? null : input.AssetCode.Trim().ToUpperInvariant();
        if (code is not null && await db.Assets.AnyAsync(a => a.AssetCode == code, ct))
            throw new BusinessException($"Asset code '{code}' is already in use.");
        await EnsureSerialUniqueAsync(input.SerialNumber, input.ManufacturerId, null, ct);

        // Allocate numbers first (each allocation saves the sequence immediately).
        int tagNo = await numbering.NextAsync("TAG", NumberingService.AssetTagScope, ct);
        int year = (input.PurchaseDate ?? clock.Today).Year;
        if (code is null)
        {
            for (int i = 0; i < 20 && code is null; i++)
            {
                int n = await numbering.NextAsync("ACODE", $"{category.Code}-{branch.Code}-{year}", ct);
                var candidate = DocumentNumbers.AssetCode(category.Code, branch.Code, year, n);
                if (!await db.Assets.AnyAsync(a => a.AssetCode == candidate, ct)) code = candidate;
            }
            code ??= DocumentNumbers.AssetTag(_opt.AssetTagPrefix, tagNo);
        }

        var asset = new Asset
        {
            AssetTag = DocumentNumbers.AssetTag(_opt.AssetTagPrefix, tagNo),
            AssetCode = code,
            Status = input.Status,
            AccumulatedDepreciation = 0
        };
        Apply(asset, input, category, financials: true);
        db.Assets.Add(asset);

        if (input.WarrantyExpiryDate is { } exp)
        {
            db.WarrantyRecords.Add(new WarrantyRecord
            {
                Asset = asset, WarrantyType = WarrantyType.Manufacturer, IsPrimary = true,
                Provider = string.IsNullOrWhiteSpace(input.WarrantyProvider) ? "Manufacturer" : input.WarrantyProvider!.Trim(),
                StartDate = input.WarrantyStartDate ?? input.PurchaseDate ?? clock.Today, ExpiryDate = exp
            });
        }

        history.Record(asset, AssetEventType.Registered, $"Asset registered with cost {asset.OriginalCost:N2} at {branch.Name}.");
        await db.SaveChangesAsync(ct);

        if (input.AssignedEmployeeId is { } emp)
        {
            string allocNo = await numbering.NextDocumentNoAsync("ALC", ct);
            var employee = await db.Employees.FirstAsync(e => e.Id == emp, ct);
            db.AssetAllocations.Add(new AssetAllocation
            {
                AllocationNo = allocNo, AssetId = asset.Id, TargetType = AllocationTargetType.Employee, EmployeeId = emp,
                DepartmentId = asset.DepartmentId, BranchId = asset.BranchId, LocationId = asset.LocationId,
                IssueDate = clock.UtcNow, ConditionAtIssue = asset.Condition, IssuedBy = user.UserName, Purpose = "Initial assignment at registration"
            });
            asset.AssignedEmployeeId = emp;
            history.Record(asset, AssetEventType.Allocated, $"Assigned to {employee.FullName} at registration.", "AssetAllocation", null, allocNo);
            await db.SaveChangesAsync(ct);
        }
        return asset;
    }

    public async Task<Asset> UpdateAsync(AssetInput input, CancellationToken ct = default)
    {
        var asset = await db.Assets.FirstOrDefaultAsync(a => a.Id == input.Id, ct) ?? throw new BusinessException("Asset not found.");
        user.EnsureCanSee(asset);
        if (asset.Status is AssetStatus.Disposed or AssetStatus.LostOrWrittenOff)
            throw new BusinessException("Disposed or written-off assets cannot be edited.");
        if (!string.IsNullOrEmpty(input.RowVersion) && asset.RowVersion is not null)
            db.Entry(asset).Property(a => a.RowVersion).OriginalValue = Convert.FromBase64String(input.RowVersion);

        var category = await db.AssetCategories.FirstOrDefaultAsync(c => c.Id == input.CategoryId, ct) ?? throw new BusinessException("Select a valid category.");
        string code = string.IsNullOrWhiteSpace(input.AssetCode) ? asset.AssetCode : input.AssetCode.Trim().ToUpperInvariant();
        if (code != asset.AssetCode && await db.Assets.AnyAsync(a => a.AssetCode == code && a.Id != asset.Id, ct))
            throw new BusinessException($"Asset code '{code}' is already in use.");
        await EnsureSerialUniqueAsync(input.SerialNumber, input.ManufacturerId, asset.Id, ct);

        bool locked = IsFinancialsLocked(asset);
        if (locked && FinancialsChanged(asset, input))
            throw new BusinessException("Cost and depreciation settings are locked because depreciation or additions have been posted. Use Asset Additions for capital changes.");

        int? oldBranch = asset.BranchId, oldDept = asset.DepartmentId, oldLoc = asset.LocationId;
        asset.AssetCode = code;
        Apply(asset, input, category, financials: !locked);
        if (oldBranch != asset.BranchId || oldDept != asset.DepartmentId || oldLoc != asset.LocationId)
            history.Record(asset, AssetEventType.Updated, "Placement corrected through asset master edit (use Transfers for actual movements).");
        else
            history.Record(asset, AssetEventType.Updated, "Asset master details updated.");

        // keep the primary warranty record in step with the master
        if (input.WarrantyExpiryDate is { } exp)
        {
            var w = await db.WarrantyRecords.Where(x => x.AssetId == asset.Id && x.IsPrimary).OrderByDescending(x => x.ExpiryDate).FirstOrDefaultAsync(ct);
            if (w is null)
                db.WarrantyRecords.Add(new WarrantyRecord
                {
                    AssetId = asset.Id, IsPrimary = true, WarrantyType = WarrantyType.Manufacturer,
                    Provider = string.IsNullOrWhiteSpace(input.WarrantyProvider) ? "Manufacturer" : input.WarrantyProvider!.Trim(),
                    StartDate = input.WarrantyStartDate ?? asset.PurchaseDate ?? clock.Today, ExpiryDate = exp
                });
            else
            {
                w.ExpiryDate = exp;
                w.StartDate = input.WarrantyStartDate ?? w.StartDate;
                if (!string.IsNullOrWhiteSpace(input.WarrantyProvider)) w.Provider = input.WarrantyProvider!.Trim();
            }
        }

        try
        {
            await db.SaveChangesAsync(ct);
        }
        catch (DbUpdateConcurrencyException)
        {
            throw new BusinessException("This asset was changed by another user after you opened it. Reload the page and apply your changes again.");
        }
        return asset;
    }

    private static bool FinancialsChanged(Asset a, AssetInput i) =>
        a.PurchaseCost != i.PurchaseCost || a.TaxAmount != i.TaxAmount || a.AdditionalCharges != i.AdditionalCharges
        || a.InstallationCharges != i.InstallationCharges || a.GstInputCreditClaimed != i.GstInputCreditClaimed
        || (i.UsefulLifeYears is { } l && l != a.UsefulLifeYears)
        || (i.DepreciationMethod is { } m && m != a.DepreciationMethod)
        || (i.DepreciationRate is { } r && r != a.DepreciationRate)
        || (i.ResidualValue is { } rv && rv != a.ResidualValue)
        || (i.DepreciationStartDate is { } ds && ds.Date != a.DepreciationStartDate?.Date);

    private void Apply(Asset a, AssetInput i, AssetCategory category, bool financials)
    {
        a.Name = i.Name.Trim();
        a.CategoryId = category.Id;
        a.SubcategoryId = i.SubcategoryId;
        a.AssetTypeId = i.AssetTypeId;
        a.ManufacturerId = i.ManufacturerId;
        a.BrandId = i.BrandId;
        a.AssetModelId = i.AssetModelId;
        a.ModelNumber = i.ModelNumber?.Trim();
        a.SerialNumber = string.IsNullOrWhiteSpace(i.SerialNumber) ? null : i.SerialNumber.Trim();
        a.PurchaseDate = i.PurchaseDate;
        a.VendorId = i.VendorId;
        a.InvoiceNumber = i.InvoiceNumber?.Trim();
        a.InvoiceDate = i.InvoiceDate;
        a.InstallationDate = i.InstallationDate;
        a.CommissioningDate = i.CommissioningDate;
        a.BranchId = i.BranchId!.Value;
        a.DepartmentId = i.DepartmentId;
        a.LocationId = i.LocationId;
        a.RackPosition = i.RackPosition?.Trim();
        a.Condition = i.Condition;
        a.IsCritical = i.IsCritical;
        a.WarrantyStartDate = i.WarrantyStartDate;
        a.WarrantyExpiryDate = i.WarrantyExpiryDate;
        a.NextServiceDate = i.NextServiceDate;
        a.Description = i.Description;
        a.Specifications = i.Specifications;
        a.Remarks = i.Remarks;

        if (!financials) return;
        a.PurchaseCost = i.PurchaseCost;
        a.TaxRate = i.TaxRate;
        a.TaxAmount = i.TaxAmount == 0 && i.TaxRate > 0 ? Math.Round(i.PurchaseCost * i.TaxRate / 100m, 2) : i.TaxAmount;
        a.GstInputCreditClaimed = i.GstInputCreditClaimed;
        a.AdditionalCharges = i.AdditionalCharges;
        a.InstallationCharges = i.InstallationCharges;
        a.OriginalCost = Asset.ComputeCapitalizedCost(a.PurchaseCost, a.TaxAmount, a.GstInputCreditClaimed, a.AdditionalCharges, a.InstallationCharges);
        a.UsefulLifeYears = i.UsefulLifeYears ?? category.DefaultUsefulLifeYears;
        a.DepreciationMethod = i.DepreciationMethod ?? category.DefaultDepreciationMethod;
        a.DepreciationRate = i.DepreciationRate ?? category.DefaultDepreciationRate;
        a.ResidualValue = i.ResidualValue ?? Math.Round(a.OriginalCost * category.DefaultResidualPercent / 100m, 2);
        a.DepreciationStartDate = i.DepreciationStartDate ?? i.CommissioningDate ?? i.InstallationDate ?? i.PurchaseDate ?? clock.Today;
        a.CurrentBookValue = a.GrossCost - a.AccumulatedDepreciation;
    }

    private async Task EnsureSerialUniqueAsync(string? serial, int? manufacturerId, int? exceptId, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(serial)) return;
        serial = serial.Trim();
        bool dup = await db.Assets.AnyAsync(a => a.SerialNumber == serial && a.ManufacturerId == manufacturerId && a.Id != (exceptId ?? 0), ct);
        if (dup) throw new BusinessException($"Another asset from the same manufacturer already has serial number '{serial}'.");
    }

    public async Task ChangeStatusAsync(int id, AssetStatus status, AssetCondition? condition, string reason, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(reason)) throw new BusinessException("Please give a reason for the status change.");
        if (status is AssetStatus.Disposed or AssetStatus.LostOrWrittenOff)
            throw new BusinessException("Use the Disposal module to dispose of or write off an asset.");
        var a = await db.Assets.FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new BusinessException("Asset not found.");
        user.EnsureCanSee(a);
        if (a.Status is AssetStatus.Disposed or AssetStatus.LostOrWrittenOff)
            throw new BusinessException("The status of a disposed asset cannot be changed.");
        history.ChangeStatus(a, status, reason.Trim());
        if (condition is { } c && c != a.Condition)
        {
            history.Record(a, AssetEventType.Updated, $"Condition changed from {a.Condition.DisplayName()} to {c.DisplayName()}.");
            a.Condition = c;
        }
        await db.SaveChangesAsync(ct);
    }

    public async Task DeleteAsync(int id, CancellationToken ct = default)
    {
        var a = await db.Assets.FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new BusinessException("Asset not found.");
        user.EnsureCanSee(a);
        bool hasTransactions =
            await db.AssetAllocations.AnyAsync(x => x.AssetId == id, ct) || await db.ServiceRequests.AnyAsync(x => x.AssetId == id, ct)
            || await db.WorkOrders.AnyAsync(x => x.AssetId == id, ct) || await db.AssetTransfers.AnyAsync(x => x.AssetId == id, ct)
            || await db.AssetAdditions.AnyAsync(x => x.AssetId == id, ct) || await db.DepreciationTransactions.AnyAsync(x => x.AssetId == id, ct)
            || await db.AssetDisposals.AnyAsync(x => x.AssetId == id, ct) || await db.AMContractAssets.AnyAsync(x => x.AssetId == id, ct)
            || await db.PhysicalVerificationItems.AnyAsync(x => x.AssetId == id, ct) || await db.MaintenanceSchedules.AnyAsync(x => x.AssetId == id, ct);
        if (hasTransactions)
            throw new BusinessException("This asset has transaction history and cannot be deleted. Mark it Inactive or dispose of it instead.");
        db.WarrantyRecords.RemoveRange(db.WarrantyRecords.Where(w => w.AssetId == id));
        db.Assets.Remove(a);
        await db.SaveChangesAsync(ct);
    }

    public Task<List<AssetEvent>> TimelineAsync(int assetId, CancellationToken ct = default) =>
        db.AssetEvents.AsNoTracking().Where(e => e.AssetId == assetId).OrderByDescending(e => e.EventAt).ThenByDescending(e => e.Id).ToListAsync(ct);

    public async Task<List<Asset>> ForLabelsAsync(IEnumerable<int> ids, CancellationToken ct = default)
    {
        var list = ids.Distinct().Take(1000).ToList();
        return await db.Assets.AsNoTracking().VisibleTo(user).Include(a => a.Branch).Include(a => a.Location)
            .Where(a => list.Contains(a.Id)).OrderBy(a => a.AssetTag).ToListAsync(ct);
    }
}
