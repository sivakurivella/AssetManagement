using GlobalAssetManagement.Application.Services;
using Microsoft.Extensions.DependencyInjection;

namespace GlobalAssetManagement.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddApplication(this IServiceCollection services)
    {
        services.AddMemoryCache();

        services.AddScoped<SettingsService>();
        services.AddScoped<NumberingService>();
        services.AddScoped<AssetHistory>();
        services.AddScoped<LookupService>();
        services.AddScoped<PermissionService>();
        services.AddScoped<ApprovalService>();
        services.AddScoped<ApprovalWorkflow>();
        services.AddScoped<AttachmentService>();
        services.AddScoped<AssetService>();
        services.AddScoped<DepreciationService>();
        services.AddScoped<ReminderService>();
        services.AddScoped<NotificationInbox>();
        services.AddScoped<DashboardService>();
        services.AddScoped<ReportService>();

        // Module services that also react to completed approval chains.
        AddWithApprovalHandler<ProcurementService>(services);
        AddWithApprovalHandler<AllocationService>(services);
        AddWithApprovalHandler<AdditionService>(services);
        AddWithApprovalHandler<MaintenanceService>(services);
        AddWithApprovalHandler<WarrantyAmcService>(services);
        AddWithApprovalHandler<VerificationService>(services);
        AddWithApprovalHandler<DisposalService>(services);
        return services;
    }

    private static void AddWithApprovalHandler<T>(IServiceCollection services) where T : class, IApprovalHandler
    {
        services.AddScoped<T>();
        services.AddScoped<IApprovalHandler>(sp => sp.GetRequiredService<T>());
    }
}
