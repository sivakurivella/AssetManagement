using System.Text;

namespace GlobalAssetManagement.Application.Common.Documents;

public enum QrErrorCorrection { L = 1, M = 0, Q = 3, H = 2 }

/// <summary>
/// Self-contained QR Code (ISO/IEC 18004) encoder: byte mode, versions 1-10, all error-correction levels.
/// Version 10-M holds 213 bytes which is ample for asset URLs and authenticator (TOTP) URIs.
/// </summary>
public sealed class QrCode
{
    public int Version { get; }
    public int Size { get; }
    public QrErrorCorrection Ecc { get; }
    public int Mask { get; private set; }
    private readonly bool[,] _modules;   // [y, x]
    private readonly bool[,] _isFunction;

    public bool this[int x, int y] => x >= 0 && y >= 0 && x < Size && y < Size && _modules[y, x];

    // Per version (1..10) and ECC level: EC codewords per block, blocks in group 1, data cw per block g1, blocks g2, data cw g2.
    private static readonly int[,][] Blocks = BuildBlockTable();
    private static readonly int[][] AlignmentPositions =
    {
        Array.Empty<int>(), Array.Empty<int>(), new[] { 6, 18 }, new[] { 6, 22 }, new[] { 6, 26 }, new[] { 6, 30 },
        new[] { 6, 34 }, new[] { 6, 22, 38 }, new[] { 6, 24, 42 }, new[] { 6, 26, 46 }, new[] { 6, 28, 50 }
    };

    private QrCode(int version, QrErrorCorrection ecc, byte[] dataCodewords, int mask)
    {
        Version = version;
        Ecc = ecc;
        Size = version * 4 + 17;
        _modules = new bool[Size, Size];
        _isFunction = new bool[Size, Size];

        DrawFunctionPatterns();
        var all = AddEccAndInterleave(dataCodewords);
        DrawCodewords(all);

        if (mask < 0)
        {
            int best = 0, minPenalty = int.MaxValue;
            for (int m = 0; m < 8; m++)
            {
                ApplyMask(m);
                DrawFormatBits(m);
                int p = Penalty();
                if (p < minPenalty) { minPenalty = p; best = m; }
                ApplyMask(m); // undo (XOR)
            }
            mask = best;
        }
        Mask = mask;
        ApplyMask(mask);
        DrawFormatBits(mask);
    }

    public static QrCode EncodeText(string text, QrErrorCorrection ecc = QrErrorCorrection.M)
        => EncodeBytes(Encoding.UTF8.GetBytes(text ?? ""), ecc);

    public static QrCode EncodeBytes(byte[] data, QrErrorCorrection ecc = QrErrorCorrection.M)
    {
        for (int v = 1; v <= 10; v++)
        {
            int capacityBits = DataCodewords(v, ecc) * 8;
            int countBits = v <= 9 ? 8 : 16;
            int needed = 4 + countBits + data.Length * 8;
            if (needed > capacityBits) continue;

            var bb = new BitBuffer();
            bb.Append(0b0100, 4);
            bb.Append(data.Length, countBits);
            foreach (var b in data) bb.Append(b, 8);
            bb.Append(0, Math.Min(4, capacityBits - bb.Count));
            bb.Append(0, (8 - bb.Count % 8) % 8);
            for (byte pad = 0xEC; bb.Count < capacityBits; pad ^= 0xEC ^ 0x11) bb.Append(pad, 8);

            return new QrCode(v, ecc, bb.ToBytes(), -1);
        }
        throw new ArgumentException($"Data too long for a version 10 QR code ({data.Length} bytes).");
    }

    /// <summary>SVG markup with a 4-module quiet zone.</summary>
    public string ToSvg(int moduleSize = 4, string dark = "#000", string light = "#fff")
    {
        int border = 4, dim = (Size + border * 2) * moduleSize;
        var sb = new StringBuilder();
        sb.Append($"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 {Size + border * 2} {Size + border * 2}\" width=\"{dim}\" height=\"{dim}\" shape-rendering=\"crispEdges\">");
        sb.Append($"<rect width=\"100%\" height=\"100%\" fill=\"{light}\"/><path fill=\"{dark}\" d=\"");
        for (int y = 0; y < Size; y++)
            for (int x = 0; x < Size; x++)
                if (_modules[y, x]) sb.Append($"M{x + border},{y + border}h1v1h-1z");
        sb.Append("\"/></svg>");
        return sb.ToString();
    }

    // ------------------------------------------------------------------ tables

    private static int[,][] BuildBlockTable()
    {
        // rows: version 1..10; columns: L, M, Q, H  -> {ecPerBlock, g1Blocks, g1Data, g2Blocks, g2Data}
        int[][][] t =
        {
            new[] { new[] { 7, 1, 19, 0, 0 }, new[] { 10, 1, 16, 0, 0 }, new[] { 13, 1, 13, 0, 0 }, new[] { 17, 1, 9, 0, 0 } },
            new[] { new[] { 10, 1, 34, 0, 0 }, new[] { 16, 1, 28, 0, 0 }, new[] { 22, 1, 22, 0, 0 }, new[] { 28, 1, 16, 0, 0 } },
            new[] { new[] { 15, 1, 55, 0, 0 }, new[] { 26, 1, 44, 0, 0 }, new[] { 18, 2, 17, 0, 0 }, new[] { 22, 2, 13, 0, 0 } },
            new[] { new[] { 20, 1, 80, 0, 0 }, new[] { 18, 2, 32, 0, 0 }, new[] { 26, 2, 24, 0, 0 }, new[] { 16, 4, 9, 0, 0 } },
            new[] { new[] { 26, 1, 108, 0, 0 }, new[] { 24, 2, 43, 0, 0 }, new[] { 18, 2, 15, 2, 16 }, new[] { 22, 2, 11, 2, 12 } },
            new[] { new[] { 18, 2, 68, 0, 0 }, new[] { 16, 4, 27, 0, 0 }, new[] { 24, 4, 19, 0, 0 }, new[] { 28, 4, 15, 0, 0 } },
            new[] { new[] { 20, 2, 78, 0, 0 }, new[] { 18, 4, 31, 0, 0 }, new[] { 18, 2, 14, 4, 15 }, new[] { 26, 4, 13, 1, 14 } },
            new[] { new[] { 24, 2, 97, 0, 0 }, new[] { 22, 2, 38, 2, 39 }, new[] { 22, 4, 18, 2, 19 }, new[] { 26, 4, 14, 2, 15 } },
            new[] { new[] { 30, 2, 116, 0, 0 }, new[] { 22, 3, 36, 2, 37 }, new[] { 20, 4, 16, 4, 17 }, new[] { 24, 4, 12, 4, 13 } },
            new[] { new[] { 18, 2, 68, 2, 69 }, new[] { 26, 4, 43, 1, 44 }, new[] { 24, 6, 19, 2, 20 }, new[] { 28, 6, 15, 2, 16 } },
        };
        var r = new int[11, 4][];
        for (int v = 1; v <= 10; v++)
            for (int e = 0; e < 4; e++) r[v, e] = t[v - 1][e];
        return r;
    }

    private static int EccColumn(QrErrorCorrection e) => e switch
    {
        QrErrorCorrection.L => 0, QrErrorCorrection.M => 1, QrErrorCorrection.Q => 2, _ => 3
    };

    private static int DataCodewords(int version, QrErrorCorrection ecc)
    {
        var b = Blocks[version, EccColumn(ecc)];
        return b[1] * b[2] + b[3] * b[4];
    }

    // ------------------------------------------------------------------ drawing

    private void SetFunction(int x, int y, bool dark)
    {
        _modules[y, x] = dark;
        _isFunction[y, x] = true;
    }

    private void DrawFunctionPatterns()
    {
        for (int i = 0; i < Size; i++)
        {
            SetFunction(6, i, i % 2 == 0);
            SetFunction(i, 6, i % 2 == 0);
        }
        DrawFinder(3, 3);
        DrawFinder(Size - 4, 3);
        DrawFinder(3, Size - 4);

        var pos = AlignmentPositions[Version];
        int n = pos.Length;
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
            {
                if ((i == 0 && j == 0) || (i == 0 && j == n - 1) || (i == n - 1 && j == 0)) continue;
                DrawAlignment(pos[i], pos[j]);
            }

        DrawFormatBits(0); // reserve area; real bits drawn after masking
        DrawVersion();
    }

    private void DrawFinder(int cx, int cy)
    {
        for (int dy = -4; dy <= 4; dy++)
            for (int dx = -4; dx <= 4; dx++)
            {
                int dist = Math.Max(Math.Abs(dx), Math.Abs(dy));
                int x = cx + dx, y = cy + dy;
                if (x >= 0 && x < Size && y >= 0 && y < Size)
                    SetFunction(x, y, dist != 2 && dist != 4);
            }
    }

    private void DrawAlignment(int cx, int cy)
    {
        for (int dy = -2; dy <= 2; dy++)
            for (int dx = -2; dx <= 2; dx++)
                SetFunction(cx + dx, cy + dy, Math.Max(Math.Abs(dx), Math.Abs(dy)) != 1);
    }

    private void DrawFormatBits(int mask)
    {
        int data = ((int)Ecc << 3) | mask;
        int rem = data;
        for (int i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >> 9) * 0x537);
        int bits = ((data << 10) | rem) ^ 0x5412;

        for (int i = 0; i <= 5; i++) SetFunction(8, i, Bit(bits, i));
        SetFunction(8, 7, Bit(bits, 6));
        SetFunction(8, 8, Bit(bits, 7));
        SetFunction(7, 8, Bit(bits, 8));
        for (int i = 9; i < 15; i++) SetFunction(14 - i, 8, Bit(bits, i));

        for (int i = 0; i < 8; i++) SetFunction(Size - 1 - i, 8, Bit(bits, i));
        for (int i = 8; i < 15; i++) SetFunction(8, Size - 15 + i, Bit(bits, i));
        SetFunction(8, Size - 8, true); // dark module
    }

    private void DrawVersion()
    {
        if (Version < 7) return;
        int rem = Version;
        for (int i = 0; i < 12; i++) rem = (rem << 1) ^ ((rem >> 11) * 0x1F25);
        int bits = (Version << 12) | rem;
        for (int i = 0; i < 18; i++)
        {
            bool b = Bit(bits, i);
            int a = Size - 11 + i % 3, c = i / 3;
            SetFunction(a, c, b);
            SetFunction(c, a, b);
        }
    }

    private byte[] AddEccAndInterleave(byte[] data)
    {
        var b = Blocks[Version, EccColumn(Ecc)];
        int ecLen = b[0];
        var blocks = new List<byte[]>();
        var eccs = new List<byte[]>();
        var divisor = RsDivisor(ecLen);
        int k = 0;
        for (int g = 0; g < 2; g++)
        {
            int count = g == 0 ? b[1] : b[3], len = g == 0 ? b[2] : b[4];
            for (int i = 0; i < count; i++)
            {
                var block = data.Skip(k).Take(len).ToArray();
                k += len;
                blocks.Add(block);
                eccs.Add(RsRemainder(block, divisor));
            }
        }

        var result = new List<byte>();
        int maxLen = blocks.Max(x => x.Length);
        for (int i = 0; i < maxLen; i++)
            foreach (var blk in blocks)
                if (i < blk.Length) result.Add(blk[i]);
        for (int i = 0; i < ecLen; i++)
            foreach (var e in eccs) result.Add(e[i]);
        return result.ToArray();
    }

    private void DrawCodewords(byte[] data)
    {
        int i = 0, totalBits = data.Length * 8;
        for (int right = Size - 1; right >= 1; right -= 2)
        {
            if (right == 6) right = 5;
            for (int vert = 0; vert < Size; vert++)
            {
                for (int j = 0; j < 2; j++)
                {
                    int x = right - j;
                    bool upward = ((right + 1) & 2) == 0;
                    int y = upward ? Size - 1 - vert : vert;
                    if (!_isFunction[y, x] && i < totalBits)
                    {
                        _modules[y, x] = Bit(data[i >> 3], 7 - (i & 7));
                        i++;
                    }
                }
            }
        }
    }

    private void ApplyMask(int mask)
    {
        for (int y = 0; y < Size; y++)
            for (int x = 0; x < Size; x++)
            {
                if (_isFunction[y, x]) continue;
                bool invert = mask switch
                {
                    0 => (x + y) % 2 == 0,
                    1 => y % 2 == 0,
                    2 => x % 3 == 0,
                    3 => (x + y) % 3 == 0,
                    4 => (x / 3 + y / 2) % 2 == 0,
                    5 => x * y % 2 + x * y % 3 == 0,
                    6 => (x * y % 2 + x * y % 3) % 2 == 0,
                    _ => ((x + y) % 2 + x * y % 3) % 2 == 0
                };
                if (invert) _modules[y, x] = !_modules[y, x];
            }
    }

    private int Penalty()
    {
        int penalty = 0;
        // Rule 1: runs of 5+ same-colour modules in rows and columns.
        for (int pass = 0; pass < 2; pass++)
            for (int a = 0; a < Size; a++)
            {
                int run = 1;
                for (int b = 1; b < Size; b++)
                {
                    bool cur = pass == 0 ? _modules[a, b] : _modules[b, a];
                    bool prev = pass == 0 ? _modules[a, b - 1] : _modules[b - 1, a];
                    if (cur == prev) { run++; if (run == 5) penalty += 3; else if (run > 5) penalty++; }
                    else run = 1;
                }
            }
        // Rule 2: 2x2 blocks.
        for (int y = 0; y < Size - 1; y++)
            for (int x = 0; x < Size - 1; x++)
            {
                bool c = _modules[y, x];
                if (c == _modules[y, x + 1] && c == _modules[y + 1, x] && c == _modules[y + 1, x + 1]) penalty += 3;
            }
        // Rule 3: finder-like patterns 1011101 with 4 light modules on either side.
        bool[] p1 = { true, false, true, true, true, false, true, false, false, false, false };
        bool[] p2 = { false, false, false, false, true, false, true, true, true, false, true };
        for (int pass = 0; pass < 2; pass++)
            for (int a = 0; a < Size; a++)
                for (int b = 0; b <= Size - 11; b++)
                {
                    bool m1 = true, m2 = true;
                    for (int k = 0; k < 11; k++)
                    {
                        bool v = pass == 0 ? _modules[a, b + k] : _modules[b + k, a];
                        if (v != p1[k]) m1 = false;
                        if (v != p2[k]) m2 = false;
                    }
                    if (m1) penalty += 40;
                    if (m2) penalty += 40;
                }
        // Rule 4: dark/light balance.
        int dark = 0;
        foreach (bool m in _modules) if (m) dark++;
        int total = Size * Size;
        int kDev = (Math.Abs(dark * 20 - total * 10) + total - 1) / total - 1;
        penalty += Math.Max(0, kDev) * 10;
        return penalty;
    }

    // ------------------------------------------------------------------ Reed-Solomon over GF(256), poly 0x11D

    private static byte[] RsDivisor(int degree)
    {
        var result = new byte[degree];
        result[degree - 1] = 1;
        int root = 1;
        for (int i = 0; i < degree; i++)
        {
            for (int j = 0; j < degree; j++)
            {
                result[j] = GfMul(result[j], root);
                if (j + 1 < degree) result[j] ^= result[j + 1];
            }
            root = GfMul(root, 0x02);
        }
        return result;
    }

    private static byte[] RsRemainder(byte[] data, byte[] divisor)
    {
        var result = new byte[divisor.Length];
        foreach (byte b in data)
        {
            int factor = b ^ result[0];
            Array.Copy(result, 1, result, 0, result.Length - 1);
            result[^1] = 0;
            for (int i = 0; i < result.Length; i++) result[i] ^= GfMul(divisor[i], factor);
        }
        return result;
    }

    private static byte GfMul(int x, int y)
    {
        int z = 0;
        for (int i = 7; i >= 0; i--)
        {
            z = (z << 1) ^ ((z >> 7) * 0x11D);
            z ^= ((y >> i) & 1) * x;
        }
        return (byte)z;
    }

    private static bool Bit(int x, int i) => ((x >> i) & 1) != 0;

    private sealed class BitBuffer
    {
        private readonly List<bool> _bits = new();
        public int Count => _bits.Count;

        public void Append(int value, int length)
        {
            for (int i = length - 1; i >= 0; i--) _bits.Add(((value >> i) & 1) != 0);
        }

        public byte[] ToBytes()
        {
            var r = new byte[(_bits.Count + 7) / 8];
            for (int i = 0; i < _bits.Count; i++) if (_bits[i]) r[i >> 3] |= (byte)(0x80 >> (i & 7));
            return r;
        }
    }
}
