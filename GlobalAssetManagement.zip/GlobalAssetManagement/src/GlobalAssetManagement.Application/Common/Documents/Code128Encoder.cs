using System.Text;

namespace GlobalAssetManagement.Application.Common.Documents;

/// <summary>Code 128 (code set B) barcode encoder producing SVG. Supports printable ASCII 32-126.</summary>
public static class Code128Encoder
{
    // Bar/space widths for symbol values 0..106 (106 = stop, 7 elements).
    private static readonly string[] Patterns =
    {
        "212222","222122","222221","121223","121322","131222","122213","122312","132212","221213",
        "221312","231212","112232","122132","122231","113222","123122","123221","223211","221132",
        "221231","213212","223112","312131","311222","321122","321221","312212","322112","322211",
        "212123","212321","232121","111323","131123","131321","112313","132113","132311","211313",
        "231113","231311","112133","112331","132131","113123","113321","133121","313121","211331",
        "231131","213113","213311","213131","311123","311321","331121","312113","312311","332111",
        "314111","221411","431111","111224","111422","121124","121421","141122","141221","112214",
        "112412","122114","122411","142112","142211","241211","221114","413111","241112","134111",
        "111242","121142","121241","114212","124112","124211","411212","421112","421211","212141",
        "214121","412121","111143","111341","131141","114113","114311","411113","411311","113141",
        "114131","311141","411131","211412","211214","211232","2331112"
    };

    private const int StartB = 104;
    private const int Stop = 106;

    public static IReadOnlyList<string> PatternTable => Patterns;

    /// <summary>Symbol values including start, check and stop.</summary>
    public static int[] Encode(string text)
    {
        if (string.IsNullOrEmpty(text)) throw new ArgumentException("Barcode text is empty.");
        var values = new List<int> { StartB };
        foreach (char c in text)
        {
            if (c < 32 || c > 126) throw new ArgumentException($"Character '{c}' cannot be encoded in Code 128-B.");
            values.Add(c - 32);
        }
        int checksum = StartB;
        for (int i = 1; i < values.Count; i++) checksum += values[i] * i;
        values.Add(checksum % 103);
        values.Add(Stop);
        return values.ToArray();
    }

    /// <summary>Module widths alternating bar/space, starting with a bar.</summary>
    public static int[] Widths(string text) =>
        Encode(text).SelectMany(v => Patterns[v].Select(ch => ch - '0')).ToArray();

    public static string ToSvg(string text, int moduleWidth = 2, int height = 60, bool showText = true)
    {
        var widths = Widths(text);
        const int quiet = 10;
        int totalModules = widths.Sum() + quiet * 2;
        int textHeight = showText ? 16 : 0;
        int w = totalModules * moduleWidth, h = height + textHeight;

        var sb = new StringBuilder();
        sb.Append($"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 {totalModules} {height + textHeight}\" width=\"{w}\" height=\"{h}\" preserveAspectRatio=\"none\" shape-rendering=\"crispEdges\">");
        sb.Append("<rect width=\"100%\" height=\"100%\" fill=\"#fff\"/><path fill=\"#000\" d=\"");
        int x = quiet;
        for (int i = 0; i < widths.Length; i++)
        {
            if (i % 2 == 0) sb.Append($"M{x},0h{widths[i]}v{height}h-{widths[i]}z");
            x += widths[i];
        }
        sb.Append("\"/>");
        if (showText)
            sb.Append($"<text x=\"{totalModules / 2}\" y=\"{height + 13}\" font-family=\"monospace\" font-size=\"13\" text-anchor=\"middle\">{System.Net.WebUtility.HtmlEncode(text)}</text>");
        sb.Append("</svg>");
        return sb.ToString();
    }
}
