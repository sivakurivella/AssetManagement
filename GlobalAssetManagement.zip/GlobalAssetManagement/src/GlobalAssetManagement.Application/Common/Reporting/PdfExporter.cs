using System.Globalization;
using System.Text;

namespace GlobalAssetManagement.Application.Common.Reporting;

/// <summary>
/// Dependency-free PDF writer for tabular reports: A4 landscape, standard Helvetica fonts, repeating page header
/// (organization, report title, filters, generation date), column headers and "Page x of y" footer.
/// Text is encoded as WinAnsi (Latin-1); characters outside it (e.g. the rupee sign) are transliterated.
/// </summary>
public static class PdfExporter
{
    private const float PageW = 842f, PageH = 595f, Margin = 28f;
    private const float FontSize = 7.5f, HeaderFontSize = 7.5f, RowH = 12.5f;

    public static byte[] Export(ReportTable t)
    {
        float usable = PageW - Margin * 2;
        var widths = ColumnWidths(t, usable);
        var allRows = t.Rows.Select(r => (Cells: r, Bold: false)).ToList();
        if (t.HasTotals) allRows.Add((t.TotalsRow(), true));

        float headerBlock = 64 + t.Filters.Count * 10;
        float tableTop = PageH - Margin - headerBlock;
        int rowsPerPage = Math.Max(1, (int)((tableTop - Margin - 24 - RowH) / RowH));
        int pageCount = Math.Max(1, (int)Math.Ceiling(allRows.Count / (double)rowsPerPage));

        var pages = new List<string>();
        for (int p = 0; p < pageCount; p++)
        {
            var sb = new StringBuilder();
            float y = PageH - Margin;

            // Brand bar
            sb.Append("0.043 0.235 0.490 rg ").Append(F(Margin)).Append(' ').Append(F(y - 4)).Append(' ').Append(F(usable)).Append(" 4 re f\n");
            y -= 20;
            Text(sb, Margin, y, 13, true, t.OrganizationName, "0.043 0.235 0.490");
            Text(sb, PageW - Margin - TextWidth("Global Asset Management", 8, false), y + 2, 8, false, "Global Asset Management", "0.4 0.4 0.4");
            y -= 11;
            if (!string.IsNullOrWhiteSpace(t.OrganizationAddress)) Text(sb, Margin, y, 7.5f, false, t.OrganizationAddress!, "0.3 0.3 0.3");
            y -= 16;
            Text(sb, Margin, y, 11, true, t.Title, "0 0 0");
            string gen = $"Generated: {t.GeneratedAt:dd-MM-yyyy HH:mm}" + (t.GeneratedBy is null ? "" : $" by {t.GeneratedBy}");
            Text(sb, PageW - Margin - TextWidth(gen, 7.5f, false), y, 7.5f, false, gen, "0.3 0.3 0.3");
            y -= 12;
            foreach (var f in t.Filters) { Text(sb, Margin, y, 7.5f, false, f, "0.3 0.3 0.3"); y -= 10; }
            y = tableTop;

            // Column header row
            sb.Append("0.863 0.922 0.980 rg ").Append(F(Margin)).Append(' ').Append(F(y - RowH)).Append(' ').Append(F(usable)).Append(' ').Append(F(RowH)).Append(" re f\n");
            float x = Margin;
            for (int c = 0; c < t.Columns.Count; c++)
            {
                Cell(sb, x, y, widths[c], t.Columns[c].Header, IsRight(t.Columns[c].Kind), true, HeaderFontSize);
                x += widths[c];
            }
            y -= RowH;

            foreach (var (cells, bold) in allRows.Skip(p * rowsPerPage).Take(rowsPerPage))
            {
                x = Margin;
                if (bold)
                    sb.Append("0.94 0.94 0.94 rg ").Append(F(Margin)).Append(' ').Append(F(y - RowH)).Append(' ').Append(F(usable)).Append(' ').Append(F(RowH)).Append(" re f\n");
                for (int c = 0; c < t.Columns.Count; c++)
                {
                    string s = ReportTable.Format(cells[c], t.Columns[c].Kind);
                    Cell(sb, x, y, widths[c], s, IsRight(t.Columns[c].Kind), bold, FontSize);
                    x += widths[c];
                }
                sb.Append("0.85 0.85 0.85 RG 0.4 w ").Append(F(Margin)).Append(' ').Append(F(y - RowH)).Append(" m ")
                  .Append(F(PageW - Margin)).Append(' ').Append(F(y - RowH)).Append(" l S\n");
                y -= RowH;
            }
            if (t.Rows.Count == 0) Text(sb, Margin + 4, y - 9, 8, false, "No records match the selected filters.", "0.4 0.4 0.4");

            // Footer
            sb.Append("0.7 0.7 0.7 RG 0.5 w ").Append(F(Margin)).Append(' ').Append(F(Margin + 10)).Append(" m ").Append(F(PageW - Margin)).Append(' ').Append(F(Margin + 10)).Append(" l S\n");
            Text(sb, Margin, Margin, 7, false, "Global Asset Management - developed and maintained by S.S. Solutions, Guntur | sssolutions.co.in", "0.4 0.4 0.4");
            string pg = $"Page {p + 1} of {pageCount}";
            Text(sb, PageW - Margin - TextWidth(pg, 7, false), Margin, 7, false, pg, "0.4 0.4 0.4");
            pages.Add(sb.ToString());
        }
        return Assemble(pages, t.Title);
    }

    private static bool IsRight(ColumnKind k) => k is ColumnKind.Money or ColumnKind.Number or ColumnKind.Integer or ColumnKind.Percent;

    private static float[] ColumnWidths(ReportTable t, float usable)
    {
        int n = Math.Max(1, t.Columns.Count);
        var w = new float[n];
        for (int c = 0; c < t.Columns.Count; c++)
        {
            float headerW = TextWidth(t.Columns[c].Header, HeaderFontSize, true) + 8;
            float content = t.Rows.Take(300).Select(r => TextWidth(ReportTable.Format(r[c], t.Columns[c].Kind), FontSize, false)).DefaultIfEmpty(0).Max() + 8;
            w[c] = Math.Clamp(Math.Max(headerW, content), 34f, 220f);
        }
        float total = w.Sum();
        if (total > 0)
            for (int c = 0; c < n; c++) w[c] = w[c] * usable / total;
        return w;
    }

    private static void Cell(StringBuilder sb, float x, float yTop, float width, string text, bool right, bool bold, float size)
    {
        float max = width - 6;
        string s = Fit(text, size, bold, max);
        float tx = right ? x + width - 3 - TextWidth(s, size, bold) : x + 3;
        Text(sb, tx, yTop - RowH + 3.8f, size, bold, s, "0 0 0");
    }

    private static string Fit(string s, float size, bool bold, float max)
    {
        s = Sanitize(s);
        if (TextWidth(s, size, bold) <= max) return s;
        while (s.Length > 1 && TextWidth(s + "..", size, bold) > max) s = s[..^1];
        return s + "..";
    }

    private static void Text(StringBuilder sb, float x, float y, float size, bool bold, string text, string rgb)
    {
        sb.Append(rgb).Append(" rg BT /").Append(bold ? "F2 " : "F1 ").Append(F(size)).Append(" Tf ")
          .Append(F(x)).Append(' ').Append(F(y)).Append(" Td (").Append(Escape(Sanitize(text))).Append(") Tj ET\n");
    }

    private static string F(float v) => v.ToString("0.##", CultureInfo.InvariantCulture);

    private static string Sanitize(string s)
    {
        var sb = new StringBuilder(s.Length);
        foreach (char ch in s)
        {
            if (ch == '₹') sb.Append("Rs.");
            else if (ch is '–' or '—') sb.Append('-');
            else if (ch is '‘' or '’') sb.Append('\'');
            else if (ch is '“' or '”') sb.Append('"');
            else if (ch is '\r' or '\n' or '\t') sb.Append(' ');
            else if (ch < 32) continue;
            else if (ch <= 255) sb.Append(ch);
            else sb.Append('?');
        }
        return sb.ToString();
    }

    private static string Escape(string s) => s.Replace("\\", "\\\\").Replace("(", "\\(").Replace(")", "\\)");

    // Helvetica advance widths (1/1000 em) for ASCII 32..126.
    private static readonly short[] Helv =
    {
        278,278,355,556,556,889,667,191,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,
        278,278,584,584,584,556,1015,667,667,722,722,667,611,778,722,278,500,667,556,833,722,778,667,778,722,667,
        611,722,667,944,667,667,611,278,278,278,469,556,333,556,556,500,556,556,278,556,556,222,222,500,222,833,
        556,556,556,556,333,500,278,556,500,722,500,500,500,334,260,334,584
    };

    public static float TextWidth(string s, float size, bool bold)
    {
        float units = 0;
        foreach (char ch in Sanitize(s))
            units += ch >= 32 && ch <= 126 ? Helv[ch - 32] : 556;
        return units / 1000f * size * (bold ? 1.06f : 1f);
    }

    private static byte[] Assemble(List<string> pageContents, string title)
    {
        var latin1 = Encoding.Latin1;
        using var ms = new MemoryStream();
        var offsets = new List<long>();
        void Write(string s) { var b = latin1.GetBytes(s); ms.Write(b, 0, b.Length); }
        void Obj(int id, string body) { offsets.Add(ms.Position); Write($"{id} 0 obj\n{body}\nendobj\n"); }

        Write("%PDF-1.4\n%âãÏÓ\n");
        int n = pageContents.Count;
        // 1 catalog, 2 pages, 3 F1, 4 F2, 5 info, then (page, content) pairs
        var kids = string.Join(" ", Enumerable.Range(0, n).Select(i => $"{6 + i * 2} 0 R"));
        Obj(1, "<< /Type /Catalog /Pages 2 0 R >>");
        Obj(2, $"<< /Type /Pages /Kids [{kids}] /Count {n} >>");
        Obj(3, "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>");
        Obj(4, "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>");
        Obj(5, $"<< /Title ({Escape(Sanitize(title))}) /Producer (Global Asset Management) /CreationDate (D:{DateTime.UtcNow:yyyyMMddHHmmss}Z) >>");
        for (int i = 0; i < n; i++)
        {
            int pageId = 6 + i * 2, contentId = pageId + 1;
            Obj(pageId, $"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {F(PageW)} {F(PageH)}] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents {contentId} 0 R >>");
            var content = pageContents[i];
            int len = latin1.GetByteCount(content);
            Obj(contentId, $"<< /Length {len} >>\nstream\n{content}\nendstream");
        }
        long xref = ms.Position;
        int count = offsets.Count + 1;
        var sb = new StringBuilder();
        sb.Append($"xref\n0 {count}\n0000000000 65535 f \n");
        foreach (var o in offsets) sb.Append($"{o:D10} 00000 n \n");
        sb.Append($"trailer\n<< /Size {count} /Root 1 0 R /Info 5 0 R >>\nstartxref\n{xref}\n%%EOF\n");
        Write(sb.ToString());
        return ms.ToArray();
    }
}
