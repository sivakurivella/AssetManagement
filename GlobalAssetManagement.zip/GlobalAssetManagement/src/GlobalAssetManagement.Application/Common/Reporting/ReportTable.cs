using System.Globalization;

namespace GlobalAssetManagement.Application.Common.Reporting;

public enum ColumnKind { Text, Integer, Number, Money, Date, DateTime, Percent }

public sealed record ReportColumn(string Header, ColumnKind Kind = ColumnKind.Text, bool Total = false);

/// <summary>Tabular, export-ready report result. Rows contain raw values; formatting happens per output format.</summary>
public sealed class ReportTable
{
    public string Title { get; set; } = "";
    public string OrganizationName { get; set; } = "";
    public string? OrganizationAddress { get; set; }
    public DateTime GeneratedAt { get; set; }
    public string? GeneratedBy { get; set; }
    public List<string> Filters { get; } = new();
    public List<ReportColumn> Columns { get; } = new();
    public List<object?[]> Rows { get; } = new();

    /// <summary>Optional link per row (same index as <see cref="Rows"/>) used for drill-down in the HTML view.</summary>
    public List<string?> RowLinks { get; } = new();

    public ReportTable AddColumn(string header, ColumnKind kind = ColumnKind.Text, bool total = false)
    {
        Columns.Add(new ReportColumn(header, kind, total));
        return this;
    }

    public void AddRow(string? link, params object?[] values)
    {
        if (values.Length != Columns.Count)
            throw new InvalidOperationException($"Report '{Title}' row has {values.Length} values but {Columns.Count} columns.");
        Rows.Add(values);
        RowLinks.Add(link);
    }

    public bool HasTotals => Columns.Any(c => c.Total);

    public object?[] TotalsRow()
    {
        var t = new object?[Columns.Count];
        for (int i = 0; i < Columns.Count; i++)
        {
            if (!Columns[i].Total) continue;
            decimal sum = 0;
            foreach (var r in Rows)
                if (r[i] is IConvertible c && r[i] is not string && r[i] is not DateTime)
                    sum += Convert.ToDecimal(c, CultureInfo.InvariantCulture);
            t[i] = Columns[i].Kind == ColumnKind.Integer ? (object)(long)sum : sum;
        }
        if (Columns.Count > 0 && t[0] is null) t[0] = "TOTAL";
        return t;
    }

    public static readonly CultureInfo Culture = CreateCulture();

    private static CultureInfo CreateCulture()
    {
        try { return CultureInfo.GetCultureInfo("en-IN"); }
        catch (CultureNotFoundException) { return CultureInfo.InvariantCulture; }
    }

    public static string Format(object? value, ColumnKind kind)
    {
        if (value is null) return "";
        return kind switch
        {
            ColumnKind.Money when value is IConvertible m && value is not string => Convert.ToDecimal(m, CultureInfo.InvariantCulture).ToString("N2", Culture),
            ColumnKind.Number when value is IConvertible n && value is not string => Convert.ToDecimal(n, CultureInfo.InvariantCulture).ToString("#,##0.##", Culture),
            ColumnKind.Percent when value is IConvertible p && value is not string => Convert.ToDecimal(p, CultureInfo.InvariantCulture).ToString("0.##", Culture) + "%",
            ColumnKind.Integer when value is IConvertible i && value is not string => Convert.ToInt64(i, CultureInfo.InvariantCulture).ToString("N0", Culture),
            ColumnKind.Date when value is DateTime d => d.ToString("dd-MM-yyyy", CultureInfo.InvariantCulture),
            ColumnKind.DateTime when value is DateTime dt => dt.ToString("dd-MM-yyyy HH:mm", CultureInfo.InvariantCulture),
            _ => value switch
            {
                DateTime d2 => d2.ToString("dd-MM-yyyy", CultureInfo.InvariantCulture),
                bool b => b ? "Yes" : "No",
                IFormattable f => f.ToString(null, Culture),
                _ => value.ToString() ?? ""
            }
        };
    }
}
