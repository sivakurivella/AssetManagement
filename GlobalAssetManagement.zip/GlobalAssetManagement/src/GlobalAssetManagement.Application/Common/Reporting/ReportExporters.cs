using System.Globalization;
using System.IO.Compression;
using System.Security;
using System.Text;

namespace GlobalAssetManagement.Application.Common.Reporting;

public static class CsvExporter
{
    public static byte[] Export(ReportTable t)
    {
        var sb = new StringBuilder();
        void Line(IEnumerable<string> cells) => sb.Append(string.Join(",", cells.Select(Escape))).Append("\r\n");

        Line(new[] { t.OrganizationName });
        Line(new[] { t.Title });
        Line(new[] { $"Generated: {t.GeneratedAt:dd-MM-yyyy HH:mm}" + (t.GeneratedBy is null ? "" : $" by {t.GeneratedBy}") });
        foreach (var f in t.Filters) Line(new[] { f });
        sb.Append("\r\n");
        Line(t.Columns.Select(c => c.Header));
        foreach (var r in t.Rows) Line(r.Select((v, i) => Raw(v, t.Columns[i].Kind)));
        if (t.HasTotals) Line(t.TotalsRow().Select((v, i) => Raw(v, t.Columns[i].Kind)));

        // UTF-8 with BOM so Excel opens rupee symbols and Telugu text correctly.
        return Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(sb.ToString())).ToArray();
    }

    private static string Raw(object? v, ColumnKind kind) => v switch
    {
        null => "",
        DateTime d => kind == ColumnKind.DateTime ? d.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture) : d.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
        decimal m => m.ToString("0.##", CultureInfo.InvariantCulture),
        double dbl => dbl.ToString("0.##", CultureInfo.InvariantCulture),
        bool b => b ? "Yes" : "No",
        IFormattable f => f.ToString(null, CultureInfo.InvariantCulture),
        _ => v.ToString() ?? ""
    };

    private static string Escape(string s)
    {
        // Neutralise spreadsheet formula injection.
        if (s.Length > 0 && "=+-@".Contains(s[0]) && !decimal.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out _))
            s = "'" + s;
        return s.IndexOfAny(new[] { ',', '"', '\r', '\n' }) >= 0 ? "\"" + s.Replace("\"", "\"\"") + "\"" : s;
    }
}

/// <summary>Minimal Office Open XML (.xlsx) writer: one worksheet, inline strings, numeric cells, header styling.</summary>
public static class ExcelExporter
{
    public static byte[] Export(ReportTable t)
    {
        using var ms = new MemoryStream();
        using (var zip = new ZipArchive(ms, ZipArchiveMode.Create, true))
        {
            Add(zip, "[Content_Types].xml",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
                "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
                "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>" +
                "<Override PartName=\"/docProps/core.xml\" ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/>" +
                "</Types>");
            Add(zip, "_rels/.rels",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>" +
                "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties\" Target=\"docProps/core.xml\"/>" +
                "</Relationships>");
            Add(zip, "docProps/core.xml",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:dcterms=\"http://purl.org/dc/terms/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">" +
                $"<dc:title>{X(t.Title)}</dc:title><dc:creator>Global Asset Management</dc:creator>" +
                $"<dcterms:created xsi:type=\"dcterms:W3CDTF\">{t.GeneratedAt.ToUniversalTime():yyyy-MM-ddTHH:mm:ssZ}</dcterms:created>" +
                "</cp:coreProperties>");
            Add(zip, "xl/workbook.xml",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">" +
                $"<sheets><sheet name=\"{X(SheetName(t.Title))}\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>");
            Add(zip, "xl/_rels/workbook.xml.rels",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>" +
                "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>" +
                "</Relationships>");
            // Styles: 0 default, 1 bold, 2 money, 3 date, 4 header (bold + fill + border), 5 title (bold 14), 6 integer, 7 bold money
            Add(zip, "xl/styles.xml",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
                "<numFmts count=\"2\"><numFmt numFmtId=\"164\" formatCode=\"#,##0.00\"/><numFmt numFmtId=\"165\" formatCode=\"dd\\-mm\\-yyyy\"/></numFmts>" +
                "<fonts count=\"3\"><font><sz val=\"10\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"10\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"14\"/><color rgb=\"FF0B3C7D\"/><name val=\"Calibri\"/></font></fonts>" +
                "<fills count=\"3\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFDCEBFA\"/><bgColor indexed=\"64\"/></patternFill></fill></fills>" +
                "<borders count=\"2\"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style=\"thin\"/><right style=\"thin\"/><top style=\"thin\"/><bottom style=\"thin\"/><diagonal/></border></borders>" +
                "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
                "<cellXfs count=\"8\">" +
                "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>" +
                "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/>" +
                "<xf numFmtId=\"164\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/>" +
                "<xf numFmtId=\"165\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/>" +
                "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"1\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyBorder=\"1\"/>" +
                "<xf numFmtId=\"0\" fontId=\"2\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/>" +
                "<xf numFmtId=\"3\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/>" +
                "<xf numFmtId=\"164\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\" applyFont=\"1\"/>" +
                "</cellXfs><cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>");

            var sheet = new StringBuilder();
            sheet.Append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
            sheet.Append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">");
            int headerRow = 4 + t.Filters.Count + 1;
            sheet.Append($"<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"{headerRow}\" topLeftCell=\"A{headerRow + 1}\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews>");
            sheet.Append("<cols>");
            for (int i = 0; i < t.Columns.Count; i++)
            {
                int width = Math.Clamp(Math.Max(t.Columns[i].Header.Length,
                    t.Rows.Take(200).Select(r => ReportTable.Format(r[i], t.Columns[i].Kind).Length).DefaultIfEmpty(0).Max()) + 2, 8, 60);
                sheet.Append($"<col min=\"{i + 1}\" max=\"{i + 1}\" width=\"{width}\" customWidth=\"1\"/>");
            }
            sheet.Append("</cols><sheetData>");

            int row = 1;
            sheet.Append(RowXml(row++, new[] { Str(0, row - 1, t.OrganizationName, 5) }));
            if (!string.IsNullOrWhiteSpace(t.OrganizationAddress))
                sheet.Append(RowXml(row++, new[] { Str(0, row - 1, t.OrganizationAddress!, 0) }));
            else row++;
            sheet.Append(RowXml(row++, new[] { Str(0, row - 1, t.Title, 1) }));
            sheet.Append(RowXml(row++, new[] { Str(0, row - 1, $"Generated on {t.GeneratedAt:dd-MM-yyyy HH:mm}" + (t.GeneratedBy is null ? "" : $" by {t.GeneratedBy}"), 0) }));
            foreach (var f in t.Filters) sheet.Append(RowXml(row++, new[] { Str(0, row - 1, f, 0) }));
            row = headerRow;
            sheet.Append(RowXml(row, t.Columns.Select((c, i) => Str(i, row, c.Header, 4))));
            row++;
            foreach (var r in t.Rows)
            {
                int rr = row;
                sheet.Append(RowXml(rr, r.Select((v, i) => Cell(i, rr, v, t.Columns[i].Kind, false))));
                row++;
            }
            if (t.HasTotals)
            {
                int rr = row;
                sheet.Append(RowXml(rr, t.TotalsRow().Select((v, i) => Cell(i, rr, v, t.Columns[i].Kind, true))));
            }
            sheet.Append("</sheetData>");
            sheet.Append("<pageSetup orientation=\"landscape\" paperSize=\"9\" fitToWidth=\"1\" fitToHeight=\"0\"/>");
            sheet.Append("</worksheet>");
            Add(zip, "xl/worksheets/sheet1.xml", sheet.ToString());
        }
        return ms.ToArray();
    }

    private static string RowXml(int r, IEnumerable<string> cells) => $"<row r=\"{r}\">{string.Concat(cells)}</row>";

    private static string Ref(int col, int row)
    {
        var s = "";
        col++;
        while (col > 0) { int m = (col - 1) % 26; s = (char)('A' + m) + s; col = (col - 1) / 26; }
        return s + row;
    }

    private static string Str(int col, int row, string text, int style) =>
        $"<c r=\"{Ref(col, row)}\" t=\"inlineStr\" s=\"{style}\"><is><t xml:space=\"preserve\">{X(text)}</t></is></c>";

    private static string Cell(int col, int row, object? v, ColumnKind kind, bool bold)
    {
        if (v is null) return "";
        switch (v)
        {
            case DateTime d:
                double serial = (d - new DateTime(1899, 12, 30)).TotalDays;
                return $"<c r=\"{Ref(col, row)}\" s=\"3\"><v>{serial.ToString(CultureInfo.InvariantCulture)}</v></c>";
            case bool b:
                return Str(col, row, b ? "Yes" : "No", bold ? 1 : 0);
            case string s:
                return Str(col, row, s, bold ? 1 : 0);
            case IConvertible c when IsNumeric(v):
                int style = kind is ColumnKind.Integer ? 6 : kind is ColumnKind.Money or ColumnKind.Number ? (bold ? 7 : 2) : (bold ? 1 : 0);
                return $"<c r=\"{Ref(col, row)}\" s=\"{style}\"><v>{Convert.ToDecimal(c, CultureInfo.InvariantCulture).ToString(CultureInfo.InvariantCulture)}</v></c>";
            default:
                return Str(col, row, ReportTable.Format(v, kind), bold ? 1 : 0);
        }
    }

    private static bool IsNumeric(object v) => v is byte or short or int or long or float or double or decimal;

    private static string SheetName(string title)
    {
        var clean = new string(title.Where(ch => !"[]:*?/\\".Contains(ch)).ToArray()).Trim();
        if (clean.Length == 0) clean = "Report";
        return clean.Length > 31 ? clean[..31] : clean;
    }

    private static string X(string s) => SecurityElement.Escape(new string(s.Where(ch => ch == '\t' || ch == '\n' || ch == '\r' || ch >= ' ').ToArray())) ?? "";

    private static void Add(ZipArchive zip, string name, string content)
    {
        var e = zip.CreateEntry(name, CompressionLevel.Optimal);
        using var w = new StreamWriter(e.Open(), new UTF8Encoding(false));
        w.Write(content);
    }
}
