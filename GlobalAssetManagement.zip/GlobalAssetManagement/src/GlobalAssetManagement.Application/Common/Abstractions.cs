using GlobalAssetManagement.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;

namespace GlobalAssetManagement.Application.Common;

/// <summary>Unit of work over the SQL Server database. Implemented by the Infrastructure AppDbContext.</summary>
public interface IAppDbContext
{
    DbSet<Company> Companies { get; }
    DbSet<Branch> Branches { get; }
    DbSet<Department> Departments { get; }
    DbSet<Location> Locations { get; }
    DbSet<Employee> Employees { get; }
    DbSet<AssetCategory> AssetCategories { get; }
    DbSet<AssetSubcategory> AssetSubcategories { get; }
    DbSet<AssetType> AssetTypes { get; }
    DbSet<Manufacturer> Manufacturers { get; }
    DbSet<Brand> Brands { get; }
    DbSet<AssetModel> AssetModels { get; }
    DbSet<Asset> Assets { get; }
    DbSet<AssetDocument> AssetDocuments { get; }
    DbSet<AssetImage> AssetImages { get; }
    DbSet<AssetEvent> AssetEvents { get; }
    DbSet<Attachment> Attachments { get; }
    DbSet<Vendor> Vendors { get; }
    DbSet<PurchaseRequest> PurchaseRequests { get; }
    DbSet<PurchaseRequestItem> PurchaseRequestItems { get; }
    DbSet<Quotation> Quotations { get; }
    DbSet<PurchaseOrder> PurchaseOrders { get; }
    DbSet<PurchaseOrderItem> PurchaseOrderItems { get; }
    DbSet<GoodsReceipt> GoodsReceipts { get; }
    DbSet<GoodsReceiptItem> GoodsReceiptItems { get; }
    DbSet<PurchaseInvoice> PurchaseInvoices { get; }
    DbSet<AssetAllocation> AssetAllocations { get; }
    DbSet<AssetTransfer> AssetTransfers { get; }
    DbSet<AssetReturn> AssetReturns { get; }
    DbSet<AssetAddition> AssetAdditions { get; }
    DbSet<ServiceAgency> ServiceProviders { get; }
    DbSet<ServiceRequest> ServiceRequests { get; }
    DbSet<RepairEstimate> RepairEstimates { get; }
    DbSet<WorkOrder> WorkOrders { get; }
    DbSet<WorkOrderLabour> WorkOrderLabour { get; }
    DbSet<WorkOrderPart> WorkOrderParts { get; }
    DbSet<MaintenanceSchedule> MaintenanceSchedules { get; }
    DbSet<MaintenanceHistory> MaintenanceHistory { get; }
    DbSet<WarrantyRecord> WarrantyRecords { get; }
    DbSet<AMContract> AMContracts { get; }
    DbSet<AMContractAsset> AMContractAssets { get; }
    DbSet<ServiceVisit> ServiceVisits { get; }
    DbSet<PhysicalVerificationSession> PhysicalVerificationSessions { get; }
    DbSet<PhysicalVerificationItem> PhysicalVerificationItems { get; }
    DbSet<DepreciationSchedule> DepreciationSchedules { get; }
    DbSet<DepreciationTransaction> DepreciationTransactions { get; }
    DbSet<AssetDisposal> AssetDisposals { get; }
    DbSet<ApprovalRule> ApprovalRules { get; }
    DbSet<Approval> Approvals { get; }
    DbSet<Notification> Notifications { get; }
    DbSet<NotificationLog> NotificationLogs { get; }
    DbSet<NotificationSetting> NotificationSettings { get; }
    DbSet<AuditLog> AuditLogs { get; }
    DbSet<LoginHistory> LoginHistory { get; }
    DbSet<ApplicationSetting> ApplicationSettings { get; }
    DbSet<RolePermission> RolePermissions { get; }
    DbSet<NumberSequence> NumberSequences { get; }
    DbSet<BackupLog> BackupLogs { get; }

    DbSet<TEntity> Set<TEntity>() where TEntity : class;
    Microsoft.EntityFrameworkCore.ChangeTracking.EntityEntry<TEntity> Entry<TEntity>(TEntity entity) where TEntity : class;
    DatabaseFacade Database { get; }
    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
}

public interface ICurrentUser
{
    string? UserId { get; }
    string UserName { get; }
    bool IsAuthenticated { get; }
    IReadOnlyCollection<string> Roles { get; }
    bool IsInRole(string role);

    /// <summary>When set, the user may only see data of this branch.</summary>
    int? BranchId { get; }

    /// <summary>When set, the user may only see data of this department.</summary>
    int? DepartmentId { get; }

    int? EmployeeId { get; }
    string? IpAddress { get; }
}

public interface IClock
{
    DateTime UtcNow { get; }

    /// <summary>Current time in the configured application time zone (default India Standard Time).</summary>
    DateTime Now { get; }

    DateTime Today { get; }
    DateTime ToLocal(DateTime utc);
}

public interface IFileStorage
{
    /// <summary>Saves a stream under a random file name and returns that name.</summary>
    Task<string> SaveAsync(Stream content, string folder, string extension, CancellationToken ct = default);
    Stream? OpenRead(string folder, string storedFileName);
    void Delete(string folder, string storedFileName);
    string RootPath { get; }
}

public sealed record DirectoryUser(string UserId, string UserName, string? FullName, string? Email, string? Phone, int? BranchId, int? EmployeeId);

public interface IUserDirectory
{
    Task<IReadOnlyList<DirectoryUser>> GetUsersInRoleAsync(string role, CancellationToken ct = default);
    Task<DirectoryUser?> FindAsync(string userId, CancellationToken ct = default);
}

public sealed record SendResult(bool Success, bool Skipped, string? Error)
{
    public static readonly SendResult Ok = new(true, false, null);
    public static readonly SendResult NotConfigured = new(false, true, "Channel not configured");
    public static SendResult Failed(string error) => new(false, false, error);
}

public interface IEmailSender
{
    bool IsConfigured { get; }
    Task<SendResult> SendAsync(string to, string subject, string htmlBody, CancellationToken ct = default);
}

public interface ISmsSender
{
    bool IsConfigured { get; }
    Task<SendResult> SendAsync(string mobile, string message, CancellationToken ct = default);
}

public interface IWhatsAppSender
{
    bool IsConfigured { get; }
    Task<SendResult> SendAsync(string mobile, string message, CancellationToken ct = default);
}

/// <summary>Validation or business-rule failure that should be shown to the user as a friendly message.</summary>
public sealed class BusinessException(string message) : Exception(message);

public sealed class PagedResult<T>
{
    public IReadOnlyList<T> Items { get; init; } = Array.Empty<T>();
    public int Page { get; init; }
    public int PageSize { get; init; }
    public int TotalCount { get; init; }
    public int TotalPages => PageSize <= 0 ? 1 : Math.Max(1, (int)Math.Ceiling(TotalCount / (double)PageSize));
}

public sealed class AppOptions
{
    public const string Section = "App";

    public string ProductName { get; set; } = "Global Asset Management";
    public string AssetTagPrefix { get; set; } = "GAM";

    /// <summary>Base URL encoded in asset QR codes, e.g. https://assets.example.com. Falls back to the request host.</summary>
    public string? PublicBaseUrl { get; set; }

    /// <summary>Windows ("India Standard Time") or IANA ("Asia/Kolkata") time zone id used for display and dates.</summary>
    public string TimeZone { get; set; } = "India Standard Time";

    public int ExpiringSoonDays { get; set; } = 30;
    public int AmcRenewalWindowDays { get; set; } = 30;
}

public sealed class UploadOptions
{
    public const string Section = "Uploads";

    /// <summary>Folder outside wwwroot where documents are stored. Relative paths resolve from the content root.</summary>
    public string RootPath { get; set; } = "App_Data/uploads";
    public int MaxFileSizeMb { get; set; } = 10;
}

public sealed class NotificationOptions
{
    public const string Section = "Notifications";
    public bool BackgroundJobsEnabled { get; set; } = true;
    public int IntervalMinutes { get; set; } = 60;
}

public sealed class BackupOptions
{
    public const string Section = "Backup";

    /// <summary>Folder on the SQL Server machine where BACKUP DATABASE writes .bak files.</summary>
    public string DatabaseBackupFolder { get; set; } = @"C:\GAMBackups\Database";

    /// <summary>Folder on the web server where zipped copies of the uploads folder are written.</summary>
    public string FilesBackupFolder { get; set; } = @"C:\GAMBackups\Files";
    public int RetentionDays { get; set; } = 30;

    /// <summary>When set (0-23), the application takes a daily database + files backup after this hour. Null = disabled.</summary>
    public int? AutoBackupHour { get; set; }
}
