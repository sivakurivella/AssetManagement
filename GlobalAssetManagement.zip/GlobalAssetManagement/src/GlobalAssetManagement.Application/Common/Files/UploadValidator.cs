namespace GlobalAssetManagement.Application.Common.Files;

public sealed record UploadCheckResult(bool Ok, string? Error)
{
    public static readonly UploadCheckResult Success = new(true, null);
    public static UploadCheckResult Fail(string error) => new(false, error);
}

/// <summary>
/// Validates uploads by extension whitelist, size limit and file signature ("magic numbers"), so a renamed
/// executable cannot be stored as a PDF or image.
/// </summary>
public static class UploadValidator
{
    public static readonly string[] ImageExtensions = { ".jpg", ".jpeg", ".png", ".gif", ".webp" };
    public static readonly string[] DocumentExtensions = { ".pdf", ".jpg", ".jpeg", ".png", ".gif", ".webp", ".doc", ".docx", ".xls", ".xlsx", ".txt", ".csv" };

    public static UploadCheckResult Validate(string? fileName, long length, ReadOnlySpan<byte> header,
        IReadOnlyCollection<string> allowedExtensions, long maxBytes)
    {
        if (string.IsNullOrWhiteSpace(fileName)) return UploadCheckResult.Fail("File name is missing.");
        if (length <= 0) return UploadCheckResult.Fail("The file is empty.");
        if (length > maxBytes) return UploadCheckResult.Fail($"The file exceeds the maximum size of {maxBytes / 1024 / 1024} MB.");

        string name = Path.GetFileName(fileName.Replace('\\', '/'));
        string ext = Path.GetExtension(name).ToLowerInvariant();
        if (string.IsNullOrEmpty(ext) || !allowedExtensions.Contains(ext, StringComparer.OrdinalIgnoreCase))
            return UploadCheckResult.Fail($"File type '{ext}' is not allowed. Allowed: {string.Join(", ", allowedExtensions)}.");

        if (!SignatureMatches(ext, header))
            return UploadCheckResult.Fail("The file content does not match its extension.");

        return UploadCheckResult.Success;
    }

    public static string ContentTypeFor(string extension) => extension.ToLowerInvariant() switch
    {
        ".pdf" => "application/pdf",
        ".jpg" or ".jpeg" => "image/jpeg",
        ".png" => "image/png",
        ".gif" => "image/gif",
        ".webp" => "image/webp",
        ".doc" => "application/msword",
        ".docx" => "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ".xls" => "application/vnd.ms-excel",
        ".xlsx" => "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ".txt" => "text/plain",
        ".csv" => "text/csv",
        _ => "application/octet-stream"
    };

    private static bool SignatureMatches(string ext, ReadOnlySpan<byte> h)
    {
        static bool Starts(ReadOnlySpan<byte> span, params byte[] sig) => span.Length >= sig.Length && span[..sig.Length].SequenceEqual(sig);

        return ext switch
        {
            ".pdf" => Starts(h, 0x25, 0x50, 0x44, 0x46),
            ".png" => Starts(h, 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A),
            ".jpg" or ".jpeg" => Starts(h, 0xFF, 0xD8, 0xFF),
            ".gif" => Starts(h, 0x47, 0x49, 0x46, 0x38),
            ".webp" => h.Length >= 12 && Starts(h, 0x52, 0x49, 0x46, 0x46) && h[8] == 0x57 && h[9] == 0x45 && h[10] == 0x42 && h[11] == 0x50,
            ".docx" or ".xlsx" => Starts(h, 0x50, 0x4B, 0x03, 0x04),
            ".doc" or ".xls" => Starts(h, 0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1),
            ".txt" or ".csv" => !h.Contains((byte)0) && !Starts(h, 0x4D, 0x5A),
            _ => false
        };
    }
}
