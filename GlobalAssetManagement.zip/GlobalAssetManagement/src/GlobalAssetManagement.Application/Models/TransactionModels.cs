using System.ComponentModel.DataAnnotations;
using GlobalAssetManagement.Domain.Enums;

namespace GlobalAssetManagement.Application.Models;

// ------------------------------------------------------------------ procurement

public sealed class LineInput
{
    public int Id { get; set; }
    [StringLength(300)] public string? Description { get; set; }
    public int? CategoryId { get; set; }
    public int? AssetModelId { get; set; }
    [Range(0, 1000000)] public decimal Quantity { get; set; } = 1;
    [Range(0, 999999999999)] public decimal UnitPrice { get; set; }
    [Range(0, 100)] public decimal TaxRate { get; set; }
    [StringLength(1000)] public string? Specifications { get; set; }
}

public sealed class PurchaseRequestInput
{
    public int Id { get; set; }
    [DataType(DataType.Date), Display(Name = "Request Date")] public DateTime RequestDate { get; set; } = DateTime.Today;
    [Display(Name = "Requested By")] public int? RequestedByEmployeeId { get; set; }
    [Required(ErrorMessage = "Select a branch."), Display(Name = "Branch")] public int? BranchId { get; set; }
    [Display(Name = "Department")] public int? DepartmentId { get; set; }
    [Required, StringLength(1000), Display(Name = "Purpose / Justification")] public string Purpose { get; set; } = "";
    [DataType(DataType.Date), Display(Name = "Required By")] public DateTime? RequiredByDate { get; set; }
    public Priority Priority { get; set; } = Priority.Normal;
    [StringLength(1000)] public string? Remarks { get; set; }
    public List<LineInput> Items { get; set; } = new();
}

public sealed class QuotationInput
{
    public int PurchaseRequestId { get; set; }
    [Required(ErrorMessage = "Select a vendor."), Display(Name = "Vendor")] public int? VendorId { get; set; }
    [Required, StringLength(50), Display(Name = "Quotation No.")] public string QuotationNo { get; set; } = "";
    [DataType(DataType.Date), Display(Name = "Quotation Date")] public DateTime QuotationDate { get; set; } = DateTime.Today;
    [DataType(DataType.Date), Display(Name = "Valid Until")] public DateTime? ValidUntil { get; set; }
    [Range(0, 999999999999), Display(Name = "Amount (excl. tax)")] public decimal SubTotal { get; set; }
    [Range(0, 999999999999), Display(Name = "Tax")] public decimal TaxAmount { get; set; }
    [Range(0, 999999999999), Display(Name = "Other Charges")] public decimal OtherCharges { get; set; }
    [Range(0, 3650), Display(Name = "Delivery (days)")] public int DeliveryDays { get; set; }
    [Range(0, 600), Display(Name = "Warranty (months)")] public int WarrantyMonths { get; set; }
    [StringLength(1000)] public string? Terms { get; set; }
}

public sealed class PurchaseOrderInput
{
    public int Id { get; set; }
    [DataType(DataType.Date), Display(Name = "PO Date")] public DateTime PODate { get; set; } = DateTime.Today;
    [Required(ErrorMessage = "Select a vendor."), Display(Name = "Vendor")] public int? VendorId { get; set; }
    public int? PurchaseRequestId { get; set; }
    public int? QuotationId { get; set; }
    [Required(ErrorMessage = "Select a branch."), Display(Name = "Branch")] public int? BranchId { get; set; }
    [StringLength(500), Display(Name = "Delivery Address")] public string? DeliveryAddress { get; set; }
    [DataType(DataType.Date), Display(Name = "Expected Delivery")] public DateTime? ExpectedDeliveryDate { get; set; }
    [Range(0, 999999999999), Display(Name = "Other Charges (freight etc.)")] public decimal OtherCharges { get; set; }
    [StringLength(2000), Display(Name = "Terms & Conditions")] public string? Terms { get; set; }
    [StringLength(1000)] public string? Remarks { get; set; }
    public List<LineInput> Items { get; set; } = new();
}

public sealed class GoodsReceiptLineInput
{
    public int PurchaseOrderItemId { get; set; }
    public string? Description { get; set; }
    public decimal Ordered { get; set; }
    public decimal AlreadyReceived { get; set; }
    [Range(0, 1000000)] public decimal QuantityReceived { get; set; }
    [Range(0, 1000000)] public decimal QuantityRejected { get; set; }
    [StringLength(500)] public string? Remarks { get; set; }
}

public sealed class GoodsReceiptInput
{
    public int PurchaseOrderId { get; set; }
    [DataType(DataType.Date), Display(Name = "Receipt Date")] public DateTime ReceiptDate { get; set; } = DateTime.Today;
    [StringLength(50), Display(Name = "Delivery Challan No.")] public string? DeliveryChallanNo { get; set; }
    [StringLength(150), Display(Name = "Received By")] public string? ReceivedBy { get; set; }
    [StringLength(1000)] public string? Remarks { get; set; }
    public List<GoodsReceiptLineInput> Lines { get; set; } = new();
}

public sealed class PurchaseInvoiceInput
{
    public int Id { get; set; }
    [Required, StringLength(50), Display(Name = "Invoice Number")] public string InvoiceNumber { get; set; } = "";
    [DataType(DataType.Date), Display(Name = "Invoice Date")] public DateTime InvoiceDate { get; set; } = DateTime.Today;
    [Required(ErrorMessage = "Select a vendor."), Display(Name = "Vendor")] public int? VendorId { get; set; }
    [Display(Name = "Purchase Order")] public int? PurchaseOrderId { get; set; }
    [Display(Name = "Goods Receipt")] public int? GoodsReceiptId { get; set; }
    [Range(0, 999999999999), Display(Name = "Taxable Value")] public decimal SubTotal { get; set; }
    [Range(0, 999999999999), Display(Name = "GST Amount")] public decimal TaxAmount { get; set; }
    [Range(0, 999999999999), Display(Name = "Freight Charges")] public decimal FreightCharges { get; set; }
    [Range(0, 999999999999), Display(Name = "Installation Charges")] public decimal InstallationCharges { get; set; }
    [Range(0, 999999999999), Display(Name = "Other Charges")] public decimal OtherCharges { get; set; }
    [Display(Name = "GST input credit claimed")] public bool GstInputCreditClaimed { get; set; } = true;
    [DataType(DataType.Date), Display(Name = "Payment Due Date")] public DateTime? DueDate { get; set; }
    [StringLength(1000)] public string? Remarks { get; set; }
}

public sealed class RegisterAssetLine
{
    public int? PurchaseOrderItemId { get; set; }
    [Required, StringLength(200)] public string Name { get; set; } = "";
    [Required] public int? CategoryId { get; set; }
    public int? SubcategoryId { get; set; }
    public int? AssetModelId { get; set; }
    public int? ManufacturerId { get; set; }
    public int? BrandId { get; set; }
    [StringLength(100)] public string? ModelNumber { get; set; }
    [Range(0, 999999999999)] public decimal UnitCost { get; set; }
    [Range(0, 100)] public decimal TaxRate { get; set; }
    public decimal PendingQuantity { get; set; }
    [Range(0, 1000)] public int Quantity { get; set; }

    /// <summary>One serial number per line of text; may be fewer than the quantity.</summary>
    public string? SerialNumbers { get; set; }
    [Range(0, 600)] public int WarrantyMonths { get; set; }
}

public sealed class RegisterAssetsInput
{
    public int PurchaseInvoiceId { get; set; }
    [Required] public int? BranchId { get; set; }
    public int? DepartmentId { get; set; }
    public int? LocationId { get; set; }
    public AssetStatus Status { get; set; } = AssetStatus.Received;
    [DataType(DataType.Date)] public DateTime? InstallationDate { get; set; }
    public List<RegisterAssetLine> Lines { get; set; } = new();
}

// ------------------------------------------------------------------ allocation

public sealed class IssueInput
{
    [Required(ErrorMessage = "Select an asset."), Display(Name = "Asset")] public int? AssetId { get; set; }
    [Display(Name = "Issue To")] public AllocationTargetType TargetType { get; set; } = AllocationTargetType.Employee;
    [Display(Name = "Employee")] public int? EmployeeId { get; set; }
    [Display(Name = "Department")] public int? DepartmentId { get; set; }
    [Display(Name = "Location")] public int? LocationId { get; set; }
    [DataType(DataType.Date), Display(Name = "Expected Return Date")] public DateTime? ExpectedReturnDate { get; set; }
    [Display(Name = "Temporary loan / reusable equipment")] public bool IsTemporaryLoan { get; set; }
    [StringLength(500)] public string? Purpose { get; set; }
    [Display(Name = "Condition at Issue")] public AssetCondition ConditionAtIssue { get; set; } = AssetCondition.Good;
    [StringLength(500), Display(Name = "Accessories Issued")] public string? AccessoriesIssued { get; set; }
}

public sealed class ReturnInput
{
    public int AllocationId { get; set; }
    [DataType(DataType.Date), Display(Name = "Return Date")] public DateTime ReturnDate { get; set; } = DateTime.Today;
    [Display(Name = "Condition on Return")] public AssetCondition ReturnCondition { get; set; } = AssetCondition.Good;
    [StringLength(1000)] public string? Remarks { get; set; }
    [Display(Name = "Send for repair after return")] public bool SendForRepair { get; set; }
}

public sealed class TransferInput
{
    [Required(ErrorMessage = "Select an asset."), Display(Name = "Asset")] public int? AssetId { get; set; }
    [Display(Name = "Transfer Type")] public TransferType TransferType { get; set; } = TransferType.Location;
    [Display(Name = "To Employee")] public int? ToEmployeeId { get; set; }
    [Display(Name = "To Department")] public int? ToDepartmentId { get; set; }
    [Display(Name = "To Branch")] public int? ToBranchId { get; set; }
    [Display(Name = "To Location")] public int? ToLocationId { get; set; }
    [DataType(DataType.Date), Display(Name = "Transfer Date")] public DateTime TransferDate { get; set; } = DateTime.Today;
    [Required, StringLength(1000), Display(Name = "Reason for Transfer")] public string Reason { get; set; } = "";
}

// ------------------------------------------------------------------ additions

public sealed class AdditionInput
{
    [Required(ErrorMessage = "Select an asset."), Display(Name = "Asset")] public int? AssetId { get; set; }
    [DataType(DataType.Date), Display(Name = "Addition Date")] public DateTime AdditionDate { get; set; } = DateTime.Today;
    [Required, StringLength(1000)] public string Description { get; set; } = "";
    [Display(Name = "Supplier")] public int? VendorId { get; set; }
    [StringLength(50), Display(Name = "Invoice Number")] public string? InvoiceNumber { get; set; }
    [DataType(DataType.Date), Display(Name = "Invoice Date")] public DateTime? InvoiceDate { get; set; }
    [Range(0.01, 999999999999)] public decimal Cost { get; set; }
    [Range(0, 999999999999), Display(Name = "GST / Tax")] public decimal TaxAmount { get; set; }
    [Display(Name = "GST input credit claimed")] public bool GstInputCreditClaimed { get; set; } = true;
    [StringLength(1000)] public string? Remarks { get; set; }
}

public sealed class ClassifyAdditionInput
{
    public int Id { get; set; }
    [Display(Name = "Classification")] public ExpenditureType ExpenditureType { get; set; }
    [DataType(DataType.Date), Display(Name = "Capitalization Date")] public DateTime? CapitalizationDate { get; set; }
    [Range(0, 100), Display(Name = "Revised Useful Life (years, optional)")] public decimal? RevisedUsefulLifeYears { get; set; }
    [StringLength(1000)] public string? Remarks { get; set; }
}

// ------------------------------------------------------------------ maintenance

public sealed class ServiceRequestInput
{
    [Required(ErrorMessage = "Select an asset."), Display(Name = "Asset")] public int? AssetId { get; set; }
    [Display(Name = "Problem Category")] public ProblemCategory ProblemCategory { get; set; } = ProblemCategory.Hardware;
    [Required, StringLength(2000), Display(Name = "Fault Description")] public string FaultDescription { get; set; } = "";
    public Priority Priority { get; set; } = Priority.Normal;
    [DataType(DataType.Date), Display(Name = "Requested Service Date")] public DateTime? RequestedServiceDate { get; set; }
    [Display(Name = "Asset is not usable (start downtime)")] public bool AssetDown { get; set; }
    [Display(Name = "Requested By (employee)")] public int? RequestedByEmployeeId { get; set; }
}

public sealed class EstimateInput
{
    public int ServiceRequestId { get; set; }
    [Display(Name = "Service Provider")] public int? ServiceProviderId { get; set; }
    [Range(0, 999999999999), Display(Name = "Labour")] public decimal LabourCharges { get; set; }
    [Range(0, 999999999999), Display(Name = "Spare Parts")] public decimal PartsCost { get; set; }
    [Range(0, 999999999999), Display(Name = "Travel")] public decimal TravelCharges { get; set; }
    [Range(0, 999999999999), Display(Name = "Other")] public decimal OtherCharges { get; set; }
    [Range(0, 999999999999), Display(Name = "GST / Tax")] public decimal TaxAmount { get; set; }
    [StringLength(2000)] public string? Details { get; set; }
}

public sealed class WorkOrderInput
{
    [Required(ErrorMessage = "Select an asset."), Display(Name = "Asset")] public int? AssetId { get; set; }
    public int? ServiceRequestId { get; set; }
    [Display(Name = "Work Type")] public WorkType WorkType { get; set; } = WorkType.Breakdown;
    public Priority Priority { get; set; } = Priority.Normal;
    [Required, StringLength(300)] public string Title { get; set; } = "";
    [Display(Name = "Technician (user)")] public string? TechnicianUserId { get; set; }
    [StringLength(150), Display(Name = "Technician Name")] public string? TechnicianName { get; set; }
    [Display(Name = "Service Provider")] public int? ServiceProviderId { get; set; }
    [DataType(DataType.Date), Display(Name = "Due Date")] public DateTime? DueDate { get; set; }
}

public sealed class WorkOrderCompletionInput
{
    public int WorkOrderId { get; set; }
    [Range(0, 999999999999)] public decimal TravelCharges { get; set; }
    [Range(0, 999999999999), Display(Name = "Other Expenses")] public decimal OtherExpenses { get; set; }
    [Range(0, 999999999999), Display(Name = "GST / Tax")] public decimal TaxAmount { get; set; }
    [Range(0, 600), Display(Name = "Repair Warranty (months)")] public int RepairWarrantyMonths { get; set; }
    [Required, StringLength(4000), Display(Name = "Service Report")] public string ServiceReport { get; set; } = "";
    [Display(Name = "Asset condition after work")] public AssetCondition ConditionAfter { get; set; } = AssetCondition.Good;
}

public sealed class ScheduleInput
{
    public int Id { get; set; }
    [Required(ErrorMessage = "Select an asset."), Display(Name = "Asset")] public int? AssetId { get; set; }
    [Required, StringLength(200)] public string Title { get; set; } = "";
    [Display(Name = "Maintenance Type")] public WorkType MaintenanceType { get; set; } = WorkType.Preventive;
    public MaintenanceFrequency Frequency { get; set; } = MaintenanceFrequency.Monthly;
    [Range(1, 3650), Display(Name = "Custom Interval (days)")] public int? CustomIntervalDays { get; set; }
    [DataType(DataType.Date), Display(Name = "First Due Date")] public DateTime StartDate { get; set; } = DateTime.Today;
    [DataType(DataType.Date), Display(Name = "End Date (optional)")] public DateTime? EndDate { get; set; }
    [Range(0, 90), Display(Name = "Create work order (days before due)")] public int LeadDays { get; set; } = 7;
    [Display(Name = "Service Provider")] public int? ServiceProviderId { get; set; }
    [Display(Name = "AMC Contract")] public int? AMContractId { get; set; }
    [StringLength(150), Display(Name = "Assigned Technician")] public string? AssignedTechnician { get; set; }
    [StringLength(2000)] public string? Checklist { get; set; }
    [Range(0, 999999999999), Display(Name = "Estimated Cost")] public decimal EstimatedCost { get; set; }
    [Display(Name = "Active")] public bool IsActive { get; set; } = true;
}

// ------------------------------------------------------------------ warranty / AMC

public sealed class WarrantyInput
{
    public int Id { get; set; }
    [Required(ErrorMessage = "Select an asset."), Display(Name = "Asset")] public int? AssetId { get; set; }
    [Display(Name = "Warranty Type")] public WarrantyType WarrantyType { get; set; } = WarrantyType.Manufacturer;
    [Required, StringLength(200)] public string Provider { get; set; } = "";
    [DataType(DataType.Date), Display(Name = "Start Date")] public DateTime StartDate { get; set; } = DateTime.Today;
    [DataType(DataType.Date), Display(Name = "Expiry Date")] public DateTime ExpiryDate { get; set; } = DateTime.Today.AddYears(1);
    [StringLength(2000)] public string? Terms { get; set; }
    [StringLength(2000), Display(Name = "Coverage Details")] public string? CoverageDetails { get; set; }
    [StringLength(200), Display(Name = "Claim Contact")] public string? ClaimContact { get; set; }
    [StringLength(100), Display(Name = "Certificate No.")] public string? CertificateNo { get; set; }
    [Display(Name = "Primary warranty (shown on asset master)")] public bool IsPrimary { get; set; } = true;
}

public sealed class AmcInput
{
    public int Id { get; set; }
    [Required, StringLength(50), Display(Name = "Contract No.")] public string ContractNo { get; set; } = "";
    [Required(ErrorMessage = "Select the AMC provider."), Display(Name = "AMC Provider")] public int? ServiceProviderId { get; set; }
    [Display(Name = "Contract Type")] public AmcContractType ContractType { get; set; } = AmcContractType.Comprehensive;
    [DataType(DataType.Date), Display(Name = "Start Date")] public DateTime StartDate { get; set; } = DateTime.Today;
    [DataType(DataType.Date), Display(Name = "Expiry Date")] public DateTime ExpiryDate { get; set; } = DateTime.Today.AddYears(1).AddDays(-1);
    [Range(0, 999999999999), Display(Name = "Annual Contract Value")] public decimal AnnualValue { get; set; }
    [Range(0, 999999999999), Display(Name = "GST")] public decimal TaxAmount { get; set; }
    [Range(0, 365), Display(Name = "Service Visits per Year")] public int VisitsPerYear { get; set; } = 4;
    [Range(0, 720), Display(Name = "Response Time (hours)")] public int ResponseTimeHours { get; set; } = 24;
    [Range(0, 2160), Display(Name = "Resolution Time (hours)")] public int ResolutionTimeHours { get; set; } = 72;
    [StringLength(2000)] public string? Coverage { get; set; }
    [StringLength(2000)] public string? Terms { get; set; }
    [Display(Name = "Covered Assets")] public List<int> AssetIds { get; set; } = new();
    [Display(Name = "Generate visit schedule")] public bool GenerateVisits { get; set; } = true;
}

public sealed class ServiceVisitInput
{
    public int Id { get; set; }
    public int? AMContractId { get; set; }
    [Display(Name = "Asset")] public int? AssetId { get; set; }
    [DataType(DataType.Date), Display(Name = "Scheduled Date")] public DateTime ScheduledDate { get; set; } = DateTime.Today;
    [Display(Name = "Call Logged At")] public DateTime? CallLoggedAt { get; set; }
    [Display(Name = "Engineer Responded At")] public DateTime? RespondedAt { get; set; }
    [Display(Name = "Resolved At")] public DateTime? ResolvedAt { get; set; }
    [StringLength(150), Display(Name = "Engineer")] public string? EngineerName { get; set; }
    [StringLength(2000), Display(Name = "Work Done")] public string? WorkDone { get; set; }
    public ServiceVisitStatus Status { get; set; } = ServiceVisitStatus.Completed;
}

// ------------------------------------------------------------------ verification, disposal

public sealed class VerificationSessionInput
{
    [Required, StringLength(200)] public string Title { get; set; } = "";
    [Display(Name = "Branch")] public int? BranchId { get; set; }
    [Display(Name = "Department")] public int? DepartmentId { get; set; }
    [Display(Name = "Location")] public int? LocationId { get; set; }
    [Display(Name = "Record GPS coordinates with each scan (asks the browser for permission)")] public bool CaptureGps { get; set; }
    [StringLength(2000)] public string? Remarks { get; set; }
}

public sealed class ScanInput
{
    public int SessionId { get; set; }
    [Required, StringLength(300)] public string Code { get; set; } = "";
    public int? FoundLocationId { get; set; }
    public AssetCondition? Condition { get; set; }
    [StringLength(1000)] public string? Remarks { get; set; }
    public decimal? Latitude { get; set; }
    public decimal? Longitude { get; set; }
}

public sealed class DisposalInput
{
    [Required(ErrorMessage = "Select an asset."), Display(Name = "Asset")] public int? AssetId { get; set; }
    [Display(Name = "Disposal Method")] public DisposalMethod Method { get; set; } = DisposalMethod.Scrap;
    [DataType(DataType.Date), Display(Name = "Proposed Disposal Date")] public DateTime ProposedDisposalDate { get; set; } = DateTime.Today;
    [Required, StringLength(1000)] public string Reason { get; set; } = "";
    [Range(0, 999999999999), Display(Name = "Expected Realisable Value")] public decimal ExpectedValue { get; set; }
    [StringLength(200), Display(Name = "Buyer / Recipient")] public string? BuyerOrRecipient { get; set; }
}

public sealed class CompleteDisposalInput
{
    public int Id { get; set; }
    [DataType(DataType.Date), Display(Name = "Disposal Date")] public DateTime DisposalDate { get; set; } = DateTime.Today;
    [Range(0, 999999999999), Display(Name = "Disposal Value / Sale Proceeds")] public decimal DisposalValue { get; set; }
    [StringLength(200), Display(Name = "Buyer / Recipient")] public string? BuyerOrRecipient { get; set; }
    [StringLength(50), Display(Name = "Sale Invoice No.")] public string? SaleInvoiceNo { get; set; }
    [StringLength(1000)] public string? Remarks { get; set; }
}
