using System.ComponentModel.DataAnnotations;
using GlobalAssetManagement.Domain.Enums;

namespace GlobalAssetManagement.Application.Models;

public sealed class AssetFilter
{
    public string? Search { get; set; }
    public int? CategoryId { get; set; }
    public int? BranchId { get; set; }
    public int? DepartmentId { get; set; }
    public int? LocationId { get; set; }
    public int? EmployeeId { get; set; }
    public int? VendorId { get; set; }
    public AssetStatus? Status { get; set; }
    public AssetCondition? Condition { get; set; }
    public CoverageStatus? Warranty { get; set; }
    public bool IncludeDisposed { get; set; }
    public string Sort { get; set; } = "tag";
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 25;
}

public sealed record AssetListItem(
    int Id, string AssetTag, string AssetCode, string Name, string Category, string? Branch, string? Department,
    string? Location, string? AssignedTo, string? SerialNumber, AssetStatus Status, AssetCondition Condition,
    DateTime? PurchaseDate, decimal GrossCost, decimal BookValue, DateTime? WarrantyExpiry);

/// <summary>Create / edit form for an asset. Financial fields are locked once depreciation has been posted.</summary>
public sealed class AssetInput : IValidatableObject
{
    public int Id { get; set; }

    [StringLength(50), Display(Name = "Asset Code (leave blank to auto-generate)")]
    public string? AssetCode { get; set; }

    [Required, StringLength(200), Display(Name = "Asset Name")]
    public string Name { get; set; } = "";

    [Required(ErrorMessage = "Select a category."), Display(Name = "Category")]
    public int? CategoryId { get; set; }

    [Display(Name = "Subcategory")] public int? SubcategoryId { get; set; }
    [Display(Name = "Asset Type")] public int? AssetTypeId { get; set; }
    [Display(Name = "Manufacturer")] public int? ManufacturerId { get; set; }
    [Display(Name = "Brand")] public int? BrandId { get; set; }
    [Display(Name = "Model")] public int? AssetModelId { get; set; }

    [StringLength(100), Display(Name = "Model Number")] public string? ModelNumber { get; set; }
    [StringLength(100), Display(Name = "Serial Number")] public string? SerialNumber { get; set; }

    [DataType(DataType.Date), Display(Name = "Purchase Date")] public DateTime? PurchaseDate { get; set; }
    [Display(Name = "Supplier / Vendor")] public int? VendorId { get; set; }
    [StringLength(50), Display(Name = "Invoice Number")] public string? InvoiceNumber { get; set; }
    [DataType(DataType.Date), Display(Name = "Invoice Date")] public DateTime? InvoiceDate { get; set; }

    [Range(0, 999999999999), Display(Name = "Purchase Cost (excl. GST)")] public decimal PurchaseCost { get; set; }
    [Range(0, 100), Display(Name = "GST Rate %")] public decimal TaxRate { get; set; }
    [Range(0, 999999999999), Display(Name = "GST Amount")] public decimal TaxAmount { get; set; }
    [Display(Name = "GST input credit claimed (GST not capitalized)")] public bool GstInputCreditClaimed { get; set; } = true;
    [Range(0, 999999999999), Display(Name = "Freight / Additional Charges")] public decimal AdditionalCharges { get; set; }
    [Range(0, 999999999999), Display(Name = "Installation Charges")] public decimal InstallationCharges { get; set; }

    [DataType(DataType.Date), Display(Name = "Installation Date")] public DateTime? InstallationDate { get; set; }
    [DataType(DataType.Date), Display(Name = "Commissioning Date")] public DateTime? CommissioningDate { get; set; }

    [Required(ErrorMessage = "Select a branch."), Display(Name = "Branch")] public int? BranchId { get; set; }
    [Display(Name = "Department")] public int? DepartmentId { get; set; }
    [Display(Name = "Location")] public int? LocationId { get; set; }
    [StringLength(50), Display(Name = "Rack / Position")] public string? RackPosition { get; set; }
    [Display(Name = "Assign to Employee (creates an issue record)")] public int? AssignedEmployeeId { get; set; }

    [Display(Name = "Condition")] public AssetCondition Condition { get; set; } = AssetCondition.New;
    [Display(Name = "Initial Status")] public AssetStatus Status { get; set; } = AssetStatus.InService;
    [Display(Name = "Critical asset (alert on downtime)")] public bool IsCritical { get; set; }

    [DataType(DataType.Date), Display(Name = "Warranty Start")] public DateTime? WarrantyStartDate { get; set; }
    [DataType(DataType.Date), Display(Name = "Warranty Expiry")] public DateTime? WarrantyExpiryDate { get; set; }
    [StringLength(200), Display(Name = "Warranty Provider")] public string? WarrantyProvider { get; set; }

    [Range(0, 100), Display(Name = "Useful Life (years) - blank uses category default")] public decimal? UsefulLifeYears { get; set; }
    [Display(Name = "Depreciation Method")] public DepreciationMethod? DepreciationMethod { get; set; }
    [Range(0, 100), Display(Name = "Depreciation Rate % p.a. (WDV, or custom SLM rate)")] public decimal? DepreciationRate { get; set; }
    [Range(0, 999999999999), Display(Name = "Residual / Salvage Value")] public decimal? ResidualValue { get; set; }
    [DataType(DataType.Date), Display(Name = "Depreciation Start Date")] public DateTime? DepreciationStartDate { get; set; }

    [DataType(DataType.Date), Display(Name = "Next Service Date")] public DateTime? NextServiceDate { get; set; }

    [StringLength(2000), Display(Name = "Description")] public string? Description { get; set; }
    [StringLength(4000), Display(Name = "Technical Specifications")] public string? Specifications { get; set; }
    [StringLength(1000)] public string? Remarks { get; set; }

    public string? RowVersion { get; set; }

    /// <summary>True when cost / depreciation fields can no longer be edited.</summary>
    public bool FinancialsLocked { get; set; }

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (WarrantyStartDate is { } ws && WarrantyExpiryDate is { } we && we < ws)
            yield return new ValidationResult("Warranty expiry cannot be before the warranty start date.", new[] { nameof(WarrantyExpiryDate) });
        if (InvoiceDate is { } inv && PurchaseDate is { } pd && inv > pd.AddYears(1))
            yield return new ValidationResult("Invoice date looks wrong compared with the purchase date.", new[] { nameof(InvoiceDate) });
        if (PurchaseDate is { } p && p.Date > DateTime.Today.AddDays(1))
            yield return new ValidationResult("Purchase date cannot be in the future.", new[] { nameof(PurchaseDate) });
        if (ResidualValue is { } rv && rv > PurchaseCost + AdditionalCharges + InstallationCharges + TaxAmount && PurchaseCost > 0)
            yield return new ValidationResult("Residual value cannot exceed the asset cost.", new[] { nameof(ResidualValue) });
        if (Status is AssetStatus.Disposed or AssetStatus.LostOrWrittenOff)
            yield return new ValidationResult("Use the Disposal module to dispose of or write off an asset.", new[] { nameof(Status) });
    }
}
