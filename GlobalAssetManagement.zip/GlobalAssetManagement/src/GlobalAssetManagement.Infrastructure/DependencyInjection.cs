using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Infrastructure.Identity;
using GlobalAssetManagement.Infrastructure.Persistence;
using GlobalAssetManagement.Infrastructure.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace GlobalAssetManagement.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration config)
    {
        services.Configure<AppOptions>(config.GetSection(AppOptions.Section));
        services.Configure<UploadOptions>(config.GetSection(UploadOptions.Section));
        services.Configure<NotificationOptions>(config.GetSection(NotificationOptions.Section));
        services.Configure<BackupOptions>(config.GetSection(BackupOptions.Section));
        services.Configure<SmtpOptions>(config.GetSection(SmtpOptions.Section));
        services.Configure<WhatsAppOptions>(config.GetSection(WhatsAppOptions.Section));
        services.Configure<SmsOptions>(config.GetSection(SmsOptions.Section));

        var cs = config.GetConnectionString("DefaultConnection");
        if (string.IsNullOrWhiteSpace(cs) || cs.Contains("YOUR_SQL_SERVER", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException(
                "ConnectionStrings:DefaultConnection is not configured. Copy appsettings.Production.sample.json, set your SQL Server " +
                "connection string (or the environment variable ConnectionStrings__DefaultConnection) and restart. See README.md.");

        services.AddDbContext<AppDbContext>(o => o.UseSqlServer(cs, sql =>
        {
            sql.MigrationsAssembly(typeof(AppDbContext).Assembly.FullName);
            sql.CommandTimeout(60);
        }));
        services.AddScoped<IAppDbContext>(sp => sp.GetRequiredService<AppDbContext>());

        services.AddIdentity<ApplicationUser, IdentityRole>(o =>
            {
                o.Password.RequiredLength = 8;
                o.Password.RequireDigit = true;
                o.Password.RequireLowercase = true;
                o.Password.RequireUppercase = true;
                o.Password.RequireNonAlphanumeric = true;
                o.Password.RequiredUniqueChars = 4;
                o.Lockout.AllowedForNewUsers = true;
                o.Lockout.MaxFailedAccessAttempts = 5;
                o.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(15);
                o.User.RequireUniqueEmail = true;
                o.SignIn.RequireConfirmedAccount = false;
            })
            .AddEntityFrameworkStores<AppDbContext>()
            .AddDefaultTokenProviders();

        services.AddSingleton<IClock, AppClock>();
        services.AddSingleton<IFileStorage, LocalFileStorage>();
        services.AddHttpClient("whatsapp", c => c.Timeout = TimeSpan.FromSeconds(20));
        services.AddHttpClient("sms", c => c.Timeout = TimeSpan.FromSeconds(20));
        services.AddScoped<IEmailSender, SmtpEmailSender>();
        services.AddScoped<IWhatsAppSender, WhatsAppCloudSender>();
        services.AddScoped<ISmsSender, HttpSmsSender>();
        services.AddScoped<IUserDirectory, UserDirectory>();
        services.AddScoped<BackupService>();
        services.AddSingleton<ScheduledJobsService>();
        services.AddHostedService(sp => sp.GetRequiredService<ScheduledJobsService>());
        return services;
    }
}
