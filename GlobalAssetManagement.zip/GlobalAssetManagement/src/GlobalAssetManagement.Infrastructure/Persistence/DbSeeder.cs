using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Application.Models;
using GlobalAssetManagement.Application.Services;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using GlobalAssetManagement.Domain.Logic;
using GlobalAssetManagement.Infrastructure.Identity;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace GlobalAssetManagement.Infrastructure.Persistence;

/// <summary>
/// Creates / migrates the database and seeds master data (roles, permissions, categories, settings, reminder and
/// approval defaults). Sample transactional data is created only when Seed:SampleData is true.
/// No user accounts or passwords are seeded: the first administrator is created through the one-time /Setup page.
/// </summary>
public static class DbSeeder
{
    public static async Task InitializeAsync(IServiceProvider services, IConfiguration config, ILogger logger, CancellationToken ct = default)
    {
        using var scope = services.CreateScope();
        var sp = scope.ServiceProvider;
        var db = sp.GetRequiredService<AppDbContext>();

        if (db.Database.IsRelational())
        {
            if (db.Database.GetMigrations().Any())
            {
                logger.LogInformation("Applying database migrations...");
                await db.Database.MigrateAsync(ct);
            }
            else
            {
                logger.LogWarning("No EF Core migrations found in the build. Creating the schema with EnsureCreated. " +
                                  "Run build\\build.ps1 (or 'dotnet ef migrations add InitialCreate') so future upgrades can be migrated.");
                await db.Database.EnsureCreatedAsync(ct);
            }
        }
        else
        {
            await db.Database.EnsureCreatedAsync(ct);
        }

        await SeedRolesAsync(sp.GetRequiredService<RoleManager<IdentityRole>>());
        await SeedMastersAsync(db, config, ct);

        if (config.GetValue("Seed:SampleData", false) && !await db.Assets.AnyAsync(ct))
        {
            logger.LogInformation("Seeding sample data...");
            await SampleData.SeedAsync(sp, db, ct);
        }
    }

    private static async Task SeedRolesAsync(RoleManager<IdentityRole> roles)
    {
        foreach (var r in Roles.All)
            if (!await roles.RoleExistsAsync(r))
                await roles.CreateAsync(new IdentityRole(r));
    }

    private static async Task SeedMastersAsync(AppDbContext db, IConfiguration config, CancellationToken ct)
    {
        if (!await db.Companies.AnyAsync(ct))
        {
            db.Companies.Add(new Company
            {
                Name = config["Seed:Organization:Name"] ?? "S.S. Solutions",
                Address = config["Seed:Organization:Address"],
                City = config["Seed:Organization:City"] ?? "Guntur",
                State = config["Seed:Organization:State"] ?? "Andhra Pradesh",
                Phone = config["Seed:Organization:Phone"] ?? "98494 66721",
                Email = config["Seed:Organization:Email"] ?? "siva66721@gmail.com",
                Website = config["Seed:Organization:Website"] ?? "https://sssolutions.co.in",
                FinancialYearStartMonth = 4, CurrencySymbol = "₹"
            });
            await db.SaveChangesAsync(ct);
        }
        var company = await db.Companies.OrderBy(c => c.Id).FirstAsync(ct);

        if (!await db.Branches.AnyAsync(ct))
        {
            db.Branches.Add(new Branch { CompanyId = company.Id, Code = "HO", Name = "Head Office", City = company.City, Address = company.Address });
            await db.SaveChangesAsync(ct);
        }

        if (!await db.RolePermissions.AnyAsync(ct))
        {
            db.RolePermissions.AddRange(PermissionService.Defaults());
            await db.SaveChangesAsync(ct);
        }

        if (!await db.AssetCategories.AnyAsync(ct))
        {
            foreach (var (group, code, name, life, method, rate, subs) in Categories)
            {
                var c = new AssetCategory
                {
                    Group = group, Code = code, Name = name, DefaultUsefulLifeYears = life, DefaultDepreciationMethod = method,
                    DefaultDepreciationRate = rate, DefaultResidualPercent = 5
                };
                foreach (var (sc, sn) in subs) c.Subcategories.Add(new AssetSubcategory { Code = sc, Name = sn });
                db.AssetCategories.Add(c);
            }
            await db.SaveChangesAsync(ct);
        }

        if (!await db.AssetTypes.AnyAsync(ct))
        {
            db.AssetTypes.AddRange(
                new AssetType { Name = "Hardware / Equipment", Description = "Physical equipment and machinery" },
                new AssetType { Name = "Furniture & Fixtures", Description = "Furniture, fittings and fixtures" },
                new AssetType { Name = "Software License", Description = "Perpetual or term software licenses", IsTangible = false },
                new AssetType { Name = "Tools & Instruments", Description = "Hand tools, power tools and measuring instruments" },
                new AssetType { Name = "Vehicle", Description = "Owned vehicles" });
            await db.SaveChangesAsync(ct);
        }

        var settings = new (string Key, string Value, string Group, string Description)[]
        {
            ("Labels.DefaultSize", "50x25", "Labels", "Default label size: 50x25, 38x25, 75x50, 100x50 or A4-24"),
            ("Labels.ShowSerial", "true", "Labels", "Print the serial number on asset labels"),
            ("Labels.Content", "QR", "Labels", "QR, Barcode or Both"),
            ("Assets.RequireSerialForIT", "false", "Assets", "Require serial numbers for Computers & IT assets"),
            ("Reports.PageSize", "50", "Reports", "Rows per page in on-screen reports"),
            ("Backup.LastRestoreTest", "", "Backup", "Date of the last successful restore test (record manually)"),
        };
        foreach (var s in settings)
            if (!await db.ApplicationSettings.AnyAsync(x => x.Key == s.Key, ct))
                db.ApplicationSettings.Add(new ApplicationSetting { Key = s.Key, Value = s.Value, Group = s.Group, Description = s.Description });

        var admins = $"{Roles.Administrator},{Roles.AssetManager}";
        var notificationDefaults = new Dictionary<AlertType, (string Days, string Roles, int Escalate, string? EscalateTo)>
        {
            [AlertType.WarrantyExpiry] = ("90,60,30,15,7", admins, 0, null),
            [AlertType.AmcExpiry] = ("90,60,30,15,7", $"{admins},{Roles.PurchaseManager}", 7, Roles.Administrator),
            [AlertType.MaintenanceDue] = ("15,7,1", $"{Roles.AssetManager},{Roles.MaintenanceTechnician}", 3, Roles.AssetManager),
            [AlertType.RepairPending] = ("0", $"{Roles.AssetManager},{Roles.DepartmentManager}", 2, Roles.Administrator),
            [AlertType.RepairOverdue] = ("0", $"{Roles.AssetManager},{Roles.MaintenanceTechnician}", 2, Roles.Administrator),
            [AlertType.PurchaseApprovalPending] = ("0", Roles.PurchaseManager, 3, Roles.Administrator),
            [AlertType.AssetReturnDue] = ("3,1", $"{Roles.AssetManager},{Roles.DepartmentManager}", 0, null),
            [AlertType.InspectionDue] = ("15,7,1", $"{Roles.AssetManager},{Roles.MaintenanceTechnician}", 3, Roles.AssetManager),
            [AlertType.CalibrationDue] = ("30,15,7", $"{Roles.AssetManager},{Roles.MaintenanceTechnician}", 3, Roles.AssetManager),
            [AlertType.ContractRenewalDue] = ("60,30,15", $"{admins},{Roles.PurchaseManager}", 0, null),
            [AlertType.CriticalDowntime] = ("0", $"{admins}", 1, Roles.Administrator),
            [AlertType.VerificationPending] = ("0", $"{admins}", 0, null),
            [AlertType.ApprovalPending] = ("0", Roles.Administrator, 3, Roles.Administrator),
        };
        foreach (var (type, d) in notificationDefaults)
            if (!await db.NotificationSettings.AnyAsync(x => x.AlertType == type, ct))
                db.NotificationSettings.Add(new NotificationSetting
                {
                    AlertType = type, IsEnabled = true, DaysBefore = d.Days, RecipientRoles = d.Roles,
                    EscalateAfterDays = d.Escalate, EscalateToRole = d.EscalateTo
                });

        if (!await db.ApprovalRules.AnyAsync(ct))
        {
            db.ApprovalRules.AddRange(
                new ApprovalRule { Module = ApprovalModule.PurchaseRequest, Level = 1, MinAmount = 0, ApproverRole = Roles.DepartmentManager },
                new ApprovalRule { Module = ApprovalModule.PurchaseRequest, Level = 2, MinAmount = 100000.01m, ApproverRole = Roles.Administrator },
                new ApprovalRule { Module = ApprovalModule.PurchaseOrder, Level = 1, MinAmount = 0, ApproverRole = Roles.PurchaseManager },
                new ApprovalRule { Module = ApprovalModule.PurchaseOrder, Level = 2, MinAmount = 200000.01m, ApproverRole = Roles.FinanceUser },
                new ApprovalRule { Module = ApprovalModule.RepairEstimate, Level = 1, MinAmount = 10000.01m, ApproverRole = Roles.AssetManager },
                new ApprovalRule { Module = ApprovalModule.AssetAddition, Level = 1, MinAmount = 0, ApproverRole = Roles.FinanceUser },
                new ApprovalRule { Module = ApprovalModule.AssetDisposal, Level = 1, MinAmount = 0, ApproverRole = Roles.FinanceUser },
                new ApprovalRule { Module = ApprovalModule.AssetDisposal, Level = 2, MinAmount = 50000.01m, ApproverRole = Roles.Administrator },
                new ApprovalRule { Module = ApprovalModule.AmcRenewal, Level = 1, MinAmount = 0, ApproverRole = Roles.Administrator },
                new ApprovalRule { Module = ApprovalModule.AssetTransfer, Level = 1, MinAmount = 0, ApproverRole = Roles.AssetManager, IsActive = false },
                new ApprovalRule { Module = ApprovalModule.PhysicalVerification, Level = 1, MinAmount = 0, ApproverRole = Roles.AssetManager });
        }
        await db.SaveChangesAsync(ct);
    }

    /// <summary>Default categories. Useful-life values are editable defaults, not statutory advice; confirm them with your accountant.</summary>
    private static readonly (CategoryGroup, string, string, decimal, DepreciationMethod, decimal, (string, string)[])[] Categories =
    {
        (CategoryGroup.Electronic, "TV", "Televisions & Displays", 5, DepreciationMethod.StraightLine, 0, new[] { ("LED", "LED Television"), ("LCD", "LCD Television"), ("SIGN", "Digital Signage") }),
        (CategoryGroup.Electronic, "PROJ", "Projectors", 5, DepreciationMethod.StraightLine, 0, new[] { ("PROJ", "Projector"), ("SCRN", "Projection Screen") }),
        (CategoryGroup.Electronic, "PRN", "Printers & Scanners", 5, DepreciationMethod.StraightLine, 0, new[] { ("LASER", "Laser Printer"), ("INKJET", "Inkjet Printer"), ("MFP", "Multifunction Printer"), ("SCAN", "Scanner"), ("LABEL", "Label / Barcode Printer") }),
        (CategoryGroup.Electronic, "UPS", "UPS & Power Systems", 5, DepreciationMethod.StraightLine, 0, new[] { ("ONLINE", "Online UPS"), ("OFFLINE", "Offline UPS"), ("INV", "Inverter"), ("STAB", "Stabilizer") }),
        (CategoryGroup.Electronic, "NET", "Networking Devices", 6, DepreciationMethod.StraightLine, 0, new[] { ("ROUTER", "Router"), ("SWITCH", "Network Switch"), ("AP", "Access Point"), ("FW", "Firewall") }),
        (CategoryGroup.Electronic, "CCTV", "CCTV & Audio/Video", 5, DepreciationMethod.StraightLine, 0, new[] { ("CAM", "CCTV Camera"), ("NVR", "NVR / DVR"), ("AUDIO", "Audio System"), ("VC", "Video Conferencing") }),
        (CategoryGroup.ComputersIT, "DESK", "Desktop Computers", 3, DepreciationMethod.StraightLine, 0, new[] { ("PC", "Desktop PC"), ("AIO", "All-in-One PC"), ("THIN", "Thin Client") }),
        (CategoryGroup.ComputersIT, "LAP", "Laptops & Workstations", 3, DepreciationMethod.StraightLine, 0, new[] { ("LAP", "Laptop"), ("WS", "Workstation"), ("TAB", "Tablet") }),
        (CategoryGroup.ComputersIT, "SRV", "Servers & Rack Systems", 6, DepreciationMethod.StraightLine, 0, new[] { ("RACK", "Rack Server"), ("TOWER", "Tower Server"), ("NAS", "NAS / SAN Storage"), ("RACKCAB", "Server Rack") }),
        (CategoryGroup.ComputersIT, "MON", "Monitors", 3, DepreciationMethod.StraightLine, 0, new[] { ("MON", "Monitor") }),
        (CategoryGroup.ComputersIT, "PER", "Peripherals & Accessories", 3, DepreciationMethod.StraightLine, 0, new[] { ("KB", "Keyboard"), ("MOUSE", "Mouse"), ("SCN", "Barcode Scanner"), ("WEBCAM", "Webcam") }),
        (CategoryGroup.ComputersIT, "STOR", "Storage Devices", 3, DepreciationMethod.StraightLine, 0, new[] { ("HDD", "External Hard Disk"), ("SSD", "SSD"), ("TAPE", "Tape Drive") }),
        (CategoryGroup.ComputersIT, "SW", "Software Licenses", 3, DepreciationMethod.StraightLine, 0, new[] { ("OS", "Operating System"), ("OFFICE", "Office Suite"), ("ERP", "Business Software"), ("AV", "Antivirus") }),
        (CategoryGroup.Furniture, "TBL", "Tables & Desks", 10, DepreciationMethod.StraightLine, 0, new[] { ("DESK", "Office Desk"), ("TABLE", "Table"), ("WSTN", "Workstation Desk") }),
        (CategoryGroup.Furniture, "CHR", "Chairs", 10, DepreciationMethod.StraightLine, 0, new[] { ("EXEC", "Executive Chair"), ("STAFF", "Staff Chair"), ("VISIT", "Visitor Chair") }),
        (CategoryGroup.Furniture, "CAB", "Cabinets & Storage Units", 10, DepreciationMethod.StraightLine, 0, new[] { ("CUP", "Cupboard"), ("FILE", "Filing Cabinet"), ("RACK", "Storage Rack"), ("SAFE", "Safe / Locker") }),
        (CategoryGroup.Furniture, "CONF", "Conference Room Furniture", 10, DepreciationMethod.StraightLine, 0, new[] { ("CTABLE", "Conference Table"), ("CCHAIR", "Conference Chair") }),
        (CategoryGroup.Furniture, "FIX", "Office Fixtures & Modular Furniture", 10, DepreciationMethod.StraightLine, 0, new[] { ("MOD", "Modular Workstation"), ("PART", "Partition"), ("FIXT", "Fixture") }),
        (CategoryGroup.Other, "GEN", "Generators & Machinery", 15, DepreciationMethod.StraightLine, 0, new[] { ("DG", "Diesel Generator"), ("MACH", "Machinery") }),
        (CategoryGroup.Other, "TOOL", "Power Tools & Drilling Equipment", 5, DepreciationMethod.StraightLine, 0, new[] { ("DRILL", "Drilling Machine"), ("PTOOL", "Power Tool") }),
        (CategoryGroup.Other, "AC", "Air Conditioners", 10, DepreciationMethod.StraightLine, 0, new[] { ("SPLIT", "Split AC"), ("WIN", "Window AC"), ("CASS", "Cassette AC") }),
        (CategoryGroup.Other, "CAMLAD", "Cameras & Ladders", 5, DepreciationMethod.StraightLine, 0, new[] { ("DSLR", "Camera"), ("LADDER", "Ladder") }),
        (CategoryGroup.Other, "LAB", "Laboratory Equipment", 10, DepreciationMethod.StraightLine, 0, new[] { ("INSTR", "Instrument"), ("BAL", "Weighing Balance"), ("OVEN", "Oven / Incubator") }),
        (CategoryGroup.Other, "MED", "Medical Devices", 13, DepreciationMethod.StraightLine, 0, new[] { ("MON", "Patient Monitor"), ("DIAG", "Diagnostic Equipment") }),
        (CategoryGroup.Other, "SAFE", "Safety & Fire Equipment", 5, DepreciationMethod.StraightLine, 0, new[] { ("FEXT", "Fire Extinguisher"), ("ALARM", "Fire Alarm System"), ("PPE", "Safety Equipment") }),
        (CategoryGroup.Other, "OTH", "Other Fixed Assets", 5, DepreciationMethod.StraightLine, 0, Array.Empty<(string, string)>()),
    };
}

/// <summary>Realistic demonstration data created through the real application services (so numbering and history are consistent).</summary>
internal static class SampleData
{
    public static async Task SeedAsync(IServiceProvider sp, AppDbContext db, CancellationToken ct)
    {
        var company = await db.Companies.OrderBy(c => c.Id).FirstAsync(ct);
        var ho = await db.Branches.FirstAsync(b => b.Code == "HO", ct);
        var vja = new Branch { CompanyId = company.Id, Code = "VJA", Name = "Vijayawada Branch", City = "Vijayawada" };
        db.Branches.Add(vja);

        var depts = new[]
        {
            new Department { Code = "ADM", Name = "Administration" }, new Department { Code = "ACC", Name = "Accounts" },
            new Department { Code = "IT", Name = "Information Technology" }, new Department { Code = "HR", Name = "Human Resources" },
            new Department { Code = "OPS", Name = "Operations" }, new Department { Code = "LAB", Name = "Quality Control Lab" }
        };
        db.Departments.AddRange(depts);
        await db.SaveChangesAsync(ct);

        var locs = new[]
        {
            new Location { BranchId = ho.Id, Code = "HO-GF-REC", Building = "Main Block", Floor = "Ground", Room = "Reception" },
            new Location { BranchId = ho.Id, Code = "HO-1F-ACC", Building = "Main Block", Floor = "First", Room = "Accounts Hall" },
            new Location { BranchId = ho.Id, Code = "HO-1F-SRV", Building = "Main Block", Floor = "First", Room = "Server Room" },
            new Location { BranchId = ho.Id, Code = "HO-2F-CONF", Building = "Main Block", Floor = "Second", Room = "Conference Room" },
            new Location { BranchId = ho.Id, Code = "HO-2F-LAB", Building = "Annexe", Floor = "Second", Room = "QC Lab" },
            new Location { BranchId = vja.Id, Code = "VJA-GF-OFF", Building = "Branch Office", Floor = "Ground", Room = "Front Office" },
        };
        db.Locations.AddRange(locs);

        var emps = new[]
        {
            new Employee { EmployeeCode = "E001", FullName = "Ravi Kumar", Designation = "Administration Manager", DepartmentId = depts[0].Id, BranchId = ho.Id, Phone = "9000000001" },
            new Employee { EmployeeCode = "E002", FullName = "Lakshmi Prasanna", Designation = "Accounts Executive", DepartmentId = depts[1].Id, BranchId = ho.Id, Phone = "9000000002" },
            new Employee { EmployeeCode = "E003", FullName = "Srinivas Rao", Designation = "IT Administrator", DepartmentId = depts[2].Id, BranchId = ho.Id, Phone = "9000000003" },
            new Employee { EmployeeCode = "E004", FullName = "Anitha Reddy", Designation = "HR Executive", DepartmentId = depts[3].Id, BranchId = ho.Id, Phone = "9000000004" },
            new Employee { EmployeeCode = "E005", FullName = "Venkatesh Naidu", Designation = "Operations Lead", DepartmentId = depts[4].Id, BranchId = vja.Id, Phone = "9000000005" },
            new Employee { EmployeeCode = "E006", FullName = "Divya Sri", Designation = "QC Analyst", DepartmentId = depts[5].Id, BranchId = ho.Id, Phone = "9000000006" },
        };
        db.Employees.AddRange(emps);

        var mfr = new Dictionary<string, Manufacturer>();
        foreach (var n in new[] { "Dell", "HP", "Lenovo", "Samsung", "LG", "Epson", "APC", "Cisco", "TSC", "Hikvision", "Godrej", "Featherlite", "Kirloskar", "Voltas", "Mettler Toledo", "Bosch" })
            db.Manufacturers.Add(mfr[n] = new Manufacturer { Name = n });
        await db.SaveChangesAsync(ct);
        foreach (var m in mfr.Values) db.Brands.Add(new Brand { ManufacturerId = m.Id, Name = m.Name });

        var vendors = new[]
        {
            new Vendor { Code = "V001", Name = "Spectrum Technologies", City = "Guntur", Phone = "9849466721", Supplies = "Barcode printers, scanners, IT hardware", Rating = 4.5m, PaymentTerms = "30 days" },
            new Vendor { Code = "V002", Name = "Sri Sai Computers", City = "Vijayawada", Phone = "9000000101", Supplies = "Desktops, laptops, networking", Rating = 4m, PaymentTerms = "15 days" },
            new Vendor { Code = "V003", Name = "Andhra Office Furniture", City = "Guntur", Phone = "9000000102", Supplies = "Office furniture", Rating = 3.8m, PaymentTerms = "Advance 50%" },
        };
        db.Vendors.AddRange(vendors);
        var providers = new[]
        {
            new ServiceAgency { Code = "SP01", CompanyName = "Coastal IT Services", ContactPerson = "Mahesh", Phone = "9000000201", Specialization = "Computers, printers, networking", AuthorizedBrands = "Dell, HP, Lenovo", ResponseTimeHours = 8, Rating = 4.2m },
            new ServiceAgency { Code = "SP02", CompanyName = "CoolAir Engineering", ContactPerson = "Prakash", Phone = "9000000202", Specialization = "Air conditioners", AuthorizedBrands = "Voltas, LG", ResponseTimeHours = 24, Rating = 3.9m },
            new ServiceAgency { Code = "SP03", CompanyName = "PowerSafe Systems", ContactPerson = "Kiran", Phone = "9000000203", Specialization = "UPS, generators", AuthorizedBrands = "APC, Kirloskar", ResponseTimeHours = 12, Rating = 4.0m,
                ServiceAgreementRef = "PS/AG/2025/14", ContractStart = DateTime.Today.AddMonths(-11), ContractEnd = DateTime.Today.AddDays(40) },
        };
        db.ServiceProviders.AddRange(providers);
        await db.SaveChangesAsync(ct);

        var cats = await db.AssetCategories.Include(c => c.Subcategories).ToDictionaryAsync(c => c.Code, ct);
        var assetsSvc = sp.GetRequiredService<AssetService>();
        var today = DateTime.Today;
        var created = new List<Asset>();

        async Task<Asset> Add(string name, string cat, string sub, string make, string model, decimal cost, int monthsAgo, int warrantyMonths, Location loc, Department dept, Employee? emp = null, Vendor? vendor = null, bool critical = false)
        {
            var c = cats[cat];
            var purchase = today.AddMonths(-monthsAgo);
            var a = await assetsSvc.CreateAsync(new AssetInput
            {
                Name = name, CategoryId = c.Id, SubcategoryId = c.Subcategories.FirstOrDefault(s => s.Code == sub)?.Id,
                ManufacturerId = mfr[make].Id, ModelNumber = model, SerialNumber = $"{make[..Math.Min(3, make.Length)].ToUpper()}{Random.Shared.Next(100000, 999999)}",
                PurchaseDate = purchase, VendorId = (vendor ?? vendors[1]).Id, InvoiceNumber = $"INV-{purchase:yyMM}-{Random.Shared.Next(100, 999)}", InvoiceDate = purchase,
                PurchaseCost = cost, TaxRate = 18, TaxAmount = Math.Round(cost * 0.18m, 2), GstInputCreditClaimed = true,
                InstallationDate = purchase.AddDays(3), CommissioningDate = purchase.AddDays(3),
                BranchId = loc.BranchId, DepartmentId = dept.Id, LocationId = loc.Id, AssignedEmployeeId = emp?.Id,
                Condition = monthsAgo > 30 ? AssetCondition.Fair : AssetCondition.Good, Status = AssetStatus.InService, IsCritical = critical,
                WarrantyStartDate = warrantyMonths > 0 ? purchase : null,
                WarrantyExpiryDate = warrantyMonths > 0 ? purchase.AddMonths(warrantyMonths).AddDays(-1) : null,
                WarrantyProvider = warrantyMonths > 0 ? make : null
            }, ct);
            created.Add(a);
            return a;
        }

        var server = await Add("Dell PowerEdge R550 Server", "SRV", "RACK", "Dell", "R550", 285000, 20, 36, locs[2], depts[2], null, vendors[1], critical: true);
        await Add("Cisco Catalyst 24-port Switch", "NET", "SWITCH", "Cisco", "C1000-24T", 48000, 20, 36, locs[2], depts[2]);
        await Add("APC Smart-UPS 3kVA", "UPS", "ONLINE", "APC", "SRT3KXLI", 92000, 26, 24, locs[2], depts[2], null, vendors[0], critical: true);
        await Add("Dell Latitude 5440 Laptop", "LAP", "LAP", "Dell", "Latitude 5440", 68500, 8, 36, locs[1], depts[1], emps[1]);
        await Add("Lenovo ThinkPad E14 Laptop", "LAP", "LAP", "Lenovo", "E14 Gen 5", 61000, 14, 12, locs[0], depts[0], emps[0]);
        await Add("HP ProDesk 400 G9 Desktop", "DESK", "PC", "HP", "ProDesk 400 G9", 52000, 35, 36, locs[1], depts[1], emps[1]);
        await Add("HP ProDesk 400 G9 Desktop", "DESK", "PC", "HP", "ProDesk 400 G9", 52000, 35, 36, locs[3], depts[3], emps[3]);
        await Add("Dell OptiPlex 7010 Desktop", "DESK", "PC", "Dell", "OptiPlex 7010", 58500, 11, 36, locs[5], depts[4], emps[4]);
        await Add("Samsung 24\" Monitor", "MON", "MON", "Samsung", "LS24C310", 9800, 11, 36, locs[5], depts[4]);
        await Add("HP LaserJet Pro MFP", "PRN", "MFP", "HP", "M428fdw", 34500, 30, 12, locs[1], depts[1]);
        await Add("TSC TE244 Barcode Label Printer", "PRN", "LABEL", "TSC", "TE244", 18500, 6, 12, locs[2], depts[2], null, vendors[0]);
        await Add("Epson EB-X51 Projector", "PROJ", "PROJ", "Epson", "EB-X51", 42000, 22, 24, locs[3], depts[0]);
        await Add("LG 55\" UHD Display", "TV", "LED", "LG", "55UR7500", 47000, 9, 12, locs[3], depts[0]);
        await Add("Hikvision 8-channel NVR", "CCTV", "NVR", "Hikvision", "DS-7608NI", 16500, 28, 24, locs[0], depts[0]);
        await Add("Voltas 1.5 Ton Split AC", "AC", "SPLIT", "Voltas", "183V Vectra", 38500, 23, 12, locs[2], depts[2], null, null, critical: true);
        await Add("Voltas 2 Ton Split AC", "AC", "SPLIT", "Voltas", "243V Vectra", 49500, 23, 12, locs[3], depts[0]);
        await Add("Kirloskar 30 kVA DG Set", "GEN", "DG", "Kirloskar", "KG1-30AS", 465000, 40, 24, locs[0], depts[4], null, vendors[0], critical: true);
        await Add("Godrej Executive Desk", "TBL", "DESK", "Godrej", "Interio Exec", 28500, 34, 0, locs[1], depts[1], null, vendors[2]);
        await Add("Featherlite Executive Chair", "CHR", "EXEC", "Featherlite", "Optima HB", 14500, 34, 12, locs[1], depts[1], null, vendors[2]);
        await Add("Godrej Steel Cupboard", "CAB", "CUP", "Godrej", "Storwel M2", 17800, 34, 0, locs[1], depts[1], null, vendors[2]);
        await Add("Conference Table 10-seater", "CONF", "CTABLE", "Godrej", "Interio CT10", 72000, 34, 0, locs[3], depts[0], null, vendors[2]);
        await Add("Mettler Toledo Analytical Balance", "LAB", "BAL", "Mettler Toledo", "ME204", 165000, 18, 24, locs[4], depts[5], emps[5], critical: true);
        await Add("Bosch Rotary Hammer Drill", "TOOL", "DRILL", "Bosch", "GBH 2-26", 11500, 16, 12, locs[0], depts[4]);
        await Add("Fire Extinguisher ABC 6kg", "SAFE", "FEXT", "Bosch", "ABC-6", 3200, 10, 12, locs[0], depts[0]);

        // Warranties close to expiry for reminder demonstration
        var soon = created[3];
        soon.WarrantyExpiryDate = today.AddDays(20);
        foreach (var w in db.WarrantyRecords.Where(w => w.AssetId == soon.Id)) w.ExpiryDate = today.AddDays(20);
        await db.SaveChangesAsync(ct);

        // Preventive maintenance schedules
        var maint = sp.GetRequiredService<MaintenanceService>();
        await maint.SaveScheduleAsync(new ScheduleInput { AssetId = created[14].Id, Title = "AC filter cleaning & gas check", MaintenanceType = WorkType.Preventive, Frequency = MaintenanceFrequency.Quarterly, StartDate = today.AddDays(5), LeadDays = 7, ServiceProviderId = providers[1].Id, EstimatedCost = 800 }, ct);
        await maint.SaveScheduleAsync(new ScheduleInput { AssetId = created[16].Id, Title = "DG set monthly run test & service", MaintenanceType = WorkType.Preventive, Frequency = MaintenanceFrequency.Monthly, StartDate = today.AddDays(2), LeadDays = 5, ServiceProviderId = providers[2].Id, EstimatedCost = 1500 }, ct);
        await maint.SaveScheduleAsync(new ScheduleInput { AssetId = created[21].Id, Title = "Balance calibration", MaintenanceType = WorkType.Calibration, Frequency = MaintenanceFrequency.HalfYearly, StartDate = today.AddDays(12), LeadDays = 10, EstimatedCost = 3500 }, ct);
        await maint.SaveScheduleAsync(new ScheduleInput { AssetId = created[23].Id, Title = "Fire extinguisher inspection", MaintenanceType = WorkType.SafetyInspection, Frequency = MaintenanceFrequency.Yearly, StartDate = today.AddDays(25), LeadDays = 14 }, ct);

        // AMC covering the server room equipment, due for renewal soon
        var amc = sp.GetRequiredService<WarrantyAmcService>();
        await amc.SaveAmcAsync(new AmcInput
        {
            ContractNo = "AMC/PS/2025-26/01", ServiceProviderId = providers[2].Id, ContractType = AmcContractType.Comprehensive,
            StartDate = today.AddMonths(-11).AddDays(-10), ExpiryDate = today.AddDays(25), AnnualValue = 24000, TaxAmount = 4320,
            VisitsPerYear = 4, ResponseTimeHours = 12, AssetIds = new() { created[2].Id, created[16].Id }, GenerateVisits = true
        }, ct);

        // A breakdown service request in progress
        var sr = await maint.CreateRequestAsync(new ServiceRequestInput
        {
            AssetId = created[9].Id, ProblemCategory = ProblemCategory.Hardware, Priority = Priority.High,
            FaultDescription = "Paper jam every few pages and streaks on printouts.", AssetDown = true
        }, ct);
        await maint.DecideRequestAsync(sr.Id, true, "Approved for repair", ct);
        await maint.AssignAsync(sr.Id, new WorkOrderInput { Title = "", ServiceProviderId = providers[0].Id, TechnicianName = "Mahesh (Coastal IT)", DueDate = today.AddDays(2) }, ct);

        // A pending service request awaiting review
        await maint.CreateRequestAsync(new ServiceRequestInput
        {
            AssetId = created[15].Id, ProblemCategory = ProblemCategory.Mechanical, Priority = Priority.Normal,
            FaultDescription = "AC making noise and cooling is weak in the afternoon."
        }, ct);

        await db.SaveChangesAsync(ct);
        _ = server;
    }
}
