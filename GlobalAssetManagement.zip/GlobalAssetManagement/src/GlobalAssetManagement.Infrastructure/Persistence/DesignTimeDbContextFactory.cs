using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace GlobalAssetManagement.Infrastructure.Persistence;

/// <summary>
/// Used only by the 'dotnet ef' tools (migrations add / migrations script). Creating or scripting a migration
/// does not connect to the database, so a placeholder connection string is enough. Set GAM_DESIGN_CONNECTION
/// to use a real server for commands that do connect (e.g. 'dotnet ef database update').
/// </summary>
public sealed class DesignTimeDbContextFactory : IDesignTimeDbContextFactory<AppDbContext>
{
    public AppDbContext CreateDbContext(string[] args)
    {
        var cs = Environment.GetEnvironmentVariable("GAM_DESIGN_CONNECTION")
                 ?? "Server=(localdb)\\MSSQLLocalDB;Database=GlobalAssetManagement_Design;Trusted_Connection=True;";
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseSqlServer(cs, sql => sql.MigrationsAssembly(typeof(AppDbContext).Assembly.FullName))
            .Options;
        return new AppDbContext(options);
    }
}
