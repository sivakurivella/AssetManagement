using System.Text.Json;
using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Domain.Common;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;
using GlobalAssetManagement.Infrastructure.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;

namespace GlobalAssetManagement.Infrastructure.Persistence;

public class AppDbContext : IdentityDbContext<ApplicationUser>, IAppDbContext
{
    private readonly ICurrentUser? _currentUser;
    private readonly IClock? _clock;

    public AppDbContext(DbContextOptions<AppDbContext> options, ICurrentUser? currentUser = null, IClock? clock = null)
        : base(options)
    {
        _currentUser = currentUser;
        _clock = clock;
    }

    public DbSet<Company> Companies => Set<Company>();
    public DbSet<Branch> Branches => Set<Branch>();
    public DbSet<Department> Departments => Set<Department>();
    public DbSet<Location> Locations => Set<Location>();
    public DbSet<Employee> Employees => Set<Employee>();
    public DbSet<AssetCategory> AssetCategories => Set<AssetCategory>();
    public DbSet<AssetSubcategory> AssetSubcategories => Set<AssetSubcategory>();
    public DbSet<AssetType> AssetTypes => Set<AssetType>();
    public DbSet<Manufacturer> Manufacturers => Set<Manufacturer>();
    public DbSet<Brand> Brands => Set<Brand>();
    public DbSet<AssetModel> AssetModels => Set<AssetModel>();
    public DbSet<Asset> Assets => Set<Asset>();
    public DbSet<AssetDocument> AssetDocuments => Set<AssetDocument>();
    public DbSet<AssetImage> AssetImages => Set<AssetImage>();
    public DbSet<AssetEvent> AssetEvents => Set<AssetEvent>();
    public DbSet<Attachment> Attachments => Set<Attachment>();
    public DbSet<Vendor> Vendors => Set<Vendor>();
    public DbSet<PurchaseRequest> PurchaseRequests => Set<PurchaseRequest>();
    public DbSet<PurchaseRequestItem> PurchaseRequestItems => Set<PurchaseRequestItem>();
    public DbSet<Quotation> Quotations => Set<Quotation>();
    public DbSet<PurchaseOrder> PurchaseOrders => Set<PurchaseOrder>();
    public DbSet<PurchaseOrderItem> PurchaseOrderItems => Set<PurchaseOrderItem>();
    public DbSet<GoodsReceipt> GoodsReceipts => Set<GoodsReceipt>();
    public DbSet<GoodsReceiptItem> GoodsReceiptItems => Set<GoodsReceiptItem>();
    public DbSet<PurchaseInvoice> PurchaseInvoices => Set<PurchaseInvoice>();
    public DbSet<AssetAllocation> AssetAllocations => Set<AssetAllocation>();
    public DbSet<AssetTransfer> AssetTransfers => Set<AssetTransfer>();
    public DbSet<AssetReturn> AssetReturns => Set<AssetReturn>();
    public DbSet<AssetAddition> AssetAdditions => Set<AssetAddition>();
    public DbSet<ServiceAgency> ServiceProviders => Set<ServiceAgency>();
    public DbSet<ServiceRequest> ServiceRequests => Set<ServiceRequest>();
    public DbSet<RepairEstimate> RepairEstimates => Set<RepairEstimate>();
    public DbSet<WorkOrder> WorkOrders => Set<WorkOrder>();
    public DbSet<WorkOrderLabour> WorkOrderLabour => Set<WorkOrderLabour>();
    public DbSet<WorkOrderPart> WorkOrderParts => Set<WorkOrderPart>();
    public DbSet<MaintenanceSchedule> MaintenanceSchedules => Set<MaintenanceSchedule>();
    public DbSet<MaintenanceHistory> MaintenanceHistory => Set<MaintenanceHistory>();
    public DbSet<WarrantyRecord> WarrantyRecords => Set<WarrantyRecord>();
    public DbSet<AMContract> AMContracts => Set<AMContract>();
    public DbSet<AMContractAsset> AMContractAssets => Set<AMContractAsset>();
    public DbSet<ServiceVisit> ServiceVisits => Set<ServiceVisit>();
    public DbSet<PhysicalVerificationSession> PhysicalVerificationSessions => Set<PhysicalVerificationSession>();
    public DbSet<PhysicalVerificationItem> PhysicalVerificationItems => Set<PhysicalVerificationItem>();
    public DbSet<DepreciationSchedule> DepreciationSchedules => Set<DepreciationSchedule>();
    public DbSet<DepreciationTransaction> DepreciationTransactions => Set<DepreciationTransaction>();
    public DbSet<AssetDisposal> AssetDisposals => Set<AssetDisposal>();
    public DbSet<ApprovalRule> ApprovalRules => Set<ApprovalRule>();
    public DbSet<Approval> Approvals => Set<Approval>();
    public DbSet<Notification> Notifications => Set<Notification>();
    public DbSet<NotificationLog> NotificationLogs => Set<NotificationLog>();
    public DbSet<NotificationSetting> NotificationSettings => Set<NotificationSetting>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();
    public DbSet<LoginHistory> LoginHistory => Set<LoginHistory>();
    public DbSet<ApplicationSetting> ApplicationSettings => Set<ApplicationSetting>();
    public DbSet<RolePermission> RolePermissions => Set<RolePermission>();
    public DbSet<NumberSequence> NumberSequences => Set<NumberSequence>();
    public DbSet<BackupLog> BackupLogs => Set<BackupLog>();

    protected override void ConfigureConventions(ModelConfigurationBuilder configurationBuilder)
    {
        configurationBuilder.Properties<decimal>().HavePrecision(18, 2);
        configurationBuilder.Properties<string>().AreUnicode(true);
    }

    protected override void OnModelCreating(ModelBuilder b)
    {
        base.OnModelCreating(b);

        // Every domain entity gets its own table named after the DbSet.
        foreach (var prop in typeof(AppDbContext).GetProperties()
                     .Where(p => p.PropertyType.IsGenericType && p.PropertyType.GetGenericTypeDefinition() == typeof(DbSet<>)))
        {
            var clr = prop.PropertyType.GetGenericArguments()[0];
            if (clr.Namespace?.StartsWith("GlobalAssetManagement.Domain", StringComparison.Ordinal) == true)
                b.Entity(clr).ToTable(prop.Name);
        }

        // ---- rates and quantities need more precision than money
        b.Entity<Asset>().Property(x => x.TaxRate).HasPrecision(9, 4);
        b.Entity<Asset>().Property(x => x.DepreciationRate).HasPrecision(9, 4);
        b.Entity<Asset>().Property(x => x.UsefulLifeYears).HasPrecision(9, 2);
        b.Entity<AssetCategory>().Property(x => x.DefaultDepreciationRate).HasPrecision(9, 4);
        b.Entity<AssetCategory>().Property(x => x.DefaultResidualPercent).HasPrecision(9, 4);
        b.Entity<AssetCategory>().Property(x => x.DefaultUsefulLifeYears).HasPrecision(9, 2);
        b.Entity<PurchaseOrderItem>().Property(x => x.TaxRate).HasPrecision(9, 4);
        b.Entity<PurchaseOrderItem>().Property(x => x.Quantity).HasPrecision(18, 3);
        b.Entity<PurchaseOrderItem>().Property(x => x.ReceivedQuantity).HasPrecision(18, 3);
        b.Entity<PurchaseOrderItem>().Property(x => x.RegisteredQuantity).HasPrecision(18, 3);
        b.Entity<PurchaseRequestItem>().Property(x => x.Quantity).HasPrecision(18, 3);
        b.Entity<GoodsReceiptItem>().Property(x => x.QuantityReceived).HasPrecision(18, 3);
        b.Entity<GoodsReceiptItem>().Property(x => x.QuantityAccepted).HasPrecision(18, 3);
        b.Entity<GoodsReceiptItem>().Property(x => x.QuantityRejected).HasPrecision(18, 3);
        b.Entity<WorkOrderPart>().Property(x => x.Quantity).HasPrecision(18, 3);
        b.Entity<WorkOrderLabour>().Property(x => x.Hours).HasPrecision(9, 2);
        b.Entity<DepreciationTransaction>().Property(x => x.Rate).HasPrecision(9, 4);
        b.Entity<AssetAddition>().Property(x => x.PreviousUsefulLifeYears).HasPrecision(9, 2);
        b.Entity<AssetAddition>().Property(x => x.RevisedUsefulLifeYears).HasPrecision(9, 2);
        b.Entity<Vendor>().Property(x => x.Rating).HasPrecision(3, 1);
        b.Entity<ServiceAgency>().Property(x => x.Rating).HasPrecision(3, 1);

        // ---- unique business keys
        b.Entity<Branch>().HasIndex(x => x.Code).IsUnique();
        b.Entity<Department>().HasIndex(x => x.Code).IsUnique();
        b.Entity<Location>().HasIndex(x => new { x.BranchId, x.Code }).IsUnique();
        b.Entity<Employee>().HasIndex(x => x.EmployeeCode).IsUnique();
        b.Entity<AssetCategory>().HasIndex(x => x.Code).IsUnique();
        b.Entity<AssetSubcategory>().HasIndex(x => new { x.CategoryId, x.Code }).IsUnique();
        b.Entity<AssetType>().HasIndex(x => x.Name).IsUnique();
        b.Entity<Manufacturer>().HasIndex(x => x.Name).IsUnique();
        b.Entity<AssetModel>().HasIndex(x => new { x.BrandId, x.ModelNumber }).IsUnique();
        b.Entity<Vendor>().HasIndex(x => x.Code).IsUnique();
        b.Entity<ServiceAgency>().HasIndex(x => x.Code).IsUnique();

        b.Entity<Asset>(e =>
        {
            e.HasIndex(x => x.AssetTag).IsUnique();
            e.HasIndex(x => x.AssetCode).IsUnique();
            e.HasIndex(x => x.SerialNumber);
            e.HasIndex(x => x.Status);
            e.HasIndex(x => new { x.BranchId, x.DepartmentId });
            e.HasIndex(x => x.WarrantyExpiryDate);
            e.HasOne(x => x.PurchaseInvoice).WithMany(i => i.Assets).HasForeignKey(x => x.PurchaseInvoiceId);
        });
        b.Entity<AssetEvent>().HasIndex(x => new { x.AssetId, x.EventAt });

        b.Entity<PurchaseRequest>().HasIndex(x => x.RequestNo).IsUnique();
        b.Entity<PurchaseOrder>().HasIndex(x => x.PONumber).IsUnique();
        b.Entity<GoodsReceipt>().HasIndex(x => x.GrnNumber).IsUnique();
        b.Entity<PurchaseInvoice>().HasIndex(x => new { x.VendorId, x.InvoiceNumber }).IsUnique();
        b.Entity<AssetAllocation>().HasIndex(x => x.AllocationNo).IsUnique();
        b.Entity<AssetTransfer>().HasIndex(x => x.TransferNo).IsUnique();
        b.Entity<AssetAddition>().HasIndex(x => x.AdditionNo).IsUnique();
        b.Entity<ServiceRequest>().HasIndex(x => x.TicketNo).IsUnique();
        b.Entity<ServiceRequest>().HasIndex(x => x.Status);
        b.Entity<WorkOrder>().HasIndex(x => x.WorkOrderNo).IsUnique();
        b.Entity<WorkOrder>().HasIndex(x => new { x.MaintenanceScheduleId, x.DueDate });
        b.Entity<AMContract>().HasIndex(x => x.ContractNo).IsUnique();
        b.Entity<AMContractAsset>().HasIndex(x => new { x.AMContractId, x.AssetId }).IsUnique();
        b.Entity<PhysicalVerificationSession>().HasIndex(x => x.SessionNo).IsUnique();
        b.Entity<DepreciationSchedule>().HasIndex(x => x.RunNo).IsUnique();
        b.Entity<DepreciationTransaction>().HasIndex(x => new { x.AssetId, x.PeriodFrom });
        b.Entity<AssetDisposal>().HasIndex(x => x.DisposalNo).IsUnique();
        b.Entity<Approval>().HasIndex(x => new { x.Module, x.EntityId, x.Status });
        b.Entity<Notification>().HasIndex(x => x.DedupKey).IsUnique();
        b.Entity<Notification>().HasIndex(x => new { x.IsAcknowledged, x.CreatedAt });
        b.Entity<NotificationSetting>().HasIndex(x => x.AlertType).IsUnique();
        b.Entity<AuditLog>().HasIndex(x => x.Timestamp);
        b.Entity<AuditLog>().HasIndex(x => new { x.EntityName, x.EntityId });
        b.Entity<LoginHistory>().HasIndex(x => x.AttemptedAt);
        b.Entity<ApplicationSetting>().HasIndex(x => x.Key).IsUnique();
        b.Entity<RolePermission>().HasIndex(x => new { x.RoleName, x.Module }).IsUnique();
        b.Entity<NumberSequence>().HasIndex(x => new { x.Prefix, x.Scope }).IsUnique();

        // ---- relationships that conventions cannot infer
        b.Entity<AssetAllocation>()
            .HasOne(a => a.Return).WithOne(r => r.Allocation).HasForeignKey<AssetReturn>(r => r.AllocationId);
        b.Entity<AMContract>()
            .HasOne(c => c.RenewedFromContract).WithMany().HasForeignKey(c => c.RenewedFromContractId);
        b.Entity<AuditLog>().Property(x => x.Changes).HasColumnType("nvarchar(max)");

        // ---- SQL Server rejects multiple cascade paths: restrict every domain FK, then allow cascades for owned children.
        foreach (var fk in b.Model.GetEntityTypes()
                     .Where(t => t.ClrType.Namespace?.StartsWith("GlobalAssetManagement.Domain", StringComparison.Ordinal) == true)
                     .SelectMany(t => t.GetForeignKeys()))
        {
            fk.DeleteBehavior = DeleteBehavior.Restrict;
        }

        Cascade<PurchaseRequestItem, PurchaseRequest>(b, x => x.PurchaseRequest, p => p.Items);
        Cascade<Quotation, PurchaseRequest>(b, x => x.PurchaseRequest, p => p.Quotations);
        Cascade<PurchaseOrderItem, PurchaseOrder>(b, x => x.PurchaseOrder, p => p.Items);
        Cascade<GoodsReceiptItem, GoodsReceipt>(b, x => x.GoodsReceipt, p => p.Items);
        Cascade<WorkOrderLabour, WorkOrder>(b, x => x.WorkOrder, p => p.Labour);
        Cascade<WorkOrderPart, WorkOrder>(b, x => x.WorkOrder, p => p.Parts);
        Cascade<AMContractAsset, AMContract>(b, x => x.AMContract, p => p.CoveredAssets);
        Cascade<PhysicalVerificationItem, PhysicalVerificationSession>(b, x => x.Session, p => p.Items);
        Cascade<DepreciationTransaction, DepreciationSchedule>(b, x => x.DepreciationSchedule, p => p.Transactions);
        Cascade<NotificationLog, Notification>(b, x => x.Notification, p => p.Logs);
        Cascade<AssetDocument, Asset>(b, x => x.Asset, p => p.Documents);
        Cascade<AssetImage, Asset>(b, x => x.Asset, p => p.Images);
        Cascade<AssetEvent, Asset>(b, x => x.Asset, p => p.Events);
    }

    private static void Cascade<TChild, TParent>(ModelBuilder b,
        System.Linq.Expressions.Expression<Func<TChild, TParent?>> parentNav,
        System.Linq.Expressions.Expression<Func<TParent, IEnumerable<TChild>?>> children)
        where TChild : class where TParent : class
    {
        b.Entity<TChild>().HasOne(parentNav).WithMany(children).OnDelete(DeleteBehavior.Cascade);
    }

    // ------------------------------------------------------------------ auditing

    private static readonly HashSet<Type> NotAudited = new()
    {
        typeof(AuditLog), typeof(LoginHistory), typeof(NotificationLog), typeof(Notification),
        typeof(AssetEvent), typeof(NumberSequence), typeof(BackupLog)
    };

    public override int SaveChanges(bool acceptAllChangesOnSuccess)
    {
        return SaveChangesAsync(acceptAllChangesOnSuccess).GetAwaiter().GetResult();
    }

    public override async Task<int> SaveChangesAsync(bool acceptAllChangesOnSuccess, CancellationToken cancellationToken = default)
    {
        var now = _clock?.UtcNow ?? DateTime.UtcNow;
        var user = _currentUser is { IsAuthenticated: true } ? _currentUser.UserName : "system";

        foreach (var entry in ChangeTracker.Entries<AuditableEntity>())
        {
            if (entry.State == EntityState.Added)
            {
                entry.Entity.CreatedAt = now;
                entry.Entity.CreatedBy ??= user;
            }
            else if (entry.State == EntityState.Modified)
            {
                entry.Entity.ModifiedAt = now;
                entry.Entity.ModifiedBy = user;
                entry.Property(x => x.CreatedAt).IsModified = false;
                entry.Property(x => x.CreatedBy).IsModified = false;
            }
        }

        var pending = ChangeTracker.Entries()
            .Where(e => e.State is EntityState.Added or EntityState.Modified or EntityState.Deleted
                        && e.Entity.GetType().Namespace?.StartsWith("GlobalAssetManagement.Domain", StringComparison.Ordinal) == true
                        && !NotAudited.Contains(e.Entity.GetType()))
            .Select(e => new PendingAudit(e, e.State, Describe(e)))
            .ToList();

        int result = await base.SaveChangesAsync(acceptAllChangesOnSuccess, cancellationToken);

        if (pending.Count > 0)
        {
            foreach (var p in pending)
            {
                AuditLogs.Add(new AuditLog
                {
                    Timestamp = now,
                    UserName = user,
                    Action = p.State switch
                    {
                        EntityState.Added => AuditAction.Create,
                        EntityState.Deleted => AuditAction.Delete,
                        _ => AuditAction.Update
                    },
                    EntityName = p.Entry.Entity.GetType().Name,
                    EntityId = p.Entry.Properties.FirstOrDefault(x => x.Metadata.IsPrimaryKey())?.CurrentValue?.ToString(),
                    ReferenceNo = ReferenceOf(p.Entry.Entity),
                    Changes = p.Changes,
                    IpAddress = _currentUser?.IpAddress
                });
            }
            await base.SaveChangesAsync(acceptAllChangesOnSuccess, cancellationToken);
        }
        return result;
    }

    private sealed record PendingAudit(EntityEntry Entry, EntityState State, string? Changes);

    private static string? Describe(EntityEntry e)
    {
        var dict = new Dictionary<string, object?>();
        foreach (var p in e.Properties)
        {
            if (p.Metadata.IsPrimaryKey() || p.Metadata.Name is "RowVersion" or "CreatedAt" or "CreatedBy" or "ModifiedAt" or "ModifiedBy")
                continue;
            switch (e.State)
            {
                case EntityState.Added:
                    if (p.CurrentValue is not null) dict[p.Metadata.Name] = p.CurrentValue;
                    break;
                case EntityState.Deleted:
                    dict[p.Metadata.Name] = p.OriginalValue;
                    break;
                case EntityState.Modified when p.IsModified && !Equals(p.OriginalValue, p.CurrentValue):
                    dict[p.Metadata.Name] = new { Old = p.OriginalValue, New = p.CurrentValue };
                    break;
            }
        }
        if (dict.Count == 0) return null;
        var json = JsonSerializer.Serialize(dict);
        return json.Length > 8000 ? json[..8000] : json;
    }

    private static string? ReferenceOf(object entity) => entity switch
    {
        Asset a => a.AssetTag,
        PurchaseRequest pr => pr.RequestNo,
        PurchaseOrder po => po.PONumber,
        GoodsReceipt g => g.GrnNumber,
        PurchaseInvoice pi => pi.InvoiceNumber,
        AssetAllocation al => al.AllocationNo,
        AssetTransfer t => t.TransferNo,
        AssetAddition ad => ad.AdditionNo,
        ServiceRequest sr => sr.TicketNo,
        WorkOrder wo => wo.WorkOrderNo,
        AMContract c => c.ContractNo,
        AssetDisposal d => d.DisposalNo,
        DepreciationSchedule ds => ds.RunNo,
        PhysicalVerificationSession pv => pv.SessionNo,
        IHasDisplayName n => n.DisplayName.Length > 100 ? n.DisplayName[..100] : n.DisplayName,
        _ => null
    };
}
