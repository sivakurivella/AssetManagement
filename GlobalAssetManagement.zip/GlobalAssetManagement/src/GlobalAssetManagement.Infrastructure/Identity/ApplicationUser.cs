using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;

namespace GlobalAssetManagement.Infrastructure.Identity;

public class ApplicationUser : IdentityUser
{
    [StringLength(150)]
    public string FullName { get; set; } = "";

    /// <summary>Linked employee record (for "my assets", acknowledgements and service requests).</summary>
    public int? EmployeeId { get; set; }

    /// <summary>When set, the user only sees data for this branch.</summary>
    public int? BranchId { get; set; }

    /// <summary>When set, the user only sees data for this department.</summary>
    public int? DepartmentId { get; set; }

    public bool IsActive { get; set; } = true;
    public bool MustChangePassword { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? LastLoginAt { get; set; }
}
