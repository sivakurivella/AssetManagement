using System.Net;
using System.Net.Http.Json;
using System.Net.Mail;
using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Infrastructure.Identity;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace GlobalAssetManagement.Infrastructure.Services;

/// <summary>Clock that reports dates in the configured business time zone (India Standard Time by default).</summary>
public sealed class AppClock : IClock
{
    private readonly TimeZoneInfo _tz;

    public AppClock(IOptions<AppOptions> options, ILogger<AppClock> logger)
    {
        _tz = Resolve(options.Value.TimeZone, logger);
    }

    public static TimeZoneInfo Resolve(string? id, ILogger? logger = null)
    {
        foreach (var candidate in new[] { id, "India Standard Time", "Asia/Kolkata" })
        {
            if (string.IsNullOrWhiteSpace(candidate)) continue;
            if (TimeZoneInfo.TryFindSystemTimeZoneById(candidate, out var tz)) return tz;
        }
        logger?.LogWarning("Time zone '{Id}' not found; using UTC+05:30.", id);
        return TimeZoneInfo.CreateCustomTimeZone("IST", TimeSpan.FromMinutes(330), "India Standard Time", "India Standard Time");
    }

    public DateTime UtcNow => DateTime.UtcNow;
    public DateTime Now => TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, _tz);
    public DateTime Today => Now.Date;

    public DateTime ToLocal(DateTime utc) =>
        TimeZoneInfo.ConvertTimeFromUtc(utc.Kind == DateTimeKind.Local ? utc.ToUniversalTime() : DateTime.SpecifyKind(utc, DateTimeKind.Utc), _tz);
}

/// <summary>Stores uploaded files on local disk OUTSIDE wwwroot, under random names; served only through authorized actions.</summary>
public sealed class LocalFileStorage : IFileStorage
{
    public string RootPath { get; }

    public LocalFileStorage(IOptions<UploadOptions> options, IWebHostEnvironment env)
    {
        var root = options.Value.RootPath;
        RootPath = Path.GetFullPath(Path.IsPathRooted(root) ? root : Path.Combine(env.ContentRootPath, root));
        Directory.CreateDirectory(RootPath);
    }

    public async Task<string> SaveAsync(Stream content, string folder, string extension, CancellationToken ct = default)
    {
        var dir = SafeFolder(folder);
        Directory.CreateDirectory(dir);
        extension = extension.StartsWith('.') ? extension.ToLowerInvariant() : "." + extension.ToLowerInvariant();
        if (extension.Length > 6 || extension.Any(c => !char.IsLetterOrDigit(c) && c != '.')) extension = ".bin";
        string name = $"{DateTime.UtcNow:yyyyMM}_{Guid.NewGuid():N}{extension}";
        await using var fs = new FileStream(Path.Combine(dir, name), FileMode.CreateNew, FileAccess.Write, FileShare.None, 81920, true);
        await content.CopyToAsync(fs, ct);
        return name;
    }

    public Stream? OpenRead(string folder, string storedFileName)
    {
        var path = SafePath(folder, storedFileName);
        return path is not null && File.Exists(path) ? new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read, 81920, true) : null;
    }

    public void Delete(string folder, string storedFileName)
    {
        var path = SafePath(folder, storedFileName);
        if (path is not null && File.Exists(path)) File.Delete(path);
    }

    private string SafeFolder(string folder)
    {
        var clean = new string(folder.Where(c => char.IsLetterOrDigit(c) || c == '-' || c == '_').ToArray());
        return Path.Combine(RootPath, string.IsNullOrEmpty(clean) ? "misc" : clean);
    }

    private string? SafePath(string folder, string storedFileName)
    {
        var name = Path.GetFileName(storedFileName);
        if (string.IsNullOrEmpty(name) || name != storedFileName) return null;
        var full = Path.GetFullPath(Path.Combine(SafeFolder(folder), name));
        return full.StartsWith(RootPath, StringComparison.OrdinalIgnoreCase) ? full : null;
    }
}

public sealed class SmtpOptions
{
    public const string Section = "Email";
    public bool Enabled { get; set; }
    public string? Host { get; set; }
    public int Port { get; set; } = 587;
    public bool EnableSsl { get; set; } = true;
    public string? UserName { get; set; }
    public string? Password { get; set; }
    public string? FromAddress { get; set; }
    public string FromName { get; set; } = "Global Asset Management";
}

public sealed class SmtpEmailSender(IOptions<SmtpOptions> options, ILogger<SmtpEmailSender> logger) : IEmailSender
{
    private readonly SmtpOptions _o = options.Value;

    public bool IsConfigured => _o.Enabled && !string.IsNullOrWhiteSpace(_o.Host) && !string.IsNullOrWhiteSpace(_o.FromAddress);

    public async Task<SendResult> SendAsync(string to, string subject, string htmlBody, CancellationToken ct = default)
    {
        if (!IsConfigured) return SendResult.NotConfigured;
        try
        {
            using var msg = new MailMessage { From = new MailAddress(_o.FromAddress!, _o.FromName), Subject = subject, Body = htmlBody, IsBodyHtml = true };
            msg.To.Add(to);
            using var client = new SmtpClient(_o.Host, _o.Port) { EnableSsl = _o.EnableSsl, DeliveryMethod = SmtpDeliveryMethod.Network };
            if (!string.IsNullOrWhiteSpace(_o.UserName)) client.Credentials = new NetworkCredential(_o.UserName, _o.Password);
            await client.SendMailAsync(msg, ct);
            return SendResult.Ok;
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Email to {To} failed", to);
            return SendResult.Failed(ex.Message);
        }
    }
}

public sealed class WhatsAppOptions
{
    public const string Section = "WhatsApp";
    public bool Enabled { get; set; }

    /// <summary>Meta WhatsApp Cloud API phone-number id.</summary>
    public string? PhoneNumberId { get; set; }

    /// <summary>Permanent access token from Meta Business settings. Supply via environment variable / user secrets.</summary>
    public string? AccessToken { get; set; }

    /// <summary>Approved message template name with one body parameter.</summary>
    public string? TemplateName { get; set; }
    public string TemplateLanguage { get; set; } = "en";
    public string ApiVersion { get; set; } = "v20.0";
    public string DefaultCountryCode { get; set; } = "91";
}

/// <summary>Optional WhatsApp delivery through Meta's official WhatsApp Cloud API using an approved template.</summary>
public sealed class WhatsAppCloudSender(IHttpClientFactory httpFactory, IOptions<WhatsAppOptions> options, ILogger<WhatsAppCloudSender> logger) : IWhatsAppSender
{
    private readonly WhatsAppOptions _o = options.Value;

    public bool IsConfigured => _o.Enabled && !string.IsNullOrWhiteSpace(_o.PhoneNumberId) && !string.IsNullOrWhiteSpace(_o.AccessToken) && !string.IsNullOrWhiteSpace(_o.TemplateName);

    public async Task<SendResult> SendAsync(string mobile, string message, CancellationToken ct = default)
    {
        if (!IsConfigured) return SendResult.NotConfigured;
        string to = PhoneNumbers.Normalize(mobile, _o.DefaultCountryCode);
        try
        {
            var client = httpFactory.CreateClient("whatsapp");
            using var req = new HttpRequestMessage(HttpMethod.Post, $"https://graph.facebook.com/{_o.ApiVersion}/{_o.PhoneNumberId}/messages");
            req.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", _o.AccessToken);
            req.Content = JsonContent.Create(new
            {
                messaging_product = "whatsapp",
                to,
                type = "template",
                template = new
                {
                    name = _o.TemplateName,
                    language = new { code = _o.TemplateLanguage },
                    components = new object[] { new { type = "body", parameters = new object[] { new { type = "text", text = message.Length > 1000 ? message[..1000] : message } } } }
                }
            });
            using var resp = await client.SendAsync(req, ct);
            if (resp.IsSuccessStatusCode) return SendResult.Ok;
            var body = await resp.Content.ReadAsStringAsync(ct);
            return SendResult.Failed($"HTTP {(int)resp.StatusCode}: {body}");
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "WhatsApp message to {To} failed", to);
            return SendResult.Failed(ex.Message);
        }
    }
}

public sealed class SmsOptions
{
    public const string Section = "Sms";
    public bool Enabled { get; set; }

    /// <summary>
    /// HTTPS endpoint of your licensed SMS gateway (DLT-registered in India). Placeholders {mobile} and {message} are
    /// URL-encoded and substituted; the API key is sent in the header named by <see cref="ApiKeyHeader"/>.
    /// </summary>
    public string? UrlTemplate { get; set; }
    public string ApiKeyHeader { get; set; } = "authkey";
    public string? ApiKey { get; set; }
    public string DefaultCountryCode { get; set; } = "91";
}

/// <summary>Optional SMS delivery through a configurable HTTPS gateway (e.g. a DLT-registered Indian SMS provider).</summary>
public sealed class HttpSmsSender(IHttpClientFactory httpFactory, IOptions<SmsOptions> options, ILogger<HttpSmsSender> logger) : ISmsSender
{
    private readonly SmsOptions _o = options.Value;

    public bool IsConfigured => _o.Enabled && !string.IsNullOrWhiteSpace(_o.UrlTemplate) && _o.UrlTemplate.StartsWith("https://", StringComparison.OrdinalIgnoreCase);

    public async Task<SendResult> SendAsync(string mobile, string message, CancellationToken ct = default)
    {
        if (!IsConfigured) return SendResult.NotConfigured;
        try
        {
            var url = _o.UrlTemplate!
                .Replace("{mobile}", Uri.EscapeDataString(PhoneNumbers.Normalize(mobile, _o.DefaultCountryCode)))
                .Replace("{message}", Uri.EscapeDataString(message.Length > 300 ? message[..300] : message));
            var client = httpFactory.CreateClient("sms");
            using var req = new HttpRequestMessage(HttpMethod.Get, url);
            if (!string.IsNullOrWhiteSpace(_o.ApiKey)) req.Headers.TryAddWithoutValidation(_o.ApiKeyHeader, _o.ApiKey);
            using var resp = await client.SendAsync(req, ct);
            return resp.IsSuccessStatusCode ? SendResult.Ok : SendResult.Failed($"HTTP {(int)resp.StatusCode}");
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "SMS to {Mobile} failed", mobile);
            return SendResult.Failed(ex.Message);
        }
    }
}

public static class PhoneNumbers
{
    public static string Normalize(string mobile, string countryCode)
    {
        var digits = new string(mobile.Where(char.IsDigit).ToArray());
        if (digits.Length == 10) digits = countryCode + digits;
        if (digits.Length == 11 && digits.StartsWith('0')) digits = countryCode + digits[1..];
        return digits;
    }
}

public sealed class UserDirectory(UserManager<ApplicationUser> users) : IUserDirectory
{
    public async Task<IReadOnlyList<DirectoryUser>> GetUsersInRoleAsync(string role, CancellationToken ct = default)
    {
        var list = await users.GetUsersInRoleAsync(role);
        return list.Where(u => u.IsActive).Select(Map).ToList();
    }

    public async Task<DirectoryUser?> FindAsync(string userId, CancellationToken ct = default)
    {
        var u = await users.FindByIdAsync(userId);
        return u is null ? null : Map(u);
    }

    private static DirectoryUser Map(ApplicationUser u) => new(u.Id, u.UserName ?? u.Email ?? u.Id, u.FullName, u.Email, u.PhoneNumber, u.BranchId, u.EmployeeId);
}
