using System.IO.Compression;
using GlobalAssetManagement.Application.Common;
using GlobalAssetManagement.Application.Services;
using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Infrastructure.Persistence;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace GlobalAssetManagement.Infrastructure.Services;

/// <summary>
/// Periodic jobs: preventive-maintenance work orders, AMC status refresh, reminders / escalations / delivery and the
/// optional daily automatic backup. Runs inside the IIS worker process; configure the application pool as
/// AlwaysRunning with preload enabled so jobs keep running when nobody is browsing (see docs/IIS_DEPLOYMENT.md).
/// </summary>
public sealed class ScheduledJobsService(IServiceScopeFactory scopes, IOptions<NotificationOptions> options, IOptions<BackupOptions> backup,
    ILogger<ScheduledJobsService> logger) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        if (!options.Value.BackgroundJobsEnabled)
        {
            logger.LogInformation("Background jobs are disabled by configuration.");
            return;
        }
        await Task.Delay(TimeSpan.FromSeconds(30), stoppingToken);
        var interval = TimeSpan.FromMinutes(Math.Clamp(options.Value.IntervalMinutes, 5, 1440));
        while (!stoppingToken.IsCancellationRequested)
        {
            await RunOnceAsync(stoppingToken);
            try { await Task.Delay(interval, stoppingToken); } catch (TaskCanceledException) { break; }
        }
    }

    public async Task RunOnceAsync(CancellationToken ct)
    {
        using var scope = scopes.CreateScope();
        var sp = scope.ServiceProvider;
        try
        {
            int workOrders = await sp.GetRequiredService<MaintenanceService>().GenerateDueWorkOrdersAsync(ct);
            int amc = await sp.GetRequiredService<WarrantyAmcService>().RefreshStatusesAsync(ct);
            var summary = await sp.GetRequiredService<ReminderService>().RunAsync(ct);
            logger.LogInformation("Scheduled jobs: {WorkOrders} maintenance work orders, {Amc} AMC status changes, {Raised} reminders raised, {Escalated} escalated, {Sent} sent, {Failed} failed, {Skipped} skipped",
                workOrders, amc, summary.Raised, summary.Escalated, summary.Sent, summary.Failed, summary.Skipped);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            logger.LogError(ex, "Scheduled jobs failed");
        }

        if (backup.Value.AutoBackupHour is { } hour)
        {
            try
            {
                var clock = sp.GetRequiredService<IClock>();
                if (clock.Now.Hour >= hour)
                {
                    var svc = sp.GetRequiredService<BackupService>();
                    if (!await svc.HasSuccessfulBackupTodayAsync(ct))
                    {
                        await svc.BackupDatabaseAsync("scheduler", ct);
                        await svc.BackupFilesAsync("scheduler", ct);
                        svc.ApplyRetention();
                    }
                }
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                logger.LogError(ex, "Automatic backup failed");
            }
        }
    }
}

public sealed class BackupService(AppDbContext db, IFileStorage storage, IClock clock, IOptions<BackupOptions> options, ILogger<BackupService> logger)
{
    private readonly BackupOptions _o = options.Value;

    public async Task<bool> HasSuccessfulBackupTodayAsync(CancellationToken ct)
    {
        var startUtc = clock.UtcNow.AddHours(-(clock.Now - clock.Today).TotalHours);
        return await db.BackupLogs.AnyAsync(b => b.BackupType == "Database" && b.Succeeded && b.StartedAt >= startUtc, ct);
    }

    /// <summary>
    /// Runs BACKUP DATABASE on the SQL Server. The folder is on the SQL Server machine and the SQL Server service
    /// account must have write permission to it.
    /// </summary>
    public async Task<BackupLog> BackupDatabaseAsync(string performedBy, CancellationToken ct = default)
    {
        var log = new BackupLog { StartedAt = clock.UtcNow, BackupType = "Database", PerformedBy = performedBy };
        try
        {
            if (!db.Database.IsSqlServer()) throw new InvalidOperationException("Database backup is only available for SQL Server.");
            string dbName = db.Database.GetDbConnection().Database;
            string file = Path.Combine(_o.DatabaseBackupFolder, $"{dbName}_{clock.Now:yyyyMMdd_HHmmss}.bak");
            log.FilePath = file;
            db.Database.SetCommandTimeout(TimeSpan.FromMinutes(30));
            await db.Database.ExecuteSqlRawAsync(
                "BACKUP DATABASE @db TO DISK = @path WITH INIT, CHECKSUM, NAME = @name",
                new object[]
                {
                    new SqlParameter("@db", dbName), new SqlParameter("@path", file),
                    new SqlParameter("@name", $"Global Asset Management full backup {clock.Now:yyyy-MM-dd HH:mm}")
                }, ct);
            log.Succeeded = true;
            if (File.Exists(file)) log.SizeBytes = new FileInfo(file).Length;
            log.Message = "Full database backup completed with CHECKSUM.";
        }
        catch (Exception ex)
        {
            log.Succeeded = false;
            log.Message = ex.Message.Length > 1900 ? ex.Message[..1900] : ex.Message;
            logger.LogError(ex, "Database backup failed");
        }
        log.CompletedAt = clock.UtcNow;
        db.BackupLogs.Add(log);
        await db.SaveChangesAsync(ct);
        return log;
    }

    /// <summary>Zips the uploaded documents folder. SQL Server backups do NOT include these files.</summary>
    public async Task<BackupLog> BackupFilesAsync(string performedBy, CancellationToken ct = default)
    {
        var log = new BackupLog { StartedAt = clock.UtcNow, BackupType = "Files", PerformedBy = performedBy };
        try
        {
            Directory.CreateDirectory(_o.FilesBackupFolder);
            string file = Path.Combine(_o.FilesBackupFolder, $"GAM_Uploads_{clock.Now:yyyyMMdd_HHmmss}.zip");
            await Task.Run(() => ZipFile.CreateFromDirectory(storage.RootPath, file, CompressionLevel.Optimal, includeBaseDirectory: false), ct);
            log.FilePath = file;
            log.SizeBytes = new FileInfo(file).Length;
            log.Succeeded = true;
            log.Message = "Uploaded documents archived.";
        }
        catch (Exception ex)
        {
            log.Succeeded = false;
            log.Message = ex.Message.Length > 1900 ? ex.Message[..1900] : ex.Message;
            logger.LogError(ex, "Files backup failed");
        }
        log.CompletedAt = clock.UtcNow;
        db.BackupLogs.Add(log);
        await db.SaveChangesAsync(ct);
        return log;
    }

    /// <summary>Deletes backup files older than the retention period from folders this server can reach.</summary>
    public int ApplyRetention()
    {
        int removed = 0;
        var cutoff = DateTime.Now.AddDays(-Math.Max(1, _o.RetentionDays));
        foreach (var (folder, pattern) in new[] { (_o.FilesBackupFolder, "GAM_Uploads_*.zip"), (_o.DatabaseBackupFolder, "*.bak") })
        {
            try
            {
                if (!Directory.Exists(folder)) continue;
                foreach (var f in Directory.GetFiles(folder, pattern).Select(p => new FileInfo(p)).Where(f => f.LastWriteTime < cutoff))
                {
                    f.Delete();
                    removed++;
                }
            }
            catch (Exception ex)
            {
                logger.LogWarning(ex, "Retention cleanup failed for {Folder}", folder);
            }
        }
        return removed;
    }
}
