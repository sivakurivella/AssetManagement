using System.ComponentModel.DataAnnotations;

namespace GlobalAssetManagement.Domain.Enums;

public enum CategoryGroup
{
    [Display(Name = "Electronic Equipment")] Electronic = 1,
    [Display(Name = "Computers & IT Equipment")] ComputersIT = 2,
    [Display(Name = "Furniture & Office Equipment")] Furniture = 3,
    [Display(Name = "Other Equipment")] Other = 4
}

public enum AssetStatus
{
    Requested = 1,
    Ordered = 2,
    Received = 3,
    [Display(Name = "Under Installation")] UnderInstallation = 4,
    [Display(Name = "In Service")] InService = 5,
    [Display(Name = "Under Repair")] UnderRepair = 6,
    [Display(Name = "Under Maintenance")] UnderMaintenance = 7,
    Inactive = 8,
    Transferred = 9,
    Disposed = 10,
    [Display(Name = "Lost / Written Off")] LostOrWrittenOff = 11
}

public enum AssetCondition
{
    New = 1,
    Good = 2,
    Fair = 3,
    Poor = 4,
    Damaged = 5,
    [Display(Name = "Not Working")] NotWorking = 6
}

public enum DepreciationMethod
{
    [Display(Name = "Not Depreciated")] None = 0,
    [Display(Name = "Straight-Line (SLM)")] StraightLine = 1,
    [Display(Name = "Written-Down Value (WDV)")] WrittenDownValue = 2
}

public enum AssetDocumentType
{
    [Display(Name = "Purchase Invoice")] Invoice = 1,
    [Display(Name = "Warranty Card")] WarrantyCard = 2,
    Manual = 3,
    Photograph = 4,
    [Display(Name = "Service Report")] ServiceReport = 5,
    Certificate = 6,
    Other = 99
}

public enum AssetEventType
{
    Registered = 1,
    Updated = 2,
    [Display(Name = "Status Changed")] StatusChanged = 3,
    Allocated = 4,
    Returned = 5,
    Transferred = 6,
    [Display(Name = "Addition Capitalized")] AdditionCapitalized = 7,
    [Display(Name = "Service Request")] ServiceRequest = 8,
    [Display(Name = "Work Order")] WorkOrder = 9,
    Maintenance = 10,
    Warranty = 11,
    Amc = 12,
    Verified = 13,
    Depreciation = 14,
    Disposed = 15,
    [Display(Name = "Document Added")] DocumentAdded = 16
}

public enum PurchaseRequestStatus
{
    Draft = 1,
    [Display(Name = "Pending Approval")] PendingApproval = 2,
    Approved = 3,
    Rejected = 4,
    [Display(Name = "Quotations Invited")] QuotationsInvited = 5,
    Ordered = 6,
    Closed = 7,
    Cancelled = 8
}

public enum PurchaseOrderStatus
{
    Draft = 1,
    [Display(Name = "Pending Approval")] PendingApproval = 2,
    Approved = 3,
    Rejected = 4,
    Issued = 5,
    [Display(Name = "Partially Received")] PartiallyReceived = 6,
    Received = 7,
    Closed = 8,
    Cancelled = 9
}

public enum ApprovalModule
{
    [Display(Name = "Purchase Request")] PurchaseRequest = 1,
    [Display(Name = "Purchase Order")] PurchaseOrder = 2,
    [Display(Name = "Repair Estimate")] RepairEstimate = 3,
    [Display(Name = "Asset Addition")] AssetAddition = 4,
    [Display(Name = "Asset Disposal")] AssetDisposal = 5,
    [Display(Name = "AMC Renewal")] AmcRenewal = 6,
    [Display(Name = "Asset Transfer")] AssetTransfer = 7,
    [Display(Name = "Physical Verification")] PhysicalVerification = 8
}

public enum ApprovalStatus
{
    Pending = 1,
    Approved = 2,
    Rejected = 3,
    Cancelled = 4
}

public enum AllocationTargetType
{
    Employee = 1,
    Department = 2,
    Location = 3
}

public enum AllocationStatus
{
    Active = 1,
    Returned = 2
}

public enum TransferType
{
    [Display(Name = "Employee to Employee")] Employee = 1,
    [Display(Name = "Department to Department")] Department = 2,
    [Display(Name = "Branch to Branch")] Branch = 3,
    [Display(Name = "Location to Location")] Location = 4
}

public enum TransferStatus
{
    [Display(Name = "Pending Approval")] PendingApproval = 1,
    Completed = 2,
    Rejected = 3,
    Cancelled = 4
}

public enum ExpenditureType
{
    [Display(Name = "Not Classified")] Unclassified = 0,
    [Display(Name = "Capital Improvement")] CapitalImprovement = 1,
    [Display(Name = "Revenue Expense (Repair / Maintenance)")] RevenueExpense = 2
}

public enum AdditionStatus
{
    [Display(Name = "Pending Classification")] Pending = 1,
    [Display(Name = "Pending Approval")] PendingApproval = 2,
    Approved = 3,
    Capitalized = 4,
    Expensed = 5,
    Rejected = 6
}

public enum Priority
{
    Low = 1,
    Normal = 2,
    High = 3,
    Critical = 4
}

public enum ProblemCategory
{
    Hardware = 1,
    Software = 2,
    Electrical = 3,
    Mechanical = 4,
    Network = 5,
    [Display(Name = "Physical Damage")] PhysicalDamage = 6,
    Performance = 7,
    Other = 99
}

/// <summary>The 13-step repair lifecycle (plus terminal Rejected / Cancelled).</summary>
public enum ServiceRequestStatus
{
    Submitted = 1,
    [Display(Name = "Under Review")] UnderReview = 2,
    Approved = 3,
    Rejected = 4,
    [Display(Name = "Technician Assigned")] TechnicianAssigned = 5,
    Diagnosed = 6,
    [Display(Name = "Estimate Submitted")] EstimateSubmitted = 7,
    [Display(Name = "Estimate Approved")] EstimateApproved = 8,
    [Display(Name = "Awaiting Spare Parts")] AwaitingParts = 9,
    [Display(Name = "Repair In Progress")] InProgress = 10,
    [Display(Name = "Testing / QC")] Testing = 11,
    Completed = 12,
    [Display(Name = "User Confirmed")] UserConfirmed = 13,
    Closed = 14,
    Cancelled = 15
}

public enum WorkType
{
    [Display(Name = "Breakdown Repair")] Breakdown = 1,
    Preventive = 2,
    Predictive = 3,
    [Display(Name = "AMC Service")] Amc = 4,
    [Display(Name = "Manufacturer Recommended")] ManufacturerRecommended = 5,
    [Display(Name = "Periodic Inspection")] PeriodicInspection = 6,
    [Display(Name = "Safety Inspection")] SafetyInspection = 7,
    Calibration = 8
}

public enum WorkOrderStatus
{
    Open = 1,
    Assigned = 2,
    [Display(Name = "In Progress")] InProgress = 3,
    [Display(Name = "On Hold")] OnHold = 4,
    Completed = 5,
    Verified = 6,
    Closed = 7,
    Cancelled = 8
}

public enum MaintenanceFrequency
{
    Weekly = 1,
    Fortnightly = 2,
    Monthly = 3,
    Quarterly = 4,
    [Display(Name = "Half-Yearly")] HalfYearly = 5,
    Yearly = 6,
    [Display(Name = "Custom (days)")] CustomDays = 7
}

public enum WarrantyType
{
    Manufacturer = 1,
    Extended = 2,
    [Display(Name = "Repair Warranty")] Repair = 3,
    Dealer = 4
}

public enum CoverageStatus
{
    [Display(Name = "Not Covered")] None = 0,
    Active = 1,
    [Display(Name = "Expiring Soon")] ExpiringSoon = 2,
    Expired = 3
}

public enum AmcContractType
{
    Comprehensive = 1,
    [Display(Name = "Non-Comprehensive")] NonComprehensive = 2,
    [Display(Name = "On-Call")] OnCall = 3
}

public enum AmcRenewalStatus
{
    Active = 1,
    [Display(Name = "Renewal Due")] RenewalDue = 2,
    [Display(Name = "Renewal Pending Approval")] RenewalPendingApproval = 3,
    Renewed = 4,
    Expired = 5,
    Cancelled = 6
}

public enum ServiceVisitStatus
{
    Scheduled = 1,
    Completed = 2,
    Missed = 3,
    Cancelled = 4
}

public enum VerificationSessionStatus
{
    Open = 1,
    [Display(Name = "Submitted for Approval")] Submitted = 2,
    Approved = 3,
    Rejected = 4
}

public enum VerificationResult
{
    [Display(Name = "Not Yet Scanned")] Pending = 0,
    Found = 1,
    [Display(Name = "Found at Wrong Location")] WrongLocation = 2,
    Missing = 3,
    [Display(Name = "Unregistered / Unknown")] Unregistered = 4
}

public enum DepreciationRunStatus
{
    Draft = 1,
    Posted = 2,
    Reversed = 3
}

public enum DisposalMethod
{
    [Display(Name = "Sale of Asset")] Sale = 1,
    [Display(Name = "Transfer to Another Organization")] TransferToOrganization = 2,
    Donation = 3,
    Scrap = 4,
    [Display(Name = "Lost Asset")] Lost = 5,
    [Display(Name = "Damaged Beyond Repair")] Damaged = 6,
    [Display(Name = "Write-Off")] WriteOff = 7
}

public enum DisposalStatus
{
    Requested = 1,
    [Display(Name = "Pending Approval")] PendingApproval = 2,
    Approved = 3,
    Rejected = 4,
    Completed = 5
}

public enum AlertType
{
    [Display(Name = "Warranty Expiry")] WarrantyExpiry = 1,
    [Display(Name = "AMC Expiry")] AmcExpiry = 2,
    [Display(Name = "Preventive Maintenance Due")] MaintenanceDue = 3,
    [Display(Name = "Repair Pending")] RepairPending = 4,
    [Display(Name = "Repair Overdue")] RepairOverdue = 5,
    [Display(Name = "Purchase Approval Pending")] PurchaseApprovalPending = 6,
    [Display(Name = "Asset Return Due")] AssetReturnDue = 7,
    [Display(Name = "Inspection Due")] InspectionDue = 8,
    [Display(Name = "Calibration Due")] CalibrationDue = 9,
    [Display(Name = "Contract Renewal Due")] ContractRenewalDue = 10,
    [Display(Name = "Critical Asset Downtime")] CriticalDowntime = 11,
    [Display(Name = "Asset Verification Pending")] VerificationPending = 12,
    [Display(Name = "Approval Pending")] ApprovalPending = 13
}

public enum AlertSeverity
{
    Info = 1,
    Warning = 2,
    Critical = 3
}

public enum NotificationChannel
{
    [Display(Name = "In-App")] InApp = 1,
    Email = 2,
    Sms = 3,
    WhatsApp = 4
}

public enum DeliveryStatus
{
    Pending = 1,
    Sent = 2,
    Failed = 3,
    [Display(Name = "Skipped (channel not configured)")] Skipped = 4
}

public enum AppModule
{
    Dashboard = 1,
    [Display(Name = "Asset Masters")] Assets = 2,
    [Display(Name = "Categories, Locations & Masters")] Masters = 3,
    [Display(Name = "Vendors & Procurement")] Procurement = 4,
    [Display(Name = "Allocation, Transfers & Returns")] Allocation = 5,
    [Display(Name = "Asset Additions")] Additions = 6,
    [Display(Name = "Maintenance & Repairs")] Maintenance = 7,
    [Display(Name = "Warranty & AMC")] WarrantyAmc = 8,
    [Display(Name = "Physical Verification")] Verification = 9,
    [Display(Name = "Depreciation & Valuation")] Depreciation = 10,
    [Display(Name = "Disposal & Retirement")] Disposal = 11,
    [Display(Name = "Reports & Analytics")] Reports = 12,
    [Display(Name = "Financial Reports")] FinancialReports = 13,
    [Display(Name = "Notifications & Reminders")] Notifications = 14,
    [Display(Name = "User & Role Management")] Users = 15,
    [Display(Name = "Audit Trail")] Audit = 16,
    [Display(Name = "Backup & System Settings")] Settings = 17
}

public enum PermissionAction
{
    View = 1,
    Create = 2,
    Edit = 3,
    Approve = 4,
    Delete = 5,
    Export = 6
}

public enum AuditAction
{
    Create = 1,
    Update = 2,
    Delete = 3,
    Approve = 4,
    Reject = 5,
    Login = 6,
    Logout = 7,
    Export = 8,
    Backup = 9,
    Other = 99
}
