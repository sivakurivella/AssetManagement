using System.ComponentModel.DataAnnotations;

namespace GlobalAssetManagement.Domain.Common;

/// <summary>Root type for every persisted entity. Integer identity primary key.</summary>
public abstract class BaseEntity
{
    [ScaffoldColumn(false)]
    public int Id { get; set; }
}

/// <summary>Entity with standard audit columns. Values are set automatically by the DbContext.</summary>
public abstract class AuditableEntity : BaseEntity
{
    [ScaffoldColumn(false)]
    public DateTime CreatedAt { get; set; }

    [ScaffoldColumn(false), StringLength(256)]
    public string? CreatedBy { get; set; }

    [ScaffoldColumn(false)]
    public DateTime? ModifiedAt { get; set; }

    [ScaffoldColumn(false), StringLength(256)]
    public string? ModifiedBy { get; set; }
}

/// <summary>Entities that can appear in a dropdown expose a human readable name.</summary>
public interface IHasDisplayName
{
    string DisplayName { get; }
}

/// <summary>Entities that use SQL Server rowversion for optimistic concurrency.</summary>
public interface IConcurrencyVersioned
{
    byte[]? RowVersion { get; set; }
}

/// <summary>Entities that can be switched off without being deleted.</summary>
public interface IActivatable
{
    bool IsActive { get; set; }
}

/// <summary>Marks an integer foreign-key property so generic master screens render a dropdown.</summary>
[AttributeUsage(AttributeTargets.Property)]
public sealed class LookupAttribute(Type entityType) : Attribute
{
    public Type EntityType { get; } = entityType;
}

/// <summary>Marks a property that is shown as a column in generic master list screens.</summary>
[AttributeUsage(AttributeTargets.Property)]
public sealed class GridColumnAttribute : Attribute
{
}

/// <summary>Marks a string property that should be rendered as a multi-line text area.</summary>
[AttributeUsage(AttributeTargets.Property)]
public sealed class MultilineAttribute : Attribute
{
}
