using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using GlobalAssetManagement.Domain.Common;
using GlobalAssetManagement.Domain.Enums;

namespace GlobalAssetManagement.Domain.Entities;

public class WarrantyRecord : AuditableEntity
{
    public int AssetId { get; set; }
    public Asset? Asset { get; set; }

    public WarrantyType WarrantyType { get; set; } = WarrantyType.Manufacturer;
    [Required, StringLength(200)] public string Provider { get; set; } = "";
    [Column(TypeName = "date")] public DateTime StartDate { get; set; }
    [Column(TypeName = "date")] public DateTime ExpiryDate { get; set; }

    [StringLength(2000)] public string? Terms { get; set; }
    [StringLength(2000)] public string? CoverageDetails { get; set; }
    [StringLength(200)] public string? ClaimContact { get; set; }
    [StringLength(100)] public string? CertificateNo { get; set; }

    /// <summary>Primary warranty drives the warranty dates shown on the asset master.</summary>
    public bool IsPrimary { get; set; } = true;
}

public class AMContract : AuditableEntity, IHasDisplayName, IConcurrencyVersioned
{
    [Required, StringLength(50)] public string ContractNo { get; set; } = "";

    public int ServiceProviderId { get; set; }
    public ServiceAgency? ServiceProvider { get; set; }

    public AmcContractType ContractType { get; set; } = AmcContractType.Comprehensive;
    [Column(TypeName = "date")] public DateTime StartDate { get; set; }
    [Column(TypeName = "date")] public DateTime ExpiryDate { get; set; }

    public decimal AnnualValue { get; set; }
    public decimal TaxAmount { get; set; }

    public int VisitsPerYear { get; set; } = 4;
    public int ResponseTimeHours { get; set; } = 24;
    public int ResolutionTimeHours { get; set; } = 72;

    [StringLength(2000)] public string? Coverage { get; set; }
    [StringLength(2000)] public string? Terms { get; set; }

    public AmcRenewalStatus RenewalStatus { get; set; } = AmcRenewalStatus.Active;
    public int? RenewedFromContractId { get; set; }
    public AMContract? RenewedFromContract { get; set; }
    public decimal? ProposedRenewalCost { get; set; }
    [StringLength(256)] public string? RenewalApprovedBy { get; set; }
    public DateTime? RenewalApprovedAt { get; set; }

    [Timestamp] public byte[]? RowVersion { get; set; }

    public List<AMContractAsset> CoveredAssets { get; set; } = new();
    public List<ServiceVisit> Visits { get; set; } = new();

    [NotMapped] public string DisplayName => ContractNo;
}

public class AMContractAsset : BaseEntity
{
    public int AMContractId { get; set; }
    public AMContract? AMContract { get; set; }
    public int AssetId { get; set; }
    public Asset? Asset { get; set; }
}

public class ServiceVisit : AuditableEntity
{
    public int? AMContractId { get; set; }
    public AMContract? AMContract { get; set; }
    public int? AssetId { get; set; }
    public Asset? Asset { get; set; }
    public int? ServiceProviderId { get; set; }
    public ServiceAgency? ServiceProvider { get; set; }

    [Column(TypeName = "date")] public DateTime ScheduledDate { get; set; }
    public DateTime? CallLoggedAt { get; set; }
    public DateTime? RespondedAt { get; set; }
    public DateTime? ResolvedAt { get; set; }
    [StringLength(150)] public string? EngineerName { get; set; }
    [StringLength(2000)] public string? WorkDone { get; set; }
    public ServiceVisitStatus Status { get; set; } = ServiceVisitStatus.Scheduled;

    /// <summary>Null until responded; true when the response met the contract SLA.</summary>
    public bool? SlaMet { get; set; }
}

public class PhysicalVerificationSession : AuditableEntity
{
    [Required, StringLength(30)] public string SessionNo { get; set; } = "";
    [Required, StringLength(200)] public string Title { get; set; } = "";

    public int? BranchId { get; set; }
    public Branch? Branch { get; set; }
    public int? DepartmentId { get; set; }
    public Department? Department { get; set; }
    public int? LocationId { get; set; }
    public Location? Location { get; set; }

    public DateTime StartedAt { get; set; }
    public DateTime? SubmittedAt { get; set; }
    public DateTime? ApprovedAt { get; set; }
    [StringLength(256)] public string? ConductedBy { get; set; }
    [StringLength(256)] public string? ApprovedBy { get; set; }
    public bool CaptureGps { get; set; }
    public VerificationSessionStatus Status { get; set; } = VerificationSessionStatus.Open;
    [StringLength(2000)] public string? Remarks { get; set; }

    public List<PhysicalVerificationItem> Items { get; set; } = new();
}

public class PhysicalVerificationItem : BaseEntity
{
    public int SessionId { get; set; }
    public PhysicalVerificationSession? Session { get; set; }

    /// <summary>Null for an unregistered code that was scanned but is not in the asset register.</summary>
    public int? AssetId { get; set; }
    public Asset? Asset { get; set; }

    public bool IsExpected { get; set; }
    [StringLength(100)] public string? ScannedCode { get; set; }
    public VerificationResult Result { get; set; } = VerificationResult.Pending;

    public int? ExpectedLocationId { get; set; }
    public Location? ExpectedLocation { get; set; }
    public int? FoundLocationId { get; set; }
    public Location? FoundLocation { get; set; }

    public AssetCondition? ConditionObserved { get; set; }
    [StringLength(1000)] public string? Remarks { get; set; }
    public DateTime? ScannedAt { get; set; }
    [StringLength(256)] public string? ScannedBy { get; set; }

    [Column(TypeName = "decimal(9,6)")] public decimal? Latitude { get; set; }
    [Column(TypeName = "decimal(9,6)")] public decimal? Longitude { get; set; }
    [StringLength(260)] public string? PhotoFileName { get; set; }
}

/// <summary>Header of a depreciation run for one financial year / reporting period.</summary>
public class DepreciationSchedule : AuditableEntity
{
    [Required, StringLength(30)] public string RunNo { get; set; } = "";
    [Required, StringLength(9)] public string FinancialYear { get; set; } = "";
    [Column(TypeName = "date")] public DateTime PeriodFrom { get; set; }
    [Column(TypeName = "date")] public DateTime PeriodTo { get; set; }

    public int? BranchId { get; set; }
    public Branch? Branch { get; set; }

    public DepreciationRunStatus Status { get; set; } = DepreciationRunStatus.Draft;
    public decimal TotalDepreciation { get; set; }
    public int AssetCount { get; set; }
    public DateTime? PostedAt { get; set; }
    [StringLength(256)] public string? PostedBy { get; set; }
    [StringLength(1000)] public string? Remarks { get; set; }

    public List<DepreciationTransaction> Transactions { get; set; } = new();
}

public class DepreciationTransaction : BaseEntity
{
    public int? DepreciationScheduleId { get; set; }
    public DepreciationSchedule? DepreciationSchedule { get; set; }

    public int AssetId { get; set; }
    public Asset? Asset { get; set; }

    [Column(TypeName = "date")] public DateTime PeriodFrom { get; set; }
    [Column(TypeName = "date")] public DateTime PeriodTo { get; set; }
    public int Days { get; set; }

    public DepreciationMethod Method { get; set; }
    public decimal Rate { get; set; }

    public decimal OpeningGrossCost { get; set; }
    public decimal AdditionsInPeriod { get; set; }
    public decimal OpeningAccumulated { get; set; }
    public decimal OpeningBookValue { get; set; }
    public decimal DepreciationAmount { get; set; }
    public decimal ClosingAccumulated { get; set; }
    public decimal ClosingBookValue { get; set; }

    /// <summary>True when posted as catch-up depreciation at disposal.</summary>
    public bool IsDisposalCatchUp { get; set; }
    public DateTime PostedAt { get; set; }
}

public class AssetDisposal : AuditableEntity, IConcurrencyVersioned
{
    [Required, StringLength(30)] public string DisposalNo { get; set; } = "";

    public int AssetId { get; set; }
    public Asset? Asset { get; set; }

    [Column(TypeName = "date")] public DateTime RequestDate { get; set; }
    [Column(TypeName = "date")] public DateTime ProposedDisposalDate { get; set; }
    [Column(TypeName = "date")] public DateTime? DisposalDate { get; set; }

    public DisposalMethod Method { get; set; } = DisposalMethod.Scrap;
    [Required, StringLength(1000)] public string Reason { get; set; } = "";
    [StringLength(200)] public string? BuyerOrRecipient { get; set; }
    [StringLength(50)] public string? SaleInvoiceNo { get; set; }

    public decimal ExpectedValue { get; set; }
    public decimal DisposalValue { get; set; }
    public decimal GrossCostAtDisposal { get; set; }
    public decimal AccumulatedDepreciationAtDisposal { get; set; }
    public decimal BookValueAtDisposal { get; set; }
    public decimal ProfitOrLoss { get; set; }

    public DisposalStatus Status { get; set; } = DisposalStatus.Requested;
    public DateTime? CompletedAt { get; set; }
    [StringLength(256)] public string? CompletedBy { get; set; }

    /// <summary>Completed disposals are locked against further changes.</summary>
    public bool IsLocked { get; set; }
    [StringLength(1000)] public string? Remarks { get; set; }

    [Timestamp] public byte[]? RowVersion { get; set; }
}
