using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using GlobalAssetManagement.Domain.Common;
using GlobalAssetManagement.Domain.Enums;

namespace GlobalAssetManagement.Domain.Entities;

public class AssetCategory : AuditableEntity, IHasDisplayName, IActivatable
{
    [Required, StringLength(20), Display(Name = "Category Code"), GridColumn]
    public string Code { get; set; } = "";

    [Required, StringLength(150), Display(Name = "Category Name"), GridColumn]
    public string Name { get; set; } = "";

    [Display(Name = "Category Group"), GridColumn]
    public CategoryGroup Group { get; set; } = CategoryGroup.Other;

    [StringLength(500), Multiline]
    public string? Description { get; set; }

    [Range(0, 100), Display(Name = "Default Useful Life (years)")]
    public decimal DefaultUsefulLifeYears { get; set; } = 5;

    [Display(Name = "Default Depreciation Method")]
    public DepreciationMethod DefaultDepreciationMethod { get; set; } = DepreciationMethod.StraightLine;

    [Range(0, 100), Display(Name = "Default Depreciation Rate % (WDV / custom SLM)")]
    public decimal DefaultDepreciationRate { get; set; }

    [Range(0, 100), Display(Name = "Default Residual Value %")]
    public decimal DefaultResidualPercent { get; set; } = 5;

    [Display(Name = "Active"), GridColumn]
    public bool IsActive { get; set; } = true;

    [NotMapped] public string DisplayName => Name;

    public List<AssetSubcategory> Subcategories { get; set; } = new();
}

public class AssetSubcategory : AuditableEntity, IHasDisplayName, IActivatable
{
    [Lookup(typeof(AssetCategory)), Display(Name = "Category"), GridColumn]
    public int CategoryId { get; set; }
    public AssetCategory? Category { get; set; }

    [Required, StringLength(20), Display(Name = "Subcategory Code"), GridColumn]
    public string Code { get; set; } = "";

    [Required, StringLength(150), Display(Name = "Subcategory Name"), GridColumn]
    public string Name { get; set; } = "";

    [Display(Name = "Active")]
    public bool IsActive { get; set; } = true;

    [NotMapped] public string DisplayName => Name;
}

public class AssetType : AuditableEntity, IHasDisplayName, IActivatable
{
    [Required, StringLength(100), Display(Name = "Asset Type"), GridColumn]
    public string Name { get; set; } = "";

    [StringLength(300), GridColumn]
    public string? Description { get; set; }

    [Display(Name = "Tangible Asset"), GridColumn]
    public bool IsTangible { get; set; } = true;

    [Display(Name = "Active")]
    public bool IsActive { get; set; } = true;

    [NotMapped] public string DisplayName => Name;
}

public class Manufacturer : AuditableEntity, IHasDisplayName, IActivatable
{
    [Required, StringLength(150), Display(Name = "Manufacturer"), GridColumn]
    public string Name { get; set; } = "";

    [StringLength(256), Url, GridColumn]
    public string? Website { get; set; }

    [StringLength(30), Display(Name = "Support Phone"), GridColumn]
    public string? SupportPhone { get; set; }

    [StringLength(256), EmailAddress, Display(Name = "Support Email")]
    public string? SupportEmail { get; set; }

    [Display(Name = "Active")]
    public bool IsActive { get; set; } = true;

    [NotMapped] public string DisplayName => Name;
}

public class Brand : AuditableEntity, IHasDisplayName, IActivatable
{
    [Lookup(typeof(Manufacturer)), Display(Name = "Manufacturer"), GridColumn]
    public int? ManufacturerId { get; set; }
    public Manufacturer? Manufacturer { get; set; }

    [Required, StringLength(150), Display(Name = "Brand"), GridColumn]
    public string Name { get; set; } = "";

    [Display(Name = "Active")]
    public bool IsActive { get; set; } = true;

    [NotMapped] public string DisplayName => Name;
}

public class AssetModel : AuditableEntity, IHasDisplayName, IActivatable
{
    [Lookup(typeof(Brand)), Display(Name = "Brand"), GridColumn]
    public int? BrandId { get; set; }
    public Brand? Brand { get; set; }

    [Lookup(typeof(AssetSubcategory)), Display(Name = "Subcategory")]
    public int? SubcategoryId { get; set; }
    public AssetSubcategory? Subcategory { get; set; }

    [Required, StringLength(100), Display(Name = "Model Number"), GridColumn]
    public string ModelNumber { get; set; } = "";

    [StringLength(200), Display(Name = "Model Name"), GridColumn]
    public string? Name { get; set; }

    [StringLength(2000), Multiline, Display(Name = "Technical Specifications")]
    public string? Specifications { get; set; }

    [Range(0, 600), Display(Name = "Standard Warranty (months)")]
    public int StandardWarrantyMonths { get; set; }

    [Display(Name = "Active")]
    public bool IsActive { get; set; } = true;

    [NotMapped] public string DisplayName => string.IsNullOrWhiteSpace(Name) ? ModelNumber : $"{ModelNumber} - {Name}";
}
