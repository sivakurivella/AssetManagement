using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using GlobalAssetManagement.Domain.Common;
using GlobalAssetManagement.Domain.Enums;

namespace GlobalAssetManagement.Domain.Entities;

/// <summary>Service provider / repair agency (table ServiceProviders). Named ServiceAgency to avoid clashing with Microsoft.Extensions.DependencyInjection.ServiceProvider.</summary>
public class ServiceAgency : AuditableEntity, IHasDisplayName, IActivatable
{
    [Required, StringLength(20), Display(Name = "Provider Code"), GridColumn]
    public string Code { get; set; } = "";

    [Required, StringLength(200), Display(Name = "Company Name"), GridColumn]
    public string CompanyName { get; set; } = "";

    [StringLength(150), Display(Name = "Contact Person"), GridColumn]
    public string? ContactPerson { get; set; }

    [StringLength(500), Multiline]
    public string? Address { get; set; }

    [StringLength(30), Phone, GridColumn]
    public string? Phone { get; set; }

    [StringLength(256), EmailAddress]
    public string? Email { get; set; }

    [StringLength(15), Display(Name = "GSTIN")]
    public string? Gstin { get; set; }

    [StringLength(300), GridColumn]
    public string? Specialization { get; set; }

    [StringLength(300), Display(Name = "Authorized Brands")]
    public string? AuthorizedBrands { get; set; }

    [StringLength(100), Display(Name = "Service Agreement Ref.")]
    public string? ServiceAgreementRef { get; set; }

    [Column(TypeName = "date"), DataType(DataType.Date), Display(Name = "Contract From")]
    public DateTime? ContractStart { get; set; }

    [Column(TypeName = "date"), DataType(DataType.Date), Display(Name = "Contract To")]
    public DateTime? ContractEnd { get; set; }

    [Range(0, 720), Display(Name = "Committed Response Time (hours)")]
    public int ResponseTimeHours { get; set; } = 24;

    [StringLength(300), Display(Name = "Service Charges")]
    public string? ServiceCharges { get; set; }

    [StringLength(200), Display(Name = "Payment Terms")]
    public string? PaymentTerms { get; set; }

    [Range(0, 5), Display(Name = "Service Rating (0-5)"), GridColumn]
    public decimal Rating { get; set; }

    [Display(Name = "Active")]
    public bool IsActive { get; set; } = true;

    [NotMapped] public string DisplayName => $"{Code} - {CompanyName}";
}

public class ServiceRequest : AuditableEntity, IConcurrencyVersioned
{
    [Required, StringLength(30)] public string TicketNo { get; set; } = "";

    public int AssetId { get; set; }
    public Asset? Asset { get; set; }

    public DateTime RequestedAt { get; set; }
    public int? RequestedByEmployeeId { get; set; }
    public Employee? RequestedByEmployee { get; set; }
    [StringLength(256)] public string? RequestedByUser { get; set; }

    public int? DepartmentId { get; set; }
    public Department? Department { get; set; }
    public int? LocationId { get; set; }
    public Location? Location { get; set; }

    public ProblemCategory ProblemCategory { get; set; } = ProblemCategory.Hardware;
    [Required, StringLength(2000)] public string FaultDescription { get; set; } = "";
    public Priority Priority { get; set; } = Priority.Normal;
    [Column(TypeName = "date")] public DateTime? RequestedServiceDate { get; set; }

    /// <summary>Set when the fault makes the asset unusable; used for downtime calculation.</summary>
    public bool AssetDown { get; set; }
    public DateTime? DownSince { get; set; }

    public ServiceRequestStatus Status { get; set; } = ServiceRequestStatus.Submitted;
    public ApprovalStatus ApprovalStatus { get; set; } = ApprovalStatus.Pending;
    [StringLength(256)] public string? ReviewedBy { get; set; }
    public DateTime? ReviewedAt { get; set; }
    [StringLength(1000)] public string? ReviewRemarks { get; set; }

    public DateTime? CompletedAt { get; set; }
    public DateTime? ConfirmedAt { get; set; }
    [StringLength(256)] public string? ConfirmedBy { get; set; }
    public DateTime? ClosedAt { get; set; }

    [Range(0, 5)] public int? FeedbackRating { get; set; }
    [StringLength(1000)] public string? Feedback { get; set; }

    [Timestamp] public byte[]? RowVersion { get; set; }

    public List<RepairEstimate> Estimates { get; set; } = new();
    public List<WorkOrder> WorkOrders { get; set; } = new();

    [NotMapped]
    public bool IsOpen => Status is not (ServiceRequestStatus.Closed or ServiceRequestStatus.Cancelled or ServiceRequestStatus.Rejected);
}

public class RepairEstimate : AuditableEntity
{
    public int ServiceRequestId { get; set; }
    public ServiceRequest? ServiceRequest { get; set; }

    public DateTime EstimateDate { get; set; }
    public int? ServiceProviderId { get; set; }
    public ServiceAgency? ServiceProvider { get; set; }

    public decimal LabourCharges { get; set; }
    public decimal PartsCost { get; set; }
    public decimal TravelCharges { get; set; }
    public decimal OtherCharges { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal TotalAmount { get; set; }

    [StringLength(2000)] public string? Details { get; set; }
    public ApprovalStatus Status { get; set; } = ApprovalStatus.Pending;
    [StringLength(256)] public string? DecidedBy { get; set; }
    public DateTime? DecidedAt { get; set; }
}

public class WorkOrder : AuditableEntity, IConcurrencyVersioned
{
    [Required, StringLength(30)] public string WorkOrderNo { get; set; } = "";

    public int AssetId { get; set; }
    public Asset? Asset { get; set; }

    public int? ServiceRequestId { get; set; }
    public ServiceRequest? ServiceRequest { get; set; }
    public int? MaintenanceScheduleId { get; set; }
    public MaintenanceSchedule? MaintenanceSchedule { get; set; }
    public int? AMContractId { get; set; }
    public AMContract? AMContract { get; set; }

    public WorkType WorkType { get; set; } = WorkType.Breakdown;
    public Priority Priority { get; set; } = Priority.Normal;
    [Required, StringLength(300)] public string Title { get; set; } = "";

    [StringLength(450)] public string? TechnicianUserId { get; set; }
    [StringLength(150)] public string? TechnicianName { get; set; }
    public int? ServiceProviderId { get; set; }
    public ServiceAgency? ServiceProvider { get; set; }

    public DateTime? AssignedAt { get; set; }
    [Column(TypeName = "date")] public DateTime? DueDate { get; set; }

    [StringLength(2000)] public string? Diagnosis { get; set; }
    [StringLength(1000)] public string? SparePartsRequired { get; set; }
    public DateTime? WorkStartedAt { get; set; }
    public DateTime? WorkCompletedAt { get; set; }

    public decimal LabourCharges { get; set; }
    public decimal PartsCost { get; set; }
    public decimal TravelCharges { get; set; }
    public decimal OtherExpenses { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal TotalCost { get; set; }

    public decimal DowntimeHours { get; set; }
    public int RepairWarrantyMonths { get; set; }

    [StringLength(4000)] public string? ServiceReport { get; set; }
    [StringLength(1000)] public string? Checklist { get; set; }
    public bool? QualityPassed { get; set; }
    [StringLength(1000)] public string? QualityRemarks { get; set; }
    [StringLength(256)] public string? VerifiedBy { get; set; }
    public DateTime? VerifiedAt { get; set; }

    public WorkOrderStatus Status { get; set; } = WorkOrderStatus.Open;

    [Timestamp] public byte[]? RowVersion { get; set; }

    public List<WorkOrderLabour> Labour { get; set; } = new();
    public List<WorkOrderPart> Parts { get; set; } = new();

    [NotMapped] public bool IsOpen => Status is not (WorkOrderStatus.Closed or WorkOrderStatus.Cancelled or WorkOrderStatus.Verified);
}

public class WorkOrderLabour : BaseEntity
{
    public int WorkOrderId { get; set; }
    public WorkOrder? WorkOrder { get; set; }

    [Required, StringLength(150)] public string TechnicianName { get; set; } = "";
    [Column(TypeName = "date")] public DateTime WorkDate { get; set; }
    public decimal Hours { get; set; }
    public decimal RatePerHour { get; set; }
    public decimal Amount { get; set; }
    [StringLength(500)] public string? Description { get; set; }
}

public class WorkOrderPart : BaseEntity
{
    public int WorkOrderId { get; set; }
    public WorkOrder? WorkOrder { get; set; }

    [Required, StringLength(200)] public string PartName { get; set; } = "";
    [StringLength(100)] public string? PartNumber { get; set; }
    public decimal Quantity { get; set; } = 1;
    public decimal UnitCost { get; set; }
    public decimal Amount { get; set; }
    [StringLength(200)] public string? Supplier { get; set; }
}

public class MaintenanceSchedule : AuditableEntity
{
    public int AssetId { get; set; }
    public Asset? Asset { get; set; }

    [Required, StringLength(200)] public string Title { get; set; } = "";
    public WorkType MaintenanceType { get; set; } = WorkType.Preventive;
    public MaintenanceFrequency Frequency { get; set; } = MaintenanceFrequency.Monthly;
    public int? CustomIntervalDays { get; set; }

    [Column(TypeName = "date")] public DateTime StartDate { get; set; }
    [Column(TypeName = "date")] public DateTime? EndDate { get; set; }
    [Column(TypeName = "date")] public DateTime NextDueDate { get; set; }
    [Column(TypeName = "date")] public DateTime? LastDoneDate { get; set; }

    /// <summary>Work orders are generated this many days before the due date.</summary>
    public int LeadDays { get; set; } = 7;

    public int? ServiceProviderId { get; set; }
    public ServiceAgency? ServiceProvider { get; set; }
    public int? AMContractId { get; set; }
    public AMContract? AMContract { get; set; }
    [StringLength(150)] public string? AssignedTechnician { get; set; }

    [StringLength(2000)] public string? Checklist { get; set; }
    public decimal EstimatedCost { get; set; }
    public bool IsActive { get; set; } = true;
}

public class MaintenanceHistory : AuditableEntity
{
    public int AssetId { get; set; }
    public Asset? Asset { get; set; }
    public int? MaintenanceScheduleId { get; set; }
    public MaintenanceSchedule? MaintenanceSchedule { get; set; }
    public int? WorkOrderId { get; set; }
    public WorkOrder? WorkOrder { get; set; }

    [Column(TypeName = "date")] public DateTime PerformedOn { get; set; }
    public WorkType MaintenanceType { get; set; }
    [StringLength(150)] public string? PerformedBy { get; set; }
    public decimal Cost { get; set; }
    [StringLength(2000)] public string? Findings { get; set; }
    [Column(TypeName = "date")] public DateTime? NextDueDate { get; set; }
}
