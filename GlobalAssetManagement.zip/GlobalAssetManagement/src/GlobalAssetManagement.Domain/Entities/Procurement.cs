using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using GlobalAssetManagement.Domain.Common;
using GlobalAssetManagement.Domain.Enums;

namespace GlobalAssetManagement.Domain.Entities;

public class Vendor : AuditableEntity, IHasDisplayName, IActivatable
{
    [Required, StringLength(20), Display(Name = "Vendor Code"), GridColumn]
    public string Code { get; set; } = "";

    [Required, StringLength(200), Display(Name = "Vendor Name"), GridColumn]
    public string Name { get; set; } = "";

    [StringLength(150), Display(Name = "Contact Person"), GridColumn]
    public string? ContactPerson { get; set; }

    [StringLength(500), Multiline]
    public string? Address { get; set; }

    [StringLength(100), GridColumn]
    public string? City { get; set; }

    [StringLength(30), Phone, GridColumn]
    public string? Phone { get; set; }

    [StringLength(256), EmailAddress]
    public string? Email { get; set; }

    [StringLength(15), Display(Name = "GSTIN"), GridColumn]
    public string? Gstin { get; set; }

    [StringLength(10), Display(Name = "PAN")]
    public string? Pan { get; set; }

    [StringLength(200), Display(Name = "Payment Terms")]
    public string? PaymentTerms { get; set; }

    [StringLength(300), Display(Name = "Products / Services Supplied")]
    public string? Supplies { get; set; }

    [Range(0, 5), Display(Name = "Vendor Rating (0-5)")]
    public decimal Rating { get; set; }

    [Display(Name = "Active"), GridColumn]
    public bool IsActive { get; set; } = true;

    [NotMapped] public string DisplayName => $"{Code} - {Name}";
}

public class PurchaseRequest : AuditableEntity, IConcurrencyVersioned
{
    [Required, StringLength(30)] public string RequestNo { get; set; } = "";
    [Column(TypeName = "date")] public DateTime RequestDate { get; set; }

    public int? RequestedByEmployeeId { get; set; }
    public Employee? RequestedByEmployee { get; set; }

    public int BranchId { get; set; }
    public Branch? Branch { get; set; }
    public int? DepartmentId { get; set; }
    public Department? Department { get; set; }

    [Required, StringLength(1000)] public string Purpose { get; set; } = "";
    [Column(TypeName = "date")] public DateTime? RequiredByDate { get; set; }
    public Priority Priority { get; set; } = Priority.Normal;

    public PurchaseRequestStatus Status { get; set; } = PurchaseRequestStatus.Draft;
    public decimal EstimatedTotal { get; set; }
    [StringLength(1000)] public string? Remarks { get; set; }

    [Timestamp] public byte[]? RowVersion { get; set; }

    public List<PurchaseRequestItem> Items { get; set; } = new();
    public List<Quotation> Quotations { get; set; } = new();
}

public class PurchaseRequestItem : BaseEntity
{
    public int PurchaseRequestId { get; set; }
    public PurchaseRequest? PurchaseRequest { get; set; }

    [Required, StringLength(300)] public string Description { get; set; } = "";
    public int? CategoryId { get; set; }
    public AssetCategory? Category { get; set; }
    public decimal Quantity { get; set; } = 1;
    public decimal EstimatedUnitCost { get; set; }
    [StringLength(1000)] public string? Specifications { get; set; }

    [NotMapped] public decimal EstimatedAmount => Math.Round(Quantity * EstimatedUnitCost, 2);
}

public class Quotation : AuditableEntity
{
    public int PurchaseRequestId { get; set; }
    public PurchaseRequest? PurchaseRequest { get; set; }

    public int VendorId { get; set; }
    public Vendor? Vendor { get; set; }

    [Required, StringLength(50)] public string QuotationNo { get; set; } = "";
    [Column(TypeName = "date")] public DateTime QuotationDate { get; set; }
    [Column(TypeName = "date")] public DateTime? ValidUntil { get; set; }

    public decimal SubTotal { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal OtherCharges { get; set; }
    public decimal TotalAmount { get; set; }

    public int DeliveryDays { get; set; }
    public int WarrantyMonths { get; set; }
    [StringLength(1000)] public string? Terms { get; set; }
    public bool IsSelected { get; set; }
    [StringLength(500)] public string? SelectionReason { get; set; }
}

public class PurchaseOrder : AuditableEntity, IConcurrencyVersioned
{
    [Required, StringLength(30)] public string PONumber { get; set; } = "";
    [Column(TypeName = "date")] public DateTime PODate { get; set; }

    public int VendorId { get; set; }
    public Vendor? Vendor { get; set; }
    public int? PurchaseRequestId { get; set; }
    public PurchaseRequest? PurchaseRequest { get; set; }
    public int? QuotationId { get; set; }
    public Quotation? Quotation { get; set; }

    public int BranchId { get; set; }
    public Branch? Branch { get; set; }

    [StringLength(500)] public string? DeliveryAddress { get; set; }
    [Column(TypeName = "date")] public DateTime? ExpectedDeliveryDate { get; set; }

    public PurchaseOrderStatus Status { get; set; } = PurchaseOrderStatus.Draft;

    public decimal SubTotal { get; set; }
    public decimal TaxTotal { get; set; }
    public decimal OtherCharges { get; set; }
    public decimal GrandTotal { get; set; }

    [StringLength(2000)] public string? Terms { get; set; }
    [StringLength(1000)] public string? Remarks { get; set; }

    [Timestamp] public byte[]? RowVersion { get; set; }

    public List<PurchaseOrderItem> Items { get; set; } = new();
    public List<GoodsReceipt> Receipts { get; set; } = new();

    public void RecalculateTotals()
    {
        foreach (var i in Items) i.Recalculate();
        SubTotal = Items.Sum(i => i.Amount);
        TaxTotal = Items.Sum(i => i.TaxAmount);
        GrandTotal = Math.Round(SubTotal + TaxTotal + OtherCharges, 2);
    }
}

public class PurchaseOrderItem : BaseEntity
{
    public int PurchaseOrderId { get; set; }
    public PurchaseOrder? PurchaseOrder { get; set; }

    [Required, StringLength(300)] public string Description { get; set; } = "";
    public int? CategoryId { get; set; }
    public AssetCategory? Category { get; set; }
    public int? AssetModelId { get; set; }
    public AssetModel? AssetModel { get; set; }

    public decimal Quantity { get; set; } = 1;
    public decimal UnitPrice { get; set; }
    public decimal TaxRate { get; set; }
    public decimal Amount { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal LineTotal { get; set; }
    public decimal ReceivedQuantity { get; set; }
    public decimal RegisteredQuantity { get; set; }

    public void Recalculate()
    {
        Amount = Math.Round(Quantity * UnitPrice, 2);
        TaxAmount = Math.Round(Amount * TaxRate / 100m, 2);
        LineTotal = Amount + TaxAmount;
    }

    [NotMapped] public decimal PendingQuantity => Math.Max(0, Quantity - ReceivedQuantity);
}

public class GoodsReceipt : AuditableEntity
{
    [Required, StringLength(30)] public string GrnNumber { get; set; } = "";
    [Column(TypeName = "date")] public DateTime ReceiptDate { get; set; }

    public int PurchaseOrderId { get; set; }
    public PurchaseOrder? PurchaseOrder { get; set; }

    [StringLength(50)] public string? DeliveryChallanNo { get; set; }
    [StringLength(150)] public string? ReceivedBy { get; set; }
    [StringLength(1000)] public string? Remarks { get; set; }

    public List<GoodsReceiptItem> Items { get; set; } = new();
}

public class GoodsReceiptItem : BaseEntity
{
    public int GoodsReceiptId { get; set; }
    public GoodsReceipt? GoodsReceipt { get; set; }

    public int PurchaseOrderItemId { get; set; }
    public PurchaseOrderItem? PurchaseOrderItem { get; set; }

    public decimal QuantityReceived { get; set; }
    public decimal QuantityAccepted { get; set; }
    public decimal QuantityRejected { get; set; }
    [StringLength(500)] public string? Remarks { get; set; }
}

public class PurchaseInvoice : AuditableEntity
{
    [Required, StringLength(50)] public string InvoiceNumber { get; set; } = "";
    [Column(TypeName = "date")] public DateTime InvoiceDate { get; set; }

    public int VendorId { get; set; }
    public Vendor? Vendor { get; set; }
    public int? PurchaseOrderId { get; set; }
    public PurchaseOrder? PurchaseOrder { get; set; }
    public int? GoodsReceiptId { get; set; }
    public GoodsReceipt? GoodsReceipt { get; set; }

    public decimal SubTotal { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal FreightCharges { get; set; }
    public decimal InstallationCharges { get; set; }
    public decimal OtherCharges { get; set; }
    public decimal TotalAmount { get; set; }
    public bool GstInputCreditClaimed { get; set; } = true;

    [Column(TypeName = "date")] public DateTime? DueDate { get; set; }
    [StringLength(1000)] public string? Remarks { get; set; }

    public List<Asset> Assets { get; set; } = new();

    public void RecalculateTotal() =>
        TotalAmount = Math.Round(SubTotal + TaxAmount + FreightCharges + InstallationCharges + OtherCharges, 2);
}
