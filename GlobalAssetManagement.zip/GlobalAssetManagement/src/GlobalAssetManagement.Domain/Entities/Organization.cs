using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using GlobalAssetManagement.Domain.Common;

namespace GlobalAssetManagement.Domain.Entities;

public class Company : AuditableEntity, IHasDisplayName
{
    [Required, StringLength(200), Display(Name = "Organization Name"), GridColumn]
    public string Name { get; set; } = "";

    [StringLength(500), Multiline]
    public string? Address { get; set; }

    [StringLength(100), GridColumn]
    public string? City { get; set; }

    [StringLength(100)]
    public string? State { get; set; }

    [StringLength(10)]
    public string? Pincode { get; set; }

    [StringLength(30), Phone, GridColumn]
    public string? Phone { get; set; }

    [StringLength(256), EmailAddress]
    public string? Email { get; set; }

    [StringLength(256), Url]
    public string? Website { get; set; }

    [StringLength(15), Display(Name = "GSTIN")]
    public string? Gstin { get; set; }

    [StringLength(10), Display(Name = "PAN")]
    public string? Pan { get; set; }

    [Range(1, 12), Display(Name = "Financial Year Start Month (1-12)")]
    public int FinancialYearStartMonth { get; set; } = 4;

    [StringLength(10), Display(Name = "Currency Symbol")]
    public string CurrencySymbol { get; set; } = "₹";

    [ScaffoldColumn(false), StringLength(300)]
    public string? LogoPath { get; set; }

    [NotMapped] public string DisplayName => Name;

    public List<Branch> Branches { get; set; } = new();
}

public class Branch : AuditableEntity, IHasDisplayName, IActivatable
{
    [Lookup(typeof(Company)), Display(Name = "Company")]
    public int CompanyId { get; set; }
    public Company? Company { get; set; }

    [Required, StringLength(20), Display(Name = "Branch Code"), GridColumn]
    public string Code { get; set; } = "";

    [Required, StringLength(150), Display(Name = "Branch Name"), GridColumn]
    public string Name { get; set; } = "";

    [StringLength(500), Multiline]
    public string? Address { get; set; }

    [StringLength(100), GridColumn]
    public string? City { get; set; }

    [StringLength(30), Phone]
    public string? Phone { get; set; }

    [StringLength(256), EmailAddress]
    public string? Email { get; set; }

    [Display(Name = "Active"), GridColumn]
    public bool IsActive { get; set; } = true;

    [NotMapped] public string DisplayName => $"{Code} - {Name}";
}

public class Department : AuditableEntity, IHasDisplayName, IActivatable
{
    [Required, StringLength(20), Display(Name = "Department Code"), GridColumn]
    public string Code { get; set; } = "";

    [Required, StringLength(150), Display(Name = "Department Name"), GridColumn]
    public string Name { get; set; } = "";

    [Lookup(typeof(Branch)), Display(Name = "Branch (optional)")]
    public int? BranchId { get; set; }
    public Branch? Branch { get; set; }

    [StringLength(150), Display(Name = "Department Head")]
    public string? HeadName { get; set; }

    [StringLength(30), Display(Name = "Cost Centre")]
    public string? CostCentre { get; set; }

    [Display(Name = "Active"), GridColumn]
    public bool IsActive { get; set; } = true;

    [NotMapped] public string DisplayName => $"{Code} - {Name}";
}

/// <summary>Physical place inside a branch: building / floor / room (rack is recorded on the asset).</summary>
public class Location : AuditableEntity, IHasDisplayName, IActivatable
{
    [Lookup(typeof(Branch)), Display(Name = "Branch")]
    public int BranchId { get; set; }
    public Branch? Branch { get; set; }

    [Required, StringLength(30), Display(Name = "Location Code"), GridColumn]
    public string Code { get; set; } = "";

    [Required, StringLength(100), GridColumn]
    public string Building { get; set; } = "";

    [StringLength(50), GridColumn]
    public string? Floor { get; set; }

    [StringLength(100), Display(Name = "Room / Area"), GridColumn]
    public string? Room { get; set; }

    [StringLength(300)]
    public string? Description { get; set; }

    [Display(Name = "Active")]
    public bool IsActive { get; set; } = true;

    [NotMapped]
    public string DisplayName =>
        string.Join(" / ", new[] { Code, Building, Floor, Room }.Where(s => !string.IsNullOrWhiteSpace(s)));
}

public class Employee : AuditableEntity, IHasDisplayName, IActivatable
{
    [Required, StringLength(30), Display(Name = "Employee Code"), GridColumn]
    public string EmployeeCode { get; set; } = "";

    [Required, StringLength(150), Display(Name = "Full Name"), GridColumn]
    public string FullName { get; set; } = "";

    [StringLength(100), GridColumn]
    public string? Designation { get; set; }

    [Lookup(typeof(Department)), Display(Name = "Department")]
    public int? DepartmentId { get; set; }
    public Department? Department { get; set; }

    [Lookup(typeof(Branch)), Display(Name = "Branch")]
    public int? BranchId { get; set; }
    public Branch? Branch { get; set; }

    [StringLength(256), EmailAddress]
    public string? Email { get; set; }

    [StringLength(30), Phone, GridColumn]
    public string? Phone { get; set; }

    [ScaffoldColumn(false), StringLength(450)]
    public string? UserId { get; set; }

    [Display(Name = "Active"), GridColumn]
    public bool IsActive { get; set; } = true;

    [NotMapped] public string DisplayName => $"{EmployeeCode} - {FullName}";
}
