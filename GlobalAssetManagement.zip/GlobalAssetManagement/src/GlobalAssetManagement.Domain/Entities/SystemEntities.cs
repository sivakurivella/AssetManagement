using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using GlobalAssetManagement.Domain.Common;
using GlobalAssetManagement.Domain.Enums;

namespace GlobalAssetManagement.Domain.Entities;

/// <summary>Configurable approval limit: transactions of a module whose amount falls in range need approval by the role.</summary>
public class ApprovalRule : AuditableEntity, IActivatable
{
    [Display(Name = "Module"), GridColumn]
    public ApprovalModule Module { get; set; }

    [Range(1, 9), Display(Name = "Approval Level"), GridColumn]
    public int Level { get; set; } = 1;

    [Range(0, 999999999999), Display(Name = "Applies From Amount"), GridColumn]
    public decimal MinAmount { get; set; }

    [Range(0, 999999999999), Display(Name = "Applies Up To Amount (blank = no limit)"), GridColumn]
    public decimal? MaxAmount { get; set; }

    [Required, StringLength(100), Display(Name = "Approver Role"), GridColumn]
    public string ApproverRole { get; set; } = "";

    [Range(0, 60), Display(Name = "Escalate After (days)")]
    public int EscalateAfterDays { get; set; } = 3;

    [Display(Name = "Active"), GridColumn]
    public bool IsActive { get; set; } = true;

    public bool AppliesTo(decimal amount) => IsActive && amount >= MinAmount && (MaxAmount is null || amount <= MaxAmount);
}

public class Approval : AuditableEntity
{
    public ApprovalModule Module { get; set; }
    public int EntityId { get; set; }
    [StringLength(50)] public string? ReferenceNo { get; set; }
    public int Level { get; set; }
    [Required, StringLength(100)] public string ApproverRole { get; set; } = "";
    public decimal Amount { get; set; }

    public ApprovalStatus Status { get; set; } = ApprovalStatus.Pending;
    [StringLength(256)] public string? ActionedBy { get; set; }
    public DateTime? ActionedAt { get; set; }
    [StringLength(1000)] public string? Comments { get; set; }
    [StringLength(256)] public string? RequestedBy { get; set; }
    public DateTime RequestedAt { get; set; }
}

public class Notification : BaseEntity
{
    public AlertType AlertType { get; set; }
    public AlertSeverity Severity { get; set; } = AlertSeverity.Info;
    [Required, StringLength(200)] public string Title { get; set; } = "";
    [Required, StringLength(2000)] public string Message { get; set; } = "";

    [StringLength(60)] public string? EntityName { get; set; }
    public int? EntityId { get; set; }
    [StringLength(300)] public string? Link { get; set; }

    /// <summary>Unique key that prevents duplicate reminders (e.g. "WarrantyExpiry:Asset:12:30").</summary>
    [Required, StringLength(200)] public string DedupKey { get; set; } = "";

    [StringLength(100)] public string? TargetRole { get; set; }
    [StringLength(450)] public string? TargetUserId { get; set; }
    public int? BranchId { get; set; }

    [Column(TypeName = "date")] public DateTime? DueDate { get; set; }
    public DateTime CreatedAt { get; set; }

    public bool IsAcknowledged { get; set; }
    [StringLength(256)] public string? AcknowledgedBy { get; set; }
    public DateTime? AcknowledgedAt { get; set; }

    public bool IsEscalated { get; set; }
    public DateTime? EscalatedAt { get; set; }

    public List<NotificationLog> Logs { get; set; } = new();
}

public class NotificationLog : BaseEntity
{
    public int NotificationId { get; set; }
    public Notification? Notification { get; set; }

    public NotificationChannel Channel { get; set; }
    [Required, StringLength(256)] public string Recipient { get; set; } = "";
    public DeliveryStatus Status { get; set; } = DeliveryStatus.Pending;
    public DateTime AttemptedAt { get; set; }
    public int Attempts { get; set; }
    [StringLength(2000)] public string? Error { get; set; }
}

/// <summary>Per alert-type configuration: intervals, recipients, channels and escalation.</summary>
public class NotificationSetting : AuditableEntity
{
    [Display(Name = "Alert Type"), GridColumn]
    public AlertType AlertType { get; set; }

    [Display(Name = "Enabled"), GridColumn]
    public bool IsEnabled { get; set; } = true;

    [StringLength(100), Display(Name = "Remind Days Before (comma separated, e.g. 90,60,30,15,7)"), GridColumn]
    public string? DaysBefore { get; set; } = "90,60,30,15,7";

    [StringLength(500), Display(Name = "Recipient Roles (comma separated)"), GridColumn]
    public string? RecipientRoles { get; set; }

    [StringLength(1000), Display(Name = "Additional Email Recipients (comma separated)")]
    public string? ExtraEmails { get; set; }

    [Display(Name = "Send Email"), GridColumn]
    public bool SendEmail { get; set; }

    [Display(Name = "Send SMS")]
    public bool SendSms { get; set; }

    [Display(Name = "Send WhatsApp")]
    public bool SendWhatsApp { get; set; }

    [Range(0, 60), Display(Name = "Escalate if not acknowledged within (days, 0 = never)")]
    public int EscalateAfterDays { get; set; }

    [StringLength(100), Display(Name = "Escalate To Role")]
    public string? EscalateToRole { get; set; }
}

public class AuditLog : BaseEntity
{
    public DateTime Timestamp { get; set; }
    [StringLength(256)] public string? UserName { get; set; }
    public AuditAction Action { get; set; }
    [Required, StringLength(100)] public string EntityName { get; set; } = "";
    [StringLength(50)] public string? EntityId { get; set; }
    [StringLength(100)] public string? ReferenceNo { get; set; }
    public string? Changes { get; set; }
    [StringLength(64)] public string? IpAddress { get; set; }
}

public class LoginHistory : BaseEntity
{
    [StringLength(450)] public string? UserId { get; set; }
    [Required, StringLength(256)] public string UserName { get; set; } = "";
    public DateTime AttemptedAt { get; set; }
    public bool Succeeded { get; set; }
    [StringLength(200)] public string? FailureReason { get; set; }
    [StringLength(64)] public string? IpAddress { get; set; }
    [StringLength(500)] public string? UserAgent { get; set; }
    public DateTime? LoggedOutAt { get; set; }
}

public class ApplicationSetting : AuditableEntity
{
    [Required, StringLength(100)] public string Key { get; set; } = "";
    [StringLength(2000)] public string? Value { get; set; }
    [StringLength(50)] public string Group { get; set; } = "General";
    [StringLength(500)] public string? Description { get; set; }
}

public class RolePermission : BaseEntity
{
    [Required, StringLength(100)] public string RoleName { get; set; } = "";
    public AppModule Module { get; set; }
    public bool CanView { get; set; }
    public bool CanCreate { get; set; }
    public bool CanEdit { get; set; }
    public bool CanApprove { get; set; }
    public bool CanDelete { get; set; }
    public bool CanExport { get; set; }

    public bool Allows(PermissionAction action) => action switch
    {
        PermissionAction.View => CanView,
        PermissionAction.Create => CanCreate,
        PermissionAction.Edit => CanEdit,
        PermissionAction.Approve => CanApprove,
        PermissionAction.Delete => CanDelete,
        PermissionAction.Export => CanExport,
        _ => false
    };
}

/// <summary>Document number series, one row per prefix and scope (financial year, or "ALL" for continuous series).</summary>
public class NumberSequence : BaseEntity
{
    [Required, StringLength(20)] public string Prefix { get; set; } = "";
    [Required, StringLength(60)] public string Scope { get; set; } = "";

    [ConcurrencyCheck] public int LastNumber { get; set; }
}

public class BackupLog : BaseEntity
{
    public DateTime StartedAt { get; set; }
    public DateTime? CompletedAt { get; set; }
    [Required, StringLength(30)] public string BackupType { get; set; } = "Database";
    [StringLength(500)] public string? FilePath { get; set; }
    public long? SizeBytes { get; set; }
    public bool Succeeded { get; set; }
    [StringLength(2000)] public string? Message { get; set; }
    [StringLength(256)] public string? PerformedBy { get; set; }
}
