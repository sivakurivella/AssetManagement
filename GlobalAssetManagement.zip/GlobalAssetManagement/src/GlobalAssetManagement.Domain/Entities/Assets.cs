using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using GlobalAssetManagement.Domain.Common;
using GlobalAssetManagement.Domain.Enums;

namespace GlobalAssetManagement.Domain.Entities;

public class Asset : AuditableEntity, IHasDisplayName, IConcurrencyVersioned
{
    /// <summary>System generated unique identifier printed on labels, e.g. GAM-000123.</summary>
    [Required, StringLength(20), Display(Name = "Asset ID")]
    public string AssetTag { get; set; } = "";

    /// <summary>Organization asset code (auto-suggested, editable, unique).</summary>
    [Required, StringLength(50), Display(Name = "Asset Code")]
    public string AssetCode { get; set; } = "";

    [Required, StringLength(200), Display(Name = "Asset Name")]
    public string Name { get; set; } = "";

    [Display(Name = "Category")] public int CategoryId { get; set; }
    public AssetCategory? Category { get; set; }

    [Display(Name = "Subcategory")] public int? SubcategoryId { get; set; }
    public AssetSubcategory? Subcategory { get; set; }

    [Display(Name = "Asset Type")] public int? AssetTypeId { get; set; }
    public AssetType? AssetType { get; set; }

    [Display(Name = "Manufacturer")] public int? ManufacturerId { get; set; }
    public Manufacturer? Manufacturer { get; set; }

    [Display(Name = "Brand")] public int? BrandId { get; set; }
    public Brand? Brand { get; set; }

    [Display(Name = "Model")] public int? AssetModelId { get; set; }
    public AssetModel? AssetModel { get; set; }

    [StringLength(100), Display(Name = "Model Number")]
    public string? ModelNumber { get; set; }

    [StringLength(100), Display(Name = "Serial Number")]
    public string? SerialNumber { get; set; }

    // ---- Purchase ----
    [Column(TypeName = "date"), Display(Name = "Purchase Date")]
    public DateTime? PurchaseDate { get; set; }

    [Display(Name = "Supplier / Vendor")] public int? VendorId { get; set; }
    public Vendor? Vendor { get; set; }

    [StringLength(50), Display(Name = "Invoice Number")]
    public string? InvoiceNumber { get; set; }

    [Column(TypeName = "date"), Display(Name = "Invoice Date")]
    public DateTime? InvoiceDate { get; set; }

    public int? PurchaseOrderId { get; set; }
    public PurchaseOrder? PurchaseOrder { get; set; }
    public int? PurchaseOrderItemId { get; set; }
    public int? GoodsReceiptId { get; set; }
    public GoodsReceipt? GoodsReceipt { get; set; }
    public int? PurchaseInvoiceId { get; set; }
    public PurchaseInvoice? PurchaseInvoice { get; set; }

    [Display(Name = "Purchase Cost (excl. tax)")]
    public decimal PurchaseCost { get; set; }

    [Display(Name = "GST Rate %")]
    public decimal TaxRate { get; set; }

    [Display(Name = "GST / Tax Amount")]
    public decimal TaxAmount { get; set; }

    /// <summary>When input tax credit is claimed the tax is NOT added to the capitalized cost.</summary>
    [Display(Name = "GST Input Credit Claimed")]
    public bool GstInputCreditClaimed { get; set; } = true;

    [Display(Name = "Freight / Additional Charges")]
    public decimal AdditionalCharges { get; set; }

    [Display(Name = "Installation Charges")]
    public decimal InstallationCharges { get; set; }

    [Column(TypeName = "date"), Display(Name = "Installation Date")]
    public DateTime? InstallationDate { get; set; }

    [Column(TypeName = "date"), Display(Name = "Commissioning Date")]
    public DateTime? CommissioningDate { get; set; }

    // ---- Placement ----
    [Display(Name = "Branch")] public int BranchId { get; set; }
    public Branch? Branch { get; set; }

    [Display(Name = "Department")] public int? DepartmentId { get; set; }
    public Department? Department { get; set; }

    [Display(Name = "Location (Building / Floor / Room)")] public int? LocationId { get; set; }
    public Location? Location { get; set; }

    [StringLength(50), Display(Name = "Rack / Position")]
    public string? RackPosition { get; set; }

    [Display(Name = "Assigned Employee / Responsible Person")] public int? AssignedEmployeeId { get; set; }
    public Employee? AssignedEmployee { get; set; }

    public AssetCondition Condition { get; set; } = AssetCondition.New;
    public AssetStatus Status { get; set; } = AssetStatus.InService;

    [Display(Name = "Critical Asset (alert on downtime)")]
    public bool IsCritical { get; set; }

    // ---- Warranty (summary of the current primary warranty record) ----
    [Column(TypeName = "date"), Display(Name = "Warranty Start")]
    public DateTime? WarrantyStartDate { get; set; }

    [Column(TypeName = "date"), Display(Name = "Warranty Expiry")]
    public DateTime? WarrantyExpiryDate { get; set; }

    // ---- Valuation ----
    /// <summary>Capitalized acquisition cost (purchase + charges + non-recoverable tax).</summary>
    [Display(Name = "Original Acquisition Cost")]
    public decimal OriginalCost { get; set; }

    [Display(Name = "Capitalized Additions")]
    public decimal CapitalizedAdditions { get; set; }

    [Display(Name = "Accumulated Depreciation")]
    public decimal AccumulatedDepreciation { get; set; }

    [Display(Name = "Current Book Value")]
    public decimal CurrentBookValue { get; set; }

    [Display(Name = "Residual / Salvage Value")]
    public decimal ResidualValue { get; set; }

    [Display(Name = "Expected Useful Life (years)")]
    public decimal UsefulLifeYears { get; set; }

    [Display(Name = "Depreciation Method")]
    public DepreciationMethod DepreciationMethod { get; set; } = DepreciationMethod.StraightLine;

    [Display(Name = "Depreciation Rate % p.a.")]
    public decimal DepreciationRate { get; set; }

    [Column(TypeName = "date"), Display(Name = "Depreciation Start Date")]
    public DateTime? DepreciationStartDate { get; set; }

    /// <summary>Last date (inclusive) up to which depreciation has been posted.</summary>
    [Column(TypeName = "date"), Display(Name = "Depreciated Up To")]
    public DateTime? DepreciatedUpTo { get; set; }

    // ---- Service ----
    [Column(TypeName = "date"), Display(Name = "Last Service Date")]
    public DateTime? LastServiceDate { get; set; }

    [Column(TypeName = "date"), Display(Name = "Next Service Date")]
    public DateTime? NextServiceDate { get; set; }

    [StringLength(2000), Display(Name = "Description")]
    public string? Description { get; set; }

    [StringLength(4000), Display(Name = "Technical Specifications")]
    public string? Specifications { get; set; }

    [StringLength(1000)]
    public string? Remarks { get; set; }

    [Timestamp] public byte[]? RowVersion { get; set; }

    public List<AssetDocument> Documents { get; set; } = new();
    public List<AssetImage> Images { get; set; } = new();
    public List<AssetEvent> Events { get; set; } = new();

    [NotMapped] public decimal GrossCost => OriginalCost + CapitalizedAdditions;
    [NotMapped] public string DisplayName => $"{AssetTag} - {Name}";

    /// <summary>Capitalized acquisition cost following the GST input-credit setting.</summary>
    public static decimal ComputeCapitalizedCost(decimal purchaseCost, decimal taxAmount, bool inputCreditClaimed,
        decimal additionalCharges, decimal installationCharges)
        => Math.Round(purchaseCost + additionalCharges + installationCharges + (inputCreditClaimed ? 0 : taxAmount), 2);
}

public class AssetDocument : AuditableEntity
{
    public int AssetId { get; set; }
    public Asset? Asset { get; set; }

    public AssetDocumentType DocumentType { get; set; } = AssetDocumentType.Other;

    [Required, StringLength(260)] public string OriginalFileName { get; set; } = "";
    [Required, StringLength(260)] public string StoredFileName { get; set; } = "";
    [Required, StringLength(100)] public string ContentType { get; set; } = "";
    public long SizeBytes { get; set; }
    [StringLength(500)] public string? Description { get; set; }
}

public class AssetImage : AuditableEntity
{
    public int AssetId { get; set; }
    public Asset? Asset { get; set; }

    [Required, StringLength(260)] public string OriginalFileName { get; set; } = "";
    [Required, StringLength(260)] public string StoredFileName { get; set; } = "";
    [Required, StringLength(100)] public string ContentType { get; set; } = "";
    public long SizeBytes { get; set; }
    public bool IsPrimary { get; set; }
    [StringLength(300)] public string? Caption { get; set; }
}

/// <summary>Immutable life-cycle timeline entry for an asset.</summary>
public class AssetEvent : BaseEntity
{
    public int AssetId { get; set; }
    public Asset? Asset { get; set; }

    public DateTime EventAt { get; set; }
    public AssetEventType EventType { get; set; }

    [Required, StringLength(1000)] public string Description { get; set; } = "";
    [StringLength(50)] public string? ReferenceType { get; set; }
    public int? ReferenceId { get; set; }
    [StringLength(50)] public string? ReferenceNo { get; set; }
    [StringLength(256)] public string? UserName { get; set; }
}

/// <summary>Supporting document attached to any non-asset transaction (PO, service request, disposal...).</summary>
public class Attachment : AuditableEntity
{
    [Required, StringLength(60)] public string EntityName { get; set; } = "";
    public int EntityId { get; set; }

    [Required, StringLength(260)] public string OriginalFileName { get; set; } = "";
    [Required, StringLength(260)] public string StoredFileName { get; set; } = "";
    [Required, StringLength(100)] public string ContentType { get; set; } = "";
    public long SizeBytes { get; set; }
    [StringLength(300)] public string? Description { get; set; }
}
