using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using GlobalAssetManagement.Domain.Common;
using GlobalAssetManagement.Domain.Enums;

namespace GlobalAssetManagement.Domain.Entities;

public class AssetAllocation : AuditableEntity
{
    [Required, StringLength(30)] public string AllocationNo { get; set; } = "";

    public int AssetId { get; set; }
    public Asset? Asset { get; set; }

    public AllocationTargetType TargetType { get; set; } = AllocationTargetType.Employee;
    public int? EmployeeId { get; set; }
    public Employee? Employee { get; set; }
    public int? DepartmentId { get; set; }
    public Department? Department { get; set; }
    public int? BranchId { get; set; }
    public Branch? Branch { get; set; }
    public int? LocationId { get; set; }
    public Location? Location { get; set; }

    public DateTime IssueDate { get; set; }
    [Column(TypeName = "date")] public DateTime? ExpectedReturnDate { get; set; }
    public bool IsTemporaryLoan { get; set; }

    [StringLength(500)] public string? Purpose { get; set; }
    public AssetCondition ConditionAtIssue { get; set; } = AssetCondition.Good;
    [StringLength(500)] public string? AccessoriesIssued { get; set; }
    [StringLength(256)] public string? IssuedBy { get; set; }

    public bool IsAcknowledged { get; set; }
    public DateTime? AcknowledgedAt { get; set; }
    [StringLength(256)] public string? AcknowledgedBy { get; set; }
    [StringLength(500)] public string? AcknowledgementRemarks { get; set; }

    public AllocationStatus Status { get; set; } = AllocationStatus.Active;

    public AssetReturn? Return { get; set; }
}

public class AssetReturn : AuditableEntity
{
    public int AllocationId { get; set; }
    public AssetAllocation? Allocation { get; set; }

    public int AssetId { get; set; }
    public Asset? Asset { get; set; }

    public DateTime ReturnDate { get; set; }
    public int? ReturnedByEmployeeId { get; set; }
    public Employee? ReturnedByEmployee { get; set; }
    [StringLength(256)] public string? ReceivedBy { get; set; }
    public AssetCondition ReturnCondition { get; set; } = AssetCondition.Good;
    [StringLength(1000)] public string? Remarks { get; set; }
    public bool ReturnedLate { get; set; }
}

public class AssetTransfer : AuditableEntity
{
    [Required, StringLength(30)] public string TransferNo { get; set; } = "";

    public int AssetId { get; set; }
    public Asset? Asset { get; set; }

    public DateTime TransferDate { get; set; }
    public TransferType TransferType { get; set; }

    public int? FromEmployeeId { get; set; }
    public Employee? FromEmployee { get; set; }
    public int? ToEmployeeId { get; set; }
    public Employee? ToEmployee { get; set; }

    public int? FromDepartmentId { get; set; }
    public Department? FromDepartment { get; set; }
    public int? ToDepartmentId { get; set; }
    public Department? ToDepartment { get; set; }

    public int FromBranchId { get; set; }
    public Branch? FromBranch { get; set; }
    public int ToBranchId { get; set; }
    public Branch? ToBranch { get; set; }

    public int? FromLocationId { get; set; }
    public Location? FromLocation { get; set; }
    public int? ToLocationId { get; set; }
    public Location? ToLocation { get; set; }

    [Required, StringLength(1000)] public string Reason { get; set; } = "";
    public TransferStatus Status { get; set; } = TransferStatus.PendingApproval;
    public DateTime? CompletedAt { get; set; }
    [StringLength(256)] public string? CompletedBy { get; set; }
}

public class AssetAddition : AuditableEntity
{
    [Required, StringLength(30)] public string AdditionNo { get; set; } = "";

    public int AssetId { get; set; }
    public Asset? Asset { get; set; }

    [Column(TypeName = "date")] public DateTime AdditionDate { get; set; }
    [Required, StringLength(1000)] public string Description { get; set; } = "";

    public int? VendorId { get; set; }
    public Vendor? Vendor { get; set; }
    [StringLength(50)] public string? InvoiceNumber { get; set; }
    [Column(TypeName = "date")] public DateTime? InvoiceDate { get; set; }

    public decimal Cost { get; set; }
    public decimal TaxAmount { get; set; }
    public bool GstInputCreditClaimed { get; set; } = true;

    /// <summary>Classification by an authorized user under the organization's accounting policy.</summary>
    public ExpenditureType ExpenditureType { get; set; } = ExpenditureType.Unclassified;
    public AdditionStatus Status { get; set; } = AdditionStatus.Pending;

    [Column(TypeName = "date")] public DateTime? CapitalizationDate { get; set; }
    public decimal PreviousGrossCost { get; set; }
    public decimal RevisedGrossCost { get; set; }
    public decimal PreviousUsefulLifeYears { get; set; }
    public decimal? RevisedUsefulLifeYears { get; set; }

    [StringLength(256)] public string? ClassifiedBy { get; set; }
    [StringLength(1000)] public string? Remarks { get; set; }

    [NotMapped] public decimal CapitalizableAmount => Cost + (GstInputCreditClaimed ? 0 : TaxAmount);
}
