using GlobalAssetManagement.Domain.Entities;
using GlobalAssetManagement.Domain.Enums;

namespace GlobalAssetManagement.Domain.Logic;

public static class Roles
{
    public const string SuperAdministrator = "Super Administrator";
    public const string Administrator = "Administrator";
    public const string AssetManager = "Asset Manager";
    public const string PurchaseManager = "Purchase Manager";
    public const string DepartmentManager = "Department Manager";
    public const string MaintenanceTechnician = "Maintenance Technician";
    public const string FinanceUser = "Finance or Accounts User";
    public const string Employee = "Employee";
    public const string Auditor = "Auditor or Read-Only User";

    public static readonly string[] All =
    {
        SuperAdministrator, Administrator, AssetManager, PurchaseManager, DepartmentManager,
        MaintenanceTechnician, FinanceUser, Employee, Auditor
    };
}

public static class FinancialYear
{
    /// <summary>Returns the financial year containing <paramref name="date"/>, e.g. 2026-27 for April-start years.</summary>
    public static (DateTime Start, DateTime End, string Label) For(DateTime date, int startMonth = 4)
    {
        if (startMonth is < 1 or > 12) startMonth = 4;
        int startYear = date.Month >= startMonth ? date.Year : date.Year - 1;
        var start = new DateTime(startYear, startMonth, 1);
        var end = start.AddYears(1).AddDays(-1);
        string label = startMonth == 1 ? $"{startYear}" : $"{startYear}-{(startYear + 1) % 100:D2}";
        return (start, end, label);
    }

    public static (DateTime Start, DateTime End, string Label) FromLabel(string label, int startMonth = 4)
    {
        if (string.IsNullOrWhiteSpace(label) || label.Length < 4 || !int.TryParse(label[..4], out int y))
            throw new ArgumentException($"Invalid financial year '{label}'.");
        return For(new DateTime(y, startMonth is < 1 or > 12 ? 4 : startMonth, 1), startMonth);
    }
}

public static class DocumentNumbers
{
    public static string AssetTag(string prefix, int number) => $"{prefix}-{number:D6}";

    public static string Document(string prefix, string financialYear, int number) => $"{prefix}/{financialYear}/{number:D4}";

    public static string AssetCode(string categoryCode, string branchCode, int year, int number)
        => $"{Clean(categoryCode)}-{Clean(branchCode)}-{year}-{number:D4}";

    private static string Clean(string s) =>
        new string((s ?? "").ToUpperInvariant().Where(char.IsLetterOrDigit).ToArray()) is { Length: > 0 } c ? c : "X";
}

public static class MaintenanceScheduler
{
    /// <summary>The n-th occurrence (n = 0 is the start date). Computed from the start date to avoid month-end drift.</summary>
    public static DateTime Occurrence(DateTime start, MaintenanceFrequency frequency, int? customDays, int n)
    {
        start = start.Date;
        return frequency switch
        {
            MaintenanceFrequency.Weekly => start.AddDays(7 * n),
            MaintenanceFrequency.Fortnightly => start.AddDays(14 * n),
            MaintenanceFrequency.Monthly => start.AddMonths(n),
            MaintenanceFrequency.Quarterly => start.AddMonths(3 * n),
            MaintenanceFrequency.HalfYearly => start.AddMonths(6 * n),
            MaintenanceFrequency.Yearly => start.AddYears(n),
            MaintenanceFrequency.CustomDays => start.AddDays(Math.Max(1, customDays ?? 30) * (long)n),
            _ => throw new ArgumentOutOfRangeException(nameof(frequency))
        };
    }

    /// <summary>First occurrence strictly after <paramref name="after"/>, or null when past the schedule end date.</summary>
    public static DateTime? NextAfter(DateTime start, DateTime? end, MaintenanceFrequency frequency, int? customDays, DateTime after)
    {
        after = after.Date;
        if (start.Date > after) return end is { } e0 && start.Date > e0.Date ? null : start.Date;
        int n = EstimateIndex(start, frequency, customDays, after);
        DateTime d;
        while ((d = Occurrence(start, frequency, customDays, n)) <= after) n++;
        while (n > 0 && Occurrence(start, frequency, customDays, n - 1) > after) n--;
        d = Occurrence(start, frequency, customDays, n);
        return end is { } e && d > e.Date ? null : d;
    }

    /// <summary>All occurrences in [from, to], honouring the schedule end date.</summary>
    public static IReadOnlyList<DateTime> Occurrences(DateTime start, DateTime? end, MaintenanceFrequency frequency, int? customDays,
        DateTime from, DateTime to)
    {
        var list = new List<DateTime>();
        int n = from.Date > start.Date ? Math.Max(0, EstimateIndex(start, frequency, customDays, from.Date) - 1) : 0;
        for (int guard = 0; guard < 10000; guard++, n++)
        {
            var d = Occurrence(start, frequency, customDays, n);
            if (d > to.Date || (end is { } e && d > e.Date)) break;
            if (d >= from.Date) list.Add(d);
        }
        return list;
    }

    private static int EstimateIndex(DateTime start, MaintenanceFrequency f, int? customDays, DateTime target)
    {
        double days = (target.Date - start.Date).TotalDays;
        if (days <= 0) return 0;
        double period = f switch
        {
            MaintenanceFrequency.Weekly => 7,
            MaintenanceFrequency.Fortnightly => 14,
            MaintenanceFrequency.Monthly => 30.4375,
            MaintenanceFrequency.Quarterly => 91.3125,
            MaintenanceFrequency.HalfYearly => 182.625,
            MaintenanceFrequency.Yearly => 365.25,
            _ => Math.Max(1, customDays ?? 30)
        };
        return Math.Max(0, (int)Math.Floor(days / period) - 1);
    }
}

public static class CoverageEvaluator
{
    public static CoverageStatus Evaluate(DateTime? expiry, DateTime today, int expiringSoonDays = 30)
    {
        if (expiry is null) return CoverageStatus.None;
        int daysLeft = (expiry.Value.Date - today.Date).Days;
        if (daysLeft < 0) return CoverageStatus.Expired;
        return daysLeft <= expiringSoonDays ? CoverageStatus.ExpiringSoon : CoverageStatus.Active;
    }

    public static AmcRenewalStatus EvaluateAmc(AmcRenewalStatus current, DateTime expiry, DateTime today, int renewalWindowDays = 30)
    {
        if (current is AmcRenewalStatus.Renewed or AmcRenewalStatus.Cancelled or AmcRenewalStatus.RenewalPendingApproval)
            return current;
        int daysLeft = (expiry.Date - today.Date).Days;
        if (daysLeft < 0) return AmcRenewalStatus.Expired;
        return daysLeft <= renewalWindowDays ? AmcRenewalStatus.RenewalDue : AmcRenewalStatus.Active;
    }
}

public static class ReminderPlanner
{
    public static readonly int[] DefaultDays = { 90, 60, 30, 15, 7 };

    public static IReadOnlyList<int> ParseDays(string? csv)
    {
        var list = (csv ?? "").Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Select(s => int.TryParse(s, out int v) ? v : -1)
            .Where(v => v >= 0)
            .Distinct()
            .OrderByDescending(v => v)
            .ToList();
        return list.Count > 0 ? list : DefaultDays;
    }

    /// <summary>
    /// Reminder bucket for a due date: the smallest configured threshold that the remaining days fall within,
    /// 0 once the date has passed, or null when it is still too far away. One reminder is raised per bucket, so a
    /// daily job never sends duplicates.
    /// </summary>
    public static int? Bucket(DateTime dueDate, DateTime today, IReadOnlyCollection<int> daysBefore)
    {
        int daysLeft = (dueDate.Date - today.Date).Days;
        if (daysLeft < 0) return 0;
        int? bucket = null;
        foreach (var t in daysBefore.OrderBy(x => x))
        {
            if (daysLeft <= t) { bucket = t; break; }
        }
        return bucket;
    }

    public static string DedupKey(AlertType type, string entityName, int entityId, DateTime dueDate, int bucket)
        => $"{type}:{entityName}:{entityId}:{dueDate:yyyyMMdd}:{bucket}";
}

public sealed record ExpectedAsset(int AssetId, int? ExpectedLocationId);
public sealed record ScanRecord(int? AssetId, string Code, int? FoundLocationId);
public sealed record ReconciliationLine(int? AssetId, string? Code, bool IsExpected, VerificationResult Result,
    int? ExpectedLocationId, int? FoundLocationId);

public static class VerificationReconciler
{
    /// <param name="finalize">When true, expected assets that were never scanned are reported as Missing.</param>
    public static IReadOnlyList<ReconciliationLine> Reconcile(IEnumerable<ExpectedAsset> expected, IEnumerable<ScanRecord> scans, bool finalize)
    {
        var exp = expected.GroupBy(e => e.AssetId).ToDictionary(g => g.Key, g => g.First());
        var lastScanByAsset = new Dictionary<int, ScanRecord>();
        var unregistered = new Dictionary<string, ScanRecord>(StringComparer.OrdinalIgnoreCase);
        foreach (var s in scans)
        {
            if (s.AssetId is { } id) lastScanByAsset[id] = s;
            else if (!string.IsNullOrWhiteSpace(s.Code)) unregistered[s.Code.Trim()] = s;
        }

        var lines = new List<ReconciliationLine>();
        foreach (var e in exp.Values)
        {
            if (lastScanByAsset.TryGetValue(e.AssetId, out var s))
            {
                bool wrong = e.ExpectedLocationId is { } el && s.FoundLocationId is { } fl && el != fl;
                lines.Add(new(e.AssetId, s.Code, true, wrong ? VerificationResult.WrongLocation : VerificationResult.Found,
                    e.ExpectedLocationId, s.FoundLocationId));
            }
            else
            {
                lines.Add(new(e.AssetId, null, true, finalize ? VerificationResult.Missing : VerificationResult.Pending,
                    e.ExpectedLocationId, null));
            }
        }

        // Registered assets scanned here although they belong to another branch / department / location.
        foreach (var (assetId, s) in lastScanByAsset.Where(kv => !exp.ContainsKey(kv.Key)))
            lines.Add(new(assetId, s.Code, false, VerificationResult.WrongLocation, null, s.FoundLocationId));

        foreach (var s in unregistered.Values)
            lines.Add(new(null, s.Code.Trim(), false, VerificationResult.Unregistered, null, s.FoundLocationId));

        return lines;
    }
}

public static class RepairCostCalculator
{
    public static decimal Line(decimal quantity, decimal rate) => Math.Round(quantity * rate, 2, MidpointRounding.AwayFromZero);

    public static decimal Total(decimal labour, decimal parts, decimal travel, decimal other, decimal tax)
    {
        if (labour < 0 || parts < 0 || travel < 0 || other < 0 || tax < 0)
            throw new ArgumentException("Cost components cannot be negative.");
        return Math.Round(labour + parts + travel + other + tax, 2, MidpointRounding.AwayFromZero);
    }

    public static decimal DowntimeHours(DateTime? downSince, DateTime? restoredAt)
    {
        if (downSince is null || restoredAt is null || restoredAt < downSince) return 0m;
        return Math.Round((decimal)(restoredAt.Value - downSince.Value).TotalHours, 2);
    }
}

public static class ServiceRequestWorkflow
{
    private static readonly Dictionary<ServiceRequestStatus, ServiceRequestStatus[]> Allowed = new()
    {
        [ServiceRequestStatus.Submitted] = new[] { ServiceRequestStatus.UnderReview, ServiceRequestStatus.Approved, ServiceRequestStatus.Rejected, ServiceRequestStatus.Cancelled },
        [ServiceRequestStatus.UnderReview] = new[] { ServiceRequestStatus.Approved, ServiceRequestStatus.Rejected, ServiceRequestStatus.Cancelled },
        [ServiceRequestStatus.Approved] = new[] { ServiceRequestStatus.TechnicianAssigned, ServiceRequestStatus.Cancelled },
        [ServiceRequestStatus.TechnicianAssigned] = new[] { ServiceRequestStatus.Diagnosed, ServiceRequestStatus.InProgress, ServiceRequestStatus.Cancelled },
        [ServiceRequestStatus.Diagnosed] = new[] { ServiceRequestStatus.EstimateSubmitted, ServiceRequestStatus.AwaitingParts, ServiceRequestStatus.InProgress, ServiceRequestStatus.Cancelled },
        [ServiceRequestStatus.EstimateSubmitted] = new[] { ServiceRequestStatus.EstimateApproved, ServiceRequestStatus.Diagnosed, ServiceRequestStatus.Cancelled },
        [ServiceRequestStatus.EstimateApproved] = new[] { ServiceRequestStatus.AwaitingParts, ServiceRequestStatus.InProgress },
        [ServiceRequestStatus.AwaitingParts] = new[] { ServiceRequestStatus.InProgress },
        [ServiceRequestStatus.InProgress] = new[] { ServiceRequestStatus.AwaitingParts, ServiceRequestStatus.Testing, ServiceRequestStatus.Completed },
        [ServiceRequestStatus.Testing] = new[] { ServiceRequestStatus.InProgress, ServiceRequestStatus.Completed },
        [ServiceRequestStatus.Completed] = new[] { ServiceRequestStatus.UserConfirmed, ServiceRequestStatus.InProgress, ServiceRequestStatus.Closed },
        [ServiceRequestStatus.UserConfirmed] = new[] { ServiceRequestStatus.Closed },
        [ServiceRequestStatus.Rejected] = Array.Empty<ServiceRequestStatus>(),
        [ServiceRequestStatus.Closed] = Array.Empty<ServiceRequestStatus>(),
        [ServiceRequestStatus.Cancelled] = Array.Empty<ServiceRequestStatus>(),
    };

    public static bool CanTransition(ServiceRequestStatus from, ServiceRequestStatus to)
        => Allowed.TryGetValue(from, out var next) && next.Contains(to);

    public static IReadOnlyList<ServiceRequestStatus> NextStates(ServiceRequestStatus from)
        => Allowed.TryGetValue(from, out var next) ? next : Array.Empty<ServiceRequestStatus>();

    public static void EnsureTransition(ServiceRequestStatus from, ServiceRequestStatus to)
    {
        if (!CanTransition(from, to))
            throw new InvalidOperationException($"A service request cannot move from {from} to {to}.");
    }
}

public static class DisposalCalculator
{
    public static decimal ProfitOrLoss(decimal disposalValue, decimal bookValueAtDisposal)
        => Math.Round(disposalValue - bookValueAtDisposal, 2, MidpointRounding.AwayFromZero);

    /// <summary>Lost assets and write-offs have no proceeds.</summary>
    public static bool HasProceeds(DisposalMethod method) =>
        method is DisposalMethod.Sale or DisposalMethod.Scrap or DisposalMethod.TransferToOrganization;

    public static AssetStatus FinalAssetStatus(DisposalMethod method) =>
        method is DisposalMethod.Lost or DisposalMethod.WriteOff ? AssetStatus.LostOrWrittenOff : AssetStatus.Disposed;
}

public static class PermissionEvaluator
{
    public static bool IsAllowed(IEnumerable<string> userRoles, IEnumerable<RolePermission> permissions, AppModule module, PermissionAction action)
    {
        var roles = new HashSet<string>(userRoles, StringComparer.OrdinalIgnoreCase);
        if (roles.Contains(Roles.SuperAdministrator)) return true;
        return permissions.Any(p => p.Module == module && roles.Contains(p.RoleName) && p.Allows(action));
    }
}
