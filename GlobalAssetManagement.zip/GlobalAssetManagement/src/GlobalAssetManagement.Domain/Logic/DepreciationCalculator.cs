using GlobalAssetManagement.Domain.Enums;

namespace GlobalAssetManagement.Domain.Logic;

/// <summary>State of an asset at the start of the period being depreciated.</summary>
public sealed record DepreciationProfile(
    DepreciationMethod Method,
    decimal RatePercent,
    decimal UsefulLifeYears,
    decimal ResidualValue,
    DateTime DepreciationStartDate,
    decimal GrossCostAtStart,
    decimal AccumulatedAtStart);

/// <summary>Capitalized addition that becomes part of the depreciable base from <see cref="Date"/>.</summary>
public sealed record CapitalAddition(DateTime Date, decimal Amount, decimal? RevisedUsefulLifeYears = null);

public sealed record DepreciationResult(
    DateTime PeriodFrom,
    DateTime PeriodTo,
    int Days,
    decimal OpeningGross,
    decimal Additions,
    decimal OpeningAccumulated,
    decimal Amount)
{
    public decimal OpeningBookValue => OpeningGross - OpeningAccumulated;
    public decimal ClosingGross => OpeningGross + Additions;
    public decimal ClosingAccumulated => OpeningAccumulated + Amount;
    public decimal ClosingBookValue => ClosingGross - ClosingAccumulated;
}

/// <summary>
/// Daily pro-rata depreciation on a 365-day year basis.
/// <list type="bullet">
/// <item>Straight-line with a rate: gross cost x rate% x days/365.</item>
/// <item>Straight-line by useful life: remaining depreciable amount spread over the remaining useful life.
/// This equals classic (cost - residual) / life when there are no additions, and spreads later additions over the
/// remaining life of the asset.</item>
/// <item>Written-down value: opening book value x rate% x days/365.</item>
/// </list>
/// Depreciation never takes the book value below the residual value. All settings are supplied by configuration
/// (category defaults / asset master); no statutory rates are hard-coded here.
/// </summary>
public static class DepreciationCalculator
{
    private const decimal DaysPerYear = 365m;

    public static DepreciationResult Calculate(DepreciationProfile p, DateTime periodFrom, DateTime periodTo,
        IEnumerable<CapitalAddition>? additions = null)
    {
        periodFrom = periodFrom.Date;
        periodTo = periodTo.Date;
        if (periodTo < periodFrom) throw new ArgumentException("Period end is before period start.");

        var adds = (additions ?? Enumerable.Empty<CapitalAddition>())
            .Where(a => a.Amount != 0 && a.Date.Date <= periodTo)
            .OrderBy(a => a.Date)
            .ToList();

        decimal gross = p.GrossCostAtStart;
        decimal acc = p.AccumulatedAtStart;
        decimal life = p.UsefulLifeYears;
        decimal totalAdditions = adds.Sum(a => a.Amount);

        var from = Max(periodFrom, p.DepreciationStartDate.Date);
        if (p.Method == DepreciationMethod.None || from > periodTo)
            return new DepreciationResult(periodFrom, periodTo, 0, p.GrossCostAtStart, totalAdditions, p.AccumulatedAtStart, 0m);

        // Additions dated on or before the first depreciable day join the base immediately.
        int idx = 0;
        while (idx < adds.Count && adds[idx].Date.Date <= from)
        {
            gross += adds[idx].Amount;
            if (adds[idx].RevisedUsefulLifeYears is { } rl) life = rl;
            idx++;
        }

        decimal amount = 0m;
        int days = 0;
        var segStart = from;
        while (true)
        {
            var nextAdd = idx < adds.Count ? adds[idx].Date.Date : (DateTime?)null;
            var segEnd = nextAdd is { } d ? d.AddDays(-1) : periodTo;
            if (segEnd >= segStart)
            {
                int segDays = (segEnd - segStart).Days + 1;
                days += segDays;
                amount += Segment(p, gross, acc + amount, life, segStart, segDays);
            }
            if (nextAdd is null) break;
            gross += adds[idx].Amount;
            if (adds[idx].RevisedUsefulLifeYears is { } rl) life = rl;
            segStart = nextAdd.Value;
            idx++;
        }

        return new DepreciationResult(periodFrom, periodTo, days, p.GrossCostAtStart, totalAdditions, p.AccumulatedAtStart,
            Math.Round(amount, 2, MidpointRounding.AwayFromZero));
    }

    private static decimal Segment(DepreciationProfile p, decimal gross, decimal acc, decimal life, DateTime segStart, int segDays)
    {
        decimal depreciable = gross - acc - p.ResidualValue;
        if (depreciable <= 0 || segDays <= 0) return 0m;

        decimal fractionOfYear = segDays / DaysPerYear;
        decimal amount;
        switch (p.Method)
        {
            case DepreciationMethod.StraightLine when p.RatePercent > 0:
                amount = gross * p.RatePercent / 100m * fractionOfYear;
                break;
            case DepreciationMethod.StraightLine:
                if (life <= 0) return 0m;
                decimal elapsedYears = (segStart.Date - p.DepreciationStartDate.Date).Days / DaysPerYear;
                decimal remainingYears = life - elapsedYears;
                amount = remainingYears <= 0 ? depreciable : depreciable * fractionOfYear / remainingYears;
                break;
            case DepreciationMethod.WrittenDownValue:
                decimal rate = p.RatePercent > 0 ? p.RatePercent : WdvRateFromLife(gross, p.ResidualValue, life);
                if (rate <= 0) return 0m;
                amount = (gross - acc) * rate / 100m * fractionOfYear;
                break;
            default:
                return 0m;
        }

        amount = Math.Round(amount, 2, MidpointRounding.AwayFromZero);
        return Math.Min(amount, Math.Round(depreciable, 2, MidpointRounding.AwayFromZero));
    }

    /// <summary>WDV rate that reduces cost to residual value over the useful life: 1 - (residual/cost)^(1/life).</summary>
    public static decimal WdvRateFromLife(decimal cost, decimal residual, decimal lifeYears)
    {
        if (cost <= 0 || residual <= 0 || lifeYears <= 0 || residual >= cost) return 0m;
        double r = 1 - Math.Pow((double)(residual / cost), 1.0 / (double)lifeYears);
        return Math.Round((decimal)r * 100m, 4);
    }

    private static DateTime Max(DateTime a, DateTime b) => a > b ? a : b;
}
