# Global Asset Management

Web application for registering, tracking, maintaining, depreciating and disposing of an organization's fixed assets.
Built for **S.S. Solutions, Guntur** (https://sssolutions.co.in · siva66721@gmail.com · 98494 66721).

| | |
|---|---|
| Platform | ASP.NET Core 8 MVC (C#), Razor views |
| Database | Microsoft SQL Server 2016 or later (Express, Standard, Enterprise) via Entity Framework Core 8 |
| Security | ASP.NET Core Identity, 9 roles, permission matrix (View / Create / Edit / Approve / Delete / Export) per module |
| UI | Bootstrap 5.3, Bootstrap Icons, jQuery validation, Chart.js 4, Tom Select, html5-qrcode (all served locally from `wwwroot/lib`, no CDN) |
| Hosting | IIS on Windows Server (in-process hosting module) |

## What it does

- **Asset master** – 4 category groups (A Computers & IT, B Furniture & Office, C Plant & Machinery / Electrical, D Vehicles & Others) with 26 seeded categories, sub-categories, types, makes, brands, models; 11 lifecycle statuses; photos and documents; full event timeline.
- **Identification** – automatic Asset ID (`GAM-000001`) and Asset Code (`LAP-HO-2026-0001`), QR codes and Code 128 barcodes generated in-house, printable labels (A4 sheet of 24, or 38×25 / 50×25 / 75×50 / 100×50 mm roll labels), TSPL output for thermal printers, camera scanning in the browser (`/a/{tag}` scan URLs).
- **Procurement** – purchase request → quotations comparison (L1 check) → purchase order → goods receipt → invoice → asset registration with freight/installation apportioned by value and full traceability.
- **Multi-level approvals** – configurable rules per module and amount, lowest level first, role checks and segregation of duties (nobody approves their own request).
- **Allocation** – issue to employee / department / location, acknowledgement, temporary loans with return dates, transfers (employee, department, branch, location) and returns with condition.
- **Additions** – capital improvement (capitalized, optional revised useful life) vs. revenue expense.
- **Maintenance** – 13-step repair lifecycle (request → review → approval → technician → diagnosis → estimate → estimate approval → parts → work → testing → completion → user confirmation → closure), work orders with labour/parts/travel costs and downtime, preventive / inspection / calibration schedules that generate work orders, service providers.
- **Warranty & AMC** – warranties (manufacturer, extended, repair), AMC contracts with covered assets, visit schedules, SLA times and renewals.
- **Reminders** – 90/60/30/15/7-day (configurable) reminders for warranty, AMC, contract renewal, maintenance, inspection, calibration, returns, repairs and approvals; de-duplicated; escalation; in-app, e-mail (SMTP), SMS (HTTP gateway) and WhatsApp Cloud API channels.
- **Physical verification** – sessions by branch/department/location, QR/barcode scanning, found / wrong location / missing / unregistered reconciliation, optional GPS capture **of each scan from the browser** (this is not continuous tracking).
- **Depreciation** – Straight Line, Written Down Value and custom rate; daily pro-rata; residual value floor; preview, post, reverse; disposal catch-up. Rates and methods are configured by your accountant per category / asset – no tax rates are hard-coded.
- **Disposal** – sale, transfer, donation, scrap, lost, damaged, write-off with approval, book value and profit/loss, record lock.
- **Dashboard** – 14 KPIs and 10 charts computed from live data with branch/department/category/date filters and drill-down.
- **28 reports** – view on screen, export to Excel (.xlsx), CSV, PDF and print.
- **Administration** – users, roles & permission matrix, login history, audit trail of every data change, organization profile, settings, approval rules, backup (database + uploaded files).

## Repository layout

```
GlobalAssetManagement.sln
src/GlobalAssetManagement.Domain          entities, enums, pure business rules (depreciation, scheduling, reminders ...)
src/GlobalAssetManagement.Application     use-case services, models, QR/barcode, Excel/CSV/PDF exporters
src/GlobalAssetManagement.Infrastructure  EF Core DbContext, Identity, seeding, storage, e-mail/SMS/WhatsApp, backups, jobs
src/GlobalAssetManagement.Web             MVC controllers, Razor views, security, wwwroot
tests/GlobalAssetManagement.Tests         unit + integration tests (xUnit, EF Core InMemory, WebApplicationFactory)
database/                                 SQL scripts: create DB, login, backup, restore, SQL Agent job
build/                                    build.ps1 / build.sh (restore, build, migrations, test, publish)
docs/                                     installation, IIS, backup, user manual, API, tests, architecture
```

## Quick start (developer machine)

Requirements: Windows 10/11 or Windows Server, .NET 8 SDK, SQL Server LocalDB or SQL Server Express, internet access to nuget.org.

```powershell
git clone <your repository> GlobalAssetManagement
cd GlobalAssetManagement
powershell -ExecutionPolicy Bypass -File build\build.ps1     # restore, build, create migration, run tests, publish
dotnet run --project src\GlobalAssetManagement.Web            # Development settings use (localdb)\MSSQLLocalDB
```

Open the URL shown in the console. On first start the database is created and you are taken to **Setup** to create the first
**Super Administrator** – there are no default users or passwords. `appsettings.Development.json` turns on sample data
(`Seed:SampleData`) so the dashboard and reports have something to show; it is off in production.

## Configuration

`src/GlobalAssetManagement.Web/appsettings.json` is a template and contains **no secrets**. The connection string is the placeholder
`Server=YOUR_SQL_SERVER;...` and the application refuses to start until you replace it. For a server, copy
`appsettings.Production.sample.json` to `appsettings.Production.json` **on the server only**, or use environment variables
(`ConnectionStrings__DefaultConnection`, `Email__Password`, `WhatsApp__AccessToken`, ...). See [docs/INSTALL.md](docs/INSTALL.md).

## Documentation

| Document | Contents |
|---|---|
| [docs/INSTALL.md](docs/INSTALL.md) | prerequisites, database, configuration, first run |
| [docs/IIS_DEPLOYMENT.md](docs/IIS_DEPLOYMENT.md) | IIS site, application pool, HTTPS, permissions, updates |
| [docs/BACKUP_RESTORE.md](docs/BACKUP_RESTORE.md) | database **and uploaded-files** backup and restore |
| [docs/USER_MANUAL.md](docs/USER_MANUAL.md) | how to use every module, by role |
| [docs/API.md](docs/API.md) | JSON endpoints, scan URLs, exports |
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | layers, data model, workflows, security design |
| [docs/TEST_CASES.md](docs/TEST_CASES.md) | automated tests and manual acceptance test cases |
| [RELEASE_NOTES.md](RELEASE_NOTES.md) | version 1.0.0 |
| [DELIVERY_REPORT.md](DELIVERY_REPORT.md) | what was built, what was verified, known limitations |

## Licence of bundled libraries

Bootstrap, Bootstrap Icons, jQuery, jQuery Validation, jQuery Validation Unobtrusive, Chart.js, Tom Select (MIT) and
html5-qrcode (Apache-2.0) are included under their own licences; each folder in `wwwroot/lib` contains its LICENSE file.
