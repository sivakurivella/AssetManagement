/*  Global Asset Management - create the empty database.
    Run in SQL Server Management Studio (SSMS) or sqlcmd as a sysadmin / dbcreator.
    Tables are created afterwards by the application (EF Core migrations) or by 03_Schema.sql
    generated with build\build.ps1 (dotnet ef migrations script --idempotent).

    Edit the file paths below to match your server, or remove the ON PRIMARY / LOG ON clauses
    to use the instance default data and log folders.                                          */
USE master;
GO
IF DB_ID(N'GlobalAssetManagement') IS NULL
BEGIN
    CREATE DATABASE GlobalAssetManagement
    COLLATE SQL_Latin1_General_CP1_CI_AS;
END
GO
ALTER DATABASE GlobalAssetManagement SET RECOVERY FULL;      -- needed for point-in-time restore with log backups
ALTER DATABASE GlobalAssetManagement SET READ_COMMITTED_SNAPSHOT ON WITH ROLLBACK IMMEDIATE;  -- fewer reader/writer blocks
ALTER DATABASE GlobalAssetManagement SET AUTO_CLOSE OFF;
ALTER DATABASE GlobalAssetManagement SET PAGE_VERIFY CHECKSUM;
GO
