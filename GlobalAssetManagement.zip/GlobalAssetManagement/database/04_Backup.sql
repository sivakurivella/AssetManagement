/*  Manual / scheduled backups of the Global Asset Management database.
    IMPORTANT: this backs up the DATABASE ONLY. Uploaded invoices, photos and documents are stored
    on disk (Uploads:RootPath, default <site>\App_Data\uploads) and must be backed up separately
    (see docs\BACKUP_RESTORE.md - robocopy / file-level backup).

    The backup folder must exist on the SQL SERVER machine and the SQL Server service account
    must have write permission on it.                                                         */
DECLARE @folder nvarchar(400) = N'C:\GAMBackups\Database\';
DECLARE @stamp  nvarchar(20)  = FORMAT(SYSDATETIME(), 'yyyyMMdd_HHmmss');

-- Full backup (daily)
DECLARE @full nvarchar(500) = @folder + N'GlobalAssetManagement_FULL_' + @stamp + N'.bak';
BACKUP DATABASE GlobalAssetManagement TO DISK = @full
    WITH CHECKSUM, COMPRESSION, INIT, NAME = N'GlobalAssetManagement full backup', STATS = 10;
-- COMPRESSION is not available on SQL Server Express; remove it there.

RESTORE VERIFYONLY FROM DISK = @full WITH CHECKSUM;
GO

/*  Transaction-log backup (e.g. every 30 minutes) - requires RECOVERY FULL (set in 01_CreateDatabase.sql).
DECLARE @folder nvarchar(400) = N'C:\GAMBackups\Database\';
DECLARE @log nvarchar(500) = @folder + N'GlobalAssetManagement_LOG_' + FORMAT(SYSDATETIME(), 'yyyyMMdd_HHmmss') + N'.trn';
BACKUP LOG GlobalAssetManagement TO DISK = @log WITH CHECKSUM, COMPRESSION, INIT;
*/
