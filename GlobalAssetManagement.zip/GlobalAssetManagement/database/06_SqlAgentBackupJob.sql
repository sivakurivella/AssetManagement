/*  SQL Server Agent job: nightly full backup at 01:30 and deletion of .bak files older than 30 days.
    SQL Server Express has no SQL Agent - use Windows Task Scheduler with sqlcmd instead:
      sqlcmd -S .\SQLEXPRESS -E -i "C:\GAM\database\04_Backup.sql"
    or enable the application's built-in nightly backup (Backup:AutoBackupHour in appsettings).       */
USE msdb;
GO
IF EXISTS (SELECT 1 FROM msdb.dbo.sysjobs WHERE name = N'GAM - Nightly full backup')
    EXEC msdb.dbo.sp_delete_job @job_name = N'GAM - Nightly full backup';
GO
EXEC msdb.dbo.sp_add_job @job_name = N'GAM - Nightly full backup', @enabled = 1,
     @description = N'Full backup of GlobalAssetManagement with checksum and verification. Files backup is separate.';

EXEC msdb.dbo.sp_add_jobstep @job_name = N'GAM - Nightly full backup', @step_name = N'Full backup', @subsystem = N'TSQL',
     @database_name = N'master', @on_success_action = 3, @retry_attempts = 1, @retry_interval = 10,
     @command = N'
DECLARE @f nvarchar(500) = N''C:\GAMBackups\Database\GlobalAssetManagement_FULL_'' + FORMAT(SYSDATETIME(), ''yyyyMMdd_HHmmss'') + N''.bak'';
BACKUP DATABASE GlobalAssetManagement TO DISK = @f WITH CHECKSUM, INIT, STATS = 10;
RESTORE VERIFYONLY FROM DISK = @f WITH CHECKSUM;';

EXEC msdb.dbo.sp_add_jobstep @job_name = N'GAM - Nightly full backup', @step_name = N'Delete backups older than 30 days', @subsystem = N'TSQL',
     @database_name = N'master',
     @command = N'DECLARE @d datetime = DATEADD(DAY, -30, GETDATE());
EXEC master.dbo.xp_delete_file 0, N''C:\GAMBackups\Database\'', N''bak'', @d, 0;';

EXEC msdb.dbo.sp_add_schedule @schedule_name = N'GAM nightly 01:30', @freq_type = 4, @freq_interval = 1, @active_start_time = 013000;
EXEC msdb.dbo.sp_attach_schedule @job_name = N'GAM - Nightly full backup', @schedule_name = N'GAM nightly 01:30';
EXEC msdb.dbo.sp_add_jobserver @job_name = N'GAM - Nightly full backup', @server_name = N'(local)';
GO
