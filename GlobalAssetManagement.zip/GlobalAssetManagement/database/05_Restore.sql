/*  Restore Global Asset Management from a full backup (optionally followed by log backups).
    1. Stop the IIS site / application pool first so no user is writing data.
    2. Restore uploaded files from the matching files backup (see docs\BACKUP_RESTORE.md).
    3. Check the logical file names with RESTORE FILELISTONLY and adjust the MOVE paths.          */
USE master;
GO
DECLARE @bak nvarchar(500) = N'C:\GAMBackups\Database\GlobalAssetManagement_FULL_yyyyMMdd_HHmmss.bak';

RESTORE FILELISTONLY FROM DISK = @bak;      -- shows LogicalName values for the MOVE clauses

IF DB_ID(N'GlobalAssetManagement') IS NOT NULL
    ALTER DATABASE GlobalAssetManagement SET SINGLE_USER WITH ROLLBACK IMMEDIATE;

RESTORE DATABASE GlobalAssetManagement FROM DISK = @bak
    WITH REPLACE, CHECKSUM, STATS = 10,
    RECOVERY;   -- use NORECOVERY instead if you will apply log backups next
    -- , MOVE N'GlobalAssetManagement'     TO N'D:\SQLData\GlobalAssetManagement.mdf'
    -- , MOVE N'GlobalAssetManagement_log' TO N'E:\SQLLogs\GlobalAssetManagement_log.ldf'

/*  Point-in-time: after RESTORE DATABASE ... NORECOVERY apply each log backup in order:
RESTORE LOG GlobalAssetManagement FROM DISK = N'C:\GAMBackups\Database\GlobalAssetManagement_LOG_....trn' WITH NORECOVERY;
RESTORE LOG GlobalAssetManagement FROM DISK = N'...last.trn' WITH STOPAT = '2026-10-25T14:30:00', RECOVERY;
*/

ALTER DATABASE GlobalAssetManagement SET MULTI_USER;
GO
-- Re-map the application user if the backup came from another server (orphaned SQL login, option B only):
-- USE GlobalAssetManagement; ALTER USER gam_app_user WITH LOGIN = gam_app;
