/*  Grants the IIS application pool identity (Windows authentication, recommended)
    or a SQL login access to the Global Asset Management database.

    OPTION A - Windows authentication (recommended for IIS on the same domain / server)
      Replace GamAppPool with the IIS application pool name. For a remote SQL Server use the
      web server's computer account instead: [DOMAIN\WEBSERVER$].

    OPTION B - SQL authentication
      Uncomment option B, choose a strong password at deployment time and put it ONLY in the
      server's appsettings.Production.json or environment variable. Never commit it.        */
USE master;
GO
-- OPTION A
IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = N'IIS APPPOOL\GamAppPool')
    CREATE LOGIN [IIS APPPOOL\GamAppPool] FROM WINDOWS WITH DEFAULT_DATABASE = GlobalAssetManagement;
GO
-- OPTION B
-- IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = N'gam_app')
--     CREATE LOGIN gam_app WITH PASSWORD = N'<set-a-strong-password-at-deployment>', CHECK_POLICY = ON, DEFAULT_DATABASE = GlobalAssetManagement;
-- GO

USE GlobalAssetManagement;
GO
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = N'gam_app_user')
    CREATE USER gam_app_user FOR LOGIN [IIS APPPOOL\GamAppPool];   -- OPTION B: FOR LOGIN gam_app
GO
-- Day-to-day access for the application.
ALTER ROLE db_datareader ADD MEMBER gam_app_user;
ALTER ROLE db_datawriter ADD MEMBER gam_app_user;
-- Needed only if the application applies its own migrations at start-up (first install / upgrades).
-- After installation you may remove db_ddladmin and apply future upgrades with the generated SQL script instead.
ALTER ROLE db_ddladmin ADD MEMBER gam_app_user;
GO
-- Needed only for the in-application "Backup Now" button (BACKUP DATABASE).
ALTER ROLE db_backupoperator ADD MEMBER gam_app_user;
GO
